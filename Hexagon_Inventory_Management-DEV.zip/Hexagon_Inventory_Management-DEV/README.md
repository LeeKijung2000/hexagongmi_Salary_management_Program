# 헥사곤_재고관리

<img width="1572" height="827" alt="image" src="https://github.com/user-attachments/assets/68292c50-b08c-4046-8a63-6ab1b43e9945" />

