package org.zerock.domain;

// import java.sql.Date;  <-- 삭제
import java.util.Date;    // <-- 이것으로 변경!

import lombok.Data;

@Data
public class BoardVO {
    private Long bno;
    private String title;
    private String content;
    private String writer;
    private Date regdate;
    private Date updateDate;
}