package org.zerock.domain;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Data
public class Ticket {
	private int tno;
	private String owner;
	private String grade;
	
	
}


