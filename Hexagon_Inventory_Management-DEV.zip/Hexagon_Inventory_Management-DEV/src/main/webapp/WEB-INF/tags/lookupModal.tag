<%-- 거래처, 창고, 담당자, 품목 공통 조회 창. 각 화면 이미지에 있는 컬럼만 표에 그린다. --%>
<%-- 取引先、倉庫、担当者、品目の共通照会画面。各画面イメージにある列だけ表に描く。 --%>
<%@ tag language="java" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>

<div class="modal-overlay" id="commonLookupOverlay">
    <div class="lookup-card">
        <div class="lookup-head">
            <h3 id="commonLookupTitle">照会<%--조회--%></h3>
            <div class="lookup-tools">
                <label id="commonLookupUnusedWrap"><input type="checkbox" id="commonLookupUnused"> 使用中止を含む<%--사용중단포함--%></label>
                <input type="text" id="commonLookupKeyword" placeholder="入力後Enter<%--입력 후 Enter--%>">
                <button type="button" class="btn-primary-sm" id="commonLookupSearch">検索<%--검색--%></button>
            </div>
            <button type="button" class="modal-close" id="commonLookupClose"><i class="mdi mdi-close"></i></button>
        </div>
        <div class="lookup-table-wrap">
            <table class="list-table" id="commonLookupTable">
                <thead id="commonLookupHead"></thead>
                <tbody id="commonLookupBody"></tbody>
            </table>
        </div>
        <div class="lookup-foot">
            <button type="button" class="btn-primary-sm" id="commonLookupApply" style="display:none;">選択<%--선택--%></button>
            <button type="button" class="btn-flat-sm" id="commonLookupNew">新規<%--신규--%></button>
            <button type="button" class="btn-flat-sm" id="commonLookupCancel">閉じる<%--닫기--%></button>
        </div>
    </div>
</div>

<%-- 신규는 기초등록의 신규 입력 화면을 이 모달 안에 띄운다. --%>
<%-- 新規は基礎登録の新規入力画面をこのモーダル内に出す。 --%>
<div class="modal-overlay" id="lookupCreateOverlay">
    <div class="lookup-card lookup-create-frame-card">
        <iframe id="lookupCreateFrame" title="新規登録"></iframe>
    </div>
</div>

<style>
    .modal-overlay{display:none;position:fixed;inset:0;background:rgba(11,16,38,.45);align-items:flex-start;justify-content:center;padding:6vh 20px;z-index:1200;overflow-y:auto}
    .modal-overlay.active{display:flex}
    .lookup-card{background:#fff;border-radius:14px;border:1px solid #e2e8f0;box-shadow:0 20px 45px -10px rgba(11,16,38,.25);width:min(920px,96vw);overflow:hidden}
    .lookup-head{display:flex;align-items:center;gap:12px;padding:16px 18px;border-bottom:1px solid #e2e8f0}
    .lookup-head h3{font-size:1.05rem;font-weight:800;color:#0B1026;margin-right:auto}
    .lookup-tools{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
    .lookup-tools input[type=text]{border:1px solid #e2e8f0;border-radius:8px;padding:8px 12px;font-size:13px;width:180px;outline:none}
    .lookup-tools input[type=text]:focus{border-color:#4B88FF}
    .lookup-tools label{font-size:12px;color:#64748b;display:inline-flex;align-items:center;gap:4px}
    .modal-close{border:none;background:#f1f5f9;color:#64748b;width:32px;height:32px;border-radius:50%;cursor:pointer}
    .btn-primary-sm,.btn-flat-sm{display:inline-flex;align-items:center;justify-content:center;cursor:pointer;border-radius:8px;font-weight:700;font-size:13px;padding:8px 14px}
    .btn-primary-sm{background:#4B88FF;color:#fff;border:none}
    .btn-flat-sm{background:#f8fafc;border:1px solid #e2e8f0;color:#64748b}
    .lookup-table-wrap{max-height:420px;overflow:auto}
    .lookup-card .list-table{width:100%;border-collapse:collapse}
    .lookup-card .list-table th,.lookup-card .list-table td{border-bottom:1px solid #e2e8f0;padding:9px 12px;font-size:13px;text-align:left}
    .lookup-card .list-table th{background:#f8fafc;color:#64748b;position:sticky;top:0}
    .lookup-card .list-table tbody tr{cursor:pointer}
    .lookup-card .list-table tbody tr:hover{background:#f7faff}
    .lookup-card .col-num{text-align:right}
    .lookup-link{color:#1F3C88;font-weight:700}
    .lookup-foot{display:flex;gap:8px;padding:14px 18px}
    .lookup-empty{text-align:center;color:#64748b;padding:24px}
    #lookupCreateOverlay{z-index:1400}
    .lookup-create-frame-card{width:min(1080px,96vw);height:min(860px,90vh);background:#fff;overflow:hidden}
    #lookupCreateFrame{width:100%;height:100%;border:0;background:#fff}
</style>

<script>
(function () {
    var ctx = '${pageContext.request.contextPath}';
    var overlay = document.getElementById('commonLookupOverlay');
    var title = document.getElementById('commonLookupTitle');
    var keyword = document.getElementById('commonLookupKeyword');
    var unusedWrap = document.getElementById('commonLookupUnusedWrap');
    var unused = document.getElementById('commonLookupUnused');
    var head = document.getElementById('commonLookupHead');
    var body = document.getElementById('commonLookupBody');
    var applyBtn = document.getElementById('commonLookupApply');
    var current = null;
    var rows = [];

    // 신규는 기초등록 화면을 모달로 연다. 등록이 끝나면 그 항목을 판매입력에 넣고 조회 모달을 닫는다.
    // 新規は基礎登録画面をモーダルで開く。登録が終わるとその項目を販売入力に入れ、照会モーダルを閉じる。
    var kinds = {
        partner: {
            title: '取引先検索<%--거래처검색--%>',
            url: '/partners',
            create: true,
            unused: true,
            headers: ['取引先コード<%--거래처코드--%>', '取引先名<%--거래처명--%>', '検索窓内容<%--검색창내용--%>', '詳細内容<%--상세내역--%>'],
            render: function (row) {
                return [link(row.businessPartnerCode), link(row.businessPartnerName), text(row.searchContent), '内容<%--내역--%>'];
            }
        },
        warehouse: {
            title: '倉庫検索<%--창고검색--%>',
            url: '/warehouses',
            create: true,
            unused: true,
            headers: ['区分<%--구분--%>', '倉庫コード<%--창고코드--%>', '倉庫名<%--창고명--%>'],
            render: function (row) {
                return [text(row.warehouseDivName), link(row.warehouseCode), link(row.warehouseName)];
            }
        },
        manager: {
            title: '社員検索<%--사원검색--%>',
            url: '/managers',
            create: true,
            unused: false,
            headers: ['社員コード<%--사원코드--%>', '社員名<%--사원명--%>'],
            render: function (row) {
                return [link(row.employeeCode), link(row.employeeName)];
            }
        },
        item: {
            title: '品目検索<%--품목검색--%>',
            url: '/items',
            create: true,
            unused: false,
            multi: true,
            headers: ['選択<%--선택--%>', '品目コード<%--품목코드--%>', '品目名<%--품목명--%>', '検索窓内容<%--검색창내용--%>', '規格<%--규격--%>', '全体在庫<%--전체재고--%>'],
            render: function (row) {
                var name = row.itemName || '';
                if (row.spec) name += ' [' + row.spec + ']';
                return ['__check__', link(row.itemCode), text(name), text(row.searchContent), text(row.spec), num(row.qty)];
            }
        }
    };

    function text(value) { return value == null ? '' : String(value); }
    function link(value) { return '<span class="lookup-link">' + escapeHtml(text(value)) + '</span>'; }
    function num(value) {
        var n = Number(value || 0);
        return '<span class="col-num">' + n.toLocaleString() + '</span>';
    }
    function escapeHtml(value) {
        return value.replace(/[&<>"]/g, function (ch) {
            return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'})[ch];
        });
    }

    function closeLookup() {
        overlay.classList.remove('active');
        current = null;
        rows = [];
        if (createOverlay)
            createOverlay.classList.remove('active');
    }

    function search() {
        if (!current) return;
        var url = ctx + current.url + '?keyword=' + encodeURIComponent(keyword.value || '');
        if (current.unused) url += '&includeUnused=' + unused.checked;
        fetch(url, {headers: {'Accept': 'application/json'}})
            .then(function (res) { return res.json(); })
            .then(function (list) {
                rows = list || [];
                draw();
            });
    }

    function draw() {
        head.innerHTML = '<tr>' + current.headers.map(function (name) {
            return '<th>' + name + '</th>';
        }).join('') + '</tr>';
        if (!rows.length) {
            body.innerHTML = '<tr><td class="lookup-empty" colspan="' + current.headers.length + '">照会されたデータがありません。<%--조회된 데이터가 없습니다.--%></td></tr>';
            return;
        }
        body.innerHTML = rows.map(function (row, index) {
            var cells = current.render(row).map(function (cell) {
                if (cell === '__check__') {
                    return '<td><input type="checkbox" class="lookup-check" data-index="' + index + '"></td>';
                }
                var align = String(cell).indexOf('col-num') >= 0 ? ' class="col-num"' : '';
                return '<td' + align + '>' + cell + '</td>';
            }).join('');
            return '<tr data-index="' + index + '">' + cells + '</tr>';
        }).join('');
    }

    function choose(row) {
        if (current && typeof current.onSelect === 'function') current.onSelect(row);
        closeLookup();
    }

    body.addEventListener('click', function (event) {
        if (event.target.classList.contains('lookup-check')) return;
        var tr = event.target.closest('tr');
        if (!tr || tr.dataset.index == null || !rows[tr.dataset.index]) return;
        if (current.multi) {
            var box = tr.querySelector('.lookup-check');
            if (box && event.target !== box) box.checked = !box.checked;
            return;
        }
        choose(rows[tr.dataset.index]);
    });

    document.getElementById('commonLookupSearch').addEventListener('click', search);
    keyword.addEventListener('keydown', function (event) {
        if (event.key === 'Enter') {
            event.preventDefault();
            search();
        }
    });
    document.getElementById('commonLookupClose').addEventListener('click', closeLookup);
    document.getElementById('commonLookupCancel').addEventListener('click', closeLookup);
    document.getElementById('commonLookupNew').addEventListener('click', function () {
        if (current)
            openLookupCreate();
    });
    applyBtn.addEventListener('click', function () {
        var selected = [];
        body.querySelectorAll('.lookup-check:checked').forEach(function (box) {
            selected.push(rows[box.dataset.index]);
        });
        if (current && typeof current.onSelect === 'function') current.onSelect(selected);
        closeLookup();
    });

    window.CommonLookup = {
        open: function (type, onSelect, keywordText) {
            var kind = kinds[type];
            if (!kind) return;
            current = {type: type, url: kind.url, create: kind.create, unused: kind.unused, multi: kind.multi, headers: kind.headers, render: kind.render, onSelect: onSelect};
            document.getElementById('commonLookupNew').style.display = kind.create ? 'inline-flex' : 'none';
            title.textContent = kind.title;
            unusedWrap.style.display = kind.unused ? 'inline-flex' : 'none';
            unused.checked = false;
            applyBtn.style.display = kind.multi ? 'inline-flex' : 'none';
            keyword.value = keywordText || '';
            overlay.classList.add('active');
            search();
            keyword.focus();
        }
    };

    var createOverlay = document.getElementById('lookupCreateOverlay');
    var createFrame = document.getElementById('lookupCreateFrame');
    var createPages = {
        partner: '/base/account?embed=1',
        warehouse: '/base/warehouse?embed=1',
        item: '/base/item?embed=1',
        manager: '/base/account?embed=1&target=manager'
    };

    function sameLookupText(value, keyword) {
        return String(value == null ? '' : value).trim() === keyword;
    }
    function closeLookupCreate() {
        createOverlay.classList.remove('active');
        createFrame.src = 'about:blank';
    }
    function openLookupCreate() {
        if (!current || !current.create || !createPages[current.type]) return;
        createFrame.src = ctx + createPages[current.type];
        createOverlay.classList.add('active');
    }
    function applyCreated(type, code, name) {
        var select = current ? current.onSelect : null;
        var multi = current ? current.multi : false;
        findCreated(type, code, name).then(function (row) {
            closeLookupCreate();
            if (!current) return;
            if (!row) {
                alert('登録されましたが販売入力に入れませんでした。検索から再度選択してください。');
                search();
                return;
            }
            if (typeof select === 'function')
                select(multi ? [row] : row);
            closeLookup();
        }).catch(function () {
            closeLookupCreate();
            alert('登録されましたが販売入力に入れませんでした。検索から再度選択してください。');
            if (current) search();
        });
    }
    window.addEventListener('message', function (event) {
        if (event.origin !== window.location.origin) return;
        var data = event.data;
        if (!data || data.type !== 'base-register' || !current) return;
        if (data.action === 'close') {
            closeLookupCreate();
            return;
        }
        if (data.action === 'saved')
            applyCreated(current.type, data.code || '', data.name || '');
    });
    createOverlay.addEventListener('click', function (event) {
        if (event.target === createOverlay) closeLookupCreate();
    });
    function findCreated(type, code, name) {
        var kind = kinds[type];
        var key = code || name;
        var url = ctx + kind.url + '?keyword=' + encodeURIComponent(key);
        return fetch(url, {headers: {'Accept': 'application/json'}})
            .then(function (res) { return res.json(); })
            .then(function (list) {
                var listRows = list || [];
                var byCode = listRows.filter(function (row) {
                    if (type === 'partner') return code && sameLookupText(row.businessPartnerCode, code);
                    if (type === 'manager') return code && sameLookupText(row.employeeCode, code);
                    if (type === 'warehouse') return code && sameLookupText(row.warehouseCode, code);
                    return code && sameLookupText(row.itemCode, code);
                });
                if (byCode.length) return byCode[0];
                var byName = listRows.filter(function (row) {
                    if (type === 'partner') return sameLookupText(row.businessPartnerName, name);
                    if (type === 'manager') return sameLookupText(row.employeeName, name);
                    if (type === 'warehouse') return sameLookupText(row.warehouseName, name);
                    return sameLookupText(row.itemName, name);
                });
                return byName.length ? byName[0] : null;
            });
    }
})();
</script>
