<%@ tag language="java" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ attribute name="embed" required="false" %>

<c:if test="${embed != '1'}">
<nav class="erp-sidebar">
    <div class="sidebar-header">
        <i class="mdi mdi-hexagon-multiple logo-icon"></i>
        <h2>ヘキサゴン ERP</h2>
    </div>
    <ul class="menu-list">
        <li class="menu-category">サービス管理</li>
        <li><a href="${pageContext.request.contextPath}/"><i class="mdi mdi-view-dashboard menu-icon"></i>メイン</a></li>
        
        <li class="menu-category">基本登録</li>
        <li><a href="${pageContext.request.contextPath}/base/account"><i class="mdi mdi-domain menu-icon"></i>取引先登録</a></li>
        <li><a href="${pageContext.request.contextPath}/base/warehouse"><i class="mdi mdi-warehouse menu-icon"></i>倉庫登録</a></li>
        <li><a href="${pageContext.request.contextPath}/base/item"><i class="mdi mdi-package-variant menu-icon"></i>品目登録</a></li>

        <li class="menu-category">営業管理：見積書</li>
        <li><a href="${pageContext.request.contextPath}/sales/estimate/inquiry"><i class="mdi mdi-file-search menu-icon"></i>見積書照会</a></li>
        <li><a href="${pageContext.request.contextPath}/sales/estimate/input"><i class="mdi mdi-file-document-edit menu-icon"></i>見積書入力</a></li>
        <li><a href="${pageContext.request.contextPath}/sales/estimate/status"><i class="mdi mdi-chart-box menu-icon"></i>見積書一覧</a></li>
        <li><a href="${pageContext.request.contextPath}/sales/estimate/unorder"><i class="mdi mdi-alert-circle-outline menu-icon"></i>未受注一覧</a></li>

        <li class="menu-category">営業管理：受注書</li>
        <li><a href="${pageContext.request.contextPath}/sales/order/inquiry"><i class="mdi mdi-clipboard-search menu-icon"></i>受注書照会</a></li>
        <li><a href="${pageContext.request.contextPath}/sales/order/input"><i class="mdi mdi-clipboard-edit menu-icon"></i>受注書入力</a></li>
        <li><a href="${pageContext.request.contextPath}/sales/order/status"><i class="mdi mdi-clipboard-text menu-icon"></i>受注書一覧</a></li>
        <li><a href="${pageContext.request.contextPath}/sales/order/release-proc"><i class="mdi mdi-truck-check menu-icon"></i>受注書出荷処理</a></li>
        <li><a href="${pageContext.request.contextPath}/sales/order/unsold"><i class="mdi mdi-basket-off menu-icon"></i>未販売一覧</a></li>

        <li class="menu-category">営業管理：販売</li>
        <li><a href="${pageContext.request.contextPath}/sales/sale/inquiry"><i class="mdi mdi-cash-register menu-icon"></i>販売照会</a></li>
        <li><a href="${pageContext.request.contextPath}/sales/sale/input"><i class="mdi mdi-cart-plus menu-icon"></i>販売入力</a></li>
        <li><a href="${pageContext.request.contextPath}/sales/sale/input2"><i class="mdi mdi-cart-arrow-right menu-icon"></i>販売入力II</a></li>
        <li><a href="${pageContext.request.contextPath}/sales/sale/change-price"><i class="mdi mdi-tag-refresh menu-icon"></i>販売単価一括変更</a></li>
        <li><a href="${pageContext.request.contextPath}/sales/sale/status"><i class="mdi mdi-poll menu-icon"></i>販売一覧</a></li>
        <li><a href="${pageContext.request.contextPath}/sales/sale/payment-inquiry"><i class="mdi mdi-credit-card-search menu-icon"></i>決済履歴照会</a></li>
        <li><a href="${pageContext.request.contextPath}/sales/sale/payment-compare"><i class="mdi mdi-compare menu-icon"></i>決済履歴データ比較</a></li>

        <li class="menu-category">営業管理：出荷</li>
        <li><a href="${pageContext.request.contextPath}/sales/ship-order/inquiry"><i class="mdi mdi-clipboard-list menu-icon"></i>出荷指示書照会</a></li>
        <li><a href="${pageContext.request.contextPath}/sales/ship-order/input"><i class="mdi mdi-file-plus menu-icon"></i>出荷指示書入力</a></li>
        <li><a href="${pageContext.request.contextPath}/sales/ship-order/status"><i class="mdi mdi-chart-line menu-icon"></i>出荷指示書一覧</a></li>
        <li><a href="${pageContext.request.contextPath}/sales/ship/inquiry"><i class="mdi mdi-truck-delivery menu-icon"></i>出荷照会</a></li>
        <li><a href="${pageContext.request.contextPath}/sales/ship/input"><i class="mdi mdi-truck-fast menu-icon"></i>出荷入力</a></li>
    </ul>
</nav>
</c:if>

<c:if test="${embed != '1'}">
<script>
(function () {
    // 현재 브라우저 URL과 메뉴 링크를 비교해 현재 페이지 메뉴에 active를 적용합니다.
    function updateActiveMenu() {
        var currentPath = window.location.pathname.replace(/\/+$/, '') || '/';
        var links = document.querySelectorAll('.erp-sidebar .menu-list a[href]');

        links.forEach(function (link) {
            var linkPath;
            try {
                linkPath = new URL(link.href, window.location.origin).pathname.replace(/\/+$/, '') || '/';
            } catch (e) {
                return;
            }
            var isActive = linkPath === currentPath;
            link.classList.toggle('active', isActive);
            if (isActive) {
                link.setAttribute('aria-current', 'page');
            } else {
                link.removeAttribute('aria-current');
            }
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', updateActiveMenu);
    } else {
        updateActiveMenu();
    }
})();
</script>
</c:if>

<style>
    /* --- 統合ERP全体レイアウトおよびサイドバースタイル --- */
    :root {
        --color-dark: #0B1026;      
        --color-navy: #1F3C88;      
        --color-blue: #4B88FF;      
        --color-skyblue: #9AD7FF;   
        --color-cream: #FFE8D6;     
        --bg-main: #f4f7fc;         
        --sidebar-bg: #0B1026;      
        --card-bg: #ffffff;         
        --text-main: #0B1026;       
        --text-sub: #64748b;        
        --border-color: #e2e8f0;    
        --shadow-soft: 0 10px 25px -5px rgba(75, 136, 255, 0.08), 0 8px 10px -6px rgba(11, 16, 38, 0.05);
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
        font-family: 'Pretendard', -apple-system, BlinkMacSystemFont, system-ui, Roboto, sans-serif;
        background-color: var(--bg-main);
        color: var(--text-main);
        height: 100vh;
        overflow: hidden;
        font-size: 14px;
        line-height: 1.5;
    }

    a { text-decoration: none; color: inherit; }
    ul { list-style: none; }

    /* 画面全体を左右に配置する主要ラッパー（自動適用） */
    .erp-wrapper {
        display: flex;
        height: 100vh;
    }

    /* サイドバーのスタイル（幅335px、太字フォント） */
    .erp-sidebar {
        width: 335px !important;
        background-color: var(--sidebar-bg);
        color: #94a3b8;
        display: flex;
        flex-direction: column;
        flex-shrink: 0;
        border-right: 1px solid rgba(154, 215, 255, 0.1);
        height: 100vh;
    }

    .sidebar-header {
        padding: 20px;
        background-color: #070a1a;
        display: flex;
        align-items: center;
        gap: 12px;
        border-bottom: 1px solid rgba(154, 215, 255, 0.1);
    }

    .logo-icon { font-size: 26px; color: var(--color-skyblue); }
    .sidebar-header h2 { font-size: 1.15rem; color: #ffffff; font-weight: 700; }

    .menu-list {
        padding: 12px 14px;
        overflow-y: auto;
        flex: 1;
    }

    .menu-list::-webkit-scrollbar { width: 5px; }
    .menu-list::-webkit-scrollbar-thumb { background-color: var(--color-navy); border-radius: 3px; }

    .menu-category {
        font-size: 0.8rem !important;
        color: var(--color-skyblue);
        margin: 16px 10px 6px;
        font-weight: 800 !important;
        text-transform: uppercase;
        letter-spacing: 0.7px;
        border-bottom: 1px solid rgba(154, 215, 255, 0.15);
        padding-bottom: 3px;
    }

    .menu-list li a {
        display: flex;
        align-items: center;
        padding: 10px 14px !important;
        margin-bottom: 2px;
        border-radius: 6px;
        gap: 10px;
        color: #cbd5e1;
        font-size: 14px !important;
        font-weight: 600 !important;
        letter-spacing: -0.2px;
        transition: all 0.15s ease;
    }

    .menu-list li a:hover {
        background-color: rgba(75, 136, 255, 0.15);
        color: var(--color-skyblue);
    }

    .menu-list li a.active {
        background-color: var(--color-blue);
        color: #ffffff;
        font-weight: 700 !important;
    }
    
    .menu-icon { font-size: 19px !important; }

    /* 右側のメインコンテンツ領域を自動整列する共通スタイル */
    .erp-main {
        flex: 1;
        display: flex;
        flex-direction: column;
        overflow: hidden;
        background-color: var(--bg-main);
    }

    .erp-content {
        flex: 1;
        padding: 30px;
        overflow-y: auto;
    }

    /* 전표불러오기 모달. 사이드바 없이 목록만 채운다. */
    body.list-embed { overflow: auto; }
    body.list-embed .erp-sidebar { display: none !important; }
    body.list-embed .erp-main { width: 100%; }
</style>