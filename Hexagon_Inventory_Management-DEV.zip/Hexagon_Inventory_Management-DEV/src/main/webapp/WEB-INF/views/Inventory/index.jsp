<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="my" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="ja">
<head>  
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hexagon ERPダッシュボード</title>
    <!-- Material Design Icons CDN -->
    <link href="https://cdn.jsdelivr.net/npm/@mdi/font@7.2.96/css/materialdesignicons.min.css" rel="stylesheet">
    
    <style>
        /* --- 메인(대시보드) 전용 꾸미기 스타일 --- */
        .welcome-banner {
            background: linear-gradient(135deg, #0B1026 0%, #1F3C88 100%);
            border-radius: 16px; padding: 35px 40px; color: #ffffff; margin-bottom: 25px;
            position: relative; overflow: hidden; box-shadow: 0 10px 25px -5px rgba(75, 136, 255, 0.08);
        }
        .welcome-banner::after {
            content: ""; position: absolute; right: -20px; bottom: -30px; width: 200px; height: 200px;
            background: rgba(154, 215, 255, 0.07); border-radius: 50%;
        }
        .welcome-badge {
            display: inline-block; background-color: rgba(154, 215, 255, 0.2);
            color: #9AD7FF; padding: 5px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; margin-bottom: 12px;
        }
        .welcome-banner h2 { font-size: 1.7rem; font-weight: 700; margin-bottom: 10px; }
        .welcome-banner p { color: #cbd5e1; font-size: 0.95rem; max-width: 650px; }

        .dashboard-grid { display: grid; grid-template-columns: 2fr 1fr; gap: 24px; }
        @media (max-width: 1200px) { .dashboard-grid { grid-template-columns: 1fr; } }

        .section-title {
            font-size: 1.05rem; font-weight: 700; color: #0B1026;
            margin-bottom: 15px; display: flex; align-items: center; gap: 8px;
        }
        .section-title i { color: #4B88FF; }

        .quick-menu-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin-bottom: 25px; }
        .quick-card {
            background-color: #ffffff; border: 1px solid #e2e8f0;
            border-radius: 12px; padding: 20px; text-align: center; transition: all 0.2s ease; box-shadow: 0 10px 25px -5px rgba(75, 136, 255, 0.08);
        }
        .quick-card:hover { transform: translateY(-3px); border-color: #4B88FF; background-color: rgba(75, 136, 255, 0.02); }
        .quick-icon {
            width: 45px; height: 45px; margin: 0 auto 12px; border-radius: 10px;
            background-color: rgba(75, 136, 255, 0.1); color: #4B88FF;
            display: flex; align-items: center; justify-content: center; font-size: 22px;
        }
        .quick-card h4 { font-size: 0.95rem; font-weight: 700; color: #0B1026; margin-bottom: 4px; }
        .quick-card p { font-size: 0.8rem; color: #64748b; }

        .notice-box {
            background-color: #ffffff; border: 1px solid #e2e8f0;
            border-radius: 12px; padding: 20px; box-shadow: 0 10px 25px -5px rgba(75, 136, 255, 0.08);
        }
        .notice-item { display: flex; align-items: center; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #e2e8f0; }
        .notice-item:last-child { border-bottom: none; }
        .notice-title { display: flex; align-items: center; gap: 8px; color: #0B1026; font-weight: 500; }
        .notice-title i { color: #4B88FF; }
        .notice-date { font-size: 0.8rem; color: #64748b; }

        .team-card {
            background-color: #ffffff; border-radius: 12px; padding: 24px;
            box-shadow: 0 10px 25px -5px rgba(75, 136, 255, 0.08); border: 1px solid #e2e8f0;
        }
        .team-leader-box {
            background: linear-gradient(135deg, rgba(75, 136, 255, 0.1), rgba(154, 215, 255, 0.2));
            border-radius: 10px; padding: 15px; display: flex; align-items: center; gap: 15px;
            margin-bottom: 20px; border: 1px solid rgba(75, 136, 255, 0.2);
        }
        .leader-avatar {
            width: 45px; height: 45px; border-radius: 50%; background-color: #4B88FF;
            color: white; display: flex; align-items: center; justify-content: center; font-size: 20px; font-weight: bold;
        }
        .leader-info .role { font-size: 0.75rem; color: #1F3C88; font-weight: 700; text-transform: uppercase; }
        .leader-info .name { font-size: 1.05rem; font-weight: 700; color: #0B1026; }
        .member-list { display: flex; flex-direction: column; gap: 10px; }
        .member-item {
            display: flex; align-items: center; justify-content: space-between; padding: 12px 15px;
            background-color: #f4f7fc; border-radius: 8px; border: 1px solid #e2e8f0; transition: background-color 0.2s;
        }
        .member-item:hover { background-color: #fff; border-color: #9AD7FF; }
        .member-info { display: flex; align-items: center; gap: 10px; font-weight: 600; color: #0B1026; }
        .member-info i { color: #4B88FF; }
        .member-badge { font-size: 0.75rem; background-color: #FFE8D6; color: #8c5822; padding: 3px 8px; border-radius: 6px; font-weight: 600; }
    </style>
</head>
<body>
    <div class="erp-wrapper">
        <!-- 공통 사이드바 태그 적용 -->
        <my:sideMenu />

        <!-- 오른쪽 본문 영역 -->
        <div class="erp-main">
            <main class="erp-content">
                <!-- 환영 배너 -->
                <div class="welcome-banner">
                    <span class="welcome-badge"><i class="mdi mdi-star-shooting"></i> HEXAGON ERP SYSTEM</span>
                    <h2>Hexagon統合ERPへようこそ。</h2>
                    <p>基礎データの体系的な管理と迅速な営業・出荷管理により、スマートな業務環境を支援します。左側のメニューから業務を選択してください。</p>
                </div>

                <div class="dashboard-grid">
                    <div>
                        <!-- よく使うクイックメニュー -->
                        <div class="section-title"><i class="mdi mdi-flash"></i> よく使うクイックメニュー</div>
                        <div class="quick-menu-grid">
                            <a href="${pageContext.request.contextPath}/base/account" class="quick-card">
                                <div class="quick-icon"><i class="mdi mdi-domain"></i></div>
                                <h4>取引先登録</h4>
                                <p>基礎情報管理</p>
                            </a>
                            <a href="${pageContext.request.contextPath}/sales/estimate/input" class="quick-card">
                                <div class="quick-icon"><i class="mdi mdi-file-document-edit"></i></div>
                                <h4>見積書入力</h4>
                                <p>営業管理</p>
                            </a>
                            <a href="${pageContext.request.contextPath}/sales/order/input" class="quick-card">
                                <div class="quick-icon"><i class="mdi mdi-clipboard-edit"></i></div>
                                <h4>注文書入力</h4>
                                <p>販売・注文</p>
                            </a>
                        </div>

                        <!-- お知らせ・更新情報 -->
                        <div class="section-title" style="margin-top: 10px;"><i class="mdi mdi-bullhorn-outline"></i> お知らせ・更新情報</div>
                        <div class="notice-box">
                            <div class="notice-item">
                                <div class="notice-title">
                                    <i class="mdi mdi-check-circle"></i>
                                    <span>［案内］Hexagon統合ERPシステム v2.4 定期アップデート完了</span>
                                </div>
                                <div class="notice-date">2026-03-20</div>
                            </div>
                            <div class="notice-item">
                                <div class="notice-title">
                                    <i class="mdi mdi-alert-circle"></i>
                                    <span>［お知らせ］営業管理モジュールの単価一括変更機能の使用手順</span>
                                </div>
                                <div class="notice-date">2026-03-15</div>
                            </div>
                            <div class="notice-item">
                                <div class="notice-title">
                                    <i class="mdi mdi-information"></i>
                                    <span>［システム］新規倉庫登録および品目コード体系の改編</span>
                                </div>
                                <div class="notice-date">2026-03-10</div>
                            </div>
                        </div>
                    </div>

                    <div>
                        <!-- 開発・運用第3チームの紹介 -->
                        <div class="section-title"><i class="mdi mdi-account-group"></i> 開発・運用第3チームの紹介</div>
                        <div class="team-card">
                            <div class="team-leader-box">
                                <div class="leader-avatar">장</div>
                                <div class="leader-info">
                                    <div class="role">Team Leader</div>
                                    <div class="name">チャン・エスター チーム長</div>
                                </div>
                            </div>

                            <div class="member-list">
                                <div class="member-item">
                                    <div class="member-info">
                                        <i class="mdi mdi-account-circle"></i>
                                        <span>イ・ギジョン</span>
                                    </div>
                                    <span class="member-badge">Team Member</span>
                                </div>
                                <div class="member-item">
                                    <div class="member-info">
                                        <i class="mdi mdi-account-circle"></i>
                                        <span>パク・ジヌ</span>
                                    </div>
                                    <span class="member-badge">Team Member</span>
                                </div>
                                <div class="member-item">
                                    <div class="member-info">
                                        <i class="mdi mdi-account-circle"></i>
                                        <span>イ・サンフン</span>
                                    </div>
                                    <span class="member-badge">Team Member</span>
                                </div>
                                <div class="member-item">
                                    <div class="member-info">
                                        <i class="mdi mdi-account-circle"></i>
                                        <span>イ・ジュニ</span>
                                    </div>
                                    <span class="member-badge">Team Member</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
</body>
</html>