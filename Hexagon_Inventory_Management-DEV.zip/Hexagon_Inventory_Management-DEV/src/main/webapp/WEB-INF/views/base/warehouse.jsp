<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ taglib prefix="my" tagdir="/WEB-INF/tags"%>
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<title>倉庫登録 - ヘキサゴンERP</title>
<link
	href="https://cdn.jsdelivr.net/npm/@mdi/font@7.2.96/css/materialdesignicons.min.css"
	rel="stylesheet">
</head>
<body class="${param.embed == '1' ? 'base-embed' : ''}">
	<div class="erp-wrapper">
		<my:sideMenu />
		<div class="erp-main">
			<main class="erp-content">
				<div class="page-title">
					<i class="mdi mdi-warehouse"></i> 倉庫登録
				</div>
				<!-- ========================= 一覧 ========================== -->
				<div class="list-wrap">
					<div class="list-head">
						<div class="list-title">
							<i class="mdi mdi-star-outline"></i> 倉庫登録一覧
						</div>
						<div class="list-toolbar">
							<form id="searchForm"
								action="${pageContext.request.contextPath}/base/warehouse"
								method="get">
								<input type="hidden" name="pageNum"
									value="${empty pageMaker.cri.pageNum ? 1 : pageMaker.cri.pageNum}">
								<input type="hidden" name="amount"
									value="${empty pageMaker.cri.amount ? 10 : pageMaker.cri.amount}">
								<!-- WarehouseMapper.xmlでは、typeArr（T/C）が必要です。これによりキーワードが検索条件に適用されます。 -->
								<input type="hidden" name="type"
									value="${empty pageMaker.cri.type ? 'TC' : pageMaker.cri.type}">
								<div class="search-box">
									<input type="text" id="whSearchInput" name="keyword"
										value="${pageMaker.cri.keyword}"
										placeholder="倉庫名/コード 入力後［Enter］">
								</div>
							</form>
							<button type="button" class="btn-primary-sm" id="btnSearch">
								<i class="mdi mdi-magnify"></i> Search(F3)
							</button>
							<button type="button" class="btn-flat-sm" id="btnResetSearch">
								<i class="mdi mdi-refresh"></i> リセット
							</button>
							<button type="button" class="btn-flat-sm">
								<i class="mdi mdi-tune-variant"></i> Option
							</button>
							<button type="button" class="btn-flat-sm">
								<i class="mdi mdi-help-circle-outline"></i> ヘルプ
							</button>
						</div>
					</div>
					<!-- =========================  ========================== -->
					<div class="list-table-wrap">
						<table class="list-table">
							<thead>
								<tr>
									<th class="col-chk"><input type="checkbox" id="checkAll">
									</th>
									<th class="col-pk">PK <i class="mdi mdi-menu-down"></i>
									</th>
									<th>倉庫コード <i class="mdi mdi-menu-down"></i>
									</th>
									<th>倉庫名 <i class="mdi mdi-menu-down"></i>
									</th>
									<th>区分 <i class="mdi mdi-menu-down"></i>
									</th>
									<th>生産工程名 <i class="mdi mdi-menu-down"></i>
									</th>
									<th>外注取引先名 <i class="mdi mdi-menu-down"></i>
									</th>
									<th>使用 <i class="mdi mdi-menu-down"></i>
									</th>
								</tr>
							</thead>
							<tbody id="warehouseTbody">
								<c:choose>
									<c:when test="${empty list}">
										<tr>
											<td colspan="8"
												style="text-align: center; padding: 30px; color: #94a3b8;">
												登録された倉庫データはありません。</td>
										</tr>
									</c:when>
									<c:otherwise>
										<c:forEach var="warehouse" items="${list}">
											<tr onclick="openWarehouseModal('${warehouse.warehousePk}')">
												<td class="col-chk"><input type="checkbox"
													onclick="event.stopPropagation();"></td>
												<td class="col-pk">${warehouse.warehousePk}</td>
												<td><a href="javascript:void(0);"
													class="row-link code-link"> ${warehouse.warehouseCode}
												</a></td>
												<td><a href="javascript:void(0);" class="row-link">
														${warehouse.warehouseName} </a></td>
												<td><c:choose>
														<c:when test="${warehouse.warehouseDiv == 0}"> 倉庫 </c:when>
														<c:when test="${warehouse.warehouseDiv == 1}"> 工場 </c:when>
														<c:when test="${warehouse.warehouseDiv == 2}"> 工場（外注費管理） </c:when>
														<c:otherwise> - </c:otherwise>
													</c:choose></td>
												<td>${warehouse.prodProcessName}</td>
												<td>${warehouse.outsourcingPartnerName}</td>
												<td><c:choose>
														<c:when test="${warehouse.useYn == 'Y'}">
															<span class="badge-yes"> Yes </span>
														</c:when>
														<c:otherwise>
															<span class="badge-no"> No </span>
														</c:otherwise>
													</c:choose></td>
											</tr>
										</c:forEach>
									</c:otherwise>
								</c:choose>
							</tbody>
						</table>
					</div>
					<!-- ========================= ページ ========================== -->
					<div class="pagination-wrap">
						<ul class="pagination">
							<c:if test="${pageMaker.prev}">
								<c:url var="prevUrl" value="/base/warehouse"><c:param name="pageNum" value="${pageMaker.startPage - 1}"/><c:param name="amount" value="10"/><c:param name="type" value="${pageMaker.cri.type}"/><c:param name="keyword" value="${pageMaker.cri.keyword}"/></c:url>
								<li class="paginate_button"><a href="${prevUrl}"> 前へ </a></li>
							</c:if>
							<c:forEach var="num" begin="${pageMaker.startPage}" end="${pageMaker.endPage}">
								<c:url var="pageUrl" value="/base/warehouse"><c:param name="pageNum" value="${num}"/><c:param name="amount" value="10"/><c:param name="type" value="${pageMaker.cri.type}"/><c:param name="keyword" value="${pageMaker.cri.keyword}"/></c:url>
								<li class="paginate_button ${pageMaker.cri.pageNum == num ? 'active' : ''}">
									<a href="${pageUrl}"> ${num} </a>
								</li>
							</c:forEach>
							<c:if test="${pageMaker.next}">
								<c:url var="nextUrl" value="/base/warehouse"><c:param name="pageNum" value="${pageMaker.endPage + 1}"/><c:param name="amount" value="10"/><c:param name="type" value="${pageMaker.cri.type}"/><c:param name="keyword" value="${pageMaker.cri.keyword}"/></c:url>
								<li class="paginate_button"><a href="${nextUrl}"> 次へ </a></li>
							</c:if>
						</ul>
					</div>
					<!-- =========================  ボタン ========================== -->
					<div class="list-footer">
						<button type="button" class="btn-primary-sm" id="btnNewWarehouse">
							<i class="mdi mdi-plus"></i> 新規(F2)
						</button>
						<button type="button" class="btn-flat-sm" id="btnToggleWarehouseUse">使用停止／再使用 <i class="mdi mdi-chevron-up"></i></button>
						<button type="button" class="btn-flat-sm" id="btnWarehouseHierarchy"
								onclick="openWarehouseHierarchyForSelected();">
							<i class="mdi mdi-file-tree-outline"></i> 階層グループ
						</button>
						<button type="button" class="btn-flat-sm danger-sm" id="btnRemoveWarehouse">
							<i class="mdi mdi-delete-outline"></i> 削除
						</button>
						<button type="button" class="btn-flat-sm">
							<i class="mdi mdi-file-excel-outline"></i> Excel
						</button>
						<button type="button" class="btn-flat-sm">Web資料アップロード</button>
					</div>
				</div>
				<!-- ===================================================== 倉庫登録 / 編集  ====================================================== -->
				<div class="modal-overlay" id="warehouseModalOverlay">
					<div class="wh-card modal-card">
						<!--  -->
						<div class="wh-card-head">
							<h3>
								<i class="mdi mdi-warehouse"></i> 倉庫登録
							</h3>
							<div class="head-btns">
								<button type="button" class="btn-option">
									<i class="mdi mdi-tune-variant"></i> Option
								</button>
								<button type="button" class="modal-close"
									id="closeWarehouseModal">
									<i class="mdi mdi-close"></i>
								</button>
							</div>
						</div>
						<!-- タブ -->
						<div class="wh-tabs">
							<button type="button" class="tab-btn active" data-tab="tab-basic">
								基本／倉庫情報</button>
							<button type="button" class="tab-btn" data-tab="tab-extra">
								追加情報</button>
						</div>
						<!-- ========================= FORM ========================== -->
						<form id="warehouseForm" class="wh-form">
							<input type="hidden" name="warehousePk" id="warehousePk" value="">
							<!-- ================================================= 基本 ================================================== -->
							<div class="tab-panel active" id="tab-basic">
								<!-- 倉庫コード -->
								<div class="form-row">
									<label> 倉庫コード </label> <input type="text" name="warehouseCode"
										id="warehouseCode" placeholder="倉庫コード">
								</div>
								<!-- 倉庫名 -->
								<div class="form-row">
									<label> 倉庫名 </label> <input type="text" name="warehouseName"
										placeholder="倉庫名">
								</div>
								<!-- ================================================= 区分 ================================================== -->
								<div class="form-row">
									<label> 区分 </label>
									<div class="radio-group">
										<label class="radio-item"> <input type="radio"
											name="warehouseDiv" value="0" checked> <span>倉庫</span>
										</label> <label class="radio-item"> <input type="radio"
											name="warehouseDiv" value="1"> <span>工場</span>
										</label> <label class="radio-item"> <input type="radio"
											name="warehouseDiv" value="2"> <span>工場（外注費管理）</span>
										</label>
									</div>
								</div>
								<!-- ================================================= 生産工程名 ★ JavaScriptで直接表示を制御 ================================================== -->
								<div class="form-row conditional-row" id="divProdProcess"
									style="display: none;">
									<label> 生産工程名 </label>
									<input type="text" name="prodProcessName" id="prodProcessSelector" placeholder="生産工程名を直接入力してください" autocomplete="off">
									<input type="hidden" name="prodProcessPk" id="prodProcessPk">
								</div>
								<!-- ================================================= 外注先名 ================================================== -->
								<div class="form-row conditional-row" id="divOutsourcing"
									style="display: none;">
									<label> 外注先名 </label>
									<input type="text" name="outsourcingPartnerName" id="outsourcePartnerSelector" placeholder="外注先名を直接入力してください" autocomplete="off">
									<input type="hidden" name="outsourcePartnerId" id="outsourcePartnerId">
								</div>
								<!-- =================================================  消費税率 ================================================== -->
								<div class="form-row">
									<label> 消費税率（売上） </label>
									<div class="radio-group">
										<label class="radio-item"> <input type="radio"
											name="vatSalesType" value="0" checked> <span>
												基本設定 </span>
										</label> <label class="radio-item"> <input type="radio"
											name="vatSalesType" value="1"> <span> 直接入力 </span>
										</label>
									</div>
								</div>
								<!-- 売上消費税率を入力 -->
								<div class="form-row conditional-row" id="divVatSalesRate"
									style="display: none;">
									<label> 売上消費税率 </label>
									<div class="price-input">
										<input type="text" id="basicVatRateSales" name="vatRateSales"
											class="num" placeholder="売上消費税率を入力"> <span
											class="unit-suffix"> % </span>
									</div>
								</div>
								<!-- =================================================  消費税率 ================================================== -->
								<div class="form-row">
									<label> 消費税率（仕入） </label>
									<div class="radio-group">
										<label class="radio-item"> <input type="radio"
											name="vatPurchaseType" value="0" checked> <span>
												基本設定 </span>
										</label> <label class="radio-item"> <input type="radio"
											name="vatPurchaseType" value="1"> <span> 直接入力
										</span>
										</label>
									</div>
								</div>
								<!-- 仕入消費税率を入力 -->
								<div class="form-row conditional-row" id="divVatPurRate"
									style="display: none;">
									<label> 仕入消費税率 </label>
									<div class="price-input">
										<input type="text" id="basicVatRatePurchase"
											name="vatRatePurchase" class="num" placeholder="仕入消費税率を入力">
										<span class="unit-suffix"> % </span>
									</div>
								</div>
							</div>
							<!-- ================================================= 倉庫情報 ================================================== -->
							<div class="tab-panel" id="tab-info">
								<div class="form-row">
									<label> 倉庫コード </label> <input type="text" class="mirror"
										data-mirror="warehouseCode" readonly>
								</div>
								<div class="form-row">
									<label> 消費税率（売上） </label>
									<div class="price-input">
										<input type="text" class="num" placeholder="消費税率（売上）" readonly>
										<span class="unit-suffix"> % </span>
									</div>
								</div>
								<div class="form-row">
									<label> 消費税率（仕入） </label>
									<div class="price-input">
										<input type="text" class="num" placeholder="消費税率（仕入）" readonly>
										<span class="unit-suffix"> % </span>
									</div>
								</div>
							</div>
							<!-- ================================================= 追加情報 ================================================== -->
							<div class="tab-panel" id="tab-extra">
								<div class="form-row">
									<label> 倉庫コード </label> <input type="text" class="mirror"
										data-mirror="warehouseCode" readonly>
								</div>
									<div class="form-row">
										<label> 販売単価グループ </label>
										<div class="popup-field">
											<input type="text" id="salesPriceGroupName" readonly placeholder="登録済みの販売単価グループを選択">
											<input type="hidden" name="salesPriceGroupPk" id="salesPriceGroupPk">
											<button type="button" class="popup-search-btn" onclick="openWarehousePriceGroupSelector('sales')" title="販売単価グループを選択"><i class="mdi mdi-magnify"></i></button>
										</div>
									</div>
									<div class="form-row">
										<label> 購入単価グループ </label>
										<div class="popup-field">
											<input type="text" id="purPriceGroupName" readonly placeholder="登録済みの購入単価グループを選択">
											<input type="hidden" name="purPriceGroupPk" id="purPriceGroupPk">
											<button type="button" class="popup-search-btn" onclick="openWarehousePriceGroupSelector('purchase')" title="購入単価グループを選択"><i class="mdi mdi-magnify"></i></button>
										</div>
									</div>
									<div class="form-row">
										<label> 倉庫階層グループ </label>
										<div class="popup-field">
											<input type="text" id="whHierGroupName" readonly placeholder="倉庫フォルダーを選択してください">
											<input type="hidden" name="whHierGroupPk" id="whHierGroupPk">
											<button type="button" class="popup-search-btn" onclick="openWarehouseHierarchySelector()" title="倉庫階層グループを選択"><i class="mdi mdi-file-tree-outline"></i></button>
										</div>
									</div>

								<div class="form-row">
									<label> 使用有無 </label>
									<div class="radio-group">
										<label class="radio-item"> <input type="radio"
											name="useYn" value="Y" checked> <span> 使用 </span>
										</label> <label class="radio-item"> <input type="radio"
											name="useYn" value="N"> <span> 未使用 </span>
										</label>
									</div>
								</div>
							</div>
						</form>
						<!-- =================================================  ================================================== -->
						<div class="wh-footer">
							<button type="button" class="btn-save" onclick="saveWarehouse();">
								保存(F8) <i class="mdi mdi-chevron-up"></i>
							</button>
							<button type="button" class="btn-flat" onclick="resetForm();">
								再入力</button>
							<button type="button" class="btn-flat"
								onclick="closeWarehouseModal();">閉じる</button>
						</div>
					</div>
				</div>
			<!-- ===================== 販売／購入単価グループ選択 ===================== -->
		<div class="modal-overlay wh-utility-overlay" id="warehousePriceGroupOverlay">
			<div class="wh-utility-card wh-group-card">
				<div class="wh-utility-head"><div><h3 id="warehousePriceGroupTitle"><i class="mdi mdi-tag-outline"></i> 単価グループ選択</h3><p>事前に登録した単価グループを選択し、倉庫に紐付けます。</p></div><button type="button" class="modal-close" onclick="closeWarehousePriceGroupSelector()"><i class="mdi mdi-close"></i></button></div>
				<div class="wh-group-list" id="warehousePriceGroupList"><div class="wh-group-empty">データを読み込んでいます。</div></div>
				<div class="wh-utility-footer"><span class="wh-group-help">この倉庫登録画面では新しいグループを作成せず、登録済みのデータを選択します。</span><button type="button" class="btn-primary-sm" onclick="selectWarehousePriceGroup()">選択</button><button type="button" class="btn-flat-sm" onclick="closeWarehousePriceGroupSelector()">閉じる</button></div>
			</div>
		</div>

		<!-- ===================== 倉庫階層グループ ===================== -->
		<div class="modal-overlay wh-utility-overlay" id="warehouseHierarchyOverlay">
			<div class="wh-utility-card wh-hierarchy-card">
				<div class="wh-utility-head"><div><h3><i class="mdi mdi-file-tree-outline"></i> 倉庫階層グループ</h3><p>倉庫一覧をフォルダー単位で分類します。品目階層グループと同じ親子構造です。</p></div><button type="button" class="modal-close" onclick="closeWarehouseHierarchySelector()"><i class="mdi mdi-close"></i></button></div>
				<div class="wh-hierarchy-layout"><div id="warehouseHierarchyTree" class="wh-hierarchy-tree"><div class="wh-group-empty">階層グループを読み込んでいます。</div></div><div class="wh-hierarchy-manage"><div class="wh-selected-label">選択中のグループ</div><div id="whHierarchySelected" class="wh-selected-value">未選択</div><input type="text" id="whHierarchyCode" maxlength="20" placeholder="グループコード"><input type="text" id="whHierarchyName" maxlength="100" placeholder="グループ"><small>新規登録すると、現在選択しているフォルダーの下に子フォルダーとして作成されます。</small><div class="wh-hierarchy-actions"><button type="button" class="btn-primary-sm" onclick="createWarehouseHierarchyGroup()">新規</button><button type="button" class="btn-flat-sm" onclick="editWarehouseHierarchyGroup()">編集</button><button type="button" class="btn-flat-sm danger-sm" onclick="deleteWarehouseHierarchyGroup()">削除</button></div><div class="hierarchy-members"><div class="hierarchy-members-title">このフォルダーに含まれる倉庫</div><div id="warehouseHierarchyMemberList" class="member-list"><div class="empty-members">フォルダーを選択すると、倉庫一覧が表示されます。</div></div></div></div></div>
				<div class="wh-utility-footer"><span class="wh-group-help">倉庫に適用するフォルダーを選択してください。</span><button type="button" class="btn-primary-sm" onclick="selectWarehouseHierarchyGroup()">選択</button><button type="button" class="btn-flat-sm" onclick="closeWarehouseHierarchySelector()">閉じる</button></div>
			</div>
		</div>
	</main>
	</div>
	</div>
	<style>
/* ===================================================== 基本 ===================================================== */
.page-title {
	font-size: 1.25rem;
	font-weight: 700;
	color: #0B1026;
	margin-bottom: 20px;
	display: flex;
	align-items: center;
	gap: 10px;
}

.page-title i {
	color: #4B88FF;
	font-size: 24px;
}
/* ===================================================== 一覧 ===================================================== */
.list-wrap {
	background: #fff;
	border-radius: 14px;
	border: 1px solid #e2e8f0;
	box-shadow: 0 10px 25px -5px rgba(75, 136, 255, .08);
	overflow: hidden;
}

.list-head {
	display: flex;
	align-items: center;
	justify-content: space-between;
	flex-wrap: wrap;
	gap: 12px;
	padding: 20px 22px 16px;
	border-bottom: 1px solid #e2e8f0;
}

.list-title {
	font-size: 1.1rem;
	font-weight: 800;
	color: #0B1026;
	display: flex;
	align-items: center;
	gap: 8px;
}

.list-title i {
	color: #f5b301;
	font-size: 20px;
}

.list-toolbar {
	display: flex;
	align-items: center;
	gap: 8px;
	flex-wrap: wrap;
}

.search-box input {
	border: 1px solid #e2e8f0;
	border-radius: 8px;
	padding: 8px 12px;
	font-size: 13px;
	width: 220px;
	outline: none;
}

.search-box input:focus {
	border-color: #4B88FF;
}
/* ===================================================== ボタン ===================================================== */
.btn-primary-sm {
	background: #4B88FF;
	color: #fff;
	border: none;
	font-weight: 700;
	font-size: 13px;
	padding: 8px 14px;
	border-radius: 8px;
	cursor: pointer;
	display: flex;
	align-items: center;
	gap: 4px;
}

.btn-flat-sm {
	background: #f8fafc;
	border: 1px solid #e2e8f0;
	color: #64748b;
	font-weight: 600;
	font-size: 13px;
	padding: 8px 14px;
	border-radius: 8px;
	cursor: pointer;
	display: flex;
	align-items: center;
	gap: 4px;
}
/* ===================================================== テーブル（横線・縦線のグリッドを適用） ===================================================== */
.list-table-wrap {
	overflow-x: auto;
}

.list-table {
	width: 100%;
	border-collapse: collapse;
	min-width: 760px;
	border-top: 1px solid #e2e8f0;
	border-bottom: 1px solid #e2e8f0;
}

.list-table thead th {
	background: #f4f7fc;
	color: #64748b;
	font-size: 12.5px;
	font-weight: 700;
	text-align: left;
	padding: 10px 14px;
	white-space: nowrap;
	border-bottom: 1px solid #cbd5e1;
	border-right: 1px solid #e2e8f0; /*   */
}

.list-table thead th:last-child {
	border-right: none;
}

.list-table tbody td {
	padding: 10px 14px;
	font-size: 13px;
	color: #0B1026;
	border-bottom: 1px solid #e2e8f0; /*   */
	border-right: 1px solid #e2e8f0; /*   */
	white-space: nowrap;
}

.list-table tbody td:last-child {
	border-right: none;
}

.list-table tbody tr {
	cursor: pointer;
}

.list-table tbody tr:hover {
	background: #f7faff;
}

.list-table tbody a {
	color: #4B88FF;
	font-weight: 700;
	text-decoration: none;
}

.col-chk {
	width: 40px;
	text-align: center;
}

.col-pk {
	width: 52px;
	text-align: center;
}
/* =====================================================  ===================================================== */
.badge-yes {
	color: #16a34a;
	font-weight: 700;
}

.badge-no {
	color: #94a3b8;
	font-weight: 700;
}
/* ===================================================== ページ ===================================================== */
.pagination-wrap {
	padding: 15px 22px;
	display: flex;
	justify-content: center;
	align-items: center;
	border-top: 1px solid #e2e8f0;
	background: #fff;
}

.pagination {
	display: flex;
	list-style: none;
	gap: 5px;
	margin: 0;
	padding: 0;
}

.pagination a {
	display: block;
	padding: 6px 12px;
	border: 1px solid #e2e8f0;
	border-radius: 6px;
	text-decoration: none;
	color: #64748b;
	font-size: 13px;
}

.pagination .active a {
	background: #4B88FF;
	color: #fff;
	border-color: #4B88FF;
	font-weight: 700;
}
/* ===================================================== Footer ===================================================== */
.list-footer {
	display: flex;
	align-items: center;
	gap: 8px;
	flex-wrap: wrap;
	padding: 16px 22px;
	background: #f8fafc;
	border-top: 1px solid #e2e8f0;
}
/* ===================================================== Modal ===================================================== */
.modal-overlay {
	display: none;
	position: fixed;
	inset: 0;
	background: rgba(11, 16, 38, .45);
	align-items: flex-start;
	justify-content: center;
	padding: 5vh 20px;
	z-index: 1000;
	overflow-y: auto;
}

.modal-overlay.active {
	display: flex;
}

.wh-card {
	background: #fff;
	border-radius: 14px;
	border: 1px solid #e2e8f0;
	box-shadow: 0 20px 45px -10px rgba(11, 16, 38, .25);
	max-width: 700px;
	width: 100%;
	overflow: hidden;
	display: flex;
	flex-direction: column;
}
/* ===================================================== Modal Header ===================================================== */
.wh-card-head {
	display: flex;
	align-items: center;
	justify-content: space-between;
	padding: 20px 22px 8px;
}

.wh-card-head h3 {
	font-size: 1.1rem;
	font-weight: 800;
	color: #0B1026;
	display: flex;
	align-items: center;
	gap: 8px;
}

.wh-card-head h3 i {
	color: #4B88FF;
}

.head-btns {
	display: flex;
	align-items: center;
	gap: 8px;
}

.modal-close {
	border: none;
	background: #f1f5f9;
	color: #64748b;
	width: 30px;
	height: 30px;
	border-radius: 50%;
	cursor: pointer;
}
/* ===================================================== タブ ===================================================== */
.wh-tabs {
	display: flex;
	gap: 6px;
	padding: 10px 22px 18px;
}

.tab-btn {
	border: none;
	background: #eef4ff;
	color: #1F3C88;
	font-weight: 700;
	font-size: 13px;
	padding: 8px 16px;
	border-radius: 999px;
	cursor: pointer;
}

.tab-btn.active {
	background: #4B88FF;
	color: #fff;
}
/* ===================================================== Form ===================================================== */
.wh-form {
	border-top: 1px solid #e2e8f0;
	padding: 22px;
	max-height: 60vh;
	overflow-y: auto;
}

.tab-panel {
	display: none;
	flex-direction: column;
	gap: 16px;
}

.tab-panel.active {
	display: flex;
}

.form-row {
	display: grid;
	grid-template-columns: 140px 1fr;
	align-items: center;
	gap: 14px;
}

.form-row label {
	font-size: 13.5px;
	font-weight: 700;
	color: #0B1026;
}

.form-row input[type="text"] {
	width: 100%;
	box-sizing: border-box;
	border: 1px solid #e2e8f0;
	border-radius: 8px;
	padding: 9px 12px;
	font-size: 13.5px;
	outline: none;
}

.form-row input[readonly] {
	background: #f4f7fc;
	color: #64748b;
}

.radio-group {
	display: flex;
	flex-wrap: wrap;
	gap: 14px;
}

.radio-item {
	display: flex;
	align-items: center;
	gap: 5px;
	font-size: 13.5px;
	color: #0B1026;
	cursor: pointer;
}

.radio-item input {
	accent-color: #4B88FF;
	width: 15px;
	height: 15px;
}

.price-input {
	display: flex;
	align-items: center;
	gap: 10px;
}

.price-input input {
	flex: 1;
}

.unit-suffix {
	color: #64748b;
	font-size: 13px;
}
/* ===================================================== Footer ===================================================== */
.wh-footer {
	border-top: 1px solid #e2e8f0;
	display: flex;
	align-items: center;
	gap: 8px;
	padding: 14px 22px;
	background: #f8fafc;
}

.btn-save {
	background: #4B88FF;
	color: #fff;
	border: none;
	font-weight: 800;
	font-size: 13.5px;
	padding: 10px 18px;
	border-radius: 8px;
	cursor: pointer;
}

.btn-flat {
	background: #fff;
	border: 1px solid #e2e8f0;
	color: #0B1026;
	font-weight: 600;
	font-size: 13px;
	padding: 9px 14px;
	border-radius: 8px;
	cursor: pointer;
}

.wh-utility-overlay{z-index:1200;padding-top:7vh}.wh-utility-card{width:min(720px,96vw);background:#fff;border:1px solid #e2e8f0;border-radius:14px;box-shadow:0 20px 55px -12px rgba(11,16,38,.3);overflow:hidden;animation:modalPop .15s ease}.wh-utility-head{display:flex;align-items:flex-start;justify-content:space-between;padding:18px 20px 14px;border-bottom:1px solid #e2e8f0}.wh-utility-head h3{margin:0;font-size:17px;font-weight:800;color:#0B1026;display:flex;align-items:center;gap:8px}.wh-utility-head h3 i{color:#4B88FF}.wh-utility-head p{margin:5px 0 0;color:#64748b;font-size:12px}.wh-group-list{max-height:430px;overflow:auto;padding:8px 18px}.wh-group-option{display:flex;align-items:center;gap:10px;padding:11px 8px;border-bottom:1px solid #eef2f7;cursor:pointer}.wh-group-option:hover{background:#f7faff}.wh-group-option.selected{background:#e8f0ff;color:#1f3c88}.wh-group-option-main{display:flex;flex-direction:column;gap:2px}.wh-group-option-main strong{font-size:13px}.wh-group-empty{padding:35px 15px;color:#94a3b8;text-align:center;font-size:13px}.wh-utility-footer{display:flex;align-items:center;gap:8px;padding:13px 18px;background:#f8fafc;border-top:1px solid #e2e8f0}.wh-group-help{margin-right:auto;color:#64748b;font-size:11.5px}.wh-hierarchy-layout{display:grid;grid-template-columns:1.35fr .9fr;min-height:390px}.wh-hierarchy-tree{padding:16px;overflow:auto;border-right:1px solid #e2e8f0;background:#fbfdff}.wh-hierarchy-node{display:flex;align-items:center;gap:7px;padding:7px 9px;border-radius:7px;cursor:pointer;font-size:13px;color:#334155}.wh-hierarchy-node:hover{background:#eef4ff}.wh-hierarchy-node.selected{background:#e8f0ff;color:#1f3c88;font-weight:800}.wh-hierarchy-children{padding-left:19px}.wh-hierarchy-manage{padding:18px;display:flex;flex-direction:column;gap:10px}.wh-hierarchy-manage input{box-sizing:border-box;width:100%;border:1px solid #dbe3ed;border-radius:8px;padding:9px 11px;font-size:13px;outline:none}.wh-selected-label{font-size:11px;color:#64748b;font-weight:700}.wh-selected-value{padding:10px 11px;border:1px solid #dbe3ed;border-radius:8px;background:#f8fafc;font-size:13px}.wh-hierarchy-manage small{font-size:11px;line-height:1.5;color:#64748b}.hierarchy-members{margin-top:4px;border-top:1px solid #e2e8f0;padding-top:12px}.hierarchy-members-title{font-size:12px;font-weight:800;color:#334155;margin-bottom:7px}.member-list{max-height:145px;overflow:auto;border:1px solid #e2e8f0;border-radius:8px;background:#fff}.member-row{display:grid;grid-template-columns:82px 1fr auto;gap:7px;align-items:center;padding:7px 8px;border-bottom:1px solid #eef2f7;font-size:11px}.member-row:last-child{border-bottom:none}.member-row .code{color:#64748b}.member-row .name{font-weight:700;color:#334155;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.member-row .status{color:#64748b}.empty-members{padding:14px 8px;color:#94a3b8;text-align:center;font-size:11px}.wh-hierarchy-actions{display:flex;gap:7px}.popup-field{display:grid;grid-template-columns:1fr 38px;gap:7px;align-items:center}.popup-field input{width:100%!important;box-sizing:border-box}.popup-search-btn{width:38px;height:38px;border:1px solid #dbe3ed;background:#f8fafc;border-radius:8px;color:#475569;cursor:pointer}.popup-search-btn:hover{background:#eef4ff;color:#1f3c88}.danger-sm{color:#b91c1c!important;border-color:#fecaca!important;background:#fff!important}.wh-hierarchy-card{width:min(820px,96vw);}
.wh-hierarchy-card .wh-hierarchy-layout{grid-template-columns:1.3fr .95fr;}
.wh-hierarchy-card .member-list{max-height:210px;}
.wh-hierarchy-card .member-row{grid-template-columns:105px minmax(0,1fr) 75px;gap:8px;font-size:12px;padding:8px 9px;}
.wh-hierarchy-card .member-row .name{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:800;}
.wh-hierarchy-card .member-row .status{text-align:right;white-space:nowrap;}
@media(max-width:720px){.wh-hierarchy-layout{grid-template-columns:1fr}.wh-hierarchy-tree{border-right:none;border-bottom:1px solid #e2e8f0;max-height:310px}}
body.base-embed{height:100vh;margin:0;overflow:hidden;background:#fff}
body.base-embed .erp-sidebar,body.base-embed .page-title,body.base-embed .list-wrap{display:none !important}
body.base-embed .erp-wrapper,body.base-embed .erp-main,body.base-embed .erp-content{height:100%;overflow:hidden;background:#fff}
body.base-embed #warehouseModalOverlay{background:transparent;padding:0;align-items:stretch}
body.base-embed #warehouseModalOverlay .wh-card{max-width:none;width:100%;height:100%;border:0;border-radius:0;box-shadow:none}
body.base-embed #warehouseModalOverlay .wh-form{flex:1;max-height:none}
</style>
	<script>
/* =====================================================
 * DOMの読み込み後にすべて実行
 * ===================================================== */
document.addEventListener('DOMContentLoaded', function () {

    // 倉庫の保存完了後に一覧へ移動する場合などに使用するアプリケーションのコンテキストパス
    var contextPath = '${pageContext.request.contextPath}';
    var baseEmbed = '${param.embed}' === '1';
    function notifyBaseRegister(action, extra) {
        if (!baseEmbed || !window.parent || window.parent === window) return;
        window.parent.postMessage({
            type: 'base-register',
            action: action,
            kind: 'warehouse',
            code: extra && extra.code ? extra.code : '',
            name: extra && extra.name ? extra.name : ''
        }, window.location.origin);
    }

    /* =====================================================
     * すべて 
     * ===================================================== */
    var checkAll = document.getElementById('checkAll');

    if (checkAll) {
        checkAll.addEventListener('change', function () {
            var checked = this.checked;

            document.querySelectorAll(
                '#warehouseTbody input[type="checkbox"]'
            ).forEach(function (checkbox) {
                checkbox.checked = checked;
            });
        });
    }


    /* =====================================================
     * 検索
     * ===================================================== */
    var btnSearch = document.getElementById('btnSearch');

    if (btnSearch) {
        btnSearch.addEventListener('click', function () {

            var form = document.getElementById('searchForm');
            var input = document.getElementById('whSearchInput');

            /* 検索時は常に1ページ目から開始 */
            form.querySelector(
                'input[name="pageNum"]'
            ).value = '1';

            /* 空白のみが入力された場合は、すべてを検索した場合と同様に処理 */
            if (input) {
                input.value = input.value.trim();
            }

            form.submit();
        });
    }

    var btnResetSearch = document.getElementById('btnResetSearch');

    if (btnResetSearch) {
        btnResetSearch.addEventListener('click', function () {

            var form = document.getElementById('searchForm');
            var input = document.getElementById('whSearchInput');

            /* 検索 リセット */
            if (input) {
                input.value = '';
            }

            form.querySelector(
                'input[name="pageNum"]'
            ).value = '1';

            /* WarehouseMapper.xml 検索  */
            var typeInput = form.querySelector('input[name="type"]');
            if (typeInput) {
                typeInput.value = 'TC';
            }

            form.submit();
        });
    }

    var searchInput = document.getElementById('whSearchInput');

    if (searchInput) {
        searchInput.addEventListener('keydown', function (e) {

            if (e.key === 'Enter') {

                e.preventDefault();

                var form = document.getElementById('searchForm');

                form.querySelector(
                    'input[name="pageNum"]'
                ).value = '1';

                this.value = this.value.trim();
                form.submit();
            }
        });
    }

    /* F3 = 検索, ESC = 検索 リセット */
    document.addEventListener('keydown', function (e) {
        if (e.key === 'F3') {
            e.preventDefault();
            if (btnSearch) {
                btnSearch.click();
            }
        }
    });


    /* =====================================================
     * ページ
     * ===================================================== */
    document.querySelectorAll('.paginate_button a[data-page]').forEach(function (link) {
        link.addEventListener('click', function (e) {
            e.preventDefault();
            var form = document.getElementById('searchForm');
            var page = this.getAttribute('data-page');
            if (!page) return;
            form.querySelector('input[name="pageNum"]').value = page;
            form.submit();
        });
    });


    /* =====================================================
     * Modal
     * ===================================================== */
    var whOverlay = document.getElementById(
        'warehouseModalOverlay'
    );


    /* =====================================================
     * 生産工程 / 外注 マスタ情報 
     * ===================================================== */
    var warehouseProdProcessRows = [];
    var warehouseOutsourcePartnerRows = [];

    function loadWarehouseReferenceData() {
        // 生産工程名/外注先名 選択 一覧  使用  入力  .
        //  データ   名称  .
        return Promise.resolve();
    }

    function escapeHtml(v) {
        return String(v == null ? '' : v).replace(/[&<>'"]/g, function(ch) {
            return {'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[ch];
        });
    }

    function syncWarehouseReferenceIds() {
        // 名称     ありません   FK .
        var p = document.getElementById('prodProcessSelector');
        var o = document.getElementById('outsourcePartnerSelector');
        var ph = document.getElementById('prodProcessPk');
        var oh = document.getElementById('outsourcePartnerId');
        if (ph && p && !p.value.trim()) ph.value = '';
        if (oh && o && !o.value.trim()) oh.value = '';
    }

    /* =====================================================
     * 倉庫登録 / 編集  
     * ===================================================== */
    window.openWarehouseModal = function (warehousePk) {

        resetForm();

        loadWarehouseReferenceData().then(function(){
            whOverlay.classList.add('active');
            applyWhDiv();
            applyVatType();

            if (warehousePk) {
                return fetch(
                    '${pageContext.request.contextPath}/warehouse/get?warehousePk='
                    + encodeURIComponent(warehousePk)
                ).then(function (res) { return res.json(); })
                .then(function (data) { if (data) fillWarehouseForm(data); });
            }
        }).catch(function(err){
            console.error(err);
            alert('生産工程／外注先の情報を読み込めませんでした。');
        });

        return;

    };


    /* =====================================================
     * Modal 閉じる
     * ===================================================== */
    window.closeWarehouseModal = function () {

        whOverlay.classList.remove('active');
        if (baseEmbed) notifyBaseRegister('close');
    };


    /* =====================================================
     * 新規 ボタン
     * ===================================================== */
    var btnNew = document.getElementById(
        'btnNewWarehouse'
    );

    if (btnNew) {

        btnNew.addEventListener('click', function () {

            openWarehouseModal(null);
        });
    }


    /* =====================================================
     * X ボタン
     * ===================================================== */
    var closeBtn = document.getElementById(
        'closeWarehouseModal'
    );

    if (closeBtn) {

        closeBtn.addEventListener(
            'click',
            closeWarehouseModal
        );
    }


    /* =====================================================
     * Modal  
     * ===================================================== */
    if (whOverlay) {

        whOverlay.addEventListener('click', function (e) {

            if (e.target === whOverlay) {
                closeWarehouseModal();
            }
        });
    }


    /* =====================================================
     * タブ
     * ===================================================== */
    document.querySelectorAll(
        '.tab-btn'
    ).forEach(function (button) {

        button.addEventListener('click', function () {

            document.querySelectorAll(
                '.tab-btn'
            ).forEach(function (btn) {

                btn.classList.remove('active');
            });


            document.querySelectorAll(
                '.tab-panel'
            ).forEach(function (panel) {

                panel.classList.remove('active');
            });


            button.classList.add('active');


            var target = document.getElementById(
                button.dataset.tab
            );

            if (target) {
                target.classList.add('active');
            }
        });
    });


    /* =====================================================
     * ★★★★★ 区分  ★★★★★
     * ===================================================== */
    var whDivRadios = document.querySelectorAll(
        'input[name="warehouseDiv"]'
    );


    window.applyWhDiv = function () {

        var checked = document.querySelector(
            'input[name="warehouseDiv"]:checked'
        );

        var processRow = document.getElementById(
            'divProdProcess'
        );

        var outsourcingRow = document.getElementById(
            'divOutsourcing'
        );


        if (!checked) {

            processRow.style.display = 'none';
            outsourcingRow.style.display = 'none';

            return;
        }


        var value = checked.value;


        /* =================================================
         * ① 倉庫
         * ================================================= */
        if (value === '0') {

            processRow.style.display = 'none';
            outsourcingRow.style.display = 'none';


            var processInputs = document.querySelectorAll(
                'input[name="prodProcessName"]'
            );

            processInputs.forEach(function (input) {

                input.value = '';
            });


            var outsourcingInputs = document.querySelectorAll(
                'input[name="outsourcingPartnerName"]'
            );

            outsourcingInputs.forEach(function (input) {

                input.value = '';
            });
        }


        /* =================================================
         * ② 工場
         * ================================================= */
        else if (value === '1') {

            processRow.style.display = 'grid';

            outsourcingRow.style.display = 'none';


            var outsourcingInputs = document.querySelectorAll(
                'input[name="outsourcingPartnerName"]'
            );

            outsourcingInputs.forEach(function (input) {

                input.value = '';
            });
        }


        /* =================================================
         * ③ 工場（外注費管理）
         * ================================================= */
        else if (value === '2') {

            processRow.style.display = 'grid';

            outsourcingRow.style.display = 'grid';
        }
    };


    whDivRadios.forEach(function (radio) {

        radio.addEventListener(
            'change',
            applyWhDiv
        );
    });

    var processSelector = document.getElementById('prodProcessSelector');
    var outsourceSelector = document.getElementById('outsourcePartnerSelector');
    if (processSelector) processSelector.addEventListener('input', syncWarehouseReferenceIds); processSelector.addEventListener('change', syncWarehouseReferenceIds);
    if (outsourceSelector) { outsourceSelector.addEventListener('input', syncWarehouseReferenceIds); outsourceSelector.addEventListener('change', syncWarehouseReferenceIds); }


    /* =====================================================
     * ★★★★★ 消費税率  ★★★★★
     * ===================================================== */
    var salesRadios = document.querySelectorAll(
        'input[name="vatSalesType"]'
    );

    var purchaseRadios = document.querySelectorAll(
        'input[name="vatPurchaseType"]'
    );


    window.applyVatType = function () {

        var salesChecked = document.querySelector(
            'input[name="vatSalesType"]:checked'
        );

        var purchaseChecked = document.querySelector(
            'input[name="vatPurchaseType"]:checked'
        );


        var salesRow = document.getElementById(
            'divVatSalesRate'
        );

        var purchaseRow = document.getElementById(
            'divVatPurRate'
        );


        /*  */
        if (
            salesChecked &&
            salesChecked.value === '1'
        ) {

            salesRow.style.display = 'grid';

        } else {

            salesRow.style.display = 'none';
        }


        /*  */
        if (
            purchaseChecked &&
            purchaseChecked.value === '1'
        ) {

            purchaseRow.style.display = 'grid';

        } else {

            purchaseRow.style.display = 'none';
        }
    };


    salesRadios.forEach(function (radio) {

        radio.addEventListener(
            'change',
            applyVatType
        );
    });


    purchaseRadios.forEach(function (radio) {

        radio.addEventListener(
            'change',
            applyVatType
        );
    });


    /* =====================================================
     * Mirror
     * ===================================================== */
    window.syncMirrors = function () {

        var form = document.getElementById(
            'warehouseForm'
        );

        var codeInput = form.querySelector(
            'input[name="warehouseCode"]'
        );


        if (!codeInput) {
            return;
        }


        document.querySelectorAll(
            '.mirror[data-mirror="warehouseCode"]'
        ).forEach(function (mirror) {

            mirror.value = codeInput.value || '';
        });
    };


    document.getElementById(
        'warehouseForm'
    ).addEventListener(
        'input',
        syncMirrors
    );


    /* =====================================================
     * ★★★★★ 編集 データ  ★★★★★
     * ===================================================== */
    window.fillWarehouseForm = function (row) {

        var form = document.getElementById(
            'warehouseForm'
        );


        form.querySelector(
            '[name="warehousePk"]'
        ).value = row.warehousePk || '';


        form.querySelector(
            '[name="warehouseCode"]'
        ).value = row.warehouseCode || '';


        form.querySelector(
            '[name="warehouseName"]'
        ).value = row.warehouseName || '';


        var divRadio = form.querySelector(
            'input[name="warehouseDiv"][value="'
            + row.warehouseDiv
            + '"]'
        );


        if (divRadio) {
            divRadio.checked = true;
        }


        var useRadio = form.querySelector(
            'input[name="useYn"][value="'
            + row.useYn
            + '"]'
        );


        if (useRadio) {
            useRadio.checked = true;
        }


        var processSelector = document.getElementById('prodProcessSelector');
        var outsourceSelector = document.getElementById('outsourcePartnerSelector');
        var processPk = document.getElementById('prodProcessPk');
        var outsourcePk = document.getElementById('outsourcePartnerId');
        if (processSelector) processSelector.value = row.prodProcessName || '';
        if (outsourceSelector) outsourceSelector.value = row.outsourcingPartnerName || '';
        if (processPk) processPk.value = row.prodProcessPk || '';
        if (outsourcePk) outsourcePk.value = row.outsourcePartnerId || '';


        var hasSales =
            row.vatRateSales !== null &&
            row.vatRateSales !== undefined &&
            row.vatRateSales !== '';


        var salesRadio = form.querySelector(
            'input[name="vatSalesType"][value="'
            + (hasSales ? '1' : '0')
            + '"]'
        );


        if (salesRadio) {
            salesRadio.checked = true;
        }


        document.getElementById(
            'basicVatRateSales'
        ).value =
            hasSales
                ? row.vatRateSales
                : '';


        var hasPurchase =
            row.vatRatePurchase !== null &&
            row.vatRatePurchase !== undefined &&
            row.vatRatePurchase !== '';


        var purchaseRadio = form.querySelector(
            'input[name="vatPurchaseType"][value="'
            + (hasPurchase ? '1' : '0')
            + '"]'
        );


        if (purchaseRadio) {
            purchaseRadio.checked = true;
        }


        document.getElementById(
            'basicVatRatePurchase'
        ).value =
            hasPurchase
                ? row.vatRatePurchase
                : '';


        applyWhDiv();
        applyVatType();
        syncMirrors();
    };


    /* =====================================================
     * リセット
     * ===================================================== */
    window.resetForm = function () {

        var form = document.getElementById(
            'warehouseForm'
        );


        form.reset();


        document.getElementById(
            'warehousePk'
        ).value = '';


        var defaultDiv = form.querySelector(
            'input[name="warehouseDiv"][value="0"]'
        );


        if (defaultDiv) {
            defaultDiv.checked = true;
        }


        var defaultSales = form.querySelector(
            'input[name="vatSalesType"][value="0"]'
        );


        if (defaultSales) {
            defaultSales.checked = true;
        }


        var defaultPurchase = form.querySelector(
            'input[name="vatPurchaseType"][value="0"]'
        );


        if (defaultPurchase) {
            defaultPurchase.checked = true;
        }


        var defaultUse = form.querySelector(
            'input[name="useYn"][value="Y"]'
        );


        if (defaultUse) {
            defaultUse.checked = true;
        }


        var processSelector = document.getElementById('prodProcessSelector');
        var outsourceSelector = document.getElementById('outsourcePartnerSelector');
        if (processSelector) processSelector.value = '';
        if (outsourceSelector) outsourceSelector.value = '';
        var processPk = document.getElementById('prodProcessPk');
        var outsourcePk = document.getElementById('outsourcePartnerId');
        if (processPk) processPk.value = '';
        if (outsourcePk) outsourcePk.value = '';


        document.querySelectorAll(
            '.tab-btn'
        ).forEach(function (btn) {

            btn.classList.remove('active');
        });


        document.querySelectorAll(
            '.tab-panel'
        ).forEach(function (panel) {

            panel.classList.remove('active');
        });


        document.querySelector(
            '.tab-btn[data-tab="tab-basic"]'
        ).classList.add('active');


        document.getElementById(
            'tab-basic'
        ).classList.add('active');


        applyWhDiv();
        applyVatType();
        syncMirrors();
    };


    /* =====================================================
     * ★★★★★ 保存 ★★★★★
     * ===================================================== */
    window.saveWarehouse = function () {

        var form = document.getElementById(
            'warehouseForm'
        );


        var pk = document.getElementById(
            'warehousePk'
        ).value;


        var sales = document.getElementById(
            'basicVatRateSales'
        );


        var purchase = document.getElementById(
            'basicVatRatePurchase'
        );


        var warehouseDiv = form.querySelector(
            'input[name="warehouseDiv"]:checked'
        );


        if (warehouseDiv) {

            if (warehouseDiv.value === '0') {

                document.getElementById('prodProcessSelector').value = '';
                document.getElementById('outsourcePartnerSelector').value = '';
                document.getElementById('prodProcessPk').value = '';
                document.getElementById('outsourcePartnerId').value = '';
            }


            else if (warehouseDiv.value === '1') {

                document.getElementById('outsourcePartnerSelector').value = '';
                document.getElementById('outsourcePartnerId').value = '';
            }
        }


        var salesType = form.querySelector(
            'input[name="vatSalesType"]:checked'
        );


        var purchaseType = form.querySelector(
            'input[name="vatPurchaseType"]:checked'
        );


        if (
            salesType &&
            salesType.value === '0'
        ) {

            sales.value = '0';
        }


        if (
            purchaseType &&
            purchaseType.value === '0'
        ) {

            purchase.value = '0';
        }


        syncWarehouseReferenceIds();

        var params = new URLSearchParams(
            new FormData(form)
        ).toString();


        var url =
            pk && pk.trim() !== ''
                ? '${pageContext.request.contextPath}/warehouse/modify'
                : '${pageContext.request.contextPath}/warehouse/register';


        fetch(url, {
            method: 'POST',
            credentials: 'same-origin',
            cache: 'no-store',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'Accept': 'text/plain'
            },
            body: params
        })
        .then(function (res) {
            return res.text().then(function (result) {
                var cleanResult = (result || '').trim();
                if (!res.ok) {
                    throw new Error(cleanResult || '倉庫の保存に失敗しました。');
                }
                return cleanResult;
            });
        })
        .then(function (result) {
            if (result === 'success') {
                alert('保存しました。');
                if (baseEmbed && !(pk && pk.trim())) {
                    var savedCode = document.getElementById('warehouseCode').value.trim();
                    var savedName = (form.querySelector('[name="warehouseName"]') || {}).value || '';
                    notifyBaseRegister('saved', {code: savedCode, name: String(savedName).trim()});
                    return;
                }
                closeWarehouseModal();
                location.href = contextPath + '/base/warehouse?pageNum=1&amount=10';
                return;
            }
            throw new Error(result || 'サーバーから保存完了の応答を受信できませんでした。');
        })
        .catch(function (err) {
            console.error('warehouse save error:', err);
            alert(err && err.message ? err.message : 'サーバーと通信できません。');
        });
    };


    window.goWarehousePage = function(page) {
        var form = document.getElementById('searchForm');
        if (!form) return;
        var pageInput = form.querySelector('input[name="pageNum"]');
        if (pageInput) pageInput.value = page;
        form.submit();
    };

    applyWhDiv();
    applyVatType();
    if (baseEmbed) openWarehouseModal(null);

});
</script>

<script>
(function(){
    'use strict';
    var contextPath='${pageContext.request.contextPath}';
    var priceMode='sales', priceRows=[], selectedPriceRow=null, whHierarchyNodes=[], selectedWhHierarchy=null, warehouseHierarchyMode='form';
    function esc(v){return String(v==null?'':v).replace(/[&<>'"]/g,function(ch){return {'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;',"\"":'&quot;'}[ch];});}
    function getJson(url,options){return fetch(url,options).then(function(res){return res.text().then(function(t){var d=null;try{d=t?JSON.parse(t):null;}catch(e){d=t;}if(!res.ok)throw new Error(typeof d==='string'?d:' 中にエラーが発生しました。');return d;});});}
    window.openWarehousePriceGroupSelector=function(mode){priceMode=mode==='purchase'?'purchase':'sales';selectedPriceRow=null;document.getElementById('warehousePriceGroupTitle').innerHTML='<i class="mdi mdi-tag-outline"></i> '+(priceMode==='sales'?'販売単価グループ':'購入単価グループ')+' 選択';var url=contextPath+(priceMode==='sales'?'/warehouse/salesPriceGroupList':'/warehouse/purPriceGroupList');getJson(url).then(function(rows){priceRows=rows||[];renderPriceRows();document.getElementById('warehousePriceGroupOverlay').classList.add('active');}).catch(function(err){alert(err.message||'単価グループ 読み込めませんでした。');});};
    function renderPriceRows(){var box=document.getElementById('warehousePriceGroupList');if(!priceRows.length){box.innerHTML='<div class="wh-group-empty">登録済みの単価グループはありません。</div>';return;}box.innerHTML=priceRows.map(function(r){var pk=String(r.pk||''),sel=selectedPriceRow&&String(selectedPriceRow.pk)===pk?' selected':'';return '<div class="wh-group-option'+sel+'" data-pk="'+esc(pk)+'"><i class="mdi '+(sel?'mdi-radiobox-marked':'mdi-radiobox-blank')+'"></i><span class="wh-group-option-main"><strong>'+esc((r.code||'')+' - '+(r.name||''))+'</strong></span></div>';}).join('');box.querySelectorAll('.wh-group-option').forEach(function(el){el.addEventListener('click',function(){var pk=el.getAttribute('data-pk');selectedPriceRow=priceRows.find(function(r){return String(r.pk)===String(pk);})||null;renderPriceRows();});});}
    window.closeWarehousePriceGroupSelector=function(){document.getElementById('warehousePriceGroupOverlay').classList.remove('active');};
    window.selectWarehousePriceGroup=function(){if(!selectedPriceRow){alert('単価グループを選択してください。');return;}var isSales=priceMode==='sales';var pkId=isSales?'salesPriceGroupPk':'purPriceGroupPk';var nameId=isSales?'salesPriceGroupName':'purPriceGroupName';document.getElementById(pkId).value=selectedPriceRow.pk||'';document.getElementById(nameId).value=(selectedPriceRow.code||'')+' - '+(selectedPriceRow.name||'');closeWarehousePriceGroupSelector();};
    function hLabel(n){return (n.code?n.code+' - ':'')+(n.name||'');}
    function hChildren(parent){return whHierarchyNodes.filter(function(n){return String(n.parentPk||'')===String(parent||'');});}
    function renderWhHierarchy(){var box=document.getElementById('warehouseHierarchyTree');if(!whHierarchyNodes.length){box.innerHTML='<div class="wh-group-empty">登録済みの倉庫階層グループはありません。</div>';clearWarehouseHierarchyMembers();return;}var roots=whHierarchyNodes.filter(function(n){return n.parentPk==null||String(n.parentPk)==='';});box.innerHTML=roots.map(function(n){return renderWhNode(n);}).join('');box.querySelectorAll('.wh-hierarchy-node').forEach(function(el){el.addEventListener('click',function(){var pk=el.getAttribute('data-pk');selectedWhHierarchy=whHierarchyNodes.find(function(n){return String(n.pk)===String(pk);})||null;renderWhHierarchy();});});document.getElementById('whHierarchySelected').textContent=selectedWhHierarchy?hLabel(selectedWhHierarchy):'未選択';if(selectedWhHierarchy){document.getElementById('whHierarchyCode').value=selectedWhHierarchy.code||'';document.getElementById('whHierarchyName').value=selectedWhHierarchy.name||'';loadWarehouseHierarchyMembers(selectedWhHierarchy.pk);}else{clearWarehouseHierarchyMembers();}}
    function renderWhNode(n){var children=hChildren(n.pk),sel=selectedWhHierarchy&&String(selectedWhHierarchy.pk)===String(n.pk);return '<div><div class="wh-hierarchy-node'+(sel?' selected':'')+'" data-pk="'+esc(n.pk)+'"><i class="mdi '+(children.length?'mdi-folder-open-outline':'mdi-folder-outline')+'"></i><span>'+esc(hLabel(n))+'</span></div>'+(children.length?'<div class="wh-hierarchy-children">'+children.map(renderWhNode).join('')+'</div>':'')+'</div>';}
    let warehouseHierarchyMemberRequestSeq=0;

    function clearWarehouseHierarchyMembers(){warehouseHierarchyMemberRequestSeq++;var box=document.getElementById('warehouseHierarchyMemberList');if(box)box.innerHTML='<div class="empty-members">フォルダーを選択すると、倉庫一覧が表示されます。</div>';}
    function loadWarehouseHierarchyMembers(pk){var box=document.getElementById('warehouseHierarchyMemberList');if(!box)return;var requestSeq=++warehouseHierarchyMemberRequestSeq,targetPk=String(pk);box.innerHTML='<div class="empty-members">読み込み中...</div>';getJson(contextPath+'/warehouse/hierarchy-members?whHierGroupPk='+encodeURIComponent(pk)+'&_='+Date.now(),{cache:'no-store'}).then(function(rows){if(requestSeq!==warehouseHierarchyMemberRequestSeq||!selectedWhHierarchy||String(selectedWhHierarchy.pk)!==targetPk)return;rows=rows||[];box.innerHTML=rows.length?rows.map(function(r){return '<div class="member-row"><span class="code">'+esc(r.warehouseCode||'')+'</span><span class="name">'+esc(r.warehouseName||'')+'</span><span class="status">'+(String(r.useYn||'').toUpperCase()==='Y'?'使用':'未使用')+'</span></div>';}).join(''):'<div class="empty-members">このフォルダーに割り当てられた倉庫はありません。</div>';}).catch(function(){if(requestSeq!==warehouseHierarchyMemberRequestSeq)return;box.innerHTML='<div class="empty-members">倉庫一覧を読み込めませんでした。</div>';});}

    function loadWhHierarchy(){return getJson(contextPath+'/base/hierarchy-group/warehouse/list?_='+Date.now()).then(function(rows){whHierarchyNodes=rows||[];renderWhHierarchy();return whHierarchyNodes;});}
    function selectedWarehousePks(){return Array.from(document.querySelectorAll('#warehouseTbody input[type=\"checkbox\"]:checked')).map(function(c){var tr=c.closest('tr');return tr?tr.querySelector('.col-pk')?.textContent.trim():null;}).filter(Boolean);}
    window.openWarehouseHierarchyForSelected=function(){openWarehouseHierarchySelector('bulk');};
    window.openWarehouseHierarchySelector=function(mode){warehouseHierarchyMode=mode==='bulk'?'bulk':'form';selectedWhHierarchy=null;document.getElementById('whHierarchySelected').textContent='未選択';document.getElementById('whHierarchyCode').value='';document.getElementById('whHierarchyName').value='';var whHelp=document.querySelector('.wh-group-help');if(whHelp)whHelp.textContent=warehouseHierarchyMode==='bulk'?'倉庫に適用するフォルダーを選択してください。':'倉庫の登録・編集に適用するフォルダーを選択してください。';loadWhHierarchy().then(function(){document.getElementById('warehouseHierarchyOverlay').classList.add('active');}).catch(function(err){alert(err.message||'倉庫階層グループを読み込めませんでした。');});};
    window.closeWarehouseHierarchySelector=function(){document.getElementById('warehouseHierarchyOverlay').classList.remove('active');};
    function postHierarchy(url,payload){var body=new URLSearchParams();Object.keys(payload).forEach(function(k){if(payload[k]!==null&&payload[k]!==undefined&&payload[k]!=='')body.append(k,payload[k]);});return getJson(url,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},body:body.toString()});}
    window.createWarehouseHierarchyGroup=function(){var code=document.getElementById('whHierarchyCode').value.trim(),name=document.getElementById('whHierarchyName').value.trim();if(!code||!name){alert('グループコードとグループ名を入力してください。');return;}postHierarchy(contextPath+'/base/hierarchy-group/warehouse/register',{code:code,name:name,parentPk:selectedWhHierarchy?selectedWhHierarchy.pk:''}).then(function(){alert('倉庫階層グループを登録しました。');return loadWhHierarchy();}).catch(function(err){alert(err.message||'階層グループの登録に失敗しました。');});};
    window.editWarehouseHierarchyGroup=function(){if(!selectedWhHierarchy){alert('編集するグループを選択してください。');return;}var code=document.getElementById('whHierarchyCode').value.trim(),name=document.getElementById('whHierarchyName').value.trim();if(!code||!name){alert('グループコードとグループ名を入力してください。');return;}postHierarchy(contextPath+'/base/hierarchy-group/warehouse/modify',{pk:selectedWhHierarchy.pk,code:code,name:name,parentPk:selectedWhHierarchy.parentPk||''}).then(function(){alert('倉庫階層グループを編集しました。');selectedWhHierarchy=null;return loadWhHierarchy();}).catch(function(err){alert(err.message||'階層グループの編集に失敗しました。');});};
    window.deleteWarehouseHierarchyGroup=function(){if(!selectedWhHierarchy){alert('削除するグループを選択してください。');return;}if(!confirm('選択した倉庫階層グループを削除しますか？'))return;postHierarchy(contextPath+'/base/hierarchy-group/warehouse/remove',{pk:selectedWhHierarchy.pk}).then(function(){alert('倉庫階層グループを削除しました。');selectedWhHierarchy=null;return loadWhHierarchy();}).catch(function(err){alert(err.message||'階層グループの削除中にエラーが発生しました。');});};
    window.selectWarehouseHierarchyGroup=function(){if(!selectedWhHierarchy){alert('倉庫階層グループを選択してください。');return;}if(warehouseHierarchyMode==='form'){document.getElementById('whHierGroupPk').value=selectedWhHierarchy.pk||'';document.getElementById('whHierGroupName').value=hLabel(selectedWhHierarchy);closeWarehouseHierarchySelector();return;}var pks=selectedWarehousePks();if(!pks.length){alert('階層グループを適用する倉庫を1件以上選択してください。');return;}var body=new URLSearchParams();pks.forEach(function(pk){body.append('warehousePks',pk);});body.append('whHierGroupPk',selectedWhHierarchy.pk);getJson(contextPath+'/warehouse/bulk-hierarchy-group',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},body:body.toString()}).then(function(){alert(pks.length+'件の倉庫に階層グループを適用しました。');loadWarehouseHierarchyMembers(selectedWhHierarchy.pk);}).catch(function(err){alert(err.message||'倉庫階層グループの適用に失敗しました。');});};
    function syncGroupNamesFromRow(row){document.getElementById('salesPriceGroupPk').value=row.salesPriceGroupPk||'';document.getElementById('purPriceGroupPk').value=row.purPriceGroupPk||'';document.getElementById('whHierGroupPk').value=row.whHierGroupPk||'';document.getElementById('salesPriceGroupName').value='';document.getElementById('purPriceGroupName').value='';document.getElementById('whHierGroupName').value='';var s=String(row.salesPriceGroupPk||''),p=String(row.purPriceGroupPk||''),h=String(row.whHierGroupPk||'');Promise.all([getJson(contextPath+'/warehouse/salesPriceGroupList'),getJson(contextPath+'/warehouse/purPriceGroupList'),getJson(contextPath+'/base/hierarchy-group/warehouse/list')]).then(function(all){var sr=(all[0]||[]).find(function(x){return String(x.pk)===s;}),pr=(all[1]||[]).find(function(x){return String(x.pk)===p;}),hr=(all[2]||[]).find(function(x){return String(x.pk)===h;});if(sr)document.getElementById('salesPriceGroupName').value=(sr.code||'')+' - '+(sr.name||'');if(pr)document.getElementById('purPriceGroupName').value=(pr.code||'')+' - '+(pr.name||'');if(hr)document.getElementById('whHierGroupName').value=hLabel(hr);}).catch(function(err){console.error(err);});}
    var originalFill=window.fillWarehouseForm;window.fillWarehouseForm=function(row){originalFill(row);syncGroupNamesFromRow(row||{});};
    var originalReset=window.resetForm;window.resetForm=function(){originalReset();document.getElementById('salesPriceGroupPk').value='';document.getElementById('purPriceGroupPk').value='';document.getElementById('whHierGroupPk').value='';document.getElementById('salesPriceGroupName').value='';document.getElementById('purPriceGroupName').value='';document.getElementById('whHierGroupName').value='';};
        var toggleWarehouseUse=document.getElementById('btnToggleWarehouseUse');
    if(toggleWarehouseUse){toggleWarehouseUse.addEventListener('click',function(){var pks=selectedWarehousePks();if(pks.length!==1){alert('使用区分を変更する倉庫を1件選択してください。');return;}var tr=document.querySelector('#warehouseTbody input[type=\"checkbox\"]:checked').closest('tr');var isUse=!!(tr && tr.querySelector('.badge-yes'));getJson(contextPath+'/warehouse/toggle-use',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},body:new URLSearchParams({warehousePk:pks[0],useYn:isUse?'N':'Y'}).toString()}).then(function(){location.reload();}).catch(function(err){alert(err.message||'使用区分の変更に失敗しました。');});});}
    // : 選択 倉庫 削除. 品目  倉庫   削除 .
    // 日本語: 選択した倉庫を削除します。商品が入っている倉庫はサーバー側の検証で削除を拒否します。
    var removeWarehouseButton = document.getElementById('btnRemoveWarehouse');
    if(removeWarehouseButton){removeWarehouseButton.addEventListener('click',function(){
        var pks=selectedWarehousePks();
        if(pks.length!==1){alert('削除する倉庫を1件選択してください。');return;}
        if(!confirm('選択した倉庫を削除しますか？\n倉庫に品目がある場合は削除できません。')) return;
        getJson(contextPath+'/warehouse/remove',{
            method:'POST',
            headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},
            body:new URLSearchParams({warehousePk:pks[0]}).toString()
        }).then(function(){alert('倉庫を削除しました。');location.reload();})
          .catch(function(err){alert(err.message||'倉庫の削除に失敗しました。');});
    });}
document.getElementById('warehousePriceGroupOverlay').addEventListener('click',function(e){if(e.target===this)closeWarehousePriceGroupSelector();});document.getElementById('warehouseHierarchyOverlay').addEventListener('click',function(e){if(e.target===this)closeWarehouseHierarchySelector();});
})();
</script>
</body>
</html>