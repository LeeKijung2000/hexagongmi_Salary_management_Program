<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="my" tagdir="/WEB-INF/tags" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>品目登録 - 헥사곤 ERP</title>
    <link href="https://cdn.jsdelivr.net/npm/@mdi/font@7.2.96/css/materialdesignicons.min.css" rel="stylesheet">
</head>
<body class="${param.embed == '1' ? 'base-embed' : ''}">
<div class="erp-wrapper">
    <my:sideMenu />

    <div class="erp-main">
        <main class="erp-content">
            <div class="page-title">
                <i class="mdi mdi-package-variant"></i> 品目登録
            </div>

            <div class="list-wrap">
                <div class="list-head">
                    <div class="list-title">
                        <i class="mdi mdi-star-outline"></i> 品目登録一覧
                    </div>
                    <div class="list-toolbar">
                        <form id="searchForm" action="${pageContext.request.contextPath}/base/item" method="get">
                            <input type="hidden" name="pageNum" value="${empty pageMaker.cri.pageNum ? 1 : pageMaker.cri.pageNum}">
                            <input type="hidden" name="amount" value="${pageMaker.cri.amount}">
                            <div class="search-box">
                                <input type="text" id="itemSearchInput" name="keyword"
                                       value="${pageMaker.cri.keyword}"
                                       placeholder="品目コード／品目名／グループ／規格／バーコードを検索してEnter">
                            </div>
                        </form>
                        <button type="button" class="btn-primary-sm" id="btnSearch">
                            <i class="mdi mdi-magnify"></i> Search(F3)
                        </button>
                        <button type="button" class="btn-flat-sm" id="btnResetSearch">
                            <i class="mdi mdi-refresh"></i> リセット
                        </button>
                    </div>
                </div>

                <div class="list-table-wrap">
                    <table class="list-table">
                        <colgroup>
                            <col style="width: 45px;">
                            <col style="width: 8%;">
                            <col style="width: 15%;">
                            <col style="width: 11%;">
                            <col style="width: 11%;">
                            <col style="width: 12%;">
                            <col style="width: 7%;">
                            <col style="width: 7%;">
                            <col style="width: 10%;">
                            <col style="width: 8%;">
                            <col style="width: 80px;">
                        </colgroup>
                        <thead>
                        <tr>
                            <th class="col-chk"><input type="checkbox" id="checkAll"></th>
                            <th>品目コード</th>
                            <th>品目名</th>
                            <th>品目グループ</th>
                            <th>規格</th>
                            <th>バーコード</th>
                            <th class="col-num">入庫単価</th>
                            <th class="col-num">出庫単価</th>
                            <th>保管倉庫</th>
                            <th>品目区分</th>
                            <th class="col-image">画像</th>
                        </tr>
                        </thead>
                        <tbody>
                        <c:choose>
                            <c:when test="${empty list}">
                                <tr>
                                    <td colspan="11" class="empty-row">登録された品目データはありません。</td>
                                </tr>
                            </c:when>
                            <c:otherwise>
                                <c:forEach var="item" items="${list}">
                                    <tr onclick="openItemModal(${item.itemPk})">
                                        <td class="col-chk" onclick="event.stopPropagation();">
                                            <input type="checkbox" class="item-check" value="${item.itemPk}">
                                        </td>
                                        <td>
                                            <a href="javascript:void(0);" class="row-link code-link">${item.itemCode}</a>
                                        </td>
                                        <td>
                                            <a href="javascript:void(0);" class="row-link">${item.itemName}</a>
                                        </td>
                                        <td>${empty item.itemGroupName ? '-' : item.itemGroupName}</td>
                                        <td>${empty item.spec ? '-' : item.spec}</td>
                                        <td>${empty item.barcode ? '-' : item.barcode}</td>
                                        <td class="col-num"><fmt:formatNumber value="${empty item.purchasePrice ? 0 : item.purchasePrice}" type="number" groupingUsed="true" maxFractionDigits="2"/></td>
                                        <td class="col-num"><fmt:formatNumber value="${empty item.salesPrice ? 0 : item.salesPrice}" type="number" groupingUsed="true" maxFractionDigits="2"/></td>
                                        <td title="${empty item.warehouseNames ? '未指定' : item.warehouseNames}">${empty item.warehouseNames ? '-' : item.warehouseNames}</td>
                                        <td>
                                            <c:choose>
                                                <c:when test="${item.itemDiv == 0}">原材料</c:when>
                                                <c:when test="${item.itemDiv == 1}">副資材</c:when>
                                                <c:when test="${item.itemDiv == 2}">製品</c:when>
                                                <c:when test="${item.itemDiv == 3}">半製品</c:when>
                                                <c:when test="${item.itemDiv == 4}">商品</c:when>
                                                <c:when test="${item.itemDiv == 5}">無形商品</c:when>
                                                <c:otherwise>-</c:otherwise>
                                            </c:choose>
                                        </td>
                                        <td class="col-image">
                                            <c:choose>
                                                <c:when test="${not empty item.imagePath}">
                                                    <img class="item-thumb" src="${pageContext.request.contextPath}${item.imagePath}" alt="${item.itemName}">
                                                </c:when>
                                                <c:otherwise>
                                                    <div class="item-thumb item-thumb-empty">
                                                        <i class="mdi mdi-package-variant"></i>
                                                    </div>
                                                </c:otherwise>
                                            </c:choose>
                                        </td>
                                    </tr>
                                </c:forEach>
                            </c:otherwise>
                        </c:choose>
                        </tbody>
                    </table>
                </div>

                <div class="pagination-wrap">
                    <ul class="pagination">
                        <c:if test="${pageMaker.prev}">
                            <c:url var="prevUrl" value="/base/item"><c:param name="pageNum" value="${pageMaker.startPage - 1}"/><c:param name="amount" value="10"/><c:param name="keyword" value="${pageMaker.cri.keyword}"/></c:url>
                            <li><a href="${prevUrl}">前へ</a></li>
                        </c:if>
                        <c:forEach var="num" begin="${pageMaker.startPage}" end="${pageMaker.endPage}">
                            <c:url var="pageUrl" value="/base/item"><c:param name="pageNum" value="${num}"/><c:param name="amount" value="10"/><c:param name="keyword" value="${pageMaker.cri.keyword}"/></c:url>
                            <li class="${pageMaker.cri.pageNum == num ? 'active' : ''}">
                                <a href="${pageUrl}">${num}</a>
                            </li>
                        </c:forEach>
                        <c:if test="${pageMaker.next}">
                            <c:url var="nextUrl" value="/base/item"><c:param name="pageNum" value="${pageMaker.endPage + 1}"/><c:param name="amount" value="10"/><c:param name="keyword" value="${pageMaker.cri.keyword}"/></c:url>
                            <li><a href="${nextUrl}">次へ</a></li>
                        </c:if>
                    </ul>
                </div>

                <div class="list-footer">
                    <button type="button" class="btn-primary-sm" id="btnNewItem">
                        <i class="mdi mdi-plus"></i> 新規(F2)
                    </button>
                    <button type="button" class="btn-flat-sm" id="btnDeleteItem">
                        <i class="mdi mdi-delete-outline"></i> 選択削除
                    </button>
                    <button type="button" class="btn-flat-sm" id="btnBulkChange">
                        <i class="mdi mdi-pencil-outline"></i> 変更
                    </button>
                    <button type="button" class="btn-flat-sm" id="btnBulkHierarchy">
                        <i class="mdi mdi-file-tree-outline"></i> 階層グループ
                    </button>
                    <button type="button" class="btn-primary-sm" id="btnBarcode">
                        <i class="mdi mdi-barcode"></i> バーコード
                    </button>
                    <button type="button" class="btn-flat-sm" id="btnRefreshList">
                        <i class="mdi mdi-refresh"></i> 更新
                    </button>
                    <span class="list-help">行をクリックすると詳細情報を照会・編集できます。</span>
                </div>
            </div>

            <!-- ===================== 品目登録 / 編集 ===================== -->
            <div class="modal-overlay" id="itemModalOverlay">
                <div class="item-card modal-card">
                    <div class="item-card-head">
                        <h3><i class="mdi mdi-package-variant"></i> 品目登録</h3>
                        <div class="head-btns">
                            <span id="modalMode" class="mode-badge">新規登録</span>
                            <button type="button" class="modal-close" id="closeItemModal">
                                <i class="mdi mdi-close"></i>
                            </button>
                        </div>
                    </div>

                    <div class="item-tabs">
                        <button type="button" class="tab-btn active" data-tab="tab-basic">基本</button>
                        <button type="button" class="tab-btn" data-tab="tab-info">品目情報</button>
                        <button type="button" class="tab-btn" data-tab="tab-qty">数量</button>
                        <button type="button" class="tab-btn" data-tab="tab-price">単価</button>
                        <button type="button" class="tab-btn" data-tab="tab-cost">原価</button>
                        <button type="button" class="tab-btn" data-tab="tab-extra">追加情報</button>
                        <button type="button" class="tab-btn" data-tab="tab-manage">管理対象</button>
                    </div>

                    <form id="itemForm" class="item-form" enctype="multipart/form-data">
                        <input type="hidden" name="itemPk" id="itemPk">

                        <div class="tab-panel active" id="tab-basic">
                            <div class="form-row required">
                                <label>品目コード</label>
                                <div class="field-with-btn">
                                    <input type="text" name="itemCode" id="itemCode" maxlength="20"  placeholder="品目コード">
                                    <button type="button" class="btn-check" id="btnCheckCode">重複確認</button>
                                </div>
                            </div>
                            <div class="form-row required">
                                <label>品目名</label>
                                <input type="text" name="itemName" id="itemName" maxlength="100" placeholder="品目名">
                            </div>
                            <div class="form-row">
                                <label>規格</label>
                                <input type="text" name="spec" id="spec" maxlength="50" placeholder="規格">
                            </div>
                            <div class="form-row">
                                <label>単位</label>
                                <input type="text" name="unit" id="unit" maxlength="20" placeholder="単位 (예: EA, KG)">
                            </div>
                            <div class="form-row">
                                <label>品目区分</label>
                                <div class="radio-group">
                                    <label class="radio-item"><input type="radio" name="itemDiv" value="0"><span>原材料</span></label>
                                    <label class="radio-item"><input type="radio" name="itemDiv" value="1"><span>副資材</span></label>
                                    <label class="radio-item"><input type="radio" name="itemDiv" value="2"><span>製品</span></label>
                                    <label class="radio-item"><input type="radio" name="itemDiv" value="3"><span>半製品</span></label>
                                    <label class="radio-item"><input type="radio" name="itemDiv" value="4" checked><span>商品</span></label>
                                    <label class="radio-item"><input type="radio" name="itemDiv" value="5"><span>無形商品</span></label>
                                </div>
                            </div>
                            <div class="form-row">
                                <label>生産工程</label>
                                <div class="popup-field">
                                    <input type="text" name="prodProcessName" id="prodProcessName" readonly placeholder="生産工程을 選択하세요">
                                    <input type="hidden" name="prodProcessPk" id="prodProcessPk">
                                    <button type="button" class="popup-search-btn" onclick="openMasterPopup('PROD_PROCESS')" title="生産工程 検索"><i class="mdi mdi-magnify"></i></button>
                                </div>
                            </div>
                            <div class="form-row">
                                <label>在庫数量</label>
                                <div class="price-input">
                                    <input type="text" name="qty" id="qty" class="num" placeholder="在庫数量">
                                    <span class="unit-suffix">数量</span>
                                </div>
                            </div>
                            <div class="form-row">
                                <label>入庫単価</label>
                                <input type="text" name="purchasePrice" id="purchasePrice" class="num" placeholder="入庫単価">
                            </div>
                            <div class="form-row">
                                <label>出庫単価</label>
                                <input type="text" name="salesPrice" id="salesPrice" class="num" placeholder="出庫単価">
                            </div>
                        </div>

                        <div class="tab-panel" id="tab-info">
                            <div class="form-row"><label>品目コード</label><input type="text" class="mirror" data-mirror="itemCode" readonly></div>
                            <div class="form-row"><label>品目名</label><input type="text" class="mirror" data-mirror="itemName" readonly></div>
                            <div class="form-row"><label>規格</label><input type="text" class="mirror" data-mirror="spec" readonly></div>
                            <div class="form-row"><label>単位</label><input type="text" class="mirror" data-mirror="unit" readonly></div>
                            <div class="form-row"><label>バーコード</label><input type="text" name="barcode" id="barcode" maxlength="50" placeholder="バーコード"></div>
                            <div class="form-row"><label>検索欄の内容</label><input type="text" name="searchContent" id="searchContent" maxlength="200" placeholder="検索창에서 使用할 추가 検索어"></div>
                            <div class="form-row"><label>消費税率（売上）</label><div class="price-input"><input type="text" name="vatRateSales" id="vatRateSales" class="num" placeholder="0 ~ 100"><span class="unit-suffix">%</span></div></div>
                            <div class="form-row"><label>消費税率（仕入）</label><div class="price-input"><input type="text" name="vatRatePurchase" id="vatRatePurchase" class="num" placeholder="0 ~ 100"><span class="unit-suffix">%</span></div></div>
                        </div>

                        <div class="tab-panel" id="tab-qty">
                            <div class="form-row"><label>品目コード</label><input type="text" class="mirror" data-mirror="itemCode" readonly></div>
                            <div class="info-box">
                                <i class="mdi mdi-information-outline"></i>
                                <div>현재 DDL에서 品目 数量은 <strong>qty</strong> 한 컬럼으로 관리됩니다. 안전재고/주문서 使用有無 등 별도 項目은 스키마에 保存 컬럼이 없어 登録 데이터에서 제외했습니다.</div>
                            </div>
                            <div class="form-row"><label>現在庫数量</label><div class="price-input"><input type="text" class="mirror num" data-mirror="qty" readonly><span class="unit-suffix">数量</span></div></div>
                        </div>

                        <div class="tab-panel" id="tab-price">
                            <div class="form-row"><label>品目コード</label><input type="text" class="mirror" data-mirror="itemCode" readonly></div>
                            <div class="form-row"><label>入庫単価</label><input type="text" class="mirror num" data-mirror="purchasePrice"></div>
                            <div class="form-row"><label>出庫単価</label><input type="text" class="mirror num" data-mirror="salesPrice"></div>
                            <div class="form-row"><label>外注単価</label><input type="text" name="outsourcingPrice" id="outsourcingPrice" class="num" placeholder="外注単価"></div>
                        </div>

                        <div class="tab-panel" id="tab-cost">
                            <div class="form-row"><label>品目コード</label><input type="text" class="mirror" data-mirror="itemCode" readonly></div>
                            <div class="form-row"><label>標準作業時間</label><div class="price-input"><input type="text" name="stdLaborTime" id="stdLaborTime" class="num numeric-decimal" inputmode="decimal" autocomplete="off" placeholder="標準作業時間"><span class="unit-suffix">분</span></div></div>
                            <div class="form-row"><label>経費配賦比率</label><input type="text" name="expenseWeight" id="expenseWeight" class="num numeric-decimal" inputmode="decimal" autocomplete="off" placeholder="経費配賦比率"></div>
                            <div class="form-row"><label>標準原価（材料費）</label><input type="text" name="stdCostMaterial" id="stdCostMaterial" class="num numeric-decimal" inputmode="decimal" autocomplete="off"></div>
                            <div class="form-row"><label>標準原価（経費）</label><input type="text" name="stdCostExpense" id="stdCostExpense" class="num numeric-decimal" inputmode="decimal" autocomplete="off"></div>
                            <div class="form-row"><label>標準原価（労務費）</label><input type="text" name="stdCostLabor" id="stdCostLabor" class="num numeric-decimal" inputmode="decimal" autocomplete="off"></div>
                            <div class="form-row"><label>標準原価（外注費）</label><input type="text" name="stdCostOutsourcing" id="stdCostOutsourcing" class="num numeric-decimal" inputmode="decimal" autocomplete="off"></div>
                        </div>

                        <div class="tab-panel" id="tab-extra">
                            <div class="form-row"><label>品目コード</label><input type="text" class="mirror" data-mirror="itemCode" readonly></div>
                            <div class="form-row"><label>品目グループ1</label><div class="popup-field"><input type="text" name="itemGroup1Name" id="itemGroup1Name" readonly placeholder="品目グループ1 選択"><input type="hidden" name="itemGroup1Pk" id="itemGroup1Pk"><button type="button" class="popup-search-btn" onclick="openMasterPopup('ITEM_GROUP1')" title="品目グループ1 検索"><i class="mdi mdi-magnify"></i></button></div></div>
                            <div class="form-row"><label>品目グループ2</label><div class="popup-field"><input type="text" name="itemGroup2Name" id="itemGroup2Name" readonly placeholder="品目グループ2 選択"><input type="hidden" name="itemGroup2Pk" id="itemGroup2Pk"><button type="button" class="popup-search-btn" onclick="openMasterPopup('ITEM_GROUP2')" title="品目グループ2 検索"><i class="mdi mdi-magnify"></i></button></div></div>
                            <div class="form-row"><label>品目グループ3</label><div class="popup-field"><input type="text" name="itemGroup3Name" id="itemGroup3Name" readonly placeholder="品目グループ3 選択"><input type="hidden" name="itemGroup3Pk" id="itemGroup3Pk"><button type="button" class="popup-search-btn" onclick="openMasterPopup('ITEM_GROUP3')" title="品目グループ3 検索"><i class="mdi mdi-magnify"></i></button></div></div>
                            <div class="form-row"><label>品目階層グループ</label><div class="popup-field"><input type="text" id="itemHierGroupName" readonly placeholder="品目一覧 폴더를 選択하세요"><input type="hidden" name="itemHierGroupPk" id="itemHierGroupPk"><button type="button" class="popup-search-btn" onclick="openItemHierarchySelector('form')" title="品目階層グループ 選択"><i class="mdi mdi-file-tree-outline"></i></button></div></div>
                            <div class="form-row"><label>保管倉庫</label><div class="popup-field"><input type="text" id="warehouseNames" readonly placeholder="보관 倉庫を 選択하세요"><button type="button" class="popup-search-btn" onclick="openItemWarehouseSelector()" title="保管倉庫 選択"><i class="mdi mdi-warehouse"></i></button></div></div>
                            <div class="form-row image-row">
                                <label>品目画像</label>
                                <div class="image-upload-box">
                                    <div class="preview-wrap">
                                        <img id="imagePreview" class="image-preview" alt="品目画像プレビュー">
                                        <div id="imagePreviewEmpty" class="image-preview-empty"><i class="mdi mdi-image-outline"></i><span>画像なし</span></div>
                                    </div>
                                    <div class="image-actions">
                                        <input type="file" name="imageFile" id="imageFile" accept="image/*">
                                        <label for="imageFile" class="file-btn"><i class="mdi mdi-image-plus"></i> 画像を選択</label>
                                        <span id="imageFileName" class="file-name">新しい画像は選択されていません</span>
                                        <small>画像ファイルのみ対応・最大5MB</small>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="tab-panel" id="tab-manage">
                            <div class="form-row"><label>品目コード</label><input type="text" class="mirror" data-mirror="itemCode" readonly></div>
                            <div class="form-row">
                                <label>品質検査方法</label>
                                <div class="radio-group">
                                    <label class="radio-item"><input type="radio" name="qualityInspMethod" value="0" checked><span>全数検査</span></label>
                                    <label class="radio-item"><input type="radio" name="qualityInspMethod" value="1"><span>抜取検査</span></label>
                                    <label class="radio-item"><input type="radio" name="qualityInspMethod" value="2"><span>免除</span></label>
                                </div>
                            </div>
                            <div class="form-row">
                                <label>品質検査種別</label>
                                <div class="popup-field">
                                    <input type="text" name="qualityInspTypeName" id="qualityInspTypeName" readonly placeholder="品質検査種別 選択">
                                    <input type="hidden" name="qualityInspTypePk" id="qualityInspTypePk">
                                    <button type="button" class="popup-search-btn" onclick="openMasterPopup('QUALITY_INSP_TYPE')" title="品質検査種別 検索"><i class="mdi mdi-magnify"></i></button>
                                </div>
                            </div>
                        </div>
                    </form>

                    <div class="item-footer">
                        <button type="button" class="btn-save" id="btnSaveItem">保存(F8) <i class="mdi mdi-chevron-up"></i></button>
                        <button type="button" class="btn-flat" id="btnAgain">再入力</button>
                        <button type="button" class="btn-flat btn-danger-outline" id="btnModalDelete" style="display:none;">削除</button>
                        <button type="button" class="btn-flat" id="btnCloseFooter">閉じる</button>
                    </div>
                </div>
            </div>

            <!-- ===================== 品目 変更: 項目検索 ===================== -->
            <div class="modal-overlay utility-overlay change-field-overlay" id="itemChangeFieldOverlay">
                <div class="utility-card change-field-card">
                    <div class="utility-head change-field-head">
                        <div><h3><i class="mdi mdi-format-list-checks"></i> 項目検索</h3><p>変更할 컬럼을 選択하세요. 品目名은 基本 컬럼으로 함께 표시됩니다.</p></div>
                        <button type="button" class="modal-close" onclick="closeItemChangeFields()"><i class="mdi mdi-close"></i></button>
                    </div>
                    <div class="change-field-quick-actions"><button type="button" class="btn-flat-sm" id="itemChangeBasicFields"><i class="mdi mdi-star-outline"></i> 基本項目</button></div>
                    <div class="change-field-body-wrap">
                        <table class="change-field-table">
                            <thead><tr><th class="change-check-col"><input type="checkbox" id="itemChangeFieldAll"></th><th>項目명</th></tr></thead>
                            <tbody id="itemChangeFieldBody"></tbody>
                        </table>
                    </div>
                    <div class="utility-footer change-field-footer">
                        <span class="change-selection-count" id="itemChangeFieldCount">1項目選択済み</span>
                        <button type="button" class="btn-primary-sm" onclick="applyItemChangeFields()">적용(F8)</button>
                        <button type="button" class="btn-flat-sm" onclick="closeItemChangeFields()">閉じる</button>
                    </div>
                </div>
            </div>

            <!-- ===================== 品目 変更: 選択 컬럼 그리드 ===================== -->
            <div class="modal-overlay utility-overlay change-grid-overlay" id="itemChangeGridOverlay">
                <div class="change-grid-card">
                    <div class="change-grid-head">
                        <div><h3><i class="mdi mdi-pencil-table"></i> 変更</h3><p><strong id="itemChangeTargetCount">0개</strong> 品目に서 選択した 項目만 編集합니다.</p></div>
                        <button type="button" class="modal-close" onclick="closeItemChangeGrid()"><i class="mdi mdi-close"></i></button>
                    </div>
                    <div class="change-grid-tools">
                        <button type="button" class="btn-flat-sm" onclick="backToItemChangeFields()"><i class="mdi mdi-format-list-checks"></i> 変更項目選択</button>
                        <div class="change-grid-tip">왼쪽 品目コード는 고정됩니다. 選択した 컬럼만 편집할 수 있습니다.</div>
                    </div>
                    <div class="change-grid-wrap" id="itemChangeGridWrap"></div>
                    <div class="change-common-row" id="itemChangeCommonRow">
                        <select id="itemChangeCommonField" aria-label="공통 変更 項目"></select>
                        <div id="itemChangeCommonControl" class="change-common-control"></div>
                        <button type="button" class="btn-primary-sm" id="itemChangeCommonApply">選択 행에 적용</button>
                    </div>
                    <div class="utility-footer change-grid-footer">
                        <span class="change-selection-count" id="itemChangeRowCount">0件の品目を選択済み</span>
                        <button type="button" class="btn-primary-sm" onclick="saveItemChangeGrid()">保存(F8)</button>
                        <button type="button" class="btn-flat-sm" onclick="closeItemChangeGrid()">閉じる</button>
                    </div>
                </div>
            </div>

            <!-- ===================== 品目階層グループ / 品目一覧 폴더 ===================== -->
            <div class="modal-overlay utility-overlay" id="itemHierarchyOverlay">
                <div class="utility-card hierarchy-card">
                    <div class="utility-head">
                        <div><h3><i class="mdi mdi-file-tree-outline"></i> 品目階層グループ</h3><p>品目 一覧를 폴더처럼 분류하는 階層グループ입니다.</p></div>
                        <button type="button" class="modal-close" onclick="closeItemHierarchy()"><i class="mdi mdi-close"></i></button>
                    </div>
                    <div class="hierarchy-layout">
                        <div id="itemHierarchyTree" class="hierarchy-tree"><div class="hierarchy-empty">階層グループ을 불러오는 중입니다.</div></div>
                        <div class="hierarchy-manage">
                            <div class="hierarchy-selected-label">選択 그룹</div>
                            <div id="itemHierarchySelected" class="hierarchy-selected">未選択</div>
                            <div class="hierarchy-manage-grid">
                                <input type="text" id="itemHierarchyCode" maxlength="20" placeholder="그룹 コード">
                                <input type="text" id="itemHierarchyName" maxlength="100" placeholder="グループ名">
                            </div>
                            <div class="hierarchy-parent-text">新規 登録 시 選択済みの 폴더 아래에 하위 폴더로 생성합니다. 選択済みの 그룹이 없으면 최상위 폴더입니다.</div>
                            <div class="hierarchy-manage-buttons">
                                <button type="button" class="btn-primary-sm" onclick="createItemHierarchyGroup()">新規</button>
                                <button type="button" class="btn-flat-sm" onclick="editItemHierarchyGroup()">編集</button>
                                <button type="button" class="btn-flat-sm danger-sm" onclick="deleteItemHierarchyGroup()">削除</button>
                            </div>
                            <div class="hierarchy-members">
                                <div class="hierarchy-members-title">이 폴더에 들어있는 品目</div>
                                <div id="itemHierarchyMemberList" class="member-list"><div class="empty-members">フォルダーを選択すると品目一覧が表示されます。</div></div>
                            </div>
                        </div>
                    </div>
                    <div class="utility-footer"><span class="hierarchy-mode-help" id="itemHierarchyModeHelp">品目登録에 適用する グループを 選択하세요.</span><button type="button" class="btn-primary-sm" onclick="selectItemHierarchyGroup()">選択</button><button type="button" class="btn-flat-sm" onclick="closeItemHierarchy()">閉じる</button></div>
                </div>
            </div>

            <!-- ===================== 品目 保管倉庫 選択 ===================== -->
            <div class="modal-overlay utility-overlay" id="itemWarehouseOverlay">
                <div class="utility-card warehouse-selector-card">
                    <div class="utility-head">
                        <div><h3><i class="mdi mdi-warehouse"></i> 保管倉庫 選択</h3><p>品目は 保管倉庫を 최대 1개만 지정할 수 있습니다.</p></div>
                        <button type="button" class="modal-close" onclick="closeItemWarehouseSelector()"><i class="mdi mdi-close"></i></button>
                    </div>
                    <div class="warehouse-selector-list" id="itemWarehouseList"><div class="hierarchy-empty">倉庫を 불러오는 중입니다.</div></div>
                    <div class="utility-footer"><span class="hierarchy-mode-help" id="warehouseSelectHelp">選択済みの 倉庫 0개</span><button type="button" class="btn-primary-sm" onclick="applyItemWarehouseSelection()">選択</button><button type="button" class="btn-flat-sm" onclick="closeItemWarehouseSelector()">閉じる</button></div>
                </div>
            </div>

            <!-- ===================== バーコード(品目) ===================== -->
            <div class="modal-overlay barcode-overlay" id="barcodeOverlay">
                <div class="barcode-card">
                    <div class="barcode-card-head">
                        <div>
                            <h3><i class="mdi mdi-barcode"></i> バーコード(品目)</h3>
                            <p>選択した 品目의 バーコード를 조회하고 印刷할 수 있습니다.</p>
                        </div>
                        <button type="button" class="modal-close" id="closeBarcode"><i class="mdi mdi-close"></i></button>
                    </div>

                    <div class="barcode-notice">
                        <i class="mdi mdi-information-outline"></i> バーコード가 없는 品目は <strong>99887766 + 品目PK 4자리</strong> 규칙으로 자동 생성됩니다. 예: 品目 PK 1 → 998877660001
                    </div>

                    <div class="barcode-table-wrap">
                        <table class="barcode-table">
                            <thead>
                            <tr>
                                <th class="barcode-check-col"><input type="checkbox" id="barcodeCheckAll" checked></th>
                                <th class="barcode-qty-col">数量</th>
                                <th>品目コード</th>
                                <th>品目名</th>
                                <th>規格</th>
                                <th>バーコード</th>
                            </tr>
                            </thead>
                            <tbody id="barcodeTbody">
                            <tr><td colspan="6" class="barcode-empty">バーコード 대상 品目を 불러오는 중입니다.</td></tr>
                            </tbody>
                        </table>
                    </div>

                    <div class="barcode-card-foot">
                        <span class="barcode-help">数量은 印刷할 라벨 장수입니다. 印刷 시 종류 1~4가 모두 출력됩니다.</span>
                        <button type="button" class="btn-flat-sm" id="btnBarcodeClose">閉じる</button>
                        <button type="button" class="btn-primary-sm" id="btnBarcodePrint"><i class="mdi mdi-eye-outline"></i> バーコード プレビュー</button>
                    </div>
                </div>
            </div>

            <!-- ===================== 生産工程 / 品目グループ / 品質検査種別 공통 検索 팝업 ===================== -->
            <div class="modal-overlay master-overlay" id="masterSearchOverlay">
                <div class="master-card">
                    <div class="master-card-head">
                        <h3><i class="mdi mdi-format-list-bulleted-square"></i> <span id="masterPopupTitle">마스터 検索</span></h3>
                        <button type="button" class="modal-close" id="closeMasterSearch"><i class="mdi mdi-close"></i></button>
                    </div>
                    <div class="master-searchbar">
                        <input type="text" id="masterSearchInput" placeholder="コード 또는 명칭 検索後Enter">
                        <button type="button" class="btn-primary-sm" id="btnMasterSearch"><i class="mdi mdi-magnify"></i> 検索</button>
                    </div>
                    <div class="master-table-wrap">
                        <table class="master-table">
                            <thead><tr><th style="width:150px">コード</th><th>명</th></tr></thead>
                            <tbody id="masterTbody"></tbody>
                        </table>
                    </div>
                    <div class="master-footer">
                        <button type="button" class="btn-primary-sm" id="btnMasterNew"><i class="mdi mdi-plus"></i> 新規(F2)</button>
                        <button type="button" class="btn-flat-sm" id="btnMasterModify"><i class="mdi mdi-pencil-outline"></i> 編集</button>
                        <button type="button" class="btn-flat-sm danger-sm" id="btnMasterDelete"><i class="mdi mdi-delete-outline"></i> 削除</button>
                        <span class="master-footer-spacer"></span>
                        <button type="button" class="btn-primary-sm" id="btnMasterSelect"><i class="mdi mdi-check"></i> 選択</button>
                        <button type="button" class="btn-flat-sm" id="btnMasterClose">閉じる</button>
                    </div>
                </div>
            </div>

            <!-- ===================== 공통 마스터 登録 (品質検査種別은 選択 전용) ===================== -->
            <div class="modal-overlay master-overlay register-overlay" id="masterRegisterOverlay">
                <div class="master-register-card">
                    <div class="master-card-head">
                        <h3><i class="mdi mdi-form-textbox"></i> <span id="masterRegisterTitle">마스터 登録</span></h3>
                        <button type="button" class="modal-close" id="closeMasterRegister"><i class="mdi mdi-close"></i></button>
                    </div>
                    <form id="masterForm" class="master-form">
                        <input type="hidden" id="masterPk" name="pk">
                        <div class="master-form-row">
                            <label id="masterCodeLabel">コード</label>
                            <input type="text" id="masterCode" name="code" maxlength="20" autocomplete="off">
                        </div>
                        <div class="master-form-row">
                            <label id="masterNameLabel">명</label>
                            <input type="text" id="masterName" name="name" maxlength="100" autocomplete="off">
                        </div>
                    </form>
                    <div class="master-footer">
                        <button type="button" class="btn-primary-sm" id="btnMasterSave">保存(F8) <i class="mdi mdi-chevron-up"></i></button>
                        <button type="button" class="btn-flat-sm" id="btnMasterCancel">閉じる</button>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<style>
    .page-title{font-size:1.25rem;font-weight:700;color:var(--text-main,#0B1026);margin-bottom:20px;display:flex;align-items:center;gap:10px}.page-title i{color:var(--color-blue,#4B88FF);font-size:24px}
    /* 品目一覧가 화면보다 길어져도 메인 영역을 밀어내지 않고 가로 스크롤 */
    .erp-main,.erp-content{min-width:0;}
    .list-wrap{background:#fff;border-radius:14px;border:1px solid var(--border-color,#e2e8f0);box-shadow:var(--shadow-soft,0 10px 25px -5px rgba(75,136,255,.08));overflow:hidden;min-width:0;width:100%;box-sizing:border-box;}
    .list-head{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;padding:20px 22px 16px;border-bottom:1px solid var(--border-color,#e2e8f0)}
    .list-title{font-size:1.1rem;font-weight:800;color:var(--text-main,#0B1026);display:flex;align-items:center;gap:8px}.list-title i{color:#f5b301;font-size:20px}
    .list-toolbar{display:flex;align-items:center;gap:8px;flex-wrap:wrap}.search-box input{border:1px solid var(--border-color,#e2e8f0);border-radius:8px;padding:9px 12px;font-size:13px;width:320px;outline:none}.search-box input:focus{border-color:var(--color-blue,#4B88FF)}
    .btn-primary-sm,.btn-flat-sm,.btn-save,.btn-flat,.btn-check{display:inline-flex;align-items:center;justify-content:center;gap:4px;cursor:pointer;border-radius:8px;font-weight:700}
    .btn-primary-sm{background:var(--color-blue,#4B88FF);color:#fff;border:none;font-size:13px;padding:8px 14px}.btn-primary-sm:hover{background:var(--color-navy,#1F3C88)}
    .btn-flat-sm{background:#f8fafc;border:1px solid var(--border-color,#e2e8f0);color:var(--text-sub,#64748b);font-size:13px;padding:8px 14px}.btn-flat-sm:hover{background:#eef2f7}
    .list-table-wrap{
        width:100% !important;
        max-width:100% !important;
        overflow-x:auto;
        overflow-y:hidden;
        -webkit-overflow-scrolling:touch;
        padding:0 !important;
        margin:0 !important;
        box-sizing:border-box;
    }
    .list-table-wrap::-webkit-scrollbar{height:12px}
    .list-table-wrap::-webkit-scrollbar-track{background:#f1f5f9;border-top:1px solid #e2e8f0}
    .list-table-wrap::-webkit-scrollbar-thumb{background:#b8c4d3;border-radius:8px;border:3px solid #f1f5f9}
    .list-table-wrap::-webkit-scrollbar-thumb:hover{background:#94a3b8}
    
    /* 표(Grid) 형태를 명확히 하기 위한 테두리(세로선/가로선) 설정 */
    .list-table{
        width:100% !important;
        min-width:100% !important;
        border-collapse:collapse;
        table-layout:fixed;
        margin:0 !important;
        border:1px solid var(--border-color,#e2e8f0);
    }
    .list-table thead th{
        background:#f4f7fc;
        color:var(--text-sub,#64748b);
        font-size:12.5px;
        font-weight:700;
        text-align:left;
        padding:11px 14px;
        white-space:nowrap;
        border-right:1px solid var(--border-color,#e2e8f0);
        border-bottom:1px solid var(--border-color,#e2e8f0);
        overflow:hidden;
        text-overflow:ellipsis;
        box-sizing:border-box;
    }
    .list-table thead th:last-child{
        border-right:none;
    }
    .list-table tbody td{
        padding:9px 14px;
        font-size:13px;
        color:var(--text-main,#0B1026);
        border-right:1px solid var(--border-color,#e2e8f0);
        border-bottom:1px solid #e2e8f0;
        white-space:nowrap;
        overflow:hidden;
        text-overflow:ellipsis;
        box-sizing:border-box;
    }
    .list-table tbody td:last-child{
        border-right:none;
    }

    .list-table thead th.col-chk,.list-table tbody td.col-chk{width:45px;text-align:center}.list-table thead th.col-image,.list-table tbody td.col-image{width:80px;text-align:center}.list-table thead th.col-num,.list-table tbody td.col-num{text-align:right;font-variant-numeric:tabular-nums}.list-table tbody tr{cursor:pointer;transition:background .1s ease}.list-table tbody tr:hover{background:#f7faff}.row-link{color:var(--color-blue,#4B88FF);font-weight:700;text-decoration:none}.row-link:hover{text-decoration:underline}.code-link{font-variant-numeric:tabular-nums}.empty-row{text-align:center!important;padding:42px!important;color:#94a3b8!important}
    .item-thumb{width:46px;height:46px;margin:0 auto;border:1px solid #dce3ed;border-radius:99px;object-fit:cover;background:#f8fafc}.item-thumb-empty{display:flex;align-items:center;justify-content:center;background:linear-gradient(145deg,#f8fbff,#edf2f8)}.item-thumb-empty i{font-size:25px;color:#91a0b4}
    .pagination-wrap{padding:14px 22px}.pagination{display:flex;justify-content:center;gap:5px}.pagination li a{display:flex;align-items:center;justify-content:center;min-width:34px;height:32px;padding:0 9px;border:1px solid var(--border-color,#e2e8f0);border-radius:7px;color:#64748b;background:#fff;font-size:13px}.pagination li.active a{background:var(--color-blue,#4B88FF);border-color:var(--color-blue,#4B88FF);color:#fff;font-weight:800}
    .list-footer{display:flex;align-items:center;gap:8px;flex-wrap:wrap;padding:16px 22px;background:#f8fafc;border-top:1px solid var(--border-color,#e2e8f0)}.list-help{margin-left:auto;color:#94a3b8;font-size:12px}
    @media (max-width: 900px){
        .erp-content{padding:20px;}
        .list-table-wrap{overflow-x:auto;}
        .list-table{min-width:850px !important;}
    }
    .modal-overlay{display:none;position:fixed;inset:0;background:rgba(11,16,38,.45);align-items:flex-start;justify-content:center;padding:4vh 20px;z-index:1000;overflow-y:auto}.modal-overlay.active{display:flex}.modal-card{animation:modalPop .15s ease}@keyframes modalPop{from{opacity:0;transform:translateY(-10px)}to{opacity:1;transform:translateY(0)}}
    .item-card{background:#fff;border-radius:14px;border:1px solid var(--border-color,#e2e8f0);box-shadow:0 20px 45px -10px rgba(11,16,38,.25);max-width:790px;width:100%;overflow:hidden;display:flex;flex-direction:column}.item-card-head{display:flex;align-items:center;justify-content:space-between;padding:18px 22px 10px}.item-card-head h3{font-size:1.1rem;font-weight:800;color:var(--text-main,#0B1026);display:flex;align-items:center;gap:8px}.item-card-head h3 i{color:var(--color-blue,#4B88FF)}.head-btns{display:flex;align-items:center;gap:9px}.mode-badge{font-size:11px;font-weight:800;padding:4px 8px;border-radius:999px;background:#eef4ff;color:#1f3c88}.modal-close{border:none;background:#f1f5f9;color:#64748b;width:32px;height:32px;border-radius:50%;cursor:pointer}.modal-close:hover{background:#fee2e2;color:#dc2626}
    .item-tabs{display:flex;gap:6px;padding:8px 22px 16px;flex-wrap:wrap}.tab-btn{border:none;background:#eef4ff;color:#1f3c88;font-weight:700;font-size:13px;padding:8px 16px;border-radius:999px;cursor:pointer}.tab-btn:hover{background:#dce9ff}.tab-btn.active{background:var(--color-blue,#4B88FF);color:#fff}
    .item-form{border-top:1px solid var(--border-color,#e2e8f0);padding:22px;max-height:68vh;overflow-y:auto}.tab-panel{display:none;flex-direction:column;gap:15px}.tab-panel.active{display:flex}.form-row{display:grid;grid-template-columns:150px 1fr;align-items:center;gap:14px}.form-row>label{font-size:13.5px;font-weight:700;color:var(--text-main,#0B1026)}.required>label:after{content:' *';color:#dc2626}
    .form-row input[type=text],.form-row select{width:100%;border:1px solid var(--border-color,#e2e8f0);border-radius:8px;padding:9px 12px;font-size:13.5px;outline:none;background:#fff}.form-row input[readonly]{background:#f4f7fc;color:#64748b}.form-row input:focus,.form-row select:focus{border-color:var(--color-blue,#4B88FF)}.num{text-align:right}.radio-group{display:flex;flex-wrap:wrap;gap:13px}.radio-item{display:flex;align-items:center;gap:5px;font-size:13.5px;color:var(--text-main,#0B1026);cursor:pointer}.radio-item input{accent-color:var(--color-blue,#4B88FF)}.price-input{display:flex;align-items:center;gap:8px}.price-input input{flex:1}.unit-suffix{font-size:13px;color:#64748b;white-space:nowrap}.field-with-btn{display:flex;gap:8px}.field-with-btn input{flex:1}.btn-check{border:1px solid #bfd0f5;background:#eef4ff;color:#1f3c88;font-size:12px;padding:0 11px;white-space:nowrap}.mirror{background:#f4f7fc!important}.info-box{display:flex;gap:9px;align-items:flex-start;padding:12px 14px;background:#f8fafc;border:1px solid var(--border-color,#e2e8f0);border-radius:8px;color:#64748b;font-size:12.5px}.info-box i{color:var(--color-blue,#4B88FF);font-size:18px}
    .image-upload-box{display:flex;gap:16px;align-items:center;padding:12px;background:#f8fafc;border:1px solid var(--border-color,#e2e8f0);border-radius:10px}.preview-wrap{width:100px;height:100px;border-radius:10px;background:#fff;border:1px solid #dce3ed;display:flex;align-items:center;justify-content:center;overflow:hidden;flex:none}.image-preview{display:none;max-width:100%;max-height:100%;object-fit:contain}.image-preview-empty{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;color:#94a3b8;font-size:11px}.image-preview-empty i{font-size:28px}.image-actions{display:flex;flex-direction:column;align-items:flex-start;gap:7px}.image-actions input[type=file]{display:none}.file-btn{display:inline-flex;align-items:center;gap:6px;background:var(--color-blue,#4B88FF);color:#fff;font-weight:700;padding:8px 12px;border-radius:8px;font-size:13px;cursor:pointer}.file-name{font-size:12px;color:#64748b}.image-actions small{color:#94a3b8;font-size:11px}
    .item-footer{border-top:1px solid var(--border-color,#e2e8f0);display:flex;align-items:center;gap:8px;padding:14px 22px;background:#f8fafc}.btn-save{background:var(--color-blue,#4B88FF);color:#fff;border:none;font-size:13.5px;padding:10px 18px}.btn-save:hover{background:var(--color-navy,#1F3C88)}.btn-flat{background:#fff;border:1px solid var(--border-color,#e2e8f0);color:var(--text-main,#0B1026);font-size:13px;padding:9px 14px}.btn-flat:hover{background:#eef2f7}.btn-danger-outline{color:#b91c1c;border-color:#fecaca}.btn-danger-outline:hover{background:#fef2f2}

    /* ===================== 공통 마스터 팝업 ===================== */
    .popup-field{display:flex;align-items:center;gap:7px}.popup-field input[type=text]{flex:1}.popup-search-btn{width:38px;height:38px;flex:none;border:1px solid #cbd5e1;border-radius:8px;background:#f8fafc;color:#1f3c88;cursor:pointer}.popup-search-btn:hover{background:#eef4ff;border-color:#9fb8ec}
    .barcode-overlay{z-index:1080;padding-top:6vh}.barcode-card{width:min(1040px,97vw);background:#fff;border:1px solid var(--border-color,#e2e8f0);border-radius:14px;box-shadow:0 20px 55px -12px rgba(11,16,38,.3);overflow:hidden;animation:modalPop .15s ease}.barcode-card-head{display:flex;align-items:center;justify-content:space-between;padding:18px 20px 14px;border-bottom:1px solid var(--border-color,#e2e8f0)}.barcode-card-head h3{font-size:1.1rem;font-weight:800;color:var(--text-main,#0B1026);display:flex;align-items:center;gap:8px}.barcode-card-head h3 i{color:var(--color-blue,#4B88FF)}.barcode-card-head p{margin:5px 0 0;color:#64748b;font-size:12px}.barcode-notice{margin:14px 18px 0;padding:10px 12px;border-radius:8px;background:#f7faff;border:1px solid #dbe8ff;color:#455468;font-size:12px}.barcode-table-wrap{max-height:450px;overflow:auto;margin-top:12px}.barcode-table{width:100%;border-collapse:collapse;min-width:850px}.barcode-table th{position:sticky;top:0;z-index:1;background:#f4f7fc;color:#64748b;font-size:12.5px;text-align:center;padding:10px 12px;border-bottom:1px solid #e2e8f0;white-space:nowrap}.barcode-table td{padding:10px 12px;border-bottom:1px solid #eef2f7;font-size:13px;color:#0B1026;text-align:center}.barcode-table tbody tr:hover td{background:#f7faff}.barcode-check-col{width:42px}.barcode-qty-col{width:85px}.barcode-check{width:17px;height:17px}.barcode-qty{width:65px;text-align:right;border:1px solid #dbe3ed;border-radius:7px;padding:7px 8px;outline:none}.barcode-qty:focus{border-color:var(--color-blue,#4B88FF);box-shadow:0 0 0 2px rgba(75,136,255,.08)}.barcode-value{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-weight:700;letter-spacing:.3px}.barcode-empty{padding:36px!important;color:#94a3b8!important}.barcode-card-foot{display:flex;align-items:center;gap:8px;padding:13px 18px;background:#f8fafc;border-top:1px solid var(--border-color,#e2e8f0)}.barcode-help{margin-right:auto;color:#64748b;font-size:11.5px}.barcode-print-only{display:none}.barcode-preview-window{background:#f1f5f9}.barcode-preview-toolbar{position:sticky;top:0;z-index:20;display:flex;align-items:center;gap:8px;padding:12px 16px;background:#fff;border-bottom:1px solid #dbe3ed;box-shadow:0 2px 8px rgba(15,23,42,.08)}.barcode-preview-toolbar .preview-title{font-weight:800;font-size:15px;margin-right:auto}.barcode-preview-toolbar button{border:1px solid #cbd5e1;background:#fff;color:#0f172a;border-radius:7px;padding:8px 13px;font-weight:700;cursor:pointer}.barcode-preview-toolbar button.primary{background:#4B88FF;border-color:#4B88FF;color:#fff}.barcode-preview-toolbar button:hover{filter:brightness(.98)}.barcode-preview-body{padding:24px}
    .master-overlay{z-index:1100;padding-top:7vh}.register-overlay{z-index:1200}.master-card,.master-register-card{width:min(720px,96vw);background:#fff;border:1px solid var(--border-color,#e2e8f0);border-radius:14px;box-shadow:0 20px 55px -12px rgba(11,16,38,.3);overflow:hidden;animation:modalPop .15s ease}.master-register-card{width:min(520px,94vw)}
    .master-card-head{display:flex;align-items:center;justify-content:space-between;padding:16px 18px 13px;border-bottom:1px solid var(--border-color,#e2e8f0)}.master-card-head h3{margin:0;font-size:17px;font-weight:800;color:var(--text-main,#0B1026);display:flex;align-items:center;gap:7px}.master-card-head h3 i{color:var(--color-blue,#4B88FF)}
    .master-searchbar{display:flex;gap:8px;padding:14px 18px;background:#f8fafc;border-bottom:1px solid var(--border-color,#e2e8f0)}.master-searchbar input{flex:1;min-width:0;border:1px solid var(--border-color,#e2e8f0);border-radius:8px;padding:9px 11px;font-size:13px;outline:none}.master-searchbar input:focus{border-color:var(--color-blue,#4B88FF)}
    .master-table-wrap{max-height:430px;overflow:auto}.master-table{width:100%;border-collapse:collapse}.master-table th{position:sticky;top:0;background:#f4f7fc;color:#64748b;font-size:12.5px;text-align:left;padding:10px 14px;border-bottom:1px solid #e2e8f0}.master-table td{padding:10px 14px;border-bottom:1px solid #eef2f7;font-size:13px;color:#0B1026;cursor:pointer}.master-table tr:hover td{background:#f7faff}.master-table tr.selected td{background:#e8f0ff;color:#1f3c88;font-weight:700}.master-empty td{text-align:center;color:#94a3b8;padding:35px}
    .master-footer{display:flex;align-items:center;gap:8px;padding:13px 18px;background:#f8fafc;border-top:1px solid var(--border-color,#e2e8f0)}.master-footer-spacer{flex:1}.danger-sm{color:#b91c1c!important;border-color:#fecaca!important;background:#fff!important}.danger-sm:hover{background:#fef2f2!important}.master-form{padding:22px 20px}.master-form-row{display:grid;grid-template-columns:170px 1fr;align-items:center;gap:14px;margin-bottom:16px}.master-form-row:last-child{margin-bottom:0}.master-form-row label{font-size:13.5px;font-weight:700;color:#0B1026}.master-form-row input{width:100%;border:1px solid #dbe3ed;border-radius:8px;padding:10px 12px;font-size:13.5px;outline:none}.master-form-row input:focus{border-color:var(--color-blue,#4B88FF);box-shadow:0 0 0 2px rgba(75,136,255,.08)}

    .utility-overlay{z-index:1200;padding-top:7vh}.utility-card{width:min(760px,96vw);background:#fff;border:1px solid #e2e8f0;border-radius:14px;box-shadow:0 20px 55px -12px rgba(11,16,38,.3);overflow:hidden;animation:modalPop .15s ease}.utility-head{display:flex;align-items:flex-start;justify-content:space-between;padding:18px 20px 14px;border-bottom:1px solid #e2e8f0}.utility-head h3{margin:0;font-size:17px;font-weight:800;color:#0B1026;display:flex;align-items:center;gap:8px}.utility-head h3 i{color:#4B88FF}.utility-head p{margin:5px 0 0;color:#64748b;font-size:12px}.utility-body{padding:20px}.utility-body .form-row{margin-bottom:15px}.utility-body .form-row:last-child{margin-bottom:0}.utility-footer{display:flex;align-items:center;gap:8px;padding:13px 18px;background:#f8fafc;border-top:1px solid #e2e8f0}.hierarchy-layout{display:grid;grid-template-columns:1.35fr .9fr;min-height:390px}.hierarchy-tree{padding:16px;overflow:auto;border-right:1px solid #e2e8f0;background:#fbfdff}.hierarchy-manage{padding:18px}.hierarchy-node{display:flex;align-items:center;gap:7px;padding:7px 9px;border-radius:7px;cursor:pointer;font-size:13px;color:#334155}.hierarchy-node:hover{background:#eef4ff}.hierarchy-node.selected{background:#e8f0ff;color:#1f3c88;font-weight:800}.hierarchy-children{padding-left:19px}.hierarchy-empty{padding:35px 15px;color:#94a3b8;text-align:center;font-size:13px}.hierarchy-selected-label{font-size:11px;color:#64748b;font-weight:700;margin-bottom:5px}.hierarchy-selected{padding:10px 11px;border:1px solid #dbe3ed;border-radius:8px;background:#f8fafc;font-size:13px;margin-bottom:14px}.hierarchy-manage-grid{display:grid;grid-template-columns:1fr;gap:8px}.hierarchy-manage-grid input,.warehouse-search-input{width:100%;box-sizing:border-box;border:1px solid #dbe3ed;border-radius:8px;padding:9px 11px;font-size:13px;outline:none}.hierarchy-parent-text{margin-top:9px;color:#64748b;font-size:11px;line-height:1.5}.hierarchy-manage-buttons{display:flex;gap:7px;margin-top:14px}.hierarchy-members{margin-top:14px;border-top:1px solid #e2e8f0;padding-top:12px}.hierarchy-members-title{font-size:12px;font-weight:800;color:#334155;margin-bottom:7px}.member-list{max-height:145px;overflow:auto;border:1px solid #e2e8f0;border-radius:8px;background:#fff}.member-row{display:grid;grid-template-columns:82px 1fr auto;gap:7px;align-items:center;padding:7px 8px;border-bottom:1px solid #eef2f7;font-size:11px}.member-row:last-child{border-bottom:none}.item-member-row{grid-template-columns:95px 1fr 120px}.item-member-row .spec{text-align:right;color:#64748b}.member-row .code{color:#64748b}.member-row .name{font-weight:700;color:#334155;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.member-row .status{color:#64748b}.empty-members{padding:14px 8px;color:#94a3b8;text-align:center;font-size:11px}.hierarchy-mode-help{margin-right:auto;color:#64748b;font-size:11.5px}.warehouse-selector-card{width:min(620px,96vw)}.warehouse-selector-list{max-height:450px;overflow:auto;padding:8px 18px}.warehouse-option{display:flex;align-items:center;gap:10px;padding:11px 8px;border-bottom:1px solid #eef2f7;cursor:pointer}.warehouse-option:hover{background:#f7faff}.warehouse-option input{width:17px;height:17px}.warehouse-option-main{display:flex;flex-direction:column;gap:2px}.warehouse-option-main strong{font-size:13px}.warehouse-option-main span{font-size:11px;color:#64748b}.bulk-help{padding:10px 12px;border-radius:8px;background:#f7faff;border:1px solid #dbe8ff;color:#64748b;font-size:11.5px;line-height:1.5}.warehouse-selector-card .utility-footer{position:sticky;bottom:0}.danger-sm{color:#b91c1c!important;border-color:#fecaca!important;background:#fff!important}.danger-sm:hover{background:#fef2f2!important}@media(max-width:720px){.hierarchy-layout{grid-template-columns:1fr}.hierarchy-tree{border-right:none;border-bottom:1px solid #e2e8f0;max-height:310px}}

    /* ===================== 変更 기능 공통 UI ===================== */
    .change-field-overlay{padding-top:6vh!important;}
    .change-field-card{width:min(640px,96vw)!important;max-height:88vh;display:flex;flex-direction:column;}
    .change-field-head{padding:15px 18px 12px;}
    .change-field-head h3{font-size:16px!important;}
    .change-field-quick-actions{padding:10px 16px 8px;background:#fff;display:flex;align-items:center;}
    .change-field-body-wrap{max-height:60vh;overflow:auto;border-top:1px solid #e2e8f0;border-bottom:1px solid #e2e8f0;}
    .change-field-table{width:100%;border-collapse:collapse;table-layout:fixed;}
    .change-field-table th,.change-field-table td{border-right:1px solid #e2e8f0;border-bottom:1px solid #e2e8f0;}
    .change-field-table th:last-child,.change-field-table td:last-child{border-right:none;}
    .change-field-table thead th{position:sticky;top:0;z-index:3;background:#f4f7fc;color:#52627f;font-size:12px;font-weight:800;padding:9px 12px;text-align:left;}
    .change-field-table tbody td{height:34px;padding:6px 12px;background:#fff;font-size:12px;color:#0f172a;}
    .change-field-table tbody tr:hover td{background:#f7faff;}
    .change-field-table .change-check-col{width:42px;text-align:center;padding:0!important;}
    .change-field-table input[type=checkbox]{width:16px;height:16px;accent-color:#2952d3;cursor:pointer;}
    .change-field-table input[type=checkbox]:disabled{opacity:.55;cursor:not-allowed;}
    .change-field-group td{background:#f7f9fd!important;font-weight:800;color:#294a9c!important;}
    .change-field-group .change-check-col{background:#eef3ff!important;}
    .group-label{font-weight:800;}
    .group-count{float:right;font-size:10px;font-weight:700;color:#94a3b8;}
    .field-label{display:inline-block;padding-left:4px;}
    .field-required-badge{margin-left:7px;display:inline-flex;align-items:center;padding:1px 5px;border-radius:999px;background:#eef3ff;color:#2952d3;font-size:9px;font-weight:800;vertical-align:middle;}
    .change-field-item.required td{background:#fbfcff;}
    .change-field-footer{min-height:48px;}
    .change-selection-count{margin-right:auto;color:#64748b;font-size:11px;font-weight:700;}
    .change-grid-overlay{padding:5vh 14px 16px!important;}
    .change-grid-card{width:min(1180px,97vw);max-height:90vh;background:#fff;border:1px solid #d7e0ec;border-radius:14px;box-shadow:0 25px 70px -18px rgba(11,16,38,.35);overflow:hidden;display:flex;flex-direction:column;animation:modalPop .15s ease;}
    .change-grid-head{display:flex;align-items:center;justify-content:space-between;padding:13px 16px 10px;border-bottom:1px solid #e2e8f0;background:#fff;flex:0 0 auto;}
    .change-grid-head h3{margin:0;font-size:16px;font-weight:800;color:#0B1026;display:flex;align-items:center;gap:7px;}
    .change-grid-head h3 i{color:#2952d3;}
    .change-grid-head p{margin:3px 0 0;color:#64748b;font-size:11px;}
    .change-grid-tools{display:flex;align-items:center;gap:9px;padding:8px 12px;background:#f8fafc;border-bottom:1px solid #e2e8f0;flex:0 0 auto;}
    .change-grid-tip{margin-left:auto;font-size:10.5px;color:#64748b;}
    .change-grid-wrap{min-height:90px;max-height:57vh;overflow:auto;border-bottom:1px solid #e2e8f0;overscroll-behavior:contain;}
    .change-grid-wrap::-webkit-scrollbar{height:11px;width:11px;}
    .change-grid-wrap::-webkit-scrollbar-track{background:#f1f5f9;}
    .change-grid-wrap::-webkit-scrollbar-thumb{background:#aebccc;border-radius:8px;border:3px solid #f1f5f9;}
    .change-grid-table{min-width:max-content;border-collapse:separate;border-spacing:0;table-layout:fixed;}
    .change-grid-table th,.change-grid-table td{border-right:1px solid #dfe6ef;border-bottom:1px solid #e2e8f0;white-space:nowrap;box-sizing:border-box;}
    .change-grid-table thead th{position:sticky;top:0;z-index:8;background:#f4f7fc;color:#334155;font-size:11.5px;font-weight:800;text-align:center;padding:8px 10px;height:39px;}
    .change-grid-table tbody td{background:#fff;padding:6px 8px;font-size:11.5px;color:#0f172a;height:48px;}
    .change-grid-table tbody tr:hover td{background:#fafcff;}
    .change-grid-table .sticky-col-1{position:sticky;left:0;z-index:12;width:42px;min-width:42px;max-width:42px;text-align:center;background:#fff;border-right:1px solid #cfd9e5!important;}
    .change-grid-table thead .sticky-col-1{z-index:16;background:#f4f7fc;}
    .change-grid-table .sticky-col-2{position:sticky;left:42px;z-index:11;width:120px;min-width:120px;max-width:120px;background:#fff;border-right:2px solid #cfd9e5!important;}
    .change-grid-table thead .sticky-col-2{z-index:15;background:#f4f7fc;}
    .change-grid-table .change-code{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-weight:800;color:#294a9c;text-align:center;}
    .change-grid-table input[type=checkbox]{width:16px;height:16px;accent-color:#2952d3;}
    .change-input,.change-select,.change-textarea{width:170px;height:31px;box-sizing:border-box;border:1px solid #ccd7e4;border-radius:6px;background:#fff;padding:0 8px;font-size:11.5px;color:#0f172a;outline:none;}
    .change-input:focus,.change-select:focus,.change-textarea:focus{border-color:#2952d3;box-shadow:0 0 0 2px rgba(41,82,211,.08);}
    .change-number{width:120px;text-align:right;}
    .change-textarea{height:48px;padding:6px 8px;resize:vertical;}
    .change-grid-table select{cursor:pointer;}
    /* 品目階層グループ 구성 品目 표시 개선 */
    .hierarchy-card{width:min(820px,96vw);}
    .hierarchy-card .item-member-row{grid-template-columns:90px minmax(0,1fr) 85px;}
    .hierarchy-card .item-member-row .name{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:800;}
    .hierarchy-card .item-member-row .spec{text-align:right;white-space:nowrap;color:#64748b;}
    .change-image-cell{display:flex;align-items:center;gap:8px;min-width:210px;}
    .change-image-preview{width:48px;height:48px;border:1px solid #dbe3ed;border-radius:7px;background:#f8fafc;display:flex;align-items:center;justify-content:center;overflow:hidden;flex:0 0 auto;}
    .change-image-preview img{width:100%;height:100%;object-fit:cover;}
    .change-image-preview i{font-size:20px;color:#94a3b8;}
    .change-file-input{width:155px;font-size:10px;}
    .change-common-row{display:flex;align-items:center;gap:7px;padding:8px 10px;background:#fbfcff;border-bottom:1px solid #e2e8f0;flex:0 0 auto;}
    .change-common-row select{height:31px;min-width:150px;}
    .change-common-control{flex:1;min-width:180px;}
    .change-common-control .change-input,.change-common-control .change-select{width:100%;}
    .change-field-hint{display:inline-flex;align-items:center;color:#64748b;font-size:10px;}
    .change-grid-footer{min-height:50px;flex:0 0 auto;}
    .change-grid-loading,.change-grid-empty{padding:42px;text-align:center;color:#94a3b8;font-size:12px;}
    @media(max-width:720px){
        .change-grid-card{width:97vw;}
        .change-grid-tip{display:none;}
        .change-grid-wrap{max-height:54vh;}
        .change-field-card{width:96vw!important;}
    }
    body.base-embed{height:100vh;margin:0;overflow:hidden;background:#fff}
    body.base-embed .erp-sidebar,body.base-embed .page-title,body.base-embed .list-wrap{display:none !important}
    body.base-embed .erp-wrapper,body.base-embed .erp-main,body.base-embed .erp-content{height:100%;overflow:hidden;background:#fff}
    body.base-embed #itemModalOverlay{background:transparent;padding:0;align-items:stretch}
    body.base-embed #itemModalOverlay .item-card{max-width:none;width:100%;height:100%;border:0;border-radius:0;box-shadow:none}
    body.base-embed #itemModalOverlay .item-form{flex:1;max-height:none}
</style>

<script>
(function(){
    'use strict';
    const contextPath = '${pageContext.request.contextPath}';
    const baseEmbed = '${param.embed}' === '1';
    const overlay = document.getElementById('itemModalOverlay');
    function notifyBaseRegister(action, extra) {
        if (!baseEmbed || !window.parent || window.parent === window) return;
        window.parent.postMessage({
            type: 'base-register',
            action: action,
            kind: 'item',
            code: extra && extra.code ? extra.code : '',
            name: extra && extra.name ? extra.name : ''
        }, window.location.origin);
    }
    const form = document.getElementById('itemForm');
    const mode = document.getElementById('modalMode');

    // 数値専用入力：品目コードは整数、作業時間・配賦比率・標準原価は数値と小数点のみ入力できます。
    function bindNumericOnly(id, allowDecimal) {
        const input = document.getElementById(id);
        if (!input) return;

        const sanitize = function() {
            let value = input.value || '';
            if (allowDecimal) {
                value = value.replace(/[^0-9.]/g, '');
                const firstDot = value.indexOf('.');
                if (firstDot !== -1) {
                    value = value.substring(0, firstDot + 1) + value.substring(firstDot + 1).replace(/\./g, '');
                }
            } else {
                value = value.replace(/[^0-9]/g, '');
            }
            input.value = value;
        };

        input.addEventListener('input', sanitize);
        input.addEventListener('paste', function() { setTimeout(sanitize, 0); });
        input.addEventListener('drop', function() { setTimeout(sanitize, 0); });
    }

    
    ['stdLaborTime', 'expenseWeight', 'stdCostMaterial', 'stdCostExpense', 'stdCostLabor', 'stdCostOutsourcing']
        .forEach(function(id) { bindNumericOnly(id, true); });

    function postForm(url, formData) {
        return fetch(url, { method:'POST', body:formData }).then(async function(res){
            const text = await res.text();
            if (!res.ok) throw new Error(text || '処理中にエラーが発生しました。');
            return text;
        });
    }

    function setRadio(name, value) {
        const radios = form.querySelectorAll('input[name="' + name + '"]');
        radios.forEach(function(r){ r.checked = String(r.value) === String(value == null ? '' : value); });
    }

    function setValue(name, value) {
        const el = form.querySelector('[name="' + name + '"]');
        if (el) el.value = value == null ? '' : value;
    }

    function syncMirrors() {
        form.querySelectorAll('.mirror[data-mirror]').forEach(function(dst){
            const src = form.querySelector('[name="' + dst.getAttribute('data-mirror') + '"]');
            if (src) dst.value = src.value || '';
        });
    }

    function clearImagePreview() {
        const img = document.getElementById('imagePreview');
        const empty = document.getElementById('imagePreviewEmpty');
        img.removeAttribute('src');
        img.style.display = 'none';
        empty.style.display = 'flex';
        document.getElementById('imageFileName').textContent = '新しい画像は選択されていません';
    }

    function showImagePreview(src) {
        const img = document.getElementById('imagePreview');
        const empty = document.getElementById('imagePreviewEmpty');
        if (!src) { clearImagePreview(); return; }
        img.src = src;
        img.style.display = 'block';
        empty.style.display = 'none';
    }

    function resetForm() {
        form.reset();
        setValue('itemPk','');
        setValue('prodProcessPk','');
        setValue('prodProcessName','');
        setValue('itemGroup1Pk','');
        setValue('itemGroup1Name','');
        setValue('itemGroup2Pk','');
        setValue('itemGroup2Name','');
        setValue('itemGroup3Pk','');
        setValue('itemGroup3Name','');
        setValue('qualityInspTypePk','');
        setValue('qualityInspTypeName','');
        setValue('itemHierGroupPk','');
        setValue('itemHierGroupName','');
        setValue('warehouseNames','');
        if (window.setItemWarehouseSelection) window.setItemWarehouseSelection([]);
        setRadio('itemDiv','4');
        setRadio('qualityInspMethod','0');
        document.getElementById('btnModalDelete').style.display = 'none';
        mode.textContent = '新規登録';
        document.getElementById('imageFile').value = '';
        clearImagePreview();
        activateTab('tab-basic');
        syncMirrors();
    }

    function fillForm(item) {
        setValue('itemPk', item.itemPk);
        setValue('itemCode', item.itemCode);
        setValue('itemName', item.itemName);
        setValue('spec', item.spec);
        setValue('unit', item.unit);
        setRadio('itemDiv', item.itemDiv);
        setValue('prodProcessPk', item.prodProcessPk);
        setValue('prodProcessName', item.prodProcessName);
        setValue('qty', item.qty);
        setValue('purchasePrice', item.purchasePrice);
        setValue('salesPrice', item.salesPrice);
        setValue('barcode', item.barcode);
        setValue('searchContent', item.searchContent);
        setValue('vatRateSales', item.vatRateSales);
        setValue('vatRatePurchase', item.vatRatePurchase);
        setValue('outsourcingPrice', item.outsourcingPrice);
        setValue('stdLaborTime', item.stdLaborTime);
        setValue('expenseWeight', item.expenseWeight);
        setValue('stdCostMaterial', item.stdCostMaterial);
        setValue('stdCostExpense', item.stdCostExpense);
        setValue('stdCostLabor', item.stdCostLabor);
        setValue('stdCostOutsourcing', item.stdCostOutsourcing);
        setValue('itemGroup1Pk', item.itemGroup1Pk);
        setValue('itemGroup1Name', item.itemGroup1Name);
        setValue('itemGroup2Pk', item.itemGroup2Pk);
        setValue('itemGroup2Name', item.itemGroup2Name);
        setValue('itemGroup3Pk', item.itemGroup3Pk);
        setValue('itemGroup3Name', item.itemGroup3Name);
        setValue('itemHierGroupPk', item.itemHierGroupPk);
        setValue('itemHierGroupName', item.itemHierGroupName);
        if (window.setItemWarehouseSelection) window.setItemWarehouseSelection(item.warehousePks || []);
        setRadio('qualityInspMethod', item.qualityInspMethod);
        setValue('qualityInspTypePk', item.qualityInspTypePk);
        setValue('qualityInspTypeName', item.qualityInspTypeName);
        mode.textContent = '編集';
        document.getElementById('btnModalDelete').style.display = 'inline-flex';
        document.getElementById('imageFile').value = '';
        document.getElementById('imageFileName').textContent = item.imagePath ? '登録 画像 使用 중 (새 파일 選択 가능)' : '新しい画像は選択されていません';
        showImagePreview(item.imagePath ? contextPath + item.imagePath : '');
        syncMirrors();
    }

    window.openItemModal = function(itemPk){
        resetForm();
        if (itemPk) {
            fetch(contextPath + '/base/item/get?itemPk=' + encodeURIComponent(itemPk))
                .then(function(res){ if (!res.ok) throw new Error('品目 の取得に失敗しました。'); return res.json(); })
                .then(function(item){ fillForm(item); overlay.classList.add('active'); })
                .catch(function(err){ alert(err.message); });
        } else {
            overlay.classList.add('active');
        }
    };

    function closeModal(){
        overlay.classList.remove('active');
        if (baseEmbed) notifyBaseRegister('close');
    }
    function activateTab(tabId){
        document.querySelectorAll('.tab-btn').forEach(function(btn){ btn.classList.toggle('active', btn.getAttribute('data-tab') === tabId); });
        document.querySelectorAll('.tab-panel').forEach(function(panel){ panel.classList.toggle('active', panel.id === tabId); });
    }

    document.querySelectorAll('.tab-btn').forEach(function(btn){ btn.addEventListener('click', function(){ activateTab(btn.getAttribute('data-tab')); }); });
    form.addEventListener('input', syncMirrors);
    document.getElementById('btnNewItem').addEventListener('click', function(){ window.openItemModal(null); });
    document.getElementById('closeItemModal').addEventListener('click', closeModal);
    document.getElementById('btnCloseFooter').addEventListener('click', closeModal);
    document.getElementById('btnAgain').addEventListener('click', resetForm);
    overlay.addEventListener('click', function(e){ if (e.target === overlay) closeModal(); });

    document.getElementById('imageFile').addEventListener('change', function(){
        const file = this.files && this.files[0];
        if (!file) return;
        if (!file.type || file.type.indexOf('image/') !== 0) {
            alert('画像ファイルのみ選択できます。'); this.value=''; clearImagePreview(); return;
        }
        if (file.size > 5 * 1024 * 1024) {
            alert('画像は5MB以下のみ登録できます。'); this.value=''; clearImagePreview(); return;
        }
        document.getElementById('imageFileName').textContent = file.name;
        const reader = new FileReader();
        reader.onload = function(e){ showImagePreview(e.target.result); };
        reader.readAsDataURL(file);
    });

    document.getElementById('btnCheckCode').addEventListener('click', function(){
        const code = document.getElementById('itemCode').value.trim();
        const itemPk = document.getElementById('itemPk').value.trim();
        if (!code) { alert('品目コードを入力してください。'); document.getElementById('itemCode').focus(); return; }
        fetch(contextPath + '/base/item/check-code?itemCode=' + encodeURIComponent(code) + (itemPk ? '&itemPk=' + encodeURIComponent(itemPk) : ''))
            .then(function(res){ return res.json(); })
            .then(function(duplicate){ alert(duplicate ? 'すでに使用中の品目コードです。' : '使用可能な品目コードです。'); })
            .catch(function(){ alert('品目コード の重複確認中にエラーが発生しました。'); });
    });

    document.getElementById('btnSaveItem').addEventListener('click', function(){
        const code = document.getElementById('itemCode').value.trim();
        const name = document.getElementById('itemName').value.trim();
        if (!code) { alert('品目コードは必須です。'); activateTab('tab-basic'); document.getElementById('itemCode').focus(); return; }
        if (!name) { alert('品目名は必須です。'); activateTab('tab-basic'); document.getElementById('itemName').focus(); return; }
        if (!confirm('品目を 保存しますか？')) return;

        const itemPk = document.getElementById('itemPk').value.trim();
        const fd = new FormData(form);
        fd.delete('warehousePks');
        if (window.getItemWarehousePks) {
            window.getItemWarehousePks().forEach(function(pk){ fd.append('warehousePks', pk); });
        }
        const url = itemPk ? contextPath + '/base/item/modify' : contextPath + '/base/item/register';
        const btn = document.getElementById('btnSaveItem');
        btn.disabled = true;
        postForm(url, fd)
            .then(function(){
                alert('保存しました。');
                if (baseEmbed && !itemPk) {
                    notifyBaseRegister('saved', {code: code, name: name});
                    return;
                }
                location.href = contextPath + '/base/item?pageNum=1&amount=' + (new URLSearchParams(location.search).get('amount') || 10);
            })
            .catch(function(err){ alert(err.message || '保存 中にエラーが発生しました。'); })
            .finally(function(){ btn.disabled = false; });
    });

    document.getElementById('btnModalDelete').addEventListener('click', function(){
        const itemPk = document.getElementById('itemPk').value.trim();
        if (!itemPk) return;
        if (!confirm('現在の品目を削除しますか？\n削除後は復元できません。')) return;
        const fd = new FormData(); fd.append('itemPks', itemPk);
        postForm(contextPath + '/base/item/remove', fd)
            .then(function(){ alert('削除しました。'); location.reload(); })
            .catch(function(err){ alert(err.message || '削除 中にエラーが発生しました。'); });
    });

    document.getElementById('checkAll').addEventListener('change', function(){
        const checked = this.checked;
        document.querySelectorAll('.item-check').forEach(function(c){ c.checked = checked; });
    });

    document.getElementById('btnDeleteItem').addEventListener('click', function(){
        const pks = Array.from(document.querySelectorAll('.item-check:checked')).map(function(c){ return c.value; });
        if (pks.length === 0) { alert('削除する 品目を 選択してください。'); return; }
        if (!confirm(pks.length + '件の品目を 削除しますか？\n削除後は復元できません。')) return;
        const fd = new FormData();
        pks.forEach(function(pk){ fd.append('itemPks', pk); });
        postForm(contextPath + '/base/item/remove', fd)
            .then(function(){ alert('削除しました。'); location.reload(); })
            .catch(function(err){ alert(err.message || '削除 中にエラーが発生しました。'); });
    });

    document.getElementById('btnSearch').addEventListener('click', function(){ document.getElementById('searchForm').submit(); });
    document.getElementById('itemSearchInput').addEventListener('keydown', function(e){ if (e.key === 'Enter') { e.preventDefault(); document.getElementById('searchForm').submit(); } });
    document.getElementById('btnResetSearch').addEventListener('click', function(){ location.href = contextPath + '/base/item'; });
    document.getElementById('btnRefreshList').addEventListener('click', function(){ location.reload(); });

    window.goPage = function(page){
        const formEl = document.getElementById('searchForm');
        formEl.querySelector('input[name=pageNum]').value = page;
        formEl.submit();
    };

    document.addEventListener('keydown', function(e){
        if (e.key === 'F2') {
            e.preventDefault();
            if (document.getElementById('masterRegisterOverlay').classList.contains('active')) {
                document.getElementById('masterCode').focus();
            } else if (document.getElementById('masterSearchOverlay').classList.contains('active')) {
                if (typeof window.masterNew === 'function') window.masterNew();
            } else {
                window.openItemModal(null);
            }
        }
        if (e.key === 'F3') { e.preventDefault(); document.getElementById('itemSearchInput').focus(); }
        if (e.key === 'F8') {
            if (document.getElementById('masterRegisterOverlay').classList.contains('active')) {
                e.preventDefault(); document.getElementById('btnMasterSave').click();
            } else if (document.getElementById('itemChangeGridOverlay').classList.contains('active')) {
                e.preventDefault(); document.querySelector('#itemChangeGridOverlay .change-grid-footer .btn-primary-sm').click();
            } else if (document.getElementById('itemChangeFieldOverlay').classList.contains('active')) {
                e.preventDefault(); document.querySelector('#itemChangeFieldOverlay .change-field-footer .btn-primary-sm').click();
            } else if (overlay.classList.contains('active')) {
                e.preventDefault(); document.getElementById('btnSaveItem').click();
            }
        }
        if (e.key === 'Escape') {
            if (document.getElementById('itemWarehouseOverlay').classList.contains('active')) {
                e.preventDefault(); closeItemWarehouseSelector();
            } else if (document.getElementById('itemHierarchyOverlay').classList.contains('active')) {
                e.preventDefault(); closeItemHierarchy();
            } else if (document.getElementById('itemChangeGridOverlay').classList.contains('active')) {
                e.preventDefault(); closeItemChangeGrid();
            } else if (document.getElementById('itemChangeFieldOverlay').classList.contains('active')) {
                e.preventDefault(); closeItemChangeFields();
            } else if (document.getElementById('barcodeOverlay').classList.contains('active')) {
                e.preventDefault(); document.getElementById('closeBarcode').click();
            } else if (document.getElementById('masterRegisterOverlay').classList.contains('active')) {
                e.preventDefault(); window.closeMasterRegister();
            } else if (document.getElementById('masterSearchOverlay').classList.contains('active')) {
                e.preventDefault(); window.closeMasterPopup();
            } else if (overlay.classList.contains('active')) {
                e.preventDefault(); closeModal();
            }
        }
    });
    if (baseEmbed) window.openItemModal(null);
})();
</script>

<script>
(function(){
    'use strict';
    const contextPath = '${pageContext.request.contextPath}';
    const barcodeOverlay = document.getElementById('barcodeOverlay');
    const barcodeTbody = document.getElementById('barcodeTbody');
    let barcodeRows = [];

    function esc(value){
        return String(value == null ? '' : value).replace(/[&<>'"]/g, function(ch){
            return {'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[ch];
        });
    }

    function money(value){
        const n = Number(value);
        if (!Number.isFinite(n)) return '0';
        return n.toLocaleString('ko-KR', {maximumFractionDigits:2});
    }

    function getSelectedItemPks(){
        return Array.from(document.querySelectorAll('.item-check:checked')).map(function(el){ return el.value; });
    }

    function renderBarcodeRows(items){
        barcodeRows = (items || []).map(function(item){
            return {
                itemPk: item.itemPk,
                itemCode: item.itemCode || '',
                itemName: item.itemName || '',
                spec: item.spec || '-',
                barcode: item.barcode || '',
                salesPrice: item.salesPrice || 0,
                qty: 1
            };
        });
        barcodeTbody.innerHTML = '';
        if (!barcodeRows.length){
            barcodeTbody.innerHTML = '<tr><td colspan="6" class="barcode-empty">取得した品目がありません。</td></tr>';
            return;
        }
        barcodeRows.forEach(function(item, index){
            const tr = document.createElement('tr');
            tr.innerHTML =
                '<td><input type="checkbox" class="barcode-check" data-index="' + index + '" checked></td>' +
                '<td><input type="number" class="barcode-qty" data-index="' + index + '" min="1" max="999" step="1" value="1" inputmode="numeric"></td>' +
                '<td>' + esc(item.itemCode) + '</td>' +
                '<td style="text-align:left">' + esc(item.itemName) + '</td>' +
                '<td>' + esc(item.spec) + '</td>' +
                '<td class="barcode-value">' + esc(item.barcode) + '</td>';
            barcodeTbody.appendChild(tr);
        });
        document.getElementById('barcodeCheckAll').checked = true;
    }

    function openBarcode(){
        const itemPks = getSelectedItemPks();
        if (!itemPks.length){
            alert('バーコードを確認する品目を先に選択してください。');
            return;
        }
        barcodeTbody.innerHTML = '<tr><td colspan="6" class="barcode-empty">バーコードを生成しています...</td></tr>';
        barcodeOverlay.classList.add('active');
        fetch(contextPath + '/base/item/barcode/list?itemPks=' + itemPks.map(encodeURIComponent).join('&itemPks='))
            .then(function(res){
                if (res.status === 404) throw new Error('選択した品目が見つかりません。');
                if (!res.ok) throw new Error('バーコード 照会中にエラーが発生しました。');
                return res.json();
            })
            .then(renderBarcodeRows)
            .catch(function(err){
                barcodeTbody.innerHTML = '<tr><td colspan="6" class="barcode-empty">エラーが発生しました。</td></tr>';
                alert(err.message || 'バーコード 照会中にエラーが発生しました。');
            });
    }

    function closeBarcode(){
        barcodeOverlay.classList.remove('active');
        barcodeRows = [];
    }

    function collectPrintRows(){
        const rows = [];
        document.querySelectorAll('.barcode-check:checked').forEach(function(check){
            const index = Number(check.getAttribute('data-index'));
            const item = barcodeRows[index];
            if (!item) return;
            const qtyEl = document.querySelector('.barcode-qty[data-index="' + index + '"]');
            const qty = qtyEl ? Math.max(1, Math.min(999, parseInt(qtyEl.value, 10) || 1)) : 1;
            if (qtyEl) qtyEl.value = qty;
            rows.push({item:item, qty:qty});
        });
        return rows;
    }

    function barcodeImage(type, barcode){
        return 'https://loginaa.ecount.com/ECAPI/Bulk/SVC/Common/Infra/BarcodeImage?BarcodeType=' + type + '&Barcode=' + encodeURIComponent(barcode);
    }

    function buildPrintHtml(rows){
        const manufacturer = '(주)가장많이쓰는ERP';
        const phone = '1566-5333';
        const address = '서울특별시 강동구 고덕비즈밸리로6길 84 (고덕동) (주)이카운트';
        let html = '';
        rows.forEach(function(entry){
            const item = entry.item;
            for (let copy = 0; copy < entry.qty; copy++){
                html += '<section class="label-page">';
                html += '<h1>バーコード印刷</h1>';

                html += '<div class="barcode-type"><h2>種類1</h2>';
                html += '<div class="label type1">';
                html += '<img src="' + barcodeImage('B1', esc(item.barcode)) + '" alt="barcode">';
                html += '<div class="name">' + esc(item.itemName) + '</div>';
                html += '<div class="price">' + money(item.salesPrice) + 'ウォン</div>';
                html += '</div></div>';

                html += '<div class="barcode-type"><h2>種類2</h2>';
                html += '<div class="label type2">';
                html += '<img src="' + barcodeImage('B4', esc(item.barcode)) + '" alt="barcode">';
                html += '<div class="barcode-text">' + esc(item.barcode) + '</div>';
                html += '<div>' + esc(item.itemName) + '</div>';
                html += '<div class="price">' + money(item.salesPrice) + 'ウォン</div>';
                html += '</div></div>';

                html += '<div class="barcode-type"><h2>種類3</h2>';
                html += '<div class="label type3">';
                html += '<div>品名：' + esc(item.itemName) + '</div><br>';
                html += '<img src="' + barcodeImage('B5', esc(item.barcode)) + '" alt="barcode"><br><br>';
                html += '<div>単価 : ' + money(item.salesPrice) + '</div><br>';
                html += '<div>メーカー：' + manufacturer + '</div><br>';
                html += '<div>連絡先 : ' + phone + '</div><br>';
                html += '<div>住所 : ' + address + '</div>';
                html += '</div></div>';

                html += '<div class="barcode-type"><h2>種類4</h2>';
                html += '<div class="label type4">';
                html += '<div>商品コード : ' + esc(item.itemCode) + '</div><br><br>';
                html += '<img src="' + barcodeImage('B6', esc(item.barcode)) + '" alt="barcode"><br><br>';
                html += '<div>生産者：</div><br>';
                html += '<div>希望小売価格：' + money(item.salesPrice) + 'ウォン<br>（税込）</div>';
                html += '</div></div>';
                html += '</section>';
            }
        });
        return html;
    }

    function previewBarcode(){
        const rows = collectPrintRows();
        if (!rows.length){
            alert('プレビューする品目を選択してください。');
            return;
        }

        const win = window.open('', '_blank', 'width=980,height=900,scrollbars=yes,resizable=yes');
        if (!win){
            alert('プレビューウィンドウがブロックされました。ブラウザーでポップアップを許可してください。');
            return;
        }

        const body = buildPrintHtml(rows);
        win.document.open();
        win.document.write('<!DOCTYPE html><html lang="ja"><head><meta charset="UTF-8"><title>バーコード プレビュー</title>' +
            '<style>' +
            'html,body{margin:0;padding:0}.barcode-preview-window{background:#f1f5f9;color:#111;font-family:Arial,Malgun Gothic,sans-serif}.barcode-preview-toolbar{position:sticky;top:0;z-index:20;display:flex;align-items:center;gap:8px;padding:12px 16px;background:#fff;border-bottom:1px solid #dbe3ed;box-shadow:0 2px 8px rgba(15,23,42,.08)}.preview-title{font-weight:800;font-size:15px;margin-right:auto}.barcode-preview-toolbar button{border:1px solid #cbd5e1;background:#fff;color:#0f172a;border-radius:7px;padding:8px 13px;font-weight:700;cursor:pointer}.barcode-preview-toolbar button.primary{background:#4B88FF;border-color:#4B88FF;color:#fff}.barcode-preview-toolbar button:hover{filter:brightness(.98)}.barcode-preview-body{padding:24px}.label-page{background:#fff;padding:24px 24px 18px;margin:0 auto 24px;max-width:900px;box-sizing:border-box;page-break-after:always;box-shadow:0 4px 16px rgba(15,23,42,.08)}.label-page:last-child{page-break-after:auto}.label-page h1{font-size:20px;margin:0 0 14px;padding-bottom:8px;border-bottom:2px solid #111}.barcode-type{margin:0 0 24px;padding-bottom:20px;border-bottom:1px dashed #9ca3af}.barcode-type h2{font-size:14px;margin:0 0 10px;font-weight:700}.label{display:flex;flex-direction:column;align-items:flex-start;gap:6px;font-size:14px;line-height:1.45}.label img{display:block;max-width:100%;height:auto;min-height:50px}.type1,.type2,.type3,.type4{border:1px solid #e5e7eb;padding:16px;box-sizing:border-box}.type1{width:340px;text-align:center;align-items:center}.type1 img{max-width:300px}.type1 .name{font-weight:700}.type1 .price{font-size:16px;font-weight:700}.type2{width:360px;align-items:center;text-align:center}.type2 img{max-width:320px}.type2 .barcode-text{font-family:Consolas,monospace;font-weight:700;letter-spacing:1px}.type2 .price{font-weight:700}.type3,.type4{width:460px}.type3 img,.type4 img{max-width:400px}.type3,.type4{font-size:14px}.price{font-weight:700}@media print{.barcode-preview-toolbar{display:none!important}.barcode-preview-body{padding:0}.barcode-preview-window{background:#fff}.label-page{max-width:none;margin:0;padding:12mm 10mm;box-shadow:none}.barcode-type{page-break-inside:avoid}}' +
            '</style></head><body class="barcode-preview-window">' +
            '<div class="barcode-preview-toolbar">' +
            '<div class="preview-title">バーコード印刷 プレビュー</div>' +
            '<button type="button" class="primary" onclick="window.print()"><i>🖨</i> 印刷</button>' +
            '<button type="button" onclick="window.close()">閉じる</button>' +
            '</div>' +
            '<div class="barcode-preview-body">' + body + '</div>' +
            '</body></html>');
        win.document.close();
    }

    document.getElementById('btnBarcode').addEventListener('click', openBarcode);
    document.getElementById('closeBarcode').addEventListener('click', closeBarcode);
    document.getElementById('btnBarcodeClose').addEventListener('click', closeBarcode);
    barcodeOverlay.addEventListener('click', function(e){ if (e.target === barcodeOverlay) closeBarcode(); });
    document.getElementById('btnBarcodePrint').addEventListener('click', previewBarcode);
    document.getElementById('barcodeCheckAll').addEventListener('change', function(){
        const checked = this.checked;
        document.querySelectorAll('.barcode-check').forEach(function(el){ el.checked = checked; });
    });
})();
</script>

<script>
(function(){
    'use strict';
    const contextPath = '${pageContext.request.contextPath}';
    const searchOverlay = document.getElementById('masterSearchOverlay');
    const registerOverlay = document.getElementById('masterRegisterOverlay');
    const searchInput = document.getElementById('masterSearchInput');
    const tbody = document.getElementById('masterTbody');
    const masterConfig = {
        PROD_PROCESS: {
            route: 'prod-process', label: '生産工程', registerTitle: '生産工程_1단계登録', codeLabel: '生産工程_1단계 コード', nameLabel: '生産工程_1단계 명',
            itemPk: 'prodProcessPk', itemName: 'prodProcessName'
        },
        ITEM_GROUP1: {
            route: 'item-group1', label: '品目グループ1', registerTitle: '品目グループ1登録', codeLabel: '品目グループ1 コード', nameLabel: '品目グループ1 명',
            itemPk: 'itemGroup1Pk', itemName: 'itemGroup1Name'
        },
        ITEM_GROUP2: {
            route: 'item-group2', label: '品目グループ2', registerTitle: '品目グループ2登録', codeLabel: '品目グループ2 コード', nameLabel: '品目グループ2 명',
            itemPk: 'itemGroup2Pk', itemName: 'itemGroup2Name'
        },
        ITEM_GROUP3: {
            route: 'item-group3', label: '品目グループ3', registerTitle: '品目グループ3登録', codeLabel: '品目グループ3 コード', nameLabel: '品目グループ3 명',
            itemPk: 'itemGroup3Pk', itemName: 'itemGroup3Name'
        },
        QUALITY_INSP_TYPE: {
            route: 'quality-insp-type', label: '品質検査種別', registerTitle: '品質検査種別登録', codeLabel: '品質検査種別 コード', nameLabel: '品質検査種別 명',
            itemPk: 'qualityInspTypePk', itemName: 'qualityInspTypeName', manage: false
        }
    };
    let currentType = null;
    let selected = null;

    function cfg(){ return masterConfig[currentType]; }
    function api(path, options){
        return fetch(contextPath + path, options || {}).then(function(res){
            return res.text().then(function(text){
                if (!res.ok) throw new Error(text || '処理中にエラーが発生しました。');
                try { return text ? JSON.parse(text) : null; } catch(e) { return text; }
            });
        });
    }
    function renderList(list){
        tbody.innerHTML = '';
        selected = null;
        if (!list || !list.length) {
            tbody.innerHTML = '<tr class="master-empty"><td colspan="2">取得したデータがありません。</td></tr>';
            return;
        }
        list.forEach(function(row){
            const tr = document.createElement('tr');
            tr.innerHTML = '<td>' + escapeHtml(row.code || '') + '</td><td>' + escapeHtml(row.name || '') + '</td>';
            tr.addEventListener('click', function(){
                tbody.querySelectorAll('tr.selected').forEach(function(el){ el.classList.remove('selected'); });
                tr.classList.add('selected');
                selected = row;
            });
            tr.addEventListener('dblclick', function(){
                selected = row;
                chooseSelected();
            });
            tbody.appendChild(tr);
        });
    }
    function escapeHtml(value){
        return String(value).replace(/[&<>'"]/g, function(ch){ return {'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[ch]; });
    }
    function loadList(){
        const keyword = searchInput.value.trim();
        api('/base/master/' + cfg().route + '/list?keyword=' + encodeURIComponent(keyword)).then(renderList).catch(function(err){ alert(err.message); });
    }
    function openPopup(type){
        currentType = type;
        const c = cfg();
        document.getElementById('masterPopupTitle').textContent = c.label + ' 検索';
        var canManage = c.manage !== false;
        ['btnMasterNew','btnMasterModify','btnMasterDelete'].forEach(function(id){
            document.getElementById(id).style.display = canManage ? '' : 'none';
        });
        searchInput.value = '';
        searchOverlay.classList.add('active');
        loadList();
        setTimeout(function(){ searchInput.focus(); }, 50);
    }
    function closePopup(){ searchOverlay.classList.remove('active'); selected = null; }
    function openRegister(row){
        const c = cfg();
        document.getElementById('masterRegisterTitle').textContent = c.registerTitle;
        document.getElementById('masterCodeLabel').textContent = c.codeLabel;
        document.getElementById('masterNameLabel').textContent = c.nameLabel;
        document.getElementById('masterPk').value = row && row.pk != null ? row.pk : '';
        document.getElementById('masterCode').value = row && row.code ? row.code : '';
        document.getElementById('masterName').value = row && row.name ? row.name : '';
        registerOverlay.classList.add('active');
        setTimeout(function(){ document.getElementById('masterCode').focus(); }, 50);
    }
    function closeRegister(){ registerOverlay.classList.remove('active'); }
    function chooseSelected(){
        if (!selected) { alert('選択할 項目을 먼저 클릭해주세요.'); return; }
        const c = cfg();
        document.getElementById(c.itemPk).value = selected.pk;
        document.getElementById(c.itemName).value = selected.name || '';
        closePopup();
    }
    function saveMaster(){
        const pk = document.getElementById('masterPk').value.trim();
        const code = document.getElementById('masterCode').value.trim();
        const name = document.getElementById('masterName').value.trim();
        if (!code) { alert(cfg().codeLabel + 'を入力してください。'); document.getElementById('masterCode').focus(); return; }
        if (!name) { alert(cfg().nameLabel + 'を入力してください。'); document.getElementById('masterName').focus(); return; }
        const query = '?code=' + encodeURIComponent(code) + (pk ? '&pk=' + encodeURIComponent(pk) : '');
        api('/base/master/' + cfg().route + '/check-code' + query).then(function(duplicate){
            if (duplicate === true) throw new Error('すでに使用中の コード입니다.');
            const fd = new URLSearchParams();
            fd.append('code', code); fd.append('name', name);
            if (pk) fd.append('pk', pk);
            const endpoint = pk ? '/base/master/' + cfg().route + '/modify' : '/base/master/' + cfg().route + '/register';
            return api(endpoint, {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'}, body:fd.toString()});
        }).then(function(result){
            const newPk = result && result !== 'success' ? Number(result) : (pk ? Number(pk) : null);
            alert('保存しました。');
            closeRegister();
            loadList();
            setTimeout(function(){
                if (newPk != null && !isNaN(newPk)) {
                    api('/base/master/' + cfg().route + '/get?pk=' + encodeURIComponent(newPk)).then(function(row){ selected = row; });
                }
            }, 120);
        }).catch(function(err){ alert(err.message || '保存 中にエラーが発生しました。'); });
    }
    function deleteMaster(){
        if (!selected) { alert('削除する 項目を先に選択してください。'); return; }
        const c = cfg();
        if (!confirm('[' + selected.code + '] ' + selected.name + 'を 削除しますか？\n品目に서 使用中の 데이터는 削除できません。')) return;
        const fd = new URLSearchParams(); fd.append('pk', selected.pk);
        api('/base/master/' + c.route + '/remove', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'}, body:fd.toString()})
            .then(function(){ alert('削除しました。'); loadList(); })
            .catch(function(err){ alert(err.message || '削除 中にエラーが発生しました。'); });
    }

    window.openMasterPopup = openPopup;
    window.closeMasterPopup = closePopup;
    window.closeMasterRegister = closeRegister;
    window.masterNew = function(){ if (cfg() && cfg().manage !== false) openRegister(null); };
    window.masterRegisterFocus = function(){ document.getElementById('masterCode').focus(); };

    document.getElementById('btnMasterNew').addEventListener('click', function(){ openRegister(null); });
    document.getElementById('btnMasterModify').addEventListener('click', function(){ if (!selected) { alert('編集する 項目을 選択してください。'); return; } openRegister(selected); });
    document.getElementById('btnMasterDelete').addEventListener('click', deleteMaster);
    document.getElementById('btnMasterSelect').addEventListener('click', chooseSelected);
    document.getElementById('btnMasterClose').addEventListener('click', closePopup);
    document.getElementById('closeMasterSearch').addEventListener('click', closePopup);
    document.getElementById('btnMasterSave').addEventListener('click', saveMaster);
    document.getElementById('btnMasterCancel').addEventListener('click', closeRegister);
    document.getElementById('closeMasterRegister').addEventListener('click', closeRegister);
    document.getElementById('btnMasterSearch').addEventListener('click', loadList);
    searchInput.addEventListener('keydown', function(e){ if(e.key === 'Enter'){ e.preventDefault(); loadList(); } });
    document.getElementById('masterName').addEventListener('keydown', function(e){ if(e.key === 'Enter'){ e.preventDefault(); saveMaster(); } });
    searchOverlay.addEventListener('click', function(e){ if(e.target === searchOverlay) closePopup(); });
    registerOverlay.addEventListener('click', function(e){ if(e.target === registerOverlay) closeRegister(); });
})();
</script>

<script>
(function(){
    'use strict';
    var contextPath = '${pageContext.request.contextPath}';
    var selectedWarehousePks = [];
    var warehouseCache = [];
    var hierarchyMode = 'form';
    var selectedHierarchyNode = null;
    var hierarchyNodes = [];

    function esc(v){
        return String(v == null ? '' : v).replace(/[&<>'"]/g, function(ch){
            return {'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','\"':'&quot;'}[ch];
        });
    }

    function jsonFetch(url, options){
        return fetch(url, options).then(function(res){
            return res.text().then(function(text){
                var data = null;
                try { data = text ? JSON.parse(text) : null; } catch(e) { data = text; }
                if (!res.ok) {
                    var message = data && data.message ? data.message : (typeof data === 'string' ? data : '処理中にエラーが発生しました。');
                    throw new Error(message);
                }
                return data;
            });
        });
    }

    function updateWarehouseNameText(){
        var input = document.getElementById('warehouseNames');
        if (!input) return;
        var names = [];
        selectedWarehousePks.forEach(function(pk){
            var row = warehouseCache.find(function(w){ return String(w.warehousePk) === String(pk); });
            if (row) names.push((row.warehouseCode || '') + ' - ' + (row.warehouseName || ''));
        });
        input.value = names.length ? names.join(', ') : '';
        input.title = input.value;
        var help = document.getElementById('warehouseSelectHelp');
        if (help) help.textContent = selectedWarehousePks.length ? '選択済みの 倉庫 1개' : '選択済みの 倉庫 없음';
    }

    window.setItemWarehouseSelection = function(pks){
        selectedWarehousePks = (pks || []).map(function(v){ return String(v); }).filter(function(v, i, arr){ return v && arr.indexOf(v) === i; }).slice(0, 1);
        updateWarehouseNameText();
    };
    window.getItemWarehousePks = function(){
        return selectedWarehousePks.slice();
    };

    function loadWarehouseList(){
        return jsonFetch(contextPath + '/base/item/warehouse-list').then(function(rows){
            warehouseCache = rows || [];
            return warehouseCache;
        });
    }

    function renderWarehouseList(){
        var box = document.getElementById('itemWarehouseList');
        if (!warehouseCache.length){
            box.innerHTML = '<div class="hierarchy-empty">登録된 倉庫が 없습니다.</div>';
            updateWarehouseNameText();
            return;
        }
        box.innerHTML = '<label class="warehouse-option warehouse-none-option">' +
                       '<input type="radio" name="itemWarehouseChoice" class="item-warehouse-check" value=""' + (selectedWarehousePks.length === 0 ? ' checked' : '') + '>' +
                       '<span class="warehouse-option-main"><strong>保管倉庫 未指定</strong><span>倉庫 연결을 하지 않습니다.</span></span></label>' +
                       warehouseCache.map(function(w){
            var checked = selectedWarehousePks.indexOf(String(w.warehousePk)) >= 0 ? ' checked' : '';
            var useText = w.useYn === 'N' ? '未使用' : '使用';
            return '<label class="warehouse-option">' +
                   '<input type="radio" name="itemWarehouseChoice" class="item-warehouse-check" value="' + esc(w.warehousePk) + '"' + checked + '>' +
                   '<span class="warehouse-option-main"><strong>' + esc((w.warehouseCode || '') + ' - ' + (w.warehouseName || '')) + '</strong>' +
                   '<span>' + esc(useText) + '</span></span></label>';
        }).join('');
        box.querySelectorAll('.item-warehouse-check').forEach(function(chk){
            chk.addEventListener('change', function(){
                var pk = String(this.value || '');
                selectedWarehousePks = pk ? [pk] : [];
                updateWarehouseNameText();
            });
        });
        updateWarehouseNameText();
    }

    window.openItemWarehouseSelector = function(){
        loadWarehouseList().then(function(){
            renderWarehouseList();
            document.getElementById('itemWarehouseOverlay').classList.add('active');
        }).catch(function(err){ alert(err.message || '倉庫一覧을 を読み込めませんでした。'); });
    };
    window.closeItemWarehouseSelector = function(){
        document.getElementById('itemWarehouseOverlay').classList.remove('active');
    };
    window.applyItemWarehouseSelection = function(){
        closeItemWarehouseSelector();
        updateWarehouseNameText();
    };

    function hierarchyLabel(node){
        return (node.code ? node.code + ' - ' : '') + (node.name || '');
    }

    function childrenOf(parentPk){
        return hierarchyNodes.filter(function(n){ return String(n.parentPk || '') === String(parentPk || ''); });
    }

    function renderHierarchyTree(){
        var box = document.getElementById('itemHierarchyTree');
        if (!hierarchyNodes.length){
            box.innerHTML = '<div class="hierarchy-empty">登録済みの品目階層グループはありません。 右側で新規登録してください。</div>';
            return;
        }
        var roots = hierarchyNodes.filter(function(n){ return n.parentPk == null || String(n.parentPk) === ''; });
        box.innerHTML = roots.map(function(n){ return renderHierarchyNode(n); }).join('');
        box.querySelectorAll('.hierarchy-node').forEach(function(el){
            el.addEventListener('click', function(){
                var pk = String(el.getAttribute('data-pk'));
                selectedHierarchyNode = hierarchyNodes.find(function(n){ return String(n.pk) === pk; }) || null;
                renderHierarchyTree();
            });
        });
        var selectedText = document.getElementById('itemHierarchySelected');
        selectedText.textContent = selectedHierarchyNode ? hierarchyLabel(selectedHierarchyNode) : '未選択';
        if (selectedHierarchyNode){
            document.getElementById('itemHierarchyCode').value = selectedHierarchyNode.code || '';
            document.getElementById('itemHierarchyName').value = selectedHierarchyNode.name || '';
            loadItemHierarchyMembers(selectedHierarchyNode.pk);
        } else {
            clearItemHierarchyMembers();
        }
    }

    function renderHierarchyNode(node){
        var isSelected = selectedHierarchyNode && String(selectedHierarchyNode.pk) === String(node.pk);
        var children = childrenOf(node.pk);
        return '<div class="hierarchy-branch">' +
               '<div class="hierarchy-node' + (isSelected ? ' selected' : '') + '" data-pk="' + esc(node.pk) + '">' +
               '<i class="mdi ' + (children.length ? 'mdi-folder-open-outline' : 'mdi-folder-outline') + '"></i><span>' + esc(hierarchyLabel(node)) + '</span></div>' +
               (children.length ? '<div class="hierarchy-children">' + children.map(function(c){ return renderHierarchyNode(c); }).join('') + '</div>' : '') +
               '</div>';
    }

    let itemHierarchyMemberRequestSeq=0;


    function clearItemHierarchyMembers(){
        itemHierarchyMemberRequestSeq++;
        var box=document.getElementById('itemHierarchyMemberList');
        if(box) box.innerHTML='<div class="empty-members">フォルダーを選択すると品目一覧が表示されます。</div>';
    }

    function loadItemHierarchyMembers(pk){
        var box=document.getElementById('itemHierarchyMemberList');
        if(!box) return;
        var requestSeq=++itemHierarchyMemberRequestSeq, targetPk=String(pk);
        box.innerHTML='<div class="empty-members">読み込み中...</div>';
        jsonFetch(contextPath + '/base/item/hierarchy-members?itemHierGroupPk=' + encodeURIComponent(pk) + '&_=' + Date.now(),{cache:'no-store'})
            .then(function(rows){
                if(requestSeq!==itemHierarchyMemberRequestSeq || !selectedHierarchyNode || String(selectedHierarchyNode.pk)!==targetPk) return;
                rows=rows||[];
                box.innerHTML=rows.length ? rows.map(function(r){
                    return '<div class="member-row item-member-row"><span class="code">'+esc(r.itemCode||'')+'</span><span class="name">'+esc(r.itemName||'')+'</span><span class="spec">'+esc(r.spec||'')+'</span></div>';
                }).join('') : '<div class="empty-members">このフォルダーに割り当てられた品目はありません。</div>';
            }).catch(function(){
                if(requestSeq!==itemHierarchyMemberRequestSeq) return;
                box.innerHTML='<div class="empty-members">品目 목록을 を読み込めませんでした。</div>';
            });
    }

    function loadItemHierarchy(){
        return jsonFetch(contextPath + '/base/hierarchy-group/item/list?_=' + Date.now()).then(function(rows){
            hierarchyNodes = rows || [];
            renderHierarchyTree();
            return hierarchyNodes;
        });
    }

    window.openItemHierarchySelector = function(mode){
        hierarchyMode = mode || 'form';
        selectedHierarchyNode = null;
        var help = document.getElementById('itemHierarchyModeHelp');
        help.textContent = hierarchyMode === 'bulk' ? '選択済みの 品目に 適用する 폴더를 選択하세요.' : '品目登録에 適用する グループを 選択하세요.';
        document.getElementById('itemHierarchyCode').value = '';
        document.getElementById('itemHierarchyName').value = '';
        document.getElementById('itemHierarchySelected').textContent = '未選択';
        loadItemHierarchy().then(function(){
            document.getElementById('itemHierarchyOverlay').classList.add('active');
        }).catch(function(err){ alert(err.message || '階層グループ을 を読み込めませんでした。'); });
    };

    window.closeItemHierarchy = function(){
        document.getElementById('itemHierarchyOverlay').classList.remove('active');
    };

    function postHierarchy(url, payload){
        var body = new URLSearchParams();
        Object.keys(payload).forEach(function(k){ if (payload[k] !== null && payload[k] !== undefined && payload[k] !== '') body.append(k, payload[k]); });
        return jsonFetch(url, {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'}, body:body.toString()});
    }

    window.createItemHierarchyGroup = function(){
        var code = document.getElementById('itemHierarchyCode').value.trim();
        var name = document.getElementById('itemHierarchyName').value.trim();
        if (!code || !name){ alert('グループコードとグループ名を入力してください。'); return; }
        postHierarchy(contextPath + '/base/hierarchy-group/item/register', {
            code: code,
            name: name,
            parentPk: selectedHierarchyNode ? selectedHierarchyNode.pk : ''
        }).then(function(){
            alert('品目階層グループ이 登録しました。');
            return loadItemHierarchy();
        }).catch(function(err){ alert(err.message || '階層グループ 登録に失敗しました。'); });
    };

    window.editItemHierarchyGroup = function(){
        if (!selectedHierarchyNode){ alert('編集する グループを 選択してください。'); return; }
        var code = document.getElementById('itemHierarchyCode').value.trim();
        var name = document.getElementById('itemHierarchyName').value.trim();
        if (!code || !name){ alert('グループコードとグループ名を入力してください。'); return; }
        postHierarchy(contextPath + '/base/hierarchy-group/item/modify', {
            pk: selectedHierarchyNode.pk,
            code: code,
            name: name,
            parentPk: selectedHierarchyNode.parentPk || ''
        }).then(function(){
            alert('品目階層グループ이 編集しました。');
            selectedHierarchyNode = null;
            return loadItemHierarchy();
        }).catch(function(err){ alert(err.message || '階層グループ 編集に失敗しました。'); });
    };

    window.deleteItemHierarchyGroup = function(){
        if (!selectedHierarchyNode){ alert('削除する グループを 選択してください。'); return; }
        if (!confirm('選択した 階層グループ을 削除しますか？')) return;
        postHierarchy(contextPath + '/base/hierarchy-group/item/remove', {pk:selectedHierarchyNode.pk})
            .then(function(){
                alert('品目階層グループ이 削除しました。');
                selectedHierarchyNode = null;
                document.getElementById('itemHierarchySelected').textContent = '未選択';
                document.getElementById('itemHierarchyCode').value = '';
                document.getElementById('itemHierarchyName').value = '';
                clearItemHierarchyMembers();
                return loadItemHierarchy();
            }).catch(function(err){ alert(err.message || '階層グループ 削除に失敗しました。'); });
    };

    window.selectItemHierarchyGroup = function(){
        if (!selectedHierarchyNode){
            if (hierarchyMode === 'bulk') alert('適用する 階層グループ을 選択してください。');
            else alert('品目階層グループ을 選択してください。');
            return;
        }
        if (hierarchyMode === 'form'){
            document.getElementById('itemHierGroupPk').value = selectedHierarchyNode.pk;
            document.getElementById('itemHierGroupName').value = hierarchyLabel(selectedHierarchyNode);
            closeItemHierarchy();
            return;
        }
        var pks = getSelectedItemPks();
        if (!pks.length){ alert('階層グループ을 適用する 品目を 選択してください。'); return; }
        var body = new URLSearchParams();
        pks.forEach(function(pk){ body.append('itemPks', pk); });
        body.append('itemHierGroupPk', selectedHierarchyNode.pk);
        jsonFetch(contextPath + '/base/item/bulk-hierarchy-group', {
            method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'}, body:body.toString()
        }).then(function(){ alert(pks.length + '件の品目に 階層グループ을 に適用しました。'); loadItemHierarchyMembers(selectedHierarchyNode.pk); })
          .catch(function(err){ alert(err.message || '階層グループ の適用に失敗しました。'); });
    };


    function getSelectedItemPks(){
        return Array.from(document.querySelectorAll('.item-check:checked')).map(function(el){ return el.value; });
    }

    var itemChangeFields = [];
    var itemChangeIds = [];
    var itemChangeRows = [];
    var itemChangeRefs = {group1:[], group2:[], group3:[], hierarchy:[], process:[], qualityType:[], warehouse:[]};

    var ITEM_CHANGE_GROUPS = [
        {key:'itemInfo', label:'品目情報', fields:[
            {key:'itemName', label:'品目名', type:'text', required:true},
            {key:'spec', label:'規格', type:'text'},
            {key:'unit', label:'単位', type:'text'},
            {key:'itemDiv', label:'品目区分', type:'select', options:[['0','原材料'],['1','副資材'],['2','製品'],['3','半製品'],['4','商品'],['5','無形商品']]},
            {key:'qty', label:'在庫数量', type:'number'},
            {key:'vatRateSales', label:'消費税率（売上）', type:'number', step:'0.01'},
            {key:'vatRatePurchase', label:'消費税率（仕入）', type:'number', step:'0.01'},
            {key:'barcode', label:'バーコード', type:'text'},
            {key:'prodProcessPk', label:'生産工程', type:'ref', ref:'process'},
            {key:'searchContent', label:'検索欄の内容', type:'text'},
            {key:'imagePath', label:'画像', type:'image'}
        ]},
        {key:'classify', label:'分類・管理', fields:[
            {key:'itemGroup1Pk', label:'品目グループ1', type:'ref', ref:'group1'},
            {key:'itemGroup2Pk', label:'品目グループ2', type:'ref', ref:'group2'},
            {key:'itemGroup3Pk', label:'品目グループ3', type:'ref', ref:'group3'},
            {key:'itemHierGroupPk', label:'品目階層グループ', type:'ref', ref:'hierarchy'},
            {key:'warehousePks', label:'保管倉庫', type:'ref', ref:'warehouse'},
            {key:'qualityInspMethod', label:'品質検査方法', type:'select', options:[['0','全数検査'],['1','抜取検査'],['2','免除']]},
            {key:'qualityInspTypePk', label:'品質検査種別', type:'ref', ref:'qualityType'}
        ]},
        {key:'price', label:'単価·原価', fields:[
            {key:'purchasePrice', label:'入庫単価', type:'number', step:'0.01'},
            {key:'salesPrice', label:'出庫単価', type:'number', step:'0.01'},
            {key:'outsourcingPrice', label:'外注単価', type:'number', step:'0.01'},
            {key:'stdLaborTime', label:'標準作業時間', type:'number', step:'0.01'},
            {key:'expenseWeight', label:'経費配賦比率', type:'number', step:'0.01'},
            {key:'stdCostMaterial', label:'標準原価（材料）', type:'number', step:'0.01'},
            {key:'stdCostExpense', label:'標準原価（経費）', type:'number', step:'0.01'},
            {key:'stdCostLabor', label:'標準原価（労務）', type:'number', step:'0.01'},
            {key:'stdCostOutsourcing', label:'標準原価（外注）', type:'number', step:'0.01'}
        ]}
    ];
    function itemChangeFieldMap(){
        var map={}; ITEM_CHANGE_GROUPS.forEach(function(g){ g.fields.forEach(function(f){ map[f.key]=f; }); }); return map;
    }
    function itemChangeFieldDef(key){ return itemChangeFieldMap()[key]; }
    function itemChangeEscape(v){ return String(v == null ? '' : v).replace(/[&<>'"]/g, function(ch){ return {'&':'&amp;','<':'&lt;','>':'&gt;','\'':'&#39;','"':'&quot;'}[ch]; }); }
    function itemChangeLabelFromRef(ref,value){
        var list=itemChangeRefs[ref]||[]; var hit=list.find(function(o){ return String(itemChangeRefValue(o,ref))===String(value==null?'':value); });
        if(!hit) return '';
        return itemChangeRefText(hit,ref);
    }
    function itemChangeRefValue(o,ref){
        if(ref==='process') return o.prodProcessPk;
        if(ref==='qualityType') return o.qualityInspTypePk;
        if(ref==='hierarchy') return o.itemHierGroupPk;
        if(ref==='group1') return o.itemGroup1Pk;
        if(ref==='group2') return o.itemGroup2Pk;
        if(ref==='group3') return o.itemGroup3Pk;
        if(ref==='warehouse') return o.warehousePk;
        return '';
    }
    function itemChangeRefText(o,ref){
        if(ref==='warehouse') return (o.warehouseCode||'') + ' - ' + (o.warehouseName||'');
        return '['+(o.code||'')+'] '+(o.name||'');
    }
    function renderItemChangeFields(){
        var body=document.getElementById('itemChangeFieldBody');
        var html='';
        ITEM_CHANGE_GROUPS.forEach(function(group){
            var activeCount=group.fields.filter(function(f){return itemChangeFields.indexOf(f.key)>=0;}).length;
            html += '<tr class="change-field-group" data-group="'+group.key+'"><td class="change-check-col"><input type="checkbox" class="item-change-group-check" data-group="'+group.key+'" '+(activeCount===group.fields.length?'checked':'')+'></td><td><span class="group-label">'+itemChangeEscape(group.label)+'</span><span class="group-count">'+activeCount+'/'+group.fields.length+'</span></td></tr>';
            group.fields.forEach(function(field){
                var checked=itemChangeFields.indexOf(field.key)>=0;
                html += '<tr class="change-field-item '+(field.required?'required':'')+'" data-field="'+field.key+'"><td class="change-check-col"><input type="checkbox" class="item-change-field-check" value="'+field.key+'" '+(checked?'checked':'')+(field.required?' disabled':'')+'></td><td><span class="field-label">'+itemChangeEscape(field.label)+'</span>'+(field.required?'<span class="field-required-badge">필수</span>':'')+'</td></tr>';
            });
        });
        body.innerHTML=html;
        document.getElementById('itemChangeFieldAll').checked=ITEM_CHANGE_GROUPS.every(function(g){ return g.fields.every(function(f){return itemChangeFields.indexOf(f.key)>=0;}); });
        body.querySelectorAll('.item-change-field-check').forEach(function(cb){ cb.addEventListener('change',function(){
            if(this.checked){ if(itemChangeFields.indexOf(this.value)<0)itemChangeFields.push(this.value); }
            else itemChangeFields=itemChangeFields.filter(function(v){return v!==this.value;},this);
            if(itemChangeFields.indexOf('itemName')<0)itemChangeFields.unshift('itemName'); syncItemChangeFieldUI();
        }); });
        body.querySelectorAll('.item-change-group-check').forEach(function(cb){ cb.addEventListener('change',function(){
            var group=ITEM_CHANGE_GROUPS.find(function(g){return g.key===cb.dataset.group;});
            group.fields.forEach(function(f){
                if(cb.checked){ if(itemChangeFields.indexOf(f.key)<0)itemChangeFields.push(f.key); }
                else if(!f.required)itemChangeFields=itemChangeFields.filter(function(v){return v!==f.key;});
            });
            if(itemChangeFields.indexOf('itemName')<0)itemChangeFields.unshift('itemName'); renderItemChangeFields();
        }); });
        updateItemChangeFieldCount();
    }
    function syncItemChangeFieldUI(){
        var all=itemChangeFields;
        document.querySelectorAll('#itemChangeFieldBody .item-change-field-check').forEach(function(cb){cb.checked=all.indexOf(cb.value)>=0;});
        document.querySelectorAll('#itemChangeFieldBody .item-change-group-check').forEach(function(cb){var g=ITEM_CHANGE_GROUPS.find(function(x){return x.key===cb.dataset.group;});cb.checked=g.fields.every(function(f){return all.indexOf(f.key)>=0;});});
        document.getElementById('itemChangeFieldAll').checked=ITEM_CHANGE_GROUPS.every(function(g){return g.fields.every(function(f){return all.indexOf(f.key)>=0;});});
        updateItemChangeFieldCount();
    }
    function updateItemChangeFieldCount(){
        var n=itemChangeFields.length; document.getElementById('itemChangeFieldCount').textContent=n+'項目選択済み';
    }
    document.getElementById('itemChangeFieldAll').addEventListener('change',function(){
        itemChangeFields=['itemName'];
        if(this.checked){ ITEM_CHANGE_GROUPS.forEach(function(g){g.fields.forEach(function(f){if(itemChangeFields.indexOf(f.key)<0)itemChangeFields.push(f.key);});}); }
        renderItemChangeFields();
    });
    document.getElementById('itemChangeBasicFields').addEventListener('click',function(){
        itemChangeFields=['itemName']; renderItemChangeFields();
    });
    function collectItemChangeFields(){
        var selected=Array.from(document.querySelectorAll('#itemChangeFieldBody .item-change-field-check:checked')).map(function(c){return c.value;});
        if(selected.indexOf('itemName')<0) selected.unshift('itemName');
        return selected;
    }
    function loadItemChangeRefs(){
        return Promise.all([
            jsonFetch(contextPath+'/base/item/group1-list'),jsonFetch(contextPath+'/base/item/group2-list'),jsonFetch(contextPath+'/base/item/group3-list'),
            jsonFetch(contextPath+'/base/item/hier-group-list'),jsonFetch(contextPath+'/base/item/prod-process-list'),jsonFetch(contextPath+'/base/item/quality-insp-type-list'),jsonFetch(contextPath+'/base/item/warehouse-list')
        ]).then(function(rows){
            itemChangeRefs={group1:rows[0]||[],group2:rows[1]||[],group3:rows[2]||[],hierarchy:rows[3]||[],process:rows[4]||[],qualityType:rows[5]||[],warehouse:rows[6]||[]};
        });
    }
    function openItemChange(){
        var pks=getSelectedItemPks();
        if(!pks.length){alert('変更할 品目を 先に選択してください。');return;}
        itemChangeIds=pks.map(function(v){return Number(v);}); itemChangeFields=['itemName'];
        renderItemChangeFields(); document.getElementById('itemChangeFieldOverlay').classList.add('active');
    }
    window.closeItemChangeFields=function(){document.getElementById('itemChangeFieldOverlay').classList.remove('active');};
    window.applyItemChangeFields=function(){
        itemChangeFields=collectItemChangeFields();
        if(!itemChangeFields.length){alert('変更する項目を1つ以上選択してください。');return;}
        loadItemChangeRows().then(function(){
            document.getElementById('itemChangeFieldOverlay').classList.remove('active');
            document.getElementById('itemChangeGridOverlay').classList.add('active');
        }).catch(function(err){alert(err.message||'変更 데이터를 を読み込めませんでした。');});
    };
    function loadItemChangeRows(){
        document.getElementById('itemChangeGridWrap').innerHTML='<div class="change-grid-loading">変更画面を準備しています。</div>';
        return loadItemChangeRefs().then(function(){return Promise.all(itemChangeIds.map(function(pk){return jsonFetch(contextPath+'/base/item/get?itemPk='+encodeURIComponent(pk));}));}).then(function(rows){
            itemChangeRows=rows||[]; renderItemChangeGrid();
        });
    }
    function itemChangeControlHtml(field,row){
        var value=row[field.key];
        if(field.key==='warehousePks') value=(row.warehousePks&&row.warehousePks.length)?row.warehousePks[0]:'';
        if(field.type==='text') return '<input class="change-input" data-field="'+field.key+'" type="text" value="'+itemChangeEscape(value==null?'':value)+'">';
        if(field.type==='number') return '<input class="change-input change-number" data-field="'+field.key+'" type="number" step="'+(field.step||'1')+'" value="'+itemChangeEscape(value==null?'':value)+'">';
        if(field.type==='select') return '<select class="change-select" data-field="'+field.key+'">'+field.options.map(function(o){return '<option value="'+o[0]+'" '+(String(value==null?'':value)===o[0]?'selected':'')+'>'+o[1]+'</option>';}).join('')+'</select>';
        if(field.type==='ref'){
            var current=field.key==='warehousePks'?((row.warehousePks||[])[0]||''):value;
            var opts=(itemChangeRefs[field.ref]||[]).map(function(o){var v=itemChangeRefValue(o,field.ref);return '<option value="'+itemChangeEscape(v)+'" '+(String(v)==String(current==null?'':current)?'selected':'')+'>'+itemChangeEscape(itemChangeRefText(o,field.ref))+'</option>';}).join('');
            return '<select class="change-select" data-field="'+field.key+'"><option value="">未選択</option>'+opts+'</select>';
        }
        if(field.type==='image'){
            var src=row.imagePath?contextPath+row.imagePath:'';
            return '<div class="change-image-cell"><div class="change-image-preview '+(!src?'change-image-empty':'')+'">'+(src?'<img class="change-image-thumb" src="'+itemChangeEscape(src)+'" alt="">':'<i class="mdi mdi-image-outline"></i>')+'</div><input class="change-file-input" data-field="imagePath" type="file" accept="image/*"></div>';
        }
        return '';
    }
    function renderItemChangeGrid(){
        var map=itemChangeFieldMap();
        var fields=itemChangeFields.map(function(k){return map[k];}).filter(Boolean);
        var html='<table class="change-grid-table"><thead><tr><th class="sticky-col-1"><input type="checkbox" id="itemChangeRowAll" checked></th><th class="sticky-col-2">品目コード</th>'+fields.map(function(f){return '<th>'+itemChangeEscape(f.label)+'</th>';}).join('')+'</tr></thead><tbody>';
        itemChangeRows.forEach(function(row,idx){
            html+='<tr data-pk="'+row.itemPk+'"><td class="sticky-col-1"><input type="checkbox" class="item-change-row-check" data-pk="'+row.itemPk+'" checked></td><td class="sticky-col-2 change-code">'+itemChangeEscape(row.itemCode||'')+'</td>'+fields.map(function(f){return '<td>'+itemChangeControlHtml(f,row)+'</td>';}).join('')+'</tr>';
        });
        html+='</tbody></table>';
        document.getElementById('itemChangeGridWrap').innerHTML=itemChangeRows.length?html:'<div class="change-grid-empty">変更할 品目が 없습니다.</div>';
        document.getElementById('itemChangeTargetCount').textContent=itemChangeRows.length+'개';
        document.getElementById('itemChangeCommonField').innerHTML=fields.map(function(f){return '<option value="'+f.key+'">'+itemChangeEscape(f.label)+'</option>';}).join('');
        updateItemChangeCommonControl(); updateItemChangeRowCount();
        var all=document.getElementById('itemChangeRowAll'); if(all) all.addEventListener('change',function(){document.querySelectorAll('.item-change-row-check').forEach(function(c){c.checked=all.checked;});updateItemChangeRowCount();});
        document.querySelectorAll('.item-change-row-check').forEach(function(c){c.addEventListener('change',updateItemChangeRowCount);});
        document.getElementById('itemChangeCommonField').addEventListener('change',updateItemChangeCommonControl);
        document.getElementById('itemChangeCommonApply').onclick=applyItemChangeCommon;
    }
    function updateItemChangeRowCount(){var n=document.querySelectorAll('.item-change-row-check:checked').length;document.getElementById('itemChangeRowCount').textContent=n+'件の品目を選択済み';}
    function changeCommonControlHtml(field){
        var map=itemChangeFieldDef(field); if(!map)return '';
        if(map.type==='text')return '<input class="change-input" id="itemChangeCommonValue" type="text" placeholder="一括適用する値を入力">';
        if(map.type==='number')return '<input class="change-input" id="itemChangeCommonValue" type="number" step="'+(map.step||'1')+'" placeholder="共通値">';
        if(map.type==='select')return '<select class="change-select" id="itemChangeCommonValue">'+map.options.map(function(o){return '<option value="'+o[0]+'">'+o[1]+'</option>';}).join('')+'</select>';
        if(map.type==='ref')return '<select class="change-select" id="itemChangeCommonValue"><option value="">未選択</option>'+(itemChangeRefs[map.ref]||[]).map(function(o){return '<option value="'+itemChangeEscape(itemChangeRefValue(o,map.ref))+'">'+itemChangeEscape(itemChangeRefText(o,map.ref))+'</option>';}).join('')+'</select>';
        return '<span class="change-field-hint">画像ファイルは各行で選択してください。</span>';
    }
    function updateItemChangeCommonControl(){var field=document.getElementById('itemChangeCommonField').value;document.getElementById('itemChangeCommonControl').innerHTML=changeCommonControlHtml(field);}
    function applyItemChangeCommon(){
        var pks=Array.from(document.querySelectorAll('.item-change-row-check:checked')).map(function(c){return c.dataset.pk;}); if(!pks.length){alert('共通値을 適用する 행을 選択してください。');return;}
        var field=document.getElementById('itemChangeCommonField').value;var control=document.getElementById('itemChangeCommonValue');if(!control){alert('画像는 각 행에서 직접 選択してください。');return;}
        var value=control.value;document.querySelectorAll('.item-change-row-check:checked').forEach(function(cb){var tr=cb.closest('tr');var target=tr.querySelector('[data-field="'+field+'"]');if(target)target.value=value;});
    }
    window.backToItemChangeFields=function(){document.getElementById('itemChangeGridOverlay').classList.remove('active');renderItemChangeFields();document.getElementById('itemChangeFieldOverlay').classList.add('active');};
    window.closeItemChangeGrid=function(){document.getElementById('itemChangeGridOverlay').classList.remove('active');};
    function saveItemChangeGrid(){
        var selected=Array.from(document.querySelectorAll('.item-change-row-check:checked')); if(!selected.length){alert('保存する 행을 選択してください。');return;}
        var fields=itemChangeFields.slice(); var requests=[];
        selected.forEach(function(cb){
            var tr=cb.closest('tr'); var fd=new FormData(); fd.append('itemPk',cb.dataset.pk); fields.forEach(function(f){fd.append('fields',f);});
            fields.forEach(function(f){var c=tr.querySelector('[data-field="'+f+'"]');if(!c)return;if(f==='imagePath')return;if(f==='warehousePks'){if(c.value)fd.append('warehousePks',c.value);}else fd.append(f,c.value);});
            var file=tr.querySelector('input[type=file][data-field="imagePath"]');if(file&&file.files&&file.files[0])fd.append('imageFile',file.files[0]);
            requests.push(fetch(contextPath+'/base/item/change',{method:'POST',body:fd}).then(function(res){return res.text().then(function(t){if(!res.ok)throw new Error(t||'品目 変更 中にエラーが発生しました。');return t;});}));
        });
        Promise.all(requests).then(function(){alert(selected.length+'件の品目を 変更했습니다.');location.reload();}).catch(function(err){alert(err.message||'品目 変更 中にエラーが発生しました。');});
    }
    window.saveItemChangeGrid=saveItemChangeGrid;

    document.getElementById('btnBulkChange').addEventListener('click', openItemChange);
    document.getElementById('btnBulkHierarchy').addEventListener('click', function(){
        var pks = getSelectedItemPks();
        if (!pks.length){ alert('階層グループ을 適用する 品目を 先に選択してください。'); return; }
        openItemHierarchySelector('bulk');
    });

    document.getElementById('itemWarehouseOverlay').addEventListener('click', function(e){ if (e.target === this) closeItemWarehouseSelector(); });
    document.getElementById('itemHierarchyOverlay').addEventListener('click', function(e){ if (e.target === this) closeItemHierarchy(); });
    document.getElementById('itemChangeFieldOverlay').addEventListener('click', function(e){ if (e.target === this) closeItemChangeFields(); });
    document.getElementById('itemChangeGridOverlay').addEventListener('click', function(e){ if (e.target === this) closeItemChangeGrid(); });
})();
</script>
</body>
</html>
