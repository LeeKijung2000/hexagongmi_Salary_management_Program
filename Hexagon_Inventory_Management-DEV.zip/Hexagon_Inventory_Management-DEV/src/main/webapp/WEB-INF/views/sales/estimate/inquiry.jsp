<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="my" tagdir="/WEB-INF/tags"%>

<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>見積書照会 - Hexagon ERP</title>

<style>
/* 기본 화면 */
/* 基本画面 */
.estimate-inquiry-body {
	margin: 0;
	background: #f5f7fc;
	color: #293c59;
	font: 13px "Yu Gothic", Meiryo, "Malgun Gothic", Arial, sans-serif;
}

.estimate-inquiry-body *, .estimate-inquiry-body *::before,
	.estimate-inquiry-body *::after {
	box-sizing: border-box;
}

.estimate-inquiry-body button, .estimate-inquiry-body input,
	.estimate-inquiry-body select {
	font: inherit;
}

.estimate-inquiry-body button {
	cursor: pointer;
}

.estimate-inquiry-body button:disabled {
	opacity: .45;
	cursor: not-allowed;
}

.estimate-inquiry-body .erp-main {
	min-width: 0;
	height: 100vh;
	overflow-y: auto;
}

.estimate-inquiry-body .erp-content {
	min-width: 0;
	width: 100%;
	padding: 18px 20px 65px;
}

.iq-page {
	width: 100%;
	min-width: 0;
}

.iq-flex {
	display: flex;
	align-items: center;
	flex-wrap: wrap;
	gap: 8px;
}

.iq-top, .iq-summary {
	display: flex;
	justify-content: space-between;
	align-items: center;
	flex-wrap: wrap;
	gap: 10px;
}

.iq-top {
	margin-bottom: 12px;
}

.iq-title {
	margin: 0 12px 0 0;
	font-size: 21px;
	font-weight: bold;
	white-space: nowrap;
}

.iq-btn {
	min-height: 32px;
	padding: 5px 13px;
	border: 1px solid #d8e2f1;
	border-radius: 13px;
	background: white;
	color: #365176;
	white-space: nowrap;
}

.iq-btn






:hover






:not



 



(
:disabled



 



)
{
background






:



 



#edf3ff






;
}
.iq-btn.primary {
	background: #3052e8;
	border-color: #3052e8;
	color: white;
}

.iq-btn.danger {
	color: #c23b50;
}

.iq-input {
	width: 100%;
	min-width: 0;
	min-height: 35px;
	padding: 6px 10px;
	border: 1px solid #d8e2f0;
	border-radius: 9px;
	outline: none;
	background: white;
	color: #304b73;
}

.iq-input:focus {
	border-color: #5a83ec;
	box-shadow: 0 0 0 2px rgba(90, 131, 236, .1);
}

.iq-keyword {
	width: 185px;
}

.iq-date {
	width: 150px;
}

.iq-message {
	margin: 12px 0;
	min-height: 18px;
	color: #4c70ac;
	font-size: 12px;
}

.iq-message.error {
	color: #c43a51;
}

.iq-help {
	color: #879bb9;
	font-size: 11px;
}

/* 진행상태 탭 */
/* 進捗状態タブ */
.iq-tabs {
	display: flex;
	align-items: center;
	flex-wrap: wrap;
	gap: 5px;
}

.iq-tab {
	display: inline-flex;
	align-items: center;
	justify-content: center;
	gap: 7px;
	min-height: 36px;
	padding: 6px 14px;
	border: 1px solid #e6ebf3;
	border-radius: 22px;
	background: #f0f2f7;
	color: #abb6c9;
	white-space: nowrap;
	font-weight: 400;
}

.iq-tab






.has-data






:not



 



(
.active



 



)
{
background






:



 



#d1e0ff






;
border-color






:



 



#9ebeff






;
color






:



 



#1944a7






;
font-weight






:



 



700;
}
.iq-tab






.empty






:not



 



(
.active



 



)
{
background






:



 



#f0f2f7






;
border-color






:



 



#e9edf4






;
color






:



 



#aab6ca






;
}
.iq-tab.active {
	background: #2445cf;
	border-color: #2445cf;
	color: white;
	font-weight: 700;
}

.iq-tab .tab-count {
	display: inline-flex;
	align-items: center;
	justify-content: center;
	min-width: 20px;
	height: 20px;
	padding: 0 5px;
	border: 1px solid #d1dbea;
	border-radius: 50%;
	background: white;
	color: #9aaac1;
	font-size: 11px;
	font-weight: 700;
}

.iq-tab.active .tab-count {
	color: white;
	background: rgba(255, 255, 255, .2);
	border-color: rgba(255, 255, 255, .65);
}

.iq-arrow {
	color: #a9b9d1;
}

.iq-summary {
	margin: 9px 0 5px;
}

.iq-count {
	display: flex;
	align-items: center;
	gap: 8px;
	color: #7a8daa;
}

.iq-count strong {
	display: inline-flex;
	align-items: center;
	justify-content: center;
	width: 31px;
	height: 31px;
	border-radius: 50%;
	background: #3052e8;
	color: white;
}

/* 견적서 목록 */
/* 見積書一覧 */
.iq-table-wrap {
	width: 100%;
	overflow-x: auto;
	border: 1px solid #dae3ee;
	background: white;
}

.iq-table {
	width: 100%;
	min-width: 900px;
	border-collapse: collapse;
	table-layout: fixed;
}

.iq-table th, .iq-table td {
	min-width: 0;
	padding: 8px 6px;
	border: 1px solid #dce5ef;
	overflow-wrap: anywhere;
}

.iq-table thead th {
	height: 40px;
	background: #eef2f8;
	text-align: center;
	font-weight: 600;
	font-size: 12px;
}

.iq-table tbody td {
	height: 47px;
	background: white;
	font-size: 12px;
}

.iq-table tbody tr.selected td {
	background: #e0edff;
}

.iq-table tbody tr:hover td {
	background: #f4f8ff;
}

.iq-col-no {
	width: 4%;
}

.iq-col-number {
	width: 16%;
}

.iq-col-partner {
	width: 15%;
}

.iq-col-manager {
	width: 10%;
}

.iq-col-item {
	width: 18%;
}

.iq-col-valid {
	width: 9%;
}

.iq-col-amount {
	width: 10%;
}

.iq-col-status {
	width: 9%;
}

.iq-col-created {
	width: 9%;
}

.iq-table .center {
	text-align: center;
}

.iq-table .amount {
	text-align: right;
	white-space: nowrap;
}

.iq-table .summary-text {
	overflow: hidden;
	text-overflow: ellipsis;
	white-space: nowrap;
}

.iq-table .number-text {
	line-height: 1.45;
}

.iq-no {
	width: 31px;
	height: 30px;
	padding: 0;
	border: 1px solid #d1dceb;
	border-radius: 8px;
	background: white;
	color: #8496b2;
}

.iq-no.selected {
	color: white;
	background: #3155e8;
	border-color: #3155e8;
}

.iq-link {
	border: 0;
	padding: 2px;
	color: #2857ad;
	background: transparent;
	text-decoration: underline;
}

.iq-link:hover {
	color: #123c92;
}

.iq-empty {
	padding: 30px !important;
	text-align: center;
	color: #8a9bb6;
}

.iq-status-button {
	width: 100%;
	padding: 6px 3px;
	border: 0;
	border-radius: 15px;
	color: #2655ac;
	background: #dce7ff;
	font-weight: 600;
}

.iq-status-button.complete {
	color: #bd7925;
	background: #fff0da;
}

.iq-status-button.local {
	color: #65758e;
	background: #e8edf7;
}

.iq-footer {
	display: flex;
	flex-wrap: wrap;
	align-items: center;
	gap: 8px;
	margin-top: 12px;
}

/* 진행상태 변경 메뉴 */
/* 進捗状態変更メニュー */
.iq-status-menu {
	display: none;
	position: fixed;
	z-index: 9800;
	width: 198px;
	padding: 8px;
	background: white;
	border: 1px solid #d8e2f0;
	border-radius: 14px;
	box-shadow: 0 10px 28px rgba(25, 45, 85, .18);
}

.iq-status-menu.open {
	display: block;
}

.iq-menu-title {
	padding: 6px 10px 3px;
	color: #8797ae;
	font-size: 11px;
}

.iq-menu-item {
	width: 100%;
	padding: 9px 12px;
	border: 0;
	border-radius: 8px;
	background: white;
	color: #365176;
	text-align: left;
}

.iq-menu-item:hover {
	background: #edf3ff;
}

.iq-menu-line {
	border-top: 1px solid #e6ebf4;
	margin: 5px 0;
}

/* 공통 팝업 */
/* 共通モーダル */
.iq-overlay {
	display: none;
	position: fixed;
	inset: 0;
	z-index: 9900;
	align-items: center;
	justify-content: center;
	padding: 18px;
	background: rgba(20, 30, 50, .5);
}

.iq-overlay.open {
	display: flex;
}

.iq-order-overlay {
	z-index: 9950;
}

.iq-lookup-overlay {
	z-index: 9990;
}

.iq-modal {
	display: flex;
	flex-direction: column;
	width: min(1180px, 97vw);
	max-height: 93vh;
	min-height: 0;
	background: #f5f7fb;
	border-radius: 14px;
	overflow: hidden;
	box-shadow: 0 18px 50px rgba(0, 0, 0, .24);
}

.iq-modal-head {
	display: flex;
	align-items: center;
	justify-content: space-between;
	gap: 12px;
	padding: 12px 16px;
	background: #254bd4;
	color: white;
}

.iq-modal-head h2 {
	margin: 0;
	font-size: 16px;
}

.iq-modal-body {
	min-height: 0;
	overflow-y: auto;
	padding: 15px;
}

.iq-modal-foot {
	display: flex;
	align-items: center;
	justify-content: flex-end;
	flex-wrap: wrap;
	gap: 8px;
	padding: 10px 15px;
	background: white;
	border-top: 1px solid #dce4f0;
}

.iq-card {
	margin-bottom: 12px;
	padding: 15px;
	border: 1px solid #dce4f0;
	border-radius: 14px;
	background: white;
}

.iq-card h3 {
	margin: 0 0 11px;
	font-size: 14px;
}

.iq-form-grid {
	display: grid;
	grid-template-columns: 1fr 1fr;
	gap: 11px 17px;
}

.iq-field {
	display: grid;
	grid-template-columns: 98px minmax(0, 1fr);
	align-items: center;
	gap: 8px;
}

.iq-field.wide {
	grid-column: 1/-1;
}

.iq-field label {
	color: #60789b;
}

.iq-pair {
	display: flex;
	align-items: center;
	gap: 4px;
	min-width: 0;
}

.iq-pair .iq-input {
	flex: 1;
	width: 40%;
}

.iq-readonly {
	background: #f3f5f9;
}

.iq-xscroll {
	width: 100%;
	overflow-x: auto;
}

.iq-detail-table {
	width: 100%;
	min-width: 850px;
	border-collapse: collapse;
	background: white;
}

.iq-detail-table th, .iq-detail-table td {
	border: 1px solid #dce4ee;
	padding: 6px;
}

.iq-detail-table th {
	background: #edf2f9;
	text-align: center;
}

.iq-detail-table td input {
	width: 100%;
}

.iq-detail-table tfoot td {
	background: #edf2f9;
	font-weight: bold;
}

.iq-numeric {
	text-align: right;
}

.iq-inline-toolbar {
	display: flex;
	gap: 8px;
	margin-bottom: 9px;
}

.iq-search-modal {
	width: min(1040px, 95vw);
	max-height: 91vh;
}

.iq-search-tabs {
	display: flex;
	padding: 10px 17px;
	border-bottom: 1px solid #e2e9f3;
	background: #f9fbfe;
}

.iq-search-tab {
	padding: 6px 12px;
	border-bottom: 2px solid #2655dd;
	color: #214cab;
	font-weight: 700;
}

.iq-search-form {
	padding: 15px;
	border: 1px solid #dce4ef;
	border-radius: 13px;
	background: white;
}

.iq-search-field {
	display: grid;
	grid-template-columns: 125px minmax(0, 1fr);
	align-items: center;
	gap: 12px;
	min-height: 49px;
}

.iq-search-field label {
	color: #657b9b;
}

.iq-search-lookup {
	display: flex;
	align-items: center;
	gap: 6px;
	min-width: 0;
}

.iq-search-lookup .iq-input {
	flex: 1;
}

.iq-search-icon {
	width: 38px;
	min-width: 38px;
	height: 35px;
	padding: 0;
	border: 1px solid #d7e1f0;
	border-radius: 9px;
	background: white;
	color: #3461b4;
}

.iq-search-icon svg {
	width: 17px;
	height: 17px;
}

.iq-search-presets {
	display: flex;
	align-items: center;
	gap: 4px;
	flex-wrap: wrap;
}

.iq-preset {
	border: 0;
	border-radius: 8px;
	padding: 7px 9px;
	color: #426086;
	background: transparent;
}

.iq-lookup-modal {
	width: min(750px, 94vw);
	max-height: 82vh;
}

.iq-lookup-list {
	width: 100%;
	border-collapse: collapse;
}

.iq-lookup-list th, .iq-lookup-list td {
	border: 1px solid #e0e6ef;
	padding: 9px;
	text-align: left;
}

.iq-lookup-list th {
	background: #f0f3f9;
}

.iq-lookup-list tbody tr:hover {
	background: #e9f1ff;
	cursor: pointer;
}

/* 핵심 수정: 주문서입력 팝업 하단 잘림 방지 */
/* 主な修正：受注入力モーダルの下部が隠れる問題を防止 */
#orderOverlay {
	padding: 8px !important;
}

#orderOverlay>.iq-modal {
	width: calc(100vw - 16px) !important;
	height: calc(100vh - 16px) !important;
	max-height: calc(100vh - 16px) !important;
	min-height: 0 !important;
	display: flex !important;
	flex-direction: column !important;
}

#orderOverlay .iq-modal-head, #orderOverlay .iq-modal-foot {
	flex: 0 0 auto !important;
}

#orderOverlay .iq-modal-head {
	padding: 9px 14px !important;
}

#orderOverlay .iq-modal-foot {
	padding: 7px 14px !important;
}

#orderOverlay .iq-modal-body {
	display: flex !important;
	flex-direction: column !important;
	flex: 1 1 0 !important;
	min-height: 0 !important;
	padding: 0 !important;
	overflow: hidden !important;
}

#orderOverlay #orderLoadMessage {
	flex: 0 0 auto !important;
	padding: 8px 14px !important;
	margin: 0 !important;
}

#orderOverlay #orderIframe {
	display: block;
	flex: 1 1 0 !important;
	width: 100% !important;
	height: 100% !important;
	min-height: 0 !important;
	max-height: none !important;
	border: 0 !important;
	background: white;
}

#orderOverlay #orderIframe[hidden] {
	display: none !important;
}

@media ( max-width : 900px) {
	.iq-form-grid {
		grid-template-columns: 1fr;
	}
	.iq-field.wide {
		grid-column: auto;
	}
	.iq-search-field {
		grid-template-columns: 95px minmax(0, 1fr);
	}
}
</style>
</head>

<body class="estimate-inquiry-body">

    <div class="erp-wrapper">
        <my:sideMenu />


        <div class="erp-main">
            <main class="erp-content">
                <section class="iq-page">

                    <!--
                    견적서 조회 상단
                    見積書照会画面の上部
                -->
                    <div class="iq-top">
                        <div class="iq-flex">
                            <h1 class="iq-title">見積書照会</h1>

                            <div id="statusTabs" class="iq-tabs">
                                <button type="button" class="iq-tab active" data-status="">
                                    すべて <span class="tab-count">0</span>
                                </button>
                                <button type="button" class="iq-tab" data-status="APPROVAL">
                                    承認中 <span class="tab-count">0</span>
                                </button>
                                <button type="button" class="iq-tab" data-status="UNREAD">
                                    未確認 <span class="tab-count">0</span>
                                </button>
                                <span class="iq-arrow">›</span>
                                <button type="button" class="iq-tab" data-status="CONFIRMED">
                                    確認 <span class="tab-count">0</span>
                                </button>
                                <span class="iq-arrow">›</span>
                                <button type="button" class="iq-tab" data-status="PROGRESS">
                                    進行中 <span class="tab-count">0</span>
                                </button>
                                <span class="iq-arrow">›</span>
                                <button type="button" class="iq-tab" data-status="COMPLETE">
                                    完了 <span class="tab-count">0</span>
                                </button>
                            </div>
                        </div>

                        <div class="iq-flex">
                            <input id="keyword" class="iq-input iq-keyword" placeholder="検索キーワードを入力">
                            <button id="searchBtn" type="button" class="iq-btn primary">Search(F3)</button>
                        </div>
                    </div>

                    <!--
                    조회 기간
                    検索期間
                -->
                    <div class="iq-summary">
                        <div class="iq-count">
                            <strong>1</strong> <span id="recordCount">0件</span> <span>» / 1</span>
                        </div>
                        <div class="iq-flex">
                            <input id="startDate" type="date" class="iq-input iq-date"> <span>~</span> <input id="endDate" type="date" class="iq-input iq-date">
                        </div>
                    </div>

                    <!--
                    견적서 목록
                    見積書一覧
                -->
                    <div class="iq-table-wrap">
                        <table class="iq-table">
                            <colgroup>
                                <col class="iq-col-no">
                                <col class="iq-col-number">
                                <col class="iq-col-partner">
                                <col class="iq-col-manager">
                                <col class="iq-col-item">
                                <col class="iq-col-valid">
                                <col class="iq-col-amount">
                                <col class="iq-col-status">
                                <col class="iq-col-created">
                            </colgroup>
                            <thead>
                                <tr>
                                    <th><button id="selectAllBtn" type="button" class="iq-link">No.</button></th>
                                    <th>日付-No.</th>
                                    <th>取引先名</th>
                                    <th>担当社員名</th>
                                    <th>品目名（概要）</th>
                                    <th>有効期限</th>
                                    <th>見積金額合計</th>
                                    <th>進捗状態</th>
                                    <th>作成済み伝票</th>
                                </tr>
                            </thead>
                            <tbody id="quotationRows">
                                <tr>
                                    <td colspan="9" class="iq-empty">見積書を照会しています。</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <!--
                    하단 기능
                    下部の操作ボタン
                -->
                    <div class="iq-footer">
                        <button id="newBtn" type="button" class="iq-btn primary">新規(F2)</button>
                        <button id="statusMenuBtn" type="button" class="iq-btn">進捗状態を変更 ▴</button>
                        <button id="deleteBtn" type="button" class="iq-btn danger" disabled>選択削除</button>
                    </div>

                    <div id="message" class="iq-message" role="status"></div>
                    <div class="iq-help">No.の数字をクリックすると見積書を選択できます。状態の変更内容はOracleに保存されます。</div>

                </section>
            </main>
        </div>
    </div>

    <!--
    진행상태 변경 메뉴
    進捗状態変更メニュー
-->
    <div id="statusMenu" class="iq-status-menu">
        <div class="iq-menu-title">承認状態</div>
        <button type="button" class="iq-menu-item" data-change-status="APPROVAL">承認中</button>
        <div class="iq-menu-line"></div>
        <div class="iq-menu-title">確認状態</div>
        <button type="button" class="iq-menu-item" data-change-status="UNREAD">未確認</button>
        <button type="button" class="iq-menu-item" data-change-status="CONFIRMED">確認</button>
        <div class="iq-menu-line"></div>
        <div class="iq-menu-title">業務進捗状態</div>
        <button type="button" class="iq-menu-item" data-change-status="PROGRESS">進行中</button>
        <button type="button" class="iq-menu-item" data-change-status="COMPLETE">完了</button>
    </div>

    <!--
    상세검색 팝업
    詳細検索モーダル
-->
    <div id="searchOverlay" class="iq-overlay" role="dialog" aria-modal="true" aria-label="見積書の詳細検索">
        <div class="iq-modal iq-search-modal">
            <div class="iq-modal-head">
                <h2>見積書照会 - 詳細検索</h2>
                <button id="searchCloseTop" type="button" class="iq-btn">閉じる ×</button>
            </div>
            <div class="iq-search-tabs">
                <span class="iq-search-tab">基本</span>
            </div>
            <div class="iq-modal-body">
                <div class="iq-search-form">

                    <div class="iq-search-field">
                        <label>基準日</label>
                        <div class="iq-flex">
                            <input id="searchStartDate" type="date" class="iq-input iq-date"> <span>~</span> <input id="searchEndDate" type="date" class="iq-input iq-date">
                        </div>
                    </div>

                    <div class="iq-search-field">
                        <label for="searchVoucher">見積No.</label> <input id="searchVoucher" class="iq-input" placeholder="見積番号を入力">
                    </div>

                    <div class="iq-search-field">
                        <label for="searchPartner">取引先</label>
                        <div class="iq-search-lookup">
                            <input id="searchPartner" class="iq-input" placeholder="取引先コードまたは取引先名">
                            <button type="button" class="iq-search-icon" data-search-lookup="partner" title="取引先検索">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <circle cx="10.5" cy="10.5" r="6.5" />
                                <path d="M16 16L21 21" />
                            </svg>
                            </button>
                        </div>
                    </div>

                    <div class="iq-search-field">
                        <label for="searchManager">担当者</label>
                        <div class="iq-search-lookup">
                            <input id="searchManager" class="iq-input" placeholder="担当者コードまたは担当者名">
                            <button type="button" class="iq-search-icon" data-search-lookup="manager" title="担当者検索">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <circle cx="10.5" cy="10.5" r="6.5" />
                                <path d="M16 16L21 21" />
                            </svg>
                            </button>
                        </div>
                    </div>

                    <div class="iq-search-field">
                        <label for="searchWarehouse">出荷倉庫</label>
                        <div class="iq-search-lookup">
                            <input id="searchWarehouse" class="iq-input" placeholder="倉庫コードまたは倉庫名">
                            <button type="button" class="iq-search-icon" data-search-lookup="warehouse" title="倉庫検索">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <circle cx="10.5" cy="10.5" r="6.5" />
                                <path d="M16 16L21 21" />
                            </svg>
                            </button>
                        </div>
                    </div>

                    <div class="iq-search-field">
                        <label for="searchItem">品目コード / 品目名</label>
                        <div class="iq-search-lookup">
                            <input id="searchItem" class="iq-input" placeholder="品目コードまたは品目名">
                            <button type="button" class="iq-search-icon" data-search-lookup="item" title="品目検索">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <circle cx="10.5" cy="10.5" r="6.5" />
                                <path d="M16 16L21 21" />
                            </svg>
                            </button>
                        </div>
                    </div>

                    <div class="iq-search-field">
                        <label for="searchTransaction">取引区分</label> <select id="searchTransaction" class="iq-input">
                            <option value="">すべて</option>
                            <option value="TAXABLE">消費税適用</option>
                            <option value="EXEMPT">免税</option>
                        </select>
                    </div>

                </div>
            </div>
            <div class="iq-modal-foot" style="justify-content: space-between">
                <div class="iq-search-presets">
                    <button type="button" class="iq-preset" data-preset="today">本日</button>
                    <button type="button" class="iq-preset" data-preset="yesterday">前日</button>
                    <button type="button" class="iq-preset" data-preset="week">今週</button>
                    <button type="button" class="iq-preset" data-preset="month">今月</button>
                    <button type="button" class="iq-preset" data-preset="last30">直近30日</button>
                    <button type="button" class="iq-preset" data-preset="year">今年</button>
                </div>
                <div class="iq-flex">
                    <button id="resetSearchBtn" type="button" class="iq-btn">再入力</button>
                    <button id="executeSearchBtn" type="button" class="iq-btn primary">検索（F8）</button>
                    <button id="searchCloseBottom" type="button" class="iq-btn">閉じる</button>
                </div>
            </div>
        </div>
    </div>

    <!--
    기준정보 조회 팝업
    マスター検索モーダル
-->
    <div id="lookupOverlay" class="iq-overlay iq-lookup-overlay" role="dialog" aria-modal="true" aria-label="マスター情報検索">
        <div class="iq-modal iq-lookup-modal">
            <div class="iq-modal-head">
                <h2 id="lookupTitle">マスター情報検索</h2>
                <button id="lookupClose" type="button" class="iq-btn">閉じる ×</button>
            </div>
            <div class="iq-modal-body">
                <div class="iq-flex" style="margin-bottom: 12px">
                    <input id="lookupKeyword" class="iq-input" style="flex: 1" placeholder="コードまたは名称で検索">
                    <button id="lookupSearchBtn" type="button" class="iq-btn primary">検索</button>
                </div>
                <div class="iq-xscroll">
                    <table class="iq-lookup-list">
                        <thead id="lookupHead"></thead>
                        <tbody id="lookupRows"></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!--
    견적서 수정 / 생성한 전표 조회
    見積書編集／作成済み伝票の照会
-->
    <div id="modalOverlay" class="iq-overlay" role="dialog" aria-modal="true" aria-label="見積書詳細">
        <div class="iq-modal">
            <div class="iq-modal-head">
                <h2 id="modalTitle">見積書</h2>
                <button id="modalCloseTop" type="button" class="iq-btn">閉じる ×</button>
            </div>

            <div class="iq-modal-body">

                <!--
                견적서 수정
                見積書の編集
            -->
                <div id="editPane" hidden>
                    <div class="iq-card">
                        <div class="iq-form-grid">
                            <div class="iq-field">
                                <label>日付</label> <input id="editDate" type="date" class="iq-input">
                            </div>
                            <div class="iq-field">
                                <label>取引先</label>
                                <div class="iq-pair">
                                    <input id="editPartnerCode" class="iq-input" placeholder="取引先コード">
                                    <button type="button" class="iq-btn" data-edit-lookup="partner">⌕</button>
                                    <input id="editPartnerName" class="iq-input iq-readonly" readonly placeholder="取引先名">
                                </div>
                            </div>
                            <div class="iq-field">
                                <label>担当者</label>
                                <div class="iq-pair">
                                    <input id="editManagerCode" class="iq-input" placeholder="担当者コード">
                                    <button type="button" class="iq-btn" data-edit-lookup="manager">⌕</button>
                                    <input id="editManagerName" class="iq-input iq-readonly" readonly placeholder="担当者名">
                                </div>
                            </div>
                            <div class="iq-field">
                                <label>出荷倉庫</label>
                                <div class="iq-pair">
                                    <input id="editWarehouseCode" class="iq-input" placeholder="倉庫コード">
                                    <button type="button" class="iq-btn" data-edit-lookup="warehouse">⌕</button>
                                    <input id="editWarehouseName" class="iq-input iq-readonly" readonly placeholder="倉庫名">
                                </div>
                            </div>
                            <div class="iq-field">
                                <label>取引区分</label> <select id="editTransaction" class="iq-input">
                                    <option value="TAXABLE">消費税適用</option>
                                    <option value="EXEMPT">免税</option>
                                </select>
                            </div>
                            <div class="iq-field">
                                <label>通貨 / 為替レート</label>
                                <div class="iq-pair">
                                    <select id="editCurrency" class="iq-input">
                                    </select> <input id="editRate" type="number" min="0.000001" step="0.000001" class="iq-input">
                                </div>
                            </div>
                            <div class="iq-field">
                                <label>有効期限</label> <input id="editValid" type="date" class="iq-input">
                            </div>
                            <div class="iq-field">
                                <label>添付</label>
                                <div class="iq-flex">
                                    <a id="editAttachmentLink" target="_blank" rel="noopener" hidden> 既存の添付ファイルをダウンロード </a> <input id="editAttachmentFile" type="file" accept=".pdf,.png,.jpg,.jpeg,.docx,.xlsx,.txt">
                                </div>
                            </div>
                            <div class="iq-field wide">
                                <label>新しい項目を追加</label> <input id="editCustom" class="iq-input" placeholder="追加情報">
                            </div>
                        </div>
                    </div>

                    <div class="iq-inline-toolbar">
                        <button id="editAddRow" type="button" class="iq-btn">＋ 行追加</button>
                        <button id="editRemoveRows" type="button" class="iq-btn">選択行を削除</button>
                    </div>

                    <div class="iq-xscroll">
                        <table class="iq-detail-table">
                            <thead>
                                <tr>
                                    <th>選択</th>
                                    <th>品目コード</th>
                                    <th>品目名</th>
                                    <th>規格</th>
                                    <th>数量</th>
                                    <th>単価</th>
                                    <th>供給価額</th>
                                    <th>消費税</th>
                                    <th>合計金額</th>
                                </tr>
                            </thead>
                            <tbody id="editItems"></tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="6">合計</td>
                                    <td id="editSupplyTotal">0</td>
                                    <td id="editVatTotal">0</td>
                                    <td id="editGrandTotal">0</td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                    <p id="editMessage" class="iq-message"></p>
                </div>

                <!--
                생성한 전표
                作成済み伝票
            -->
                <div id="ordersPane" hidden>
                    <div class="iq-card">
                        <h3>作成済み伝票</h3>
                        <p id="orderQuoteInfo" class="iq-message"></p>
                        <div class="iq-xscroll">
                            <table class="iq-detail-table">
                                <thead>
                                    <tr>
                                        <th>品目コード</th>
                                        <th>品目名</th>
                                        <th>規格</th>
                                        <th>数量</th>
                                        <th>残数量</th>
                                        <th>作成済み伝票</th>
                                        <th>作成済み伝票 日付-No.</th>
                                    </tr>
                                </thead>
                                <tbody id="quoteOrderItems"></tbody>
                            </table>
                        </div>
                    </div>

                    <div class="iq-card">
                        <h3>関連する受注伝票</h3>
                        <div class="iq-xscroll">
                            <table class="iq-detail-table">
                                <thead>
                                    <tr>
                                        <th>受注日</th>
                                        <th>伝票番号</th>
                                        <th>取引先</th>
                                        <th>金額合計</th>
                                        <th>進捗状態</th>
                                    </tr>
                                </thead>
                                <tbody id="ordersList"></tbody>
                            </table>
                        </div>
                    </div>
                    <p class="iq-help">同じ品目コードが複数の見積明細行にある場合、行ごとの受注適用数量を正確に区別できないため、残数量を「—」と表示します。</p>
                </div>
            </div>

            <div class="iq-modal-foot">
                <button id="orderNewBtn" type="button" class="iq-btn primary" hidden>新規(F2)</button>
                <button id="saveEditBtn" type="button" class="iq-btn primary" hidden>保存(F8)</button>
                <button id="modalCloseBottom" type="button" class="iq-btn">閉じる</button>
            </div>
        </div>
    </div>

    <!--
    주문서입력 팝업
    受注伝票入力モーダル
-->
    <div id="orderOverlay" class="iq-overlay iq-order-overlay" role="dialog" aria-modal="true" aria-label="受注伝票入力">
        <div class="iq-modal">
            <div class="iq-modal-head">
                <h2>受注伝票入力 - 見積書を取り込む</h2>
                <button id="orderCloseTop" type="button" class="iq-btn">閉じる ×</button>
            </div>
            <div class="iq-modal-body">
                <p id="orderLoadMessage" class="iq-message" role="status">受注伝票入力を準備しています。</p>
                <iframe id="orderIframe" title="見積書の内容が入力された受注伝票入力" hidden></iframe>
            </div>
            <div class="iq-modal-foot">
                <button id="orderCloseBottom" type="button" class="iq-btn">閉じる</button>
            </div>
        </div>
    </div>

    <script>
(function () {
    "use strict";

    // 기본 변수
    // 基本変数
    var ctx = "${pageContext.request.contextPath}";
    var api = ctx + "/sales/estimate/api";

    var allQuotes = [];
    var visibleQuotes = [];
    var selected = new Set();
    var activeFilter = "";

    var currentEditId = null;
    var currentOrderQuoteId = null;
    var modalMode = "";
    var busy = false;

    var lookupType = "";
    var lookupCallback = null;
    var lookupSerial = 0;
    var listSerial = 0;

    var criteria = {
        voucher: "",
        partner: "",
        manager: "",
        warehouse: "",
        item: "",
        transaction: ""
    };

    // 공통 함수
    // 共通関数
    function el(id) {
        return document.getElementById(id);
    }

    function txt(value) {
        return value == null ? "" : String(value);
    }

    function val(id) {
        return el(id).value.trim();
    }

    function setVal(id, value) {
        el(id).value = txt(value);
    }

    function num(value) {
        var result = Number(value);
        return isFinite(result) ? result : 0;
    }

    function money(value) {
        return num(value).toLocaleString("ja-JP", {
            maximumFractionDigits: 2
        });
    }

    function lower(value) {
        return txt(value).trim().toLowerCase();
    }

    function contains(value, word) {
        return lower(value).indexOf(lower(word)) >= 0;
    }

    function showMessage(message, error) {
        el("message").textContent = message;
        el("message").classList.toggle("error", !!error);
    }

    function cell(tr, value, className) {
        var td = document.createElement("td");
        td.textContent = txt(value);

        if (className) {
            td.className = className;
        }

        tr.appendChild(td);
        return td;
    }

    function blankRow(bodyId, colspan, message) {
        var body = el(bodyId);
        body.textContent = "";

        var tr = document.createElement("tr");
        var td = cell(tr, message, "iq-empty");
        td.colSpan = colspan;

        body.appendChild(tr);
    }

    async function request(url, options) {
        var response = await fetch(url, options || {});
        var raw = await response.text();
        var data = null;

        try {
            data = raw ? JSON.parse(raw) : null;
        } catch (error) {
            data = null;
        }

        if (!response.ok) {
            throw new Error(
                data && data.message
                    ? data.message
                    : "HTTP " + response.status + " エラー"
            );
        }

        if (data && data.success === false) {
            throw new Error(
                data.message || "リクエストの処理に失敗しました。"
            );
        }

        return data;
    }

    function jsonOptions(method, data) {
        return {
            method: method,
            headers: {
                "Content-Type": "application/json",
                "Accept": "application/json"
            },
            body: JSON.stringify(data)
        };
    }

    // 날짜 처리
    // 日付処理
    function formatDate(date) {
        var year = date.getFullYear();
        var month = String(date.getMonth() + 1).padStart(2, "0");
        var day = String(date.getDate()).padStart(2, "0");
        return year + "-" + month + "-" + day;
    }

    function todayDate() {
        var now = new Date();
        return new Date(
            now.getFullYear(),
            now.getMonth(),
            now.getDate()
        );
    }

    function initialDates() {
        var now = todayDate();

        setVal(
            "startDate",
            formatDate(new Date(
                now.getFullYear(),
                now.getMonth() - 1,
                now.getDate()
            ))
        );

        setVal(
            "endDate",
            formatDate(new Date(
                now.getFullYear(),
                now.getMonth() + 1,
                now.getDate()
            ))
        );
    }

    function setDatePreset(kind) {
        var today = todayDate();
        var start = new Date(today);
        var end = new Date(today);

        if (kind === "yesterday") {
            start.setDate(start.getDate() - 1);
            end.setDate(end.getDate() - 1);
        } else if (kind === "week") {
            var weekday = (today.getDay() + 6) % 7;
            start.setDate(start.getDate() - weekday);
        } else if (kind === "month") {
            start = new Date(today.getFullYear(), today.getMonth(), 1);
        } else if (kind === "last30") {
            start.setDate(start.getDate() - 29);
        } else if (kind === "year") {
            start = new Date(today.getFullYear(), 0, 1);
        } else if (kind !== "today") {
            return;
        }

        setVal("searchStartDate", formatDate(start));
        setVal("searchEndDate", formatDate(end));
        executeAdvancedSearch();
    }

    // 견적 진행상태
    // 見積書の進捗状態
    function currentStatus(q) {
        var status = txt(q.ui_status);

        if (
            status === "APPROVAL" ||
            status === "UNREAD" ||
            status === "CONFIRMED"
        ) {
            return status;
        }

        return q.progress_status === "COMPLETED"
            ? "COMPLETE" : "PROGRESS";
    }

    function statusLabel(code) {
        var labels = {
            APPROVAL: "承認中",
            UNREAD: "未確認",
            CONFIRMED: "確認",
            PROGRESS: "進行中",
            COMPLETE: "完了"
        };

        return labels[code] || "進行中";
    }

    function updateTabCounts() {
        var counts = {
            "": allQuotes.length,
            APPROVAL: 0,
            UNREAD: 0,
            CONFIRMED: 0,
            PROGRESS: 0,
            COMPLETE: 0
        };

        allQuotes.forEach(function (q) {
            var status = currentStatus(q);
            if (counts[status] !== undefined) {
                counts[status]++;
            }
        });

        document.querySelectorAll(".iq-tab").forEach(function (tab) {
            var status = tab.dataset.status;
            var count = counts[status] || 0;

            tab.querySelector(".tab-count").textContent = count;
            tab.classList.toggle("has-data", count > 0);
            tab.classList.toggle("empty", count === 0);
            tab.classList.toggle("active", status === activeFilter);
        });
    }

    // 상세검색 조건
    // 詳細検索条件
    function hasDetailCriteria() {
        return !!(
            criteria.partner ||
            criteria.manager ||
            criteria.warehouse ||
            criteria.item ||
            criteria.transaction
        );
    }

    function matchesDetails(detail) {
        var header = detail.header || {};
        var items = detail.items || [];

        if (
            criteria.partner &&
            !contains(header.partner_code, criteria.partner) &&
            !contains(header.partner_name, criteria.partner)
        ) {
            return false;
        }

        if (
            criteria.manager &&
            !contains(header.manager_code, criteria.manager) &&
            !contains(header.manager_name, criteria.manager)
        ) {
            return false;
        }

        if (
            criteria.warehouse &&
            !contains(header.warehouse_code, criteria.warehouse) &&
            !contains(header.warehouse_name, criteria.warehouse)
        ) {
            return false;
        }

        if (
            criteria.transaction &&
            header.transaction_type !== criteria.transaction
        ) {
            return false;
        }

        if (criteria.item) {
            return items.some(function (item) {
                return contains(item.item_code, criteria.item) ||
                       contains(item.item_name, criteria.item);
            });
        }

        return true;
    }

    // 견적서 목록 조회
    // 見積書一覧の取得
    async function loadList() {
        if (
            !val("startDate") ||
            !val("endDate") ||
            val("startDate") > val("endDate")
        ) {
            showMessage(
                "検索開始日と終了日を確認してください。",
                true
            );
            return;
        }

        var serial = ++listSerial;
        var params = new URLSearchParams();

        params.set("startDate", val("startDate"));
        params.set("endDate", val("endDate"));

        var keyword = val("keyword");
        if (keyword) {
            params.set("keyword", keyword);
        }

        el("searchBtn").disabled = true;
        showMessage("見積書を照会しています。");

        try {
            var data = await request(
                api + "/quotations?" + params.toString()
            );

            if (!Array.isArray(data)) {
                throw new Error("見積書一覧データが正しくありません。");
            }

            if (serial !== listSerial) {
                return;
            }

            data = data.filter(function (q) {
                return !criteria.voucher ||
                       contains(q.voucher_no, criteria.voucher);
            });

            if (hasDetailCriteria()) {
                var filtered = [];

                for (var i = 0; i < data.length; i += 5) {
                    var group = data.slice(i, i + 5);

                    var results = await Promise.all(
                        group.map(async function (q) {
                            var detail = await request(
                                api + "/quotations/" +
                                q.quote_id + "/detail"
                            );

                            return {
                                quote: q,
                                matched: matchesDetails(detail)
                            };
                        })
                    );

                    if (serial !== listSerial) {
                        return;
                    }

                    results.forEach(function (result) {
                        if (result.matched) {
                            filtered.push(result.quote);
                        }
                    });
                }

                data = filtered;
            }

            if (serial !== listSerial) {
                return;
            }

            allQuotes = data;
            selected.clear();
            renderList();
            showMessage("");

        } catch (error) {
            if (serial !== listSerial) {
                return;
            }

            allQuotes = [];
            selected.clear();
            renderList();
            showMessage("照会に失敗しました： " + error.message, true);

        } finally {
            if (serial === listSerial) {
                el("searchBtn").disabled = false;
            }
        }
    }

    // 견적서 목록 출력
    // 見積書一覧の表示
    function renderList() {
        updateTabCounts();

        visibleQuotes = allQuotes.filter(function (q) {
            return !activeFilter ||
                   currentStatus(q) === activeFilter;
        });

        el("recordCount").textContent =
            visibleQuotes.length + "件";

        var body = el("quotationRows");
        body.textContent = "";

        if (!visibleQuotes.length) {
            blankRow("quotationRows", 9, "該当する見積書がありません。");
            updateSelection();
            return;
        }

        visibleQuotes.forEach(function (q, index) {
            var tr = document.createElement("tr");
            var id = String(q.quote_id);
            var checked = selected.has(id);

            if (checked) {
                tr.classList.add("selected");
            }

            var noTd = document.createElement("td");
            noTd.className = "center";

            var noBtn = document.createElement("button");
            noBtn.type = "button";
            noBtn.className = "iq-no" + (checked ? " selected" : "");
            noBtn.textContent = index + 1;

            noBtn.addEventListener("click", function () {
                if (selected.has(id)) {
                    selected.delete(id);
                } else {
                    selected.add(id);
                }
                renderList();
            });

            noTd.appendChild(noBtn);
            tr.appendChild(noTd);

            var numberTd = document.createElement("td");
            numberTd.className = "number-text";

            var numberBtn = document.createElement("button");
            numberBtn.type = "button";
            numberBtn.className = "iq-link";
            numberBtn.textContent =
                txt(q.quote_date) + " - " + txt(q.voucher_no);

            numberBtn.addEventListener("click", function () {
                openEdit(q.quote_id);
            });

            numberTd.appendChild(numberBtn);
            tr.appendChild(numberTd);

            cell(tr, q.partner_name);
            cell(tr, q.manager_name);

            var itemTd = cell(tr, q.item_summary, "summary-text");
            itemTd.title = txt(q.item_summary);

            cell(tr, q.valid_until, "center");
            cell(tr, money(q.total_amount), "amount");

            var statusTd = document.createElement("td");
            statusTd.className = "center";

            var status = currentStatus(q);
            var statusBtn = document.createElement("button");
            statusBtn.type = "button";
            statusBtn.className =
                "iq-status-button" +
                (status === "COMPLETE" ? " complete" : "") +
                (["APPROVAL", "UNREAD", "CONFIRMED"].indexOf(status) >= 0
                    ? " local" : "");

            statusBtn.textContent = statusLabel(status);

            statusBtn.addEventListener("click", function () {
                selected.clear();
                selected.add(id);

                var rect = statusBtn.getBoundingClientRect();
                renderList();
                openStatusMenuAt(rect);
            });

            statusTd.appendChild(statusBtn);
            tr.appendChild(statusTd);

            var orderTd = document.createElement("td");
            orderTd.className = "center";

            var orderBtn = document.createElement("button");
            orderBtn.type = "button";
            orderBtn.className = "iq-link";
            orderBtn.textContent = "照会";

            orderBtn.addEventListener("click", function () {
                openGeneratedOrders(q);
            });

            orderTd.appendChild(orderBtn);
            tr.appendChild(orderTd);
            body.appendChild(tr);
        });

        updateSelection();
    }

    function updateSelection() {
        el("deleteBtn").disabled = selected.size === 0;
    }

    el("selectAllBtn").addEventListener("click", function () {
        var allSelected =
            visibleQuotes.length > 0 &&
            visibleQuotes.every(function (q) {
                return selected.has(String(q.quote_id));
            });

        visibleQuotes.forEach(function (q) {
            var id = String(q.quote_id);
            if (allSelected) {
                selected.delete(id);
            } else {
                selected.add(id);
            }
        });

        renderList();
    });

    document.querySelectorAll(".iq-tab").forEach(function (tab) {
        tab.addEventListener("click", function () {
            activeFilter = tab.dataset.status;
            selected.clear();
            closeStatusMenu();
            renderList();
        });
    });

    // 진행상태 변경
    // 進捗状態の変更
    function openStatusMenuAt(rect) {
        var menu = el("statusMenu");
        menu.classList.add("open");

        var left = Math.min(
            rect.left,
            window.innerWidth - menu.offsetWidth - 8
        );

        var top = rect.bottom + 5;

        if (top + menu.offsetHeight > window.innerHeight - 8) {
            top = rect.top - menu.offsetHeight - 5;
        }

        menu.style.left = Math.max(8, left) + "px";
        menu.style.top = Math.max(8, top) + "px";
    }

    function closeStatusMenu() {
        el("statusMenu").classList.remove("open");
    }

    el("statusMenuBtn").addEventListener("click", function () {
        if (el("statusMenu").classList.contains("open")) {
            closeStatusMenu();
            return;
        }

        if (!selected.size) {
            showMessage(
                "進捗状態を変更する見積書の番号を選択してください。",
                true
            );
            return;
        }

        openStatusMenuAt(this.getBoundingClientRect());
    });

    document.addEventListener("click", function (event) {
        if (
            !el("statusMenu").contains(event.target) &&
            !el("statusMenuBtn").contains(event.target) &&
            !event.target.closest(".iq-status-button")
        ) {
            closeStatusMenu();
        }
    });

    window.addEventListener("resize", closeStatusMenu);

    async function applyStatus(status) {
        var ids = Array.from(selected).map(Number);
        closeStatusMenu();

        if (!ids.length) {
            return;
        }

        if (!confirm(
            ids.length + "件を " +
            statusLabel(status) + " 状態に変更しますか？"
        )) {
            return;
        }

        try {
            for (var i = 0; i < ids.length; i++) {
                await request(
                    api + "/quotations/" + ids[i] + "/status",
                    jsonOptions("PUT", { status: status })
                );
            }

            selected.clear();
            await loadList();
            showMessage("進捗状態を変更しました。");

        } catch (error) {
            showMessage("状態の変更に失敗しました： " + error.message, true);
        }
    }

    document.querySelectorAll("[data-change-status]")
        .forEach(function (button) {
            button.addEventListener("click", function () {
                applyStatus(button.dataset.changeStatus);
            });
        });

    // 선택삭제
    // 選択取消
    el("deleteBtn").addEventListener("click", async function () {
        var ids = Array.from(selected).map(Number);

        if (!ids.length) {
            return;
        }

        if (!confirm(
            ids.length + "件を取消処理しますか？\n" +
            "有効な見積書一覧から除外されます。"
        )) {
            return;
        }

        try {
            await request(
                api + "/quotations/cancel",
                jsonOptions("POST", ids)
            );

            selected.clear();
            await loadList();
            showMessage(ids.length + "件を取り消しました。");

        } catch (error) {
            showMessage("選択削除に失敗しました： " + error.message, true);
        }
    });

    // 상세검색
    // 詳細検索
    function openSearchModal() {
        setVal("searchStartDate", val("startDate"));
        setVal("searchEndDate", val("endDate"));
        setVal("searchVoucher", criteria.voucher);
        setVal("searchPartner", criteria.partner);
        setVal("searchManager", criteria.manager);
        setVal("searchWarehouse", criteria.warehouse);
        setVal("searchItem", criteria.item);
        setVal("searchTransaction", criteria.transaction);

        el("searchOverlay").classList.add("open");
        document.body.style.overflow = "hidden";
    }

    function closeSearchModal() {
        el("searchOverlay").classList.remove("open");

        if (!el("modalOverlay").classList.contains("open")) {
            document.body.style.overflow = "";
        }
    }

    function executeAdvancedSearch() {
        var start = val("searchStartDate");
        var end = val("searchEndDate");

        if (!start || !end || start > end) {
            alert("検索開始日と終了日を確認してください。");
            return;
        }

        criteria = {
            voucher: val("searchVoucher"),
            partner: val("searchPartner"),
            manager: val("searchManager"),
            warehouse: val("searchWarehouse"),
            item: val("searchItem"),
            transaction: val("searchTransaction")
        };

        setVal("startDate", start);
        setVal("endDate", end);

        closeSearchModal();
        loadList();
    }

    function resetSearchFields() {
        [
            "searchVoucher", "searchPartner",
            "searchManager", "searchWarehouse", "searchItem"
        ].forEach(function (id) {
            setVal(id, "");
        });
        setVal("searchTransaction", "");
    }

    el("searchBtn").addEventListener("click", openSearchModal);
    el("searchCloseTop").addEventListener("click", closeSearchModal);
    el("searchCloseBottom").addEventListener("click", closeSearchModal);
    el("executeSearchBtn").addEventListener("click", executeAdvancedSearch);
    el("resetSearchBtn").addEventListener("click", resetSearchFields);

    document.querySelectorAll("[data-preset]")
        .forEach(function (button) {
            button.addEventListener("click", function (event) {
                event.preventDefault();
                setDatePreset(button.dataset.preset);
            });
        });

    el("startDate").addEventListener("change", loadList);
    el("endDate").addEventListener("change", loadList);

    el("keyword").addEventListener("keydown", function (event) {
        if (event.key === "Enter") {
            event.preventDefault();
            loadList();
        }
    });

    // 기준정보 돋보기
    // マスター検索ボタン
    function openLookup(type, keyword, callback) {
        lookupType = type;
        lookupCallback = callback;

        var names = {
            partner: "取引先検索",
            manager: "担当者検索",
            warehouse: "倉庫検索",
            item: "品目検索"
        };

        el("lookupTitle").textContent = names[type];
        setVal("lookupKeyword", keyword);
        el("lookupOverlay").classList.add("open");
        searchLookup();
    }

    function closeLookup() {
        lookupSerial++;
        el("lookupOverlay").classList.remove("open");
        lookupCallback = null;
    }

    async function searchLookup() {
        var type = lookupType;
        var keyword = val("lookupKeyword");
        var serial = ++lookupSerial;

        var headers = type === "item"
            ? ["品目コード", "品目名", "規格", "単価"]
            : ["コード", "名称"];

        var head = el("lookupHead");
        head.textContent = "";

        var headerRow = document.createElement("tr");

        headers.forEach(function (name) {
            var th = document.createElement("th");
            th.textContent = name;
            headerRow.appendChild(th);
        });

        head.appendChild(headerRow);

        blankRow("lookupRows", headers.length, "照会しています。");

        try {
            var items = await request(
                api + "/quotation-lookup/" + type +
                "?keyword=" + encodeURIComponent(keyword)
            );

            if (serial !== lookupSerial) {
                return;
            }

            if (!Array.isArray(items)) {
                throw new Error(
                    "マスターデータの形式が正しくありません。"
                );
            }

            var body = el("lookupRows");
            body.textContent = "";

            items.forEach(function (item) {
                var tr = document.createElement("tr");
                var columns = [item.code, item.name];

                if (type === "item") {
                    columns.push(item.spec, money(item.unit_price));
                }

                columns.forEach(function (value) {
                    cell(tr, value);
                });

                tr.addEventListener("click", function () {
                    var callback = lookupCallback;
                    closeLookup();
                    if (callback) {
                        callback(item);
                    }
                });

                body.appendChild(tr);
            });

            if (!items.length) {
                blankRow(
                    "lookupRows",
                    headers.length,
                    "該当するマスター情報がありません。"
                );
            }

        } catch (error) {
            if (serial !== lookupSerial) {
                return;
            }

            blankRow(
                "lookupRows",
                headers.length,
                "照会に失敗しました： " + error.message
            );
        }
    }

    var searchLookupFields = {
        partner: "searchPartner",
        manager: "searchManager",
        warehouse: "searchWarehouse",
        item: "searchItem"
    };

    document.querySelectorAll("[data-search-lookup]")
        .forEach(function (button) {
            button.addEventListener("click", function () {
                var type = button.dataset.searchLookup;
                var target = searchLookupFields[type];

                openLookup(type, val(target), function (item) {
                    setVal(target, item.code);
                });
            });
        });

    el("lookupClose").addEventListener("click", closeLookup);
    el("lookupSearchBtn").addEventListener("click", searchLookup);

    el("lookupKeyword").addEventListener("keydown", function (event) {
        if (event.key === "Enter") {
            event.preventDefault();
            searchLookup();
        }
    });

    // 공통 상세 팝업
    // 共通詳細モーダル
    function openModal(title, paneId) {
        el("editPane").hidden = true;
        el("ordersPane").hidden = true;
        el("saveEditBtn").hidden = true;
        el("orderNewBtn").hidden = true;

        el("modalTitle").textContent = title;
        el(paneId).hidden = false;

        el("modalOverlay").classList.add("open");
        document.body.style.overflow = "hidden";
    }

    function closeModal() {
        el("modalOverlay").classList.remove("open");
        document.body.style.overflow = "";

        currentEditId = null;
        currentOrderQuoteId = null;
        modalMode = "";
    }

    el("modalCloseTop").addEventListener("click", closeModal);
    el("modalCloseBottom").addEventListener("click", closeModal);

    // 생성한 전표 조회
    // 作成済み伝票の照会
    async function openGeneratedOrders(quote) {
        modalMode = "orders";
        currentOrderQuoteId = quote.quote_id;

        openModal("作成済み伝票", "ordersPane");
        el("orderNewBtn").hidden = false;

        el("orderQuoteInfo").textContent =
            "見積書: " + txt(quote.quote_date) +
            " - " + txt(quote.voucher_no);

        blankRow("quoteOrderItems", 7, "照会しています。");
        blankRow("ordersList", 5, "照会しています。");

        try {
            var results = await Promise.all([
                request(
                    api + "/quotations/" +
                    quote.quote_id + "/detail"
                ),
                request(
                    api + "/quotations/" +
                    quote.quote_id + "/orders"
                )
            ]);

            var detail = results[0] || {};
            var generated = results[1] || {};

            var items = detail.items || [];
            var orderItems = generated.items || [];
            var orders = generated.orders || [];

            var applied = {};
            var codeCount = {};

            items.forEach(function (item) {
                var code = lower(item.item_code);
                codeCount[code] = (codeCount[code] || 0) + 1;
            });

            orderItems.forEach(function (item) {
                var code = lower(item.item_code);

                if (!applied[code]) {
                    applied[code] = {
                        quantity: 0,
                        voucherNos: new Set(),
                        orderIds: new Set()
                    };
                }

                applied[code].quantity += num(item.quantity);
                applied[code].voucherNos.add(txt(item.voucher_no));
                applied[code].orderIds.add(txt(item.order_id));
            });

            var orderById = {};

            orders.forEach(function (order) {
                orderById[String(order.order_id)] = order;
            });

            var itemBody = el("quoteOrderItems");
            itemBody.textContent = "";

            items.forEach(function (item) {
                var tr = document.createElement("tr");
                var code = lower(item.item_code);
                var matched = applied[code];
                var quantity = num(item.quantity);

                var remaining = codeCount[code] === 1
                    ? Math.max(
                        0,
                        quantity - (matched ? matched.quantity : 0)
                    )
                    : "—";

                var vouchers = "—";
                var voucherDates = "—";

                if (matched) {
                    vouchers = Array.from(matched.voucherNos)
                        .filter(Boolean)
                        .join(", ") || "—";

                    var descriptions = [];

                    matched.orderIds.forEach(function (orderId) {
                        var order = orderById[orderId];

                        if (order) {
                            descriptions.push(
                                txt(order.order_date) +
                                " - " + txt(order.voucher_no)
                            );
                        }
                    });

                    voucherDates = descriptions.join(", ") || "—";
                }

                [
                    item.item_code,
                    item.item_name,
                    item.spec,
                    quantity,
                    remaining,
                    vouchers,
                    voucherDates
                ].forEach(function (value) {
                    cell(tr, value);
                });

                itemBody.appendChild(tr);
            });

            if (!items.length) {
                blankRow(
                    "quoteOrderItems", 7,
                    "見積品目がありません。"
                );
            }

            var orderBody = el("ordersList");
            orderBody.textContent = "";

            orders.forEach(function (order) {
                var tr = document.createElement("tr");

                [
                    order.order_date,
                    order.voucher_no,
                    order.partner_name,
                    money(order.total_amount),
                    order.progress_status
                ].forEach(function (value) {
                    cell(tr, value);
                });

                orderBody.appendChild(tr);
            });

            if (!orders.length) {
                blankRow(
                    "ordersList", 5,
                    "作成済みの受注伝票がありません。"
                );
            }

        } catch (error) {
            blankRow(
                "quoteOrderItems", 7,
                "照会に失敗しました： " + error.message
            );
            blankRow("ordersList", 5, "照会に失敗しました");
        }
    }

    // 견적서 수정용 통화 조회
    // 編集用の通貨一覧取得
    async function loadCurrencies(selectedId) {
        var select = el("editCurrency");
        select.textContent = "";

        try {
            var data = await request(api + "/input/currencies");

            if (data && !Array.isArray(data) && data.data) {
                data = data.data;
            }

            (data || []).forEach(function (currency) {
                var option = document.createElement("option");
                option.value = currency.currency_id;
                option.textContent =
                    txt(currency.currency_code) +
                    " - " + txt(currency.currency_name);

                select.appendChild(option);
            });

        } catch (error) {
            // 조회 실패 시 기존 통화값 유지
            // 取得失敗時は元の通貨値を維持
        }

        if (selectedId != null) {
            var exists = Array.from(select.options).some(
                function (option) {
                    return option.value === String(selectedId);
                }
            );

            if (!exists) {
                var fallback = document.createElement("option");
                fallback.value = selectedId;
                fallback.textContent = "通貨 ID: " + selectedId;
                select.appendChild(fallback);
            }

            select.value = selectedId;
        }
    }

    function rowInput(row, name) {
        return row.querySelector('[data-field="' + name + '"]');
    }

    function rowValue(row, name) {
        return rowInput(row, name).value.trim();
    }

    function makeInput(name, value, type) {
        var input = document.createElement("input");
        input.className = "iq-input";
        input.dataset.field = name;
        input.type = type || "text";
        input.value = txt(value);

        if (type === "number") {
            input.min = "0";
            input.step = name === "quantity" ? ".0001" : ".01";
            input.classList.add("iq-numeric");
        }

        return input;
    }

    // 견적서 수정 금액 계산
    // 見積書編集時の金額計算
    function totalEdit() {
        var supply = 0;
        var vat = 0;

        el("editItems").querySelectorAll("tr").forEach(function (row) {
            supply += num(rowValue(row, "supply_amount"));
            vat += num(rowValue(row, "vat_amount"));
        });

        el("editSupplyTotal").textContent = money(supply);
        el("editVatTotal").textContent = money(vat);
        el("editGrandTotal").textContent = money(supply + vat);
    }

    function calculateRow(row, auto) {
        var qty = num(rowValue(row, "quantity"));
        var price = num(rowValue(row, "unit_price"));
        var rate = num(row.dataset.vatRate || 10);

        if (auto) {
            var supply = Math.round(qty * price * 100) / 100;

            var vat = val("editTransaction") === "EXEMPT"
                ? 0
                : Math.round(supply * rate) / 100;

            rowInput(row, "supply_amount").value =
                supply.toFixed(2);
            rowInput(row, "vat_amount").value =
                vat.toFixed(2);
        }

        rowInput(row, "total_amount").value = (
            num(rowValue(row, "supply_amount")) +
            num(rowValue(row, "vat_amount"))
        ).toFixed(2);

        totalEdit();
    }

    // 견적서 수정 품목 행
    // 見積書編集時の品目行
    function addEditRow(item) {
        item = item || {};

        var row = document.createElement("tr");
        row.dataset.unitName = txt(item.unit_name);
        row.dataset.vatRate = "10";

        var checkTd = document.createElement("td");
        var check = document.createElement("input");
        check.type = "checkbox";
        check.className = "edit-row-check";
        checkTd.appendChild(check);
        row.appendChild(checkTd);

        var codeTd = document.createElement("td");
        var codeBox = document.createElement("div");
        codeBox.className = "iq-pair";

        var codeInput = makeInput("item_code", item.item_code);
        var lookupBtn = document.createElement("button");
        lookupBtn.type = "button";
        lookupBtn.className = "iq-btn";
        lookupBtn.textContent = "⌕";

        function lookupItem() {
            openLookup("item", codeInput.value, function (result) {
                rowInput(row, "item_code").value = txt(result.code);
                rowInput(row, "item_name").value = txt(result.name);
                rowInput(row, "spec").value = txt(result.spec);

                row.dataset.unitName = txt(result.unit_name);
                row.dataset.vatRate = txt(
                    result.vat_rate == null ? 10 : result.vat_rate
                );

                if (result.unit_price != null) {
                    rowInput(row, "unit_price").value =
                        result.unit_price;
                }

                calculateRow(row, true);
            });
        }

        codeInput.addEventListener("dblclick", lookupItem);
        lookupBtn.addEventListener("click", lookupItem);

        codeBox.appendChild(codeInput);
        codeBox.appendChild(lookupBtn);
        codeTd.appendChild(codeBox);
        row.appendChild(codeTd);

        [
            ["item_name", "text"],
            ["spec", "text"],
            ["quantity", "number"],
            ["unit_price", "number"],
            ["supply_amount", "number"],
            ["vat_amount", "number"],
            ["total_amount", "text"]
        ].forEach(function (field) {
            var td = document.createElement("td");
            var input = makeInput(
                field[0], item[field[0]], field[1]
            );

            if (field[0] === "total_amount") {
                input.readOnly = true;
                input.classList.add("iq-readonly");
            }

            if (
                field[0] === "quantity" ||
                field[0] === "unit_price"
            ) {
                input.addEventListener("input", function () {
                    calculateRow(row, true);
                });
            }

            if (
                field[0] === "supply_amount" ||
                field[0] === "vat_amount"
            ) {
                input.addEventListener("input", function () {
                    calculateRow(row, false);
                });
            }

            td.appendChild(input);
            row.appendChild(td);
        });

        el("editItems").appendChild(row);
        totalEdit();
        return row;
    }

    // 견적서 수정창
    // 見積書の編集画面
    async function openEdit(id) {
        modalMode = "edit";
        currentEditId = id;

        openModal("見積書入力（編集）", "editPane");
        el("editMessage").textContent = "照会しています。";

        try {
            var data = await request(
                api + "/quotations/" + id + "/detail"
            );

            var h = data.header || {};
            var items = data.items || [];

            setVal("editDate", h.quote_date);
            setVal("editValid", h.valid_until);
            setVal("editPartnerCode", h.partner_code);
            setVal("editPartnerName", h.partner_name);
            setVal("editManagerCode", h.manager_code);
            setVal("editManagerName", h.manager_name);
            setVal("editWarehouseCode", h.warehouse_code);
            setVal("editWarehouseName", h.warehouse_name);
            setVal(
                "editTransaction",
                h.transaction_type || "TAXABLE"
            );
            setVal(
                "editRate",
                h.exchange_rate == null ? 1 : h.exchange_rate
            );
            setVal("editCustom", h.custom_data);

            el("editAttachmentFile").value = "";

            var attachment = el("editAttachmentLink");
            attachment.hidden = !h.attachment_path;

            if (h.attachment_path) {
                attachment.href =
                    api + "/input/quotations/" +
                    id + "/attachment";
            }

            await loadCurrencies(h.currency_id);

            el("editItems").textContent = "";

            items.forEach(function (item) {
                addEditRow(item);
            });

            if (!items.length) {
                addEditRow({});
            }

            el("editPane").querySelectorAll(
                "input, select, button"
            ).forEach(function (control) {
                control.disabled = !!data.linked;
            });

            el("saveEditBtn").hidden = !!data.linked;

            el("editMessage").textContent = data.linked
                ? "受注・売上伝票が関連付けられた見積書は照会のみ可能です。"
                : "";

        } catch (error) {
            el("saveEditBtn").hidden = true;
            el("editMessage").textContent =
                "照会に失敗しました： " + error.message;
        }
    }

    el("editAddRow").addEventListener("click", function () {
        addEditRow({});
    });

    el("editRemoveRows").addEventListener("click", function () {
        el("editItems").querySelectorAll("tr")
            .forEach(function (row) {
                if (row.querySelector(".edit-row-check").checked) {
                    row.remove();
                }
            });

        if (!el("editItems").querySelector("tr")) {
            addEditRow({});
        }

        totalEdit();
    });

    el("editTransaction").addEventListener("change", function () {
        el("editItems").querySelectorAll("tr")
            .forEach(function (row) {
                calculateRow(row, true);
            });
    });

    var editLookups = {
        partner: ["editPartnerCode", "editPartnerName"],
        manager: ["editManagerCode", "editManagerName"],
        warehouse: ["editWarehouseCode", "editWarehouseName"]
    };

    document.querySelectorAll("[data-edit-lookup]")
        .forEach(function (button) {
            button.addEventListener("click", function () {
                var type = button.dataset.editLookup;
                var fields = editLookups[type];

                openLookup(
                    type,
                    val(fields[0]),
                    function (item) {
                        setVal(fields[0], item.code);
                        setVal(fields[1], item.name);
                    }
                );
            });
        });

    // 견적서 수정 저장
    // 見積書修正内容の保存
    function collectEditItems() {
        var result = [];

        el("editItems").querySelectorAll("tr")
            .forEach(function (row) {
                var code = rowValue(row, "item_code");
                var name = rowValue(row, "item_name");
                var quantity = rowValue(row, "quantity");

                if (!code && !name && !quantity) {
                    return;
                }

                if (!code || num(quantity) <= 0) {
                    throw new Error(
                        "品目コードと0より大きい数量を入力してください。"
                    );
                }

                result.push({
                    item_code: code,
                    item_name: name,
                    spec: rowValue(row, "spec"),
                    unit_name: row.dataset.unitName || "",
                    quantity: quantity,
                    unit_price: rowValue(row, "unit_price"),
                    supply_amount: rowValue(row, "supply_amount"),
                    vat_amount: rowValue(row, "vat_amount")
                });
            });

        if (!result.length) {
            throw new Error(
                "品目を1件以上入力してください。"
            );
        }

        return result;
    }

    el("saveEditBtn").addEventListener(
        "click",
        async function () {
            if (!currentEditId || busy) {
                return;
            }

            busy = true;
            el("saveEditBtn").disabled = true;

            try {
                var id = currentEditId;

                var payload = {
                    quote_date: val("editDate"),
                    valid_until: val("editValid"),
                    partner_code: val("editPartnerCode"),
                    manager_code: val("editManagerCode"),
                    warehouse_code: val("editWarehouseCode"),
                    transaction_type: val("editTransaction"),
                    currency_id: val("editCurrency"),
                    exchange_rate: val("editRate"),
                    custom_data: val("editCustom"),
                    items: collectEditItems()
                };

                await request(
                    api + "/quotations/" + id,
                    jsonOptions("PUT", payload)
                );

                var file = el("editAttachmentFile").files[0];
                var attachmentError = "";

                if (file) {
                    try {
                        var form = new FormData();
                        form.append("file", file);

                        await request(
                            api + "/input/quotations/" +
                            id + "/attachment",
                            {
                                method: "POST",
                                body: form
                            }
                        );

                    } catch (error) {
                        attachmentError = error.message;
                    }
                }

                closeModal();
                await loadList();

                showMessage(
                    attachmentError
                        ? "見積書は更新されましたが、添付ファイルの保存に失敗しました： " +
                          attachmentError
                        : "見積書の更新が完了しました。",
                    !!attachmentError
                );

            } catch (error) {
                el("editMessage").textContent =
                    "更新に失敗しました： " + error.message;

            } finally {
                busy = false;
                el("saveEditBtn").disabled = false;
            }
        }
    );

    // 주문서입력 팝업
    // 受注伝票入力モーダル
    function closeOrderModal() {
        var iframe = el("orderIframe");

        el("orderOverlay").classList.remove("open");
        iframe.onload = null;
        iframe.src = "about:blank";
        iframe.hidden = true;

        el("orderLoadMessage").hidden = false;
    }

    function openOrderModal() {
        var quoteId = currentOrderQuoteId;

        if (!quoteId) {
            alert("先に見積書を選択してください。");
            return;
        }

        var overlay = el("orderOverlay");
        var iframe = el("orderIframe");
        var message = el("orderLoadMessage");

        overlay.classList.add("open");

        message.textContent =
            "選択した見積書を受注伝票入力に反映しています。";
        message.hidden = false;
        iframe.hidden = true;

        iframe.onload = async function () {
            try {
                var orderWindow = iframe.contentWindow;
                var currentPath = orderWindow.location.pathname;

                // 주문서 저장 후 주문서조회로 이동했다면
                // 受注伝票の保存後、受注伝票照会画面に移動した場合
                if (
                    currentPath.indexOf("/sales/order/inquiry") !== -1
                ) {
                    closeOrderModal();
                    closeModal();
                    await loadList();

                    showMessage(
                        "受注伝票が保存されたため、一覧を更新しました。"
                    );
                    return;
                }

                if (
                    currentPath.indexOf("/sales/order/input") === -1
                ) {
                    return;
                }

                // 팝업 내부 스크롤 수정
                // モーダル内部のスクロール調整
                // sideMenu 공통 CSS의
                // sideMenu共通CSSの
                // 설정 때문에 하단 저장 버튼이 잘리므로
                // 設定で下部の保存ボタンが隠れるため
                // erp-content를 독립 스크롤 영역으로 변경
                // erp-contentを独立したスクロール領域に変更
                var css = orderWindow.document.createElement("style");

                css.textContent =
                    "html,body{" +
                    "height:100%!important;" +
                    "overflow:hidden!important;" +
                    "}" +

                    "body{" +
                    "margin:0!important;" +
                    "background:#f5f7fb!important;" +
                    "}" +

                    ".erp-sidebar{" +
                    "display:none!important;" +
                    "}" +

                    ".erp-wrapper{" +
                    "display:block!important;" +
                    "height:100%!important;" +
                    "min-height:0!important;" +
                    "overflow:hidden!important;" +
                    "}" +

                    ".erp-main{" +
                    "display:flex!important;" +
                    "flex-direction:column!important;" +
                    "width:100%!important;" +
                    "height:100%!important;" +
                    "min-height:0!important;" +
                    "overflow:hidden!important;" +
                    "}" +

                    ".erp-content{" +
                    "display:block!important;" +
                    "flex:1 1 auto!important;" +
                    "height:100%!important;" +
                    "min-height:0!important;" +
                    "width:100%!important;" +
                    "max-width:none!important;" +
                    "overflow-y:auto!important;" +
                    "overflow-x:auto!important;" +
                    "padding:12px 16px 90px!important;" +
                    "overscroll-behavior:contain!important;" +
                    "}";

                orderWindow.document.head.appendChild(css);

                // 견적서 데이터 조회
                // 見積書データの取得
                var response = await fetch(
                    ctx + "/sales/order/quote-load" +
                    "?quoteId=" + encodeURIComponent(quoteId) +
                    "&mode=remain"
                );

                if (!response.ok) {
                    throw new Error(
                        "見積データの取得に失敗しました（HTTP " +
                        response.status + ")"
                    );
                }

                var data = await response.json();

                if (
                    !overlay.classList.contains("open") ||
                    currentOrderQuoteId !== quoteId
                ) {
                    return;
                }

                if (!data.items || data.items.length === 0) {
                    message.textContent =
                        "この見積書には受注可能な残数量がありません。";
                    iframe.hidden = false;
                    return;
                }

                // 견적 거래유형을 주문 거래유형으로 변환
                // 見積書の取引区分を受注伝票の区分に変換
                if (data.header) {
                    if (
                        data.header.transactionType === "TAXABLE"
                    ) {
                        data.header.transactionType = "Y";

                    } else if (
                        data.header.transactionType === "EXEMPT"
                    ) {
                        data.header.transactionType = "N";
                    }
                }

                // 기존 주문서입력 자동 채우기 기능
                // 既存の受注伝票入力画面の自動反映機能
                if (
                    typeof orderWindow.fillFromQuote !== "function"
                ) {
                    throw new Error(
                        "受注伝票入力の見積書取込関数が見つかりません。"
                    );
                }

                orderWindow.fillFromQuote(data);

                iframe.hidden = false;
                message.hidden = true;

            } catch (error) {
                message.hidden = false;
                message.textContent =
                    "自動入力に失敗しました： " + error.message;
                iframe.hidden = false;
            }
        };

        iframe.src = ctx + "/sales/order/input";
    }

    // 생성한 전표 조회 신규(F2) -> 주문서입력 팝업
    // 作成済み伝票照会の新規（F2）→受注入力モーダル
    el("orderNewBtn").addEventListener(
        "click",
        openOrderModal
    );

    el("orderCloseTop").addEventListener(
        "click",
        closeOrderModal
    );

    el("orderCloseBottom").addEventListener(
        "click",
        closeOrderModal
    );

    // 견적서조회 메인 신규(F2) -> 견적서입력
    // 見積書照会画面の新規（F2）→見積書入力画面
    el("newBtn").addEventListener("click", function () {
        window.location.href =
            ctx + "/sales/estimate/input";
    });

    // 키보드 단축키
    // キーボードショートカット
    document.addEventListener("keydown", function (event) {
        if (event.key === "Escape") {
            if (el("lookupOverlay").classList.contains("open")) {
                closeLookup();
            } else if (
                el("orderOverlay").classList.contains("open")
            ) {
                closeOrderModal();
            } else if (
                el("searchOverlay").classList.contains("open")
            ) {
                closeSearchModal();
            } else if (
                el("modalOverlay").classList.contains("open")
            ) {
                closeModal();
            } else {
                closeStatusMenu();
            }
            return;
        }

        // F3: 상세검색
        // F3：詳細検索
        if (event.key === "F3") {
            if (
                !el("modalOverlay").classList.contains("open") &&
                !el("searchOverlay").classList.contains("open")
            ) {
                event.preventDefault();
                openSearchModal();
            }
        }

        // F8: 검색 또는 수정 저장
        // F8：検索または編集内容の保存
        if (event.key === "F8") {
            if (
                el("searchOverlay").classList.contains("open") &&
                !el("lookupOverlay").classList.contains("open")
            ) {
                event.preventDefault();
                executeAdvancedSearch();

            } else if (
                modalMode === "edit" &&
                !el("saveEditBtn").hidden
            ) {
                event.preventDefault();
                el("saveEditBtn").click();
            }
        }

        // F2: 신규
        // F2：新規
        if (event.key === "F2") {
            if (
                el("modalOverlay").classList.contains("open") &&
                modalMode === "orders"
            ) {
                event.preventDefault();
                openOrderModal();

            } else if (
                !el("modalOverlay").classList.contains("open") &&
                !el("searchOverlay").classList.contains("open") &&
                !el("orderOverlay").classList.contains("open")
            ) {
                event.preventDefault();

                window.location.href =
                    ctx + "/sales/estimate/input";
            }
        }
    });

    // 첫 화면 초기화
    // 初期画面の初期化
    initialDates();
    loadList();

})();
</script>

</body>
</html>
