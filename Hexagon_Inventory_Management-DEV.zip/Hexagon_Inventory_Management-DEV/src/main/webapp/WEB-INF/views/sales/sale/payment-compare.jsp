<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="my" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>[입력] - 헥사곤 ERP</title>
    <link href="https://cdn.jsdelivr.net/npm/@mdi/font@7.2.96/css/materialdesignicons.min.css" rel="stylesheet">
</head>
<body>
    <div class="erp-wrapper">
        <!-- 사이드바 태그를 넣는 순간 레이아웃(Flex)과 디자인이 통째로 적용됩니다 -->
        <my:sideMenu />

        <div class="erp-main">
            <main class="erp-content">
                <div style="font-size: 1.25rem; font-weight: 700; color: #0B1026; margin-bottom: 20px; display: flex; align-items: center; gap: 10px;">
                    <i class="mdi mdi-domain" style="color: #4B88FF; font-size: 24px;"></i> [입력]
                </div>
                <div style="background:#fff; padding:25px; border-radius:12px; box-shadow: 0 10px 25px -5px rgba(75, 136, 255, 0.08); border: 1px solid #e2e8f0;">
                    <p>[입력]</p>
                </div>
            </main>
        </div>
    </div>
</body>
</html>