<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ taglib prefix="my" tagdir="/WEB-INF/tags"%>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt"%>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>【未販売一覧】 - ヘキサゴン ERP</title>
<link
	href="https://cdn.jsdelivr.net/npm/@mdi/font@7.2.96/css/materialdesignicons.min.css"
	rel="stylesheet">
<style>
#overlay {
	display: none;
	position: fixed;
	top: 0;
	left: 0;
	width: 100%;
	height: 100%;
	background: rgba(0, 0, 0, 0.4);
	z-index: 1000;
}

/* 처음 진입: 일반 영역으로 표시 */
/* 初進入:一般領域に表示 */
#searchPanel {
	display: block;
	padding: 20px;
	background: white;
	border: 1px solid #e2e8f0;
	border-radius: 12px;
	line-height: 2;
	margin-bottom: 16px;
}

/* 검색 후: 모달로 표시 */
/* 検索語: モーダルで表示 */
#searchPanel.modal {
	display: none;
	position: fixed;
	top: 50%;
	left: 50%;
	transform: translate(-50%, -50%);
	width: 600px;
	max-height: 90vh;
	overflow-y: auto;
	padding: 30px;
	border-radius: 10px;
	z-index: 1001;
	margin-bottom: 0;
}

/* ===== 상단 ===== */
/* ===== 上端 ===== */
.rp-top {
	display: flex;
	align-items: center;
	justify-content: space-between;
	margin-bottom: 14px;
}

.rp-title {
	font-size: 1.1rem;
	font-weight: 700;
	color: #0B1026;
	display: flex;
	align-items: center;
	gap: 6px;
}

.rp-title .mdi-star {
	color: #cbd5e1;
}

.btn-primary {
	background: #1e5eff;
	color: #fff;
	border: none;
	padding: 7px 16px;
	border-radius: 999px;
	font-size: 0.85rem;
	cursor: pointer;
}

.btn-outline {
	background: #fff;
	color: #333;
	border: 1px solid #cbd5e1;
	padding: 6px 14px;
	border-radius: 999px;
	font-size: 0.85rem;
	cursor: pointer;
}

/* ===== 주문서 목록 영역 ===== */
/* ===== 受注書目録領域 =====*/
.report {
	background: #fff;
	padding: 20px 16px;
	border: 1px solid #e2e8f0;
	border-radius: 12px;
	box-shadow: 0 10px 25px -5px rgba(75, 136, 255, 0.08);
}

.report-title {
	text-align: center;
	font-size: 1.6rem;
	font-weight: 700;
	letter-spacing: 0.4em;
	color: #0B1026;
	margin: 6px 0 24px;
}

.report-info {
	display: flex;
	justify-content: space-between;
	font-size: 0.85rem;
	color: #1e293b;
	margin-bottom: 6px;
}

.rp-table {
	width: 100%;
	border-collapse: collapse;
	font-size: 0.85rem;
	border: 1px solid #cbd5e1;
}

.rp-table th {
	background: #f1f5f9;
	font-weight: 700;
	padding: 6px 8px;
	border: 1px solid #cbd5e1;
	color: #0B1026;
}

.rp-table td {
	padding: 4px 6px;
	border: 1px solid #e2e8f0;
	color: #1e293b;
}

.rp-table td.num {
	text-align: right;
}

.rp-table td.center {
	text-align: center;
}

.rp-table a {
	color: #1e5eff;
	text-decoration: none;
}

.rp-table a:hover {
	text-decoration: underline;
}

.rp-table tr.sub-row td {
	background: #f1f5f9;
	font-weight: 700;
}

.rp-table tr.total-row td {
	background: #e2e8f0;
	font-weight: 700;
}

.empty-msg {
	text-align: center;
	color: #94a3b8;
	padding: 30px 0 !important;
}

/* ===== 하단 버튼 ===== */
/* =====下端ボタン ===== */
.bottom-bar {
	display: flex;
	gap: 6px;
	margin-top: 14px;
}

#modifyOverlay {
	display: none;
	position: fixed;
	inset: 0;
	overflow-y: auto;
	background: rgba(0, 0, 0, 0.45);
	z-index: 2000;
}

#modifyModal {
	position: relative;
	width: 95%;
	max-width: 1400px;
	min-height: 200px;
	margin: 30px auto;
	padding: 20px;
	box-sizing: border-box;
	background: #fff;
	border-radius: 12px;
}

#closeModify {
	display: block;
	margin-left: auto;
	margin-bottom: 15px;
}
</style>
</head>
<body>
	<div class="erp-wrapper">
		<my:sideMenu />

		<div class="erp-main">
			<main class="erp-content">

				<c:set var="searched" value="${paramMap.searched == 'Y' }" />

				<!-- 상단: 제목 + 우측 버튼 -->
				<div class="rp-top">
					<div class="rp-title">
						<i class="mdi mdi-star"></i> 未販売一覧
					</div>
					<div style="display: flex; gap: 8px;">
						<c:if test="${searched }">
							<button type="button" class="btn-primary" onclick="openSearch()">Search</button>
						</c:if>
					</div>
				</div>

				<!-- 검색 조건 (처음 진입: 일반 영역 / 검색 후: 모달) -->
				<!-- 検索条件（初進入：一般領域・検索語：モーダル） -->
				<div id="overlay" onclick="closeSearch()"></div>
				<div id="searchPanel" class="${searched ? 'modal' : ''}">
					<form action="unsold" method="get">
						<input type="hidden" name="searched" value="Y">
						<!-- 구분 -->
						<!-- 区分 -->
						区分 : <input type="radio" name="type" value="0"
							${paramMap.type == 0 ? 'checked' : '' }> 品目別 <input
							type="radio" name="type" value="1"
							${paramMap.type == 1 ? 'checked' : '' }> ライン別<br>
						<!-- 기준일자 -->
						<!-- 基準日付 -->
						基準日付 : <input type="date" name="endDate"
							value="${paramMap.endDate}"><br>
						<!-- 품목별 납기일자 -->
						<!-- 品目別納期日付 -->
						品目別納期日付 : <input type="date" name="dueStartDate"
							value="${paramMap.dueStartDate}"> ~ <input type="date"
							name="dueEndDate" value="${paramMap.dueEndDate }"><br>
						<!-- 창고 -->
						<!-- 倉庫 -->
						倉庫 : <select name="warehouseId">
							<option value="">선택안함</option>
							<c:forEach var="warehouse" items="${warehouses }">
								<option value="${warehouse.warehousePk }"
									${warehouse.warehousePk eq paramMap.warehouseId ? 'selected' : '' }>${warehouse.warehouseName }</option>
							</c:forEach>
						</select><br>
						<!-- 거래처 -->
						<!-- 取引先 -->
						取引先 : <select name="businessPartnerId">
							<option value="">선택안함</option>
							<c:forEach var="partner" items="${partners }">
								<option value="${partner.businessPartnerId }"
									${partner.businessPartnerId eq paramMap.businessPartnerId ? 'selected' : '' }>${partner.businessPartnerName }</option>
							</c:forEach>
						</select><br>
						<!-- 품목코드 -->
						<!-- 品目コード -->
						品目コード : <input type="text" id="searchItemName"
								value="<c:out value='${paramMap.itemName}'/>" readonly
								style="background: #f3f4f6;"> <input type="hidden"
								name="itemId" id="searchItemId" value="${paramMap.itemId}">
							<input type="hidden" name="itemName" id="searchItemNameParam"
								value="<c:out value='${paramMap.itemName}'/>">
							<!-- 검색에 사용할 품목 ID -->
							<input type="hidden" name="itemId" id="searchItemId"
								value="${paramMap.itemId}">
							<button type="button" class="btn-outline"
								onclick="openSearchItemModal()">検索</button>
							<button type="button" class="btn-outline"
								onclick="clearSearchItem()">クリア</button>
							<br>
						<!-- 담당자 -->
						<!-- 担当者 -->
						担当者 : <select name="managerId">
							<option value="">선택안함</option>
							<c:forEach var="manager" items="${managers }">
								<option value="${manager.managerId }"
									${manager.managerId eq paramMap.managerId ? 'selected' : '' }>${manager.employeeName }</option>
							</c:forEach>
						</select><br>
						<!-- 거래처관리담당자 -->
						<!-- 取引先管理担当者 -->
						取引先管理担当者 :<select name="businessPartnerManagerId">
							<option value="">선택안함</option>
							<c:forEach var="businessPartnerManager" items="${managers }">
								<option value="${businessPartnerManager.managerId }"
									${businessPartnerManager.managerId eq paramMap.businessPartnerManagerId ? 'selected' : '' }>${businessPartnerManager.employeeName }</option>
							</c:forEach>
						</select><br>
						<!-- 미판매수량 -->
						<!-- 未販売数量 -->
						未販売数量 : <input type="number" name="unsoldQtyFrom"
							value="${paramMap.unsoldQtyFrom }"> ~ <input
							type="number" name="unsoldQtyTo" value="${paramMap.unsoldQtyTo }"><br>
						<!-- 비고 -->
						<!-- 備考 -->
						備考 : <input type="text" name="orderRemarks"
							value="${paramMap.orderRemarks }"><br>
						<!-- 수량 -->
						<!-- 数量  -->
						数量 : <input type="number" name="qtyFrom"
							value="${paramMap.qtyFrom }"> ~ <input type="number"
							name="qtyTo" value="${paramMap.qtyTo }"><br>
						<!-- 내외자구분 -->
						<!-- 内外資区分 -->
						内外資区分 : <input type="radio" name="currencyType" value=""
							${paramMap.currencyType eq '' ? 'checked' : '' }>全体 <input
							type="radio" name="currencyType" value="内資"
							${paramMap.currencyType eq '内資' ? 'checked' : '' }>内資 <input
							type="radio" name="currencyType" value="外資"
							${paramMap.currencyType eq '外資' ? 'checked' : '' }>外資 <br>
						<!-- 거래유형 -->
						<!-- 取引類型 -->
						取引類型 : <input type="radio" name="transactionType" value=""
							${paramMap.transactionType eq '' ? 'checked' : '' }>全体 <input
							type="radio" name="transactionType" value="Y"
							${paramMap.transactionType eq 'Y' ? 'checked' : '' }>付加税率適用<input
							type="radio" name="transactionType" value="N"
							${paramMap.transactionType eq 'N' ? 'checked' : '' }>付加税率未適用
						<br>
						<!-- 비고(품목) -->
						<!-- 備考（品目） -->
						備考（品目）: <input type="text" name="itemRemarks"
							value="${paramMap.itemRemarks }"><br>
						<!-- 규격 -->
						<!-- 規格 -->
						規格 : <input type="text" name="spec" value="${paramMap.spec }"><br>
						<!-- 진행상태 -->
						<!-- 進行状態 -->
						進行状態 : <input type="radio" name="progressStatus" value=""
							${paramMap.progressStatus eq '' ? 'checked' : '' }>全体 <input
							type="radio" name="progressStatus" value="UNCONFIRMED"
							${paramMap.progressStatus eq 'UNCONFIRMED' ? 'checked' : '' }>未確認
						<input type="radio" name="progressStatus" value="CONFIRMED"
							${paramMap.progressStatus eq 'CONFIRMED' ? 'checked' : '' }>確認
						<input type="radio" name="progressStatus" value="IN_PROGRESS"
							${paramMap.progressStatus eq 'IN_PROGRESS' ? 'checked' : '' }>進行中
						<input type="radio" name="progressStatus" value="COMPLETED"
							${paramMap.progressStatus eq 'COMPLETED' ? 'checked' : '' }>完了<br>
						<!-- 검색버튼 -->
						<!-- 検索ボタン -->
						<button type="submit" class="btn-primary">検索</button>
					</form>
				</div>

				<!-- 주문서 목록 -->
				<!-- 受注書目録 -->
				<c:if test="${searched }">
					<div class="report">
						<div class="report-title">未販売一覧</div>
						<div class="report-info">
							<span>会社名 : ヘキサゴン ERP</span> <span>基準日付 :
								${paramMap.endDate}</span>
						</div>

						<table class="rp-table">
							<thead>
								<tr>
									<th>日付-No.</th>
									<th>品目名【規格】</th>
									<th>数量</th>
									<th>未販売数量</th>
									<th>未販売供給価格</th>
									<th>未販売付加税</th>
									<th>品目別納期日付</th>
									<th>取引先名</th>
									<th>備考</th>
								</tr>
							</thead>
							<tbody>
								<c:set var="prevMonth" value="" />
								<c:set var="mQty" value="0" />
								<c:set var="mUnsold" value="0" />
								<c:set var="mSupply" value="0" />
								<c:set var="mVat" value="0" />
								<c:set var="tQty" value="0" />
								<c:set var="tUnsold" value="0" />
								<c:set var="tSupply" value="0" />
								<c:set var="tVat" value="0" />

								<c:forEach var="row" items="${list }">
									<!-- 월이 바뀌면 직전 월 소계 출력 -->
									<!-- 月が変わると直前月を小計を出力 -->
									<c:if
										test="${not empty prevMonth and prevMonth != row.orderMonth}">
										<tr class="sub-row">
											<td colspan="2" class="center">${prevMonth}&nbsp;計</td>
											<!-- 수량 소계 -->
											<!-- 数量の小計 -->
											<td class="num"><fmt:formatNumber value="${mQty}"
													pattern="#,##0.00" /></td>
											<!-- 미판매수량 소계 -->
											<!-- 未販売数量の小計 -->
											<td class="num"><fmt:formatNumber value="${mUnsold}"
													pattern="#,##0.00" /></td>
											<!-- 미판매공급가액 소계 -->
											<!-- 未販売供給価格の小計 -->
											<td class="num"><fmt:formatNumber value="${mSupply}"
													pattern="#,##0" /></td>
											<!-- 미판매 부가세 소계 -->
											<!-- 未販売付加税の小計 -->
											<td class="num"><fmt:formatNumber value="${mVat}"
													pattern="#,##0" /></td>
											<td colspan="3"></td>
										</tr>
										<!-- 소계 변수 초기화 -->
										<!-- 小計変数の初期化 -->
										<c:set var="mQty" value="0" />
										<c:set var="mUnsold" value="0" />
										<c:set var="mSupply" value="0" />
										<c:set var="mVat" value="0" />
									</c:if>

									<tr>
										<!-- 일자-No. -->
										<!-- 日付-No. -->
										<td class="center"><a href="#" class="modify-order"
											data-order-id="${row.orderId}">${row.orderDateStr}&nbsp;-${row.dayNo }</a></td>
										<!-- 품목명(규격) -->
										<!-- 品目名【規格】 -->
										<td>${row.itemName }&nbsp;${row.spec }</td>
										<!-- 수량 -->
										<!-- 数量 -->
										<td class="num"><fmt:formatNumber value="${row.quantity}"
												pattern="#,##0.00" /></td>
										<!-- 미판매수량 -->
										<!-- 未販売数量 -->
										<td class="num"><fmt:formatNumber
												value="${row.unsoldQty}" pattern="#,##0.00" /></td>
										<!-- 미판매 공급가액 -->
										<!-- 未販売供給価格 -->
										<td class="num"><fmt:formatNumber
												value="${row.unsoldSupply}" pattern="#,##0" /></td>
										<!-- 미판매 부가세 -->
										<!-- 未販売付加税 -->
										<td class="num"><fmt:formatNumber
												value="${row.unsoldVat}" pattern="#,##0" /></td>
										<!-- 품목별 납기일자 -->
										<!-- 品目別納期日付 -->
										<td class="center">${row.dueDateStr }</td>
										<!-- 거래처명 -->
										<!-- 取引先名 -->
										<td>${row.businessPartnerName }</td>
										<!-- 비고 -->
										<!-- 備考 -->
										<td>${row.remarks }</td>
									</tr>

									<!-- 월별, 전체 소계 누적 -->
									<!-- 月別、全体小計累積 -->
									<c:set var="mQty" value="${mQty + row.quantity}" />
									<c:set var="mUnsold" value="${mUnsold + row.unsoldQty}" />
									<c:set var="mSupply" value="${mSupply + row.unsoldSupply}" />
									<c:set var="mVat" value="${mVat + row.unsoldVat}" />
									<c:set var="tQty" value="${tQty + row.quantity}" />
									<c:set var="tUnsold" value="${tUnsold + row.unsoldQty}" />
									<c:set var="tSupply" value="${tSupply + row.unsoldSupply}" />
									<c:set var="tVat" value="${tVat + row.unsoldVat}" />
									<c:set var="prevMonth" value="${row.orderMonth}" />
								</c:forEach>

								<c:if test="${not empty list}">
									<!-- 마지막 월 소계 -->
									<!-- 最後の月の小計 -->
									<tr class="sub-row">
										<td colspan="2" class="center">${prevMonth}&nbsp;計</td>
										<!-- 수량 소계 -->
										<!-- 数量の小計 -->
										<td class="num"><fmt:formatNumber value="${mQty}"
												pattern="#,##0.00" /></td>
										<!-- 미판매 수량 소계 -->
										<!-- 未販売数量の小計 -->
										<td class="num"><fmt:formatNumber value="${mUnsold}"
												pattern="#,##0.00" /></td>
										<!-- 미판매 공급가액 소계 -->
										<!-- 未販売供給価格の小計 -->
										<td class="num"><fmt:formatNumber value="${mSupply}"
												pattern="#,##0" /></td>
										<!-- 미판매 부가세 소계 -->
										<!-- 未販売付加税の小計 -->
										<td class="num"><fmt:formatNumber value="${mVat}"
												pattern="#,##0" /></td>
										<td colspan="3"></td>
									</tr>
									<!-- 총 합계 -->
									<!-- 総合計 -->
									<tr class="total-row">
										<td colspan="2" class="center">総合計</td>
										<!-- 수량 총합계 -->
										<!-- 数量の総合計 -->
										<td class="num"><fmt:formatNumber value="${tQty}"
												pattern="#,##0.00" /></td>
										<!-- 미판매 수량 총합계 -->
										<!-- 未販売数量の総合計 -->
										<td class="num"><fmt:formatNumber value="${tUnsold}"
												pattern="#,##0.00" /></td>
										<!-- 미판매 공급가액 총합계 -->
										<!-- 未販売供給価格の総合計 -->
										<td class="num"><fmt:formatNumber value="${tSupply}"
												pattern="#,##0" /></td>
										<!-- 미판매 부가세 총합계 -->
										<!-- 未販売付加税の総合計 -->
										<td class="num"><fmt:formatNumber value="${tVat}"
												pattern="#,##0" /></td>
										<td colspan="3"></td>
									</tr>
								</c:if>

								<!-- 리스트가 비어있을 경우 -->
								<!-- リストが空いている場合 -->
								<c:if test="${empty list}">
									<tr>
										<td colspan="9" class="empty-msg">照会された内訳がありません。</td>
									</tr>
								</c:if>
							</tbody>
						</table>
					</div>

				</c:if>

			</main>
		</div>
	</div>
	<!-- 주문서 수정 모달 -->
	<!-- 受注書修正モーダル -->
	<div id="modifyOverlay">
		<div id="modifyModal">
			<button type="button" id="closeModify" class="btn-outline">閉じる</button>
			<div id="modifyContent"></div>
		</div>
	</div>

	<!-- 품목 선택 (검색 조건용, 1건) -->
	<!-- 品目選択（検索条件用、1件） -->
	<div id="searchItemModal"
		style="display: none; position: fixed; inset: 0; background: rgba(0, 0, 0, 0.4); z-index: 3000;">
		<div
			style="background: #fff; width: 900px; max-width: 95%; margin: 40px auto; padding: 20px; border-radius: 10px; max-height: 85vh; overflow: auto;">
			<div id="searchItemBody"></div>
			<div class="action-bar" style="border-top: none;">
				<button type="button" class="btn-primary"
					onclick="applySearchItem()">選択</button>
				<button type="button" class="btn-outline"
					onclick="closeSearchItemModal()">閉じる</button>
			</div>
		</div>
	</div>

		<script>
	/* ===== 검색 조건: 품목 1건 선택 ===== */
	/* ===== 検索条件：品目１件選択 ===== */
	function openSearchItemModal() {
		document.getElementById("searchItemModal").style.display = "block";
		loadSearchItems(1);
	}
	function closeSearchItemModal() {
		document.getElementById("searchItemModal").style.display = "none";
	}

	function loadSearchItems(page) {
		var kwEl = document.querySelector("#searchItemBody #itemKeyword");
		var kw = kwEl ? kwEl.value : "";
		fetch("${pageContext.request.contextPath}/sales/order/item-lookup?fn=loadSearchItems&pageNum="
				+ page + "&keyword=" + encodeURIComponent(kw))
			.then(function(r) { return r.text(); })
			.then(function(html) {
				document.getElementById("searchItemBody").innerHTML = html;
				// 1건 선택: 전체선택 체크박스 숨김
				// １件選択：全体選択チェックボックスを隠す
				document.querySelectorAll("#searchItemBody thead input[type=checkbox]")
					.forEach(function(c) { c.style.display = "none"; });
			})
			.then(null, function(e) { alert("品目を読み込めませんでした。\n" + e.message); });
	}

	// 체크는 1개만 유지
	// チェックは１個だけ維持
	document.addEventListener("change", function(e) {
		var c = e.target;
		if (!c.classList || !c.classList.contains("item-pick") || !c.closest("#searchItemBody")) { return; }
		if (c.checked) {
			document.querySelectorAll("#searchItemBody .item-pick").forEach(function(o) {
				if (o !== c) { o.checked = false; }
			});
		}
	});

	function applySearchItem() {
	    var c = document.querySelector("#searchItemBody .item-pick:checked");

	    if (!c) {
	        alert("品目を選択してください。");
	        return;
	    }

	    var row = c.closest("tr");
	    var itemName = row.querySelector("td:nth-child(3)").textContent.trim();

	    document.getElementById("searchItemId").value = row.dataset.pk;
	    document.getElementById("searchItemName").value = itemName;
	    document.getElementById("searchItemNameParam").value = itemName;

	    closeSearchItemModal();
	}
	
	function clearSearchItem() {
	    document.getElementById("searchItemId").value = "";
	    document.getElementById("searchItemName").value = "";
	}
	</script>

	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<script>
		/* ===== 검색 팝업 ===== */
		/* ===== 検索ポップアップ ===== */
		function openSearch() {
			document.getElementById("overlay").style.display = "block";
			document.getElementById("searchPanel").style.display = "none";
			document.getElementById("searchPanel").style.display = "block";
		}

		function closeSearch() {
			document.getElementById("overlay").style.display = "none";
			document.getElementById("searchPanel").style.display = "none";
		}

		/* ===== 주문서 수정 모달 ===== */
		/* ===== 受注書修正モーダル ===== */
		//모달 닫기
		//モーダル閉じる
		function closeModifyModal() {
			document.getElementById("modifyOverlay").style.display = "none";
			document.getElementById("modifyContent").innerHTML = "";
		}

		document.getElementById("closeModify").addEventListener("click",
				function() {
					closeModifyModal();
				});

		document.getElementById("modifyOverlay").addEventListener("click",
				function(e) {
					if (e.target === this) {
						closeModifyModal();
					}
				});

		document
				.addEventListener(
						"click",
						function(e) {
							const link = e.target.closest(".modify-order");
							if (!link) {
								return;
							}
							e.preventDefault();
							const orderId = link.dataset.orderId;
							if (!orderId) {
								alert("受注書の番号が確認できません。");
								return;
							}
							var ctx = "${pageContext.request.contextPath}";
							var back = location.pathname.substring(ctx.length)
									+ location.search;
							var url = ctx + "/sales/order/modify?orderId="
									+ encodeURIComponent(orderId)
									+ "&returnUrl=" + encodeURIComponent(back);
							fetch(url)
									.then(
											function(response) {
												return response
														.text()
														.then(
																function(html) {
																	if (!response.ok) {
																		throw new Error(
																				"HTTP "
																						+ response.status
																						+ "\n"
																						+ html);
																	}
																	document
																			.getElementById("modifyContent").innerHTML = html;
																	document
																			.querySelectorAll(
																					"#modifyContent script")
																			.forEach(
																					function(
																							old) {
																						var s = document
																								.createElement("script");
																						s.text = old.textContent;
																						old
																								.replaceWith(s);
																					});
																	document
																			.getElementById("modifyOverlay").style.display = "block";
																});
											}).then(
											null,
											function(error) {
												console
														.error("受注書照会失敗:",
																error);
												alert("受注書修正画面を呼び出せませんでした。\n"
														+ error.message);
											});
						});
	</script>
</body>
</html>