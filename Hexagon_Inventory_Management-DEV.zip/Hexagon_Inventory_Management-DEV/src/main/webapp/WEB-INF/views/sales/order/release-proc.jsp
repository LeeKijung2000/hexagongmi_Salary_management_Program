<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt"%>
<%@ taglib prefix="my" tagdir="/WEB-INF/tags"%>

<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>【受注書出庫処理】 - ヘキサゴン ERP</title>

<link
	href="https://cdn.jsdelivr.net/npm/@mdi/font@7.2.96/css/materialdesignicons.min.css"
	rel="stylesheet">

<style>
/* ===== 검색 팝업 ===== */
/* ===== 検索ポップアップ ===== */
#overlay {
	display: none;
	position: fixed;
	inset: 0;
	background: rgba(0, 0, 0, 0.4);
	z-index: 1000;
}

#searchPanel {
	display: none;
	position: fixed;
	top: 50%;
	left: 50%;
	transform: translate(-50%, -50%);
	width: 600px;
	max-width: 90%;
	max-height: 85vh;
	overflow-y: auto;
	padding: 30px;
	box-sizing: border-box;
	background: white;
	border-radius: 10px;
	z-index: 1001;
	line-height: 2;
}

/* ===== 수정 모달 ===== */
/* ===== 修正モーダル ===== */
#modifyOverlay {
	display: none;
	position: fixed;
	inset: 0;
	overflow-y: auto;
	background: rgba(0, 0, 0, 0.45);
	z-index: 2000;
}

#modifyModal {
	position: relative;
	width: 95%;
	max-width: 1400px;
	min-height: 200px;
	margin: 30px auto;
	padding: 20px;
	box-sizing: border-box;
	background: #fff;
	border-radius: 12px;
}

#closeModify {
	display: block;
	margin-left: auto;
	margin-bottom: 15px;
}

/* ===== 페이지 공통 ===== */
/* ===== ページ共通 ===== */
.inq-card {
	background: #fff;
	padding: 16px 20px;
	border-radius: 12px;
	box-shadow: 0 10px 25px -5px rgba(75, 136, 255, 0.08);
	border: 1px solid #e2e8f0;
}

.inq-top {
	display: flex;
	align-items: center;
	justify-content: space-between;
	margin-bottom: 14px;
}

.inq-top-left, .inq-top-right {
	display: flex;
	align-items: center;
	gap: 8px;
}

.inq-title {
	font-size: 1.1rem;
	font-weight: 700;
	color: #0B1026;
	margin-right: 8px;
	display: flex;
	align-items: center;
	gap: 6px;
}

.inq-title .mdi-star {
	color: #cbd5e1;
}

/* ===== 처리/미처리 버튼 ===== */
/* ===== 処理・未処理ボタン ===== */
.type-form {
	display: flex;
	align-items: center;
	gap: 6px;
	margin: 0;
}

.pill {
	border: none;
	background: #e8f0ff;
	color: #4B88FF;
	padding: 5px 14px;
	border-radius: 999px;
	font-size: 0.85rem;
	cursor: pointer;
}

.pill:hover {
	background: #d5e5ff;
}

.pill.active {
	background: #4B88FF;
	color: #fff;
	font-weight: 600;
}

/* ===== 버튼 ===== */
/* ===== ボタン ===== */
.btn-primary {
	background: #1e5eff;
	color: #fff;
	border: none;
	padding: 7px 16px;
	border-radius: 999px;
	font-size: 0.85rem;
	cursor: pointer;
}

.btn-outline {
	background: #fff;
	color: #333;
	border: 1px solid #cbd5e1;
	padding: 6px 14px;
	border-radius: 999px;
	font-size: 0.85rem;
	cursor: pointer;
}

/* ===== 테이블 ===== */
/* ===== テーブル ===== */
.inq-table {
	width: 100%;
	border-collapse: collapse;
	font-size: 0.85rem;
	border-top: 1px solid #cbd5e1;
}

.inq-table th {
	background: #f1f5f9;
	font-weight: 700;
	padding: 12px 8px;
	border: 1px solid #e2e8f0;
	border-top: none;
	color: #0B1026;
}

.inq-table td {
	padding: 8px;
	border-bottom: 1px solid #e2e8f0;
	border-left: 1px solid #e2e8f0;
	border-right: 1px solid #e2e8f0;
	color: #1e293b;
}

.inq-table tbody tr:hover {
	background: #f8fbff;
}

.inq-table td.center {
	text-align: center;
}

.inq-table td.num {
	text-align: right;
}

.row-no {
	display: inline-block;
	width: 22px;
	height: 22px;
	line-height: 20px;
	border: 1px solid #cbd5e1;
	border-radius: 50%;
	text-align: center;
	font-size: 0.75rem;
	color: #94a3b8;
}

.inq-table a {
	color: #1e5eff;
	text-decoration: none;
}

.inq-table a:hover {
	text-decoration: underline;
}

.badge-view {
	display: inline-block;
	background: #ffe6d2;
	color: #e8590c;
	border: 1px solid #ff922b;
	border-radius: 4px;
	padding: 0 6px;
	font-size: 0.75rem;
}

.empty-msg {
	text-align: center;
	color: #94a3b8;
	padding: 30px 0 !important;
}

/* ===== 하단 액션바 ===== */
/* ===== 下端アクションバー ===== */
.action-bar {
	display: flex;
	gap: 6px;
	margin-top: 16px;
	padding-top: 12px;
	border-top: 1px solid #e2e8f0;
}

.action-bar .btn-outline {
	padding: 5px 14px;
}
</style>
</head>

<body>
	<div class="erp-wrapper">
		<my:sideMenu />

		<div class="erp-main">
			<main class="erp-content">
				<div class="inq-card">

					<!-- 제목 및 처리 구분 -->
					<!-- タイトルと処理区分 -->
					<div class="inq-top">
						<div class="inq-top-left">
							<div class="inq-title">
								<i class="mdi mdi-star"></i> 受注書出庫処理
							</div>

							<!-- type, 시작일, 종료일은 넘기지 않도록 처리 -->
							<!-- type, 開始日、最終日は送らないように処理 -->
							<form action="release-proc" method="get" class="type-form">
								<c:forEach var="entry" items="${paramMap}">
									<c:if
										test="${entry.key != 'type' and entry.key != 'startDate' and entry.key != 'endDate'}">
										<input type="hidden" name="${entry.key}"
											value="${entry.value}">
									</c:if>
								</c:forEach>

								<button type="submit" name="type" value="미처리"
									class="pill ${paramMap.type eq '미처리'? 'active' : ''}">
									未処理</button>

								<button type="submit" name="type" value="처리"
									class="pill ${paramMap.type eq '처리' ? 'active' : ''}">処理</button>
							</form>
						</div>

						<div class="inq-top-right">
							<button type="button" class="btn-primary" onclick="openSearch()">検索条件</button>
						</div>
					</div>

					<!-- 검색팝업 버튼 -->
					<!-- 検索ポップアップボタン -->
					<div id="overlay" onclick="closeSearch()"></div>

					<!-- 검색 팝업 -->
					<!-- 検索ポップアップ -->
					<div id="searchPanel">
						<form action="release-proc" method="get">
							<input type="hidden" name="type" value="${paramMap.type }">
							<!-- 미처리탭에서는 기준일자를, 처리탭에서는 출고일자와 주문일자(선택)을 출력하도록 처리 -->
							<!-- 未処理タブでは基準日付を、処理タブでは出庫日付と受注日付（選択）を出力するように処理 -->
							<c:choose>
								<c:when test="${paramMap.type eq '처리'}">
            						出庫日付 : <input type="date" name="releaseStartDate"
										value="${paramMap.releaseStartDate}"> ~
            						  <input type="date" name="releaseEndDate"
										value="${paramMap.releaseEndDate}">
									<br>
            						受注日付（選択）: <input type="date" name="startDate"
										value="${paramMap.startDate}"> ~
            							<input type="date" name="endDate"
										value="${paramMap.endDate}">
									<br>
								</c:when>
								<c:otherwise>
            						基準日付 : <input type="date" name="startDate"
										value="${paramMap.startDate}"> ~
            							<input type="date" name="endDate"
										value="${paramMap.endDate}">
									<br>
								</c:otherwise>
							</c:choose>

							<!-- 품목별 납기일자 -->
							<!-- 品目別納期日付 -->
							品目別納期日付 : <input type="date" name="dueStartDate"
								value="${paramMap.dueStartDate}"> ~ <input type="date"
								name="dueEndDate" value="${paramMap.dueEndDate}"><br>

							<!-- 창고 -->
							<!-- 倉庫 -->
							倉庫 : <select name="warehouseId">
							<option value="">선택안함</option>
							<c:forEach var="warehouse" items="${warehouses }">
								<option value="${warehouse.warehousePk }"
									${warehouse.warehousePk eq paramMap.warehouseId ? 'selected' : '' }>${warehouse.warehouseName }</option>
							</c:forEach>
						</select><br>
							<!-- 거래처 -->
							<!-- 取引先 -->
							取引先 : <select name="businessPartnerId">
							<option value="">선택안함</option>
							<c:forEach var="partner" items="${partners }">
								<option value="${partner.businessPartnerId }"
									${partner.businessPartnerId eq paramMap.businessPartnerId ? 'selected' : '' }>${partner.businessPartnerName }</option>
							</c:forEach>
						</select><br>
							<!-- 품목코드 -->
							<!-- 品目コード -->
							品目コード : <input type="text" id="searchItemName"
								value="<c:out value='${paramMap.itemName}'/>" readonly
								style="background: #f3f4f6;"> <input type="hidden"
								name="itemId" id="searchItemId" value="${paramMap.itemId}">
							<input type="hidden" name="itemName" id="searchItemNameParam"
								value="<c:out value='${paramMap.itemName}'/>">
							<!-- 검색에 사용할 품목 ID -->
							<input type="hidden" name="itemId" id="searchItemId"
								value="${paramMap.itemId}">
							<button type="button" class="btn-outline"
								onclick="openSearchItemModal()">検索</button>
							<button type="button" class="btn-outline"
								onclick="clearSearchItem()">クリア</button>
							<br>

							<!-- 담당자 -->
							<!-- 担当者 -->
							担当者 : <select name="managerId">
							<option value="">선택안함</option>
							<c:forEach var="manager" items="${managers }">
								<option value="${manager.managerId }"
									${manager.managerId eq paramMap.managerId ? 'selected' : '' }>${manager.employeeName }</option>
							</c:forEach>
						</select><br>

							<!-- 거래처관리담당자 -->
							<!-- 取引先管理担当者 -->
							取引先管理担当者 : <select name="businessPartnerManagerId">
							<option value="">선택안함</option>
							<c:forEach var="businessPartnerManager" items="${managers }">
								<option value="${businessPartnerManager.managerId }"
									${businessPartnerManager.managerId eq paramMap.businessPartnerManagerId ? 'selected' : '' }>${businessPartnerManager.employeeName }</option>
							</c:forEach>
						</select><br>

							<!-- 진행상태 -->
							<!-- 進行状態 -->
							進行状態 : <input type="radio" name="progressStatus" value=""
								${paramMap.progressStatus eq '' ? 'checked' : '' }>全体 
							<input type="radio" name="progressStatus" value="IN_PROGRESS"
								${paramMap.progressStatus eq 'IN_PROGRESS' ? 'checked' : '' }>進行中
							<input type="radio" name="progressStatus" value="COMPLETED"
								${paramMap.progressStatus eq 'COMPLETED' ? 'checked' : '' }>完了<br>

							<!-- 내외자구분 -->
							<!-- 内外資区分 -->
							内外資区分 : <input type="radio" name="currencyType" value=""
								${paramMap.currencyType eq '' ? 'checked' : ''}>全体 <input
								type="radio" name="currencyType" value="内資"
								${paramMap.currencyType eq '内資' ? 'checked' : ''}>内資 <input
								type="radio" name="currencyType" value="外資"
								${paramMap.currencyType eq '外資' ? 'checked' : ''}>外資<br>
							<!-- 비고 -->
							<!-- 備考 -->
							備考 : <input type="text" name="orderRemarks"
								value="${paramMap.orderRemarks}"><br>

							<!-- 비고(품목) -->
							<!-- 備考（品目） -->
							備考（品目） : <input type="text" name="itemRemarks"
								value="${paramMap.itemRemarks}"><br>
							<!-- 기타 -->
							<!-- その外 -->
							その他 : <input type="checkbox" name="sortByUpdated" value="true"
								${paramMap.sortByUpdated eq 'true' ? 'checked' : ''}>
							修正日付順<br>

							<button type="submit" class="btn-primary">検索</button>
							<button type="button" class="btn-outline" onclick="closeSearch()">閉じる</button>
						</form>
					</div>

					<c:choose>
						<%-- ========== 처리 탭 ========== --%>
						<c:when test="${paramMap.type eq '처리'}">
							<table class="inq-table">
								<thead>
									<tr>
										<th>日付-No.</th>
										<th>受注書</th>
										<th>取引先名</th>
										<th>品目名</th>
										<th>出庫数量合計</th>
										<th>備考</th>
									</tr>
								</thead>
								<tbody>
									<c:forEach var="row" items="${list}">
										<tr>
											<!-- 일자-No. -->
											<!-- 日付-No. -->
											<td class="center">${row.releaseDateStr}&nbsp;-${row.releaseDayNo}</td>
											<!-- 주문서 -->
											<!-- 受注書 -->
											<td class="center"><a href="#" class="modify-order"
												data-order-id="${row.orderId}">${row.orderDateStr}&nbsp;-${row.orderDayNo}</a></td>
											<!-- 거래처명 -->
											<!-- 取引先名 -->
											<td>${row.businessPartnerName}</td>
											<!-- 품목명 -->
											<!-- 品目名 -->
											<td>${row.itemName}<c:if test="${row.itemCount > 1}">&nbsp;他 ${row.itemCount - 1}件</c:if></td>
											<!-- 출고수량합계 -->
											<!-- 出庫数量合計 -->
											<td class="num"><fmt:formatNumber
													value="${row.totalQty}" pattern="#,##0.00" /></td>
											<!-- 비고-->
											<!-- 備考 -->
											<td>${row.remarks}</td>
										</tr>
									</c:forEach>
									<!-- 리스트가 비어있을 경우 -->
									<!-- リストが空いている場合 -->
									<c:if test="${empty list}">
										<tr>
											<td colspan="6" class="empty-msg">照会された内訳がありません。</td>
										</tr>
									</c:if>
								</tbody>
							</table>
						</c:when>
						<%-- ========== 미처리 탭 ========== --%>
						<c:otherwise>
							<form id="releaseForm" method="post" action="release-proc">
								<table class="inq-table">
									<thead>
										<tr>
											<th><input type="checkbox" id="checkAll"></th>
											<th>日付-No.</th>
											<th>取引先名</th>
											<th>品目名【規格名】</th>
											<th>残り</th>
											<th>出庫数量</th>
											<th>納期日付</th>
											<th>備考</th>
										</tr>
									</thead>
									<tbody>
										<c:forEach var="row" items="${list}" varStatus="s">
											<tr>
												<!-- 체크박스-->
												<!-- チェックボックス -->
												<td class="center"><input type="checkbox"
													name="orderItemId" value="${row.orderItemId}"></td>
												<!-- 일자-No. -->
												<!-- 日付-No. -->
												<td class="center"><a href="#" class="modify-order"
													data-order-id="${row.orderId}">${row.orderDateStr}&nbsp;-${row.dayNo}</a></td>
												<!-- 거래처명 -->
												<!-- 取引先名 -->
												<td>${row.businessPartnerName}</td>
												<!-- 품목명[규격명] -->
												<!-- 品目名【規格名】 -->
												<td>${row.itemName}<c:if test="${not empty row.spec}">&nbsp;[${row.spec}]</c:if></td>
												<!-- 잔량 -->
												<!-- 残り -->
												<td class="num"><fmt:formatNumber
														value="${row.remainQty}" pattern="#,##0.00" /></td>
												<!-- 출고수량 -->
												<!-- 出庫数量 -->
												<td><input type="number" step="any" min="0"
													max="${row.remainQty}" name="qty_${row.orderItemId}"
													style="width: 100%"></td>
												<!-- 납기일자 -->
												<!-- 納期日付 -->
												<td class="center">${row.dueDate}</td>
												<!-- 비고 -->
												<!-- 備考 -->
												<td>${row.remarks}</td>
											</tr>
										</c:forEach>
										<!-- 리스트가 비어있을 경우 -->
										<!-- リストが空いている場合 -->
										<c:if test="${empty list}">
											<tr>
												<td colspan="8" class="empty-msg">照会された内訳がありません。</td>
											</tr>
										</c:if>
									</tbody>
								</table>
								<!-- 하단 액션바 -->
								<!-- 下端アクションバー -->
								<div class="action-bar">
									<button type="submit" class="btn-primary">出庫処理</button>
								</div>
							</form>

						</c:otherwise>

					</c:choose>






				</div>
			</main>
		</div>
	</div>

	<!-- 주문서 수정 모달 -->
	<!-- 受注書修正モーダル -->
	<div id="modifyOverlay">
		<div id="modifyModal">
			<button type="button" id="closeModify" class="btn-outline">
				閉じる</button>

			<div id="modifyContent"></div>
		</div>
	</div>
	<!-- 팝업 메시지 -->
	<!-- ポップアップメッセージ -->
	<c:if test="${not empty msg}">
		<script>
			alert("${msg}");
		</script>
	</c:if>
<!-- 품목 선택 (검색 조건용, 1건) -->
	<!-- 品目選択（検索条件用、1件） -->
	<div id="searchItemModal"
		style="display: none; position: fixed; inset: 0; background: rgba(0, 0, 0, 0.4); z-index: 3000;">
		<div
			style="background: #fff; width: 900px; max-width: 95%; margin: 40px auto; padding: 20px; border-radius: 10px; max-height: 85vh; overflow: auto;">
			<div id="searchItemBody"></div>
			<div class="action-bar" style="border-top: none;">
				<button type="button" class="btn-primary"
					onclick="applySearchItem()">選択</button>
				<button type="button" class="btn-outline"
					onclick="closeSearchItemModal()">閉じる</button>
			</div>
		</div>
	</div>

	<script>
	/* ===== 검색 조건: 품목 1건 선택 ===== */
	/* ===== 検索条件：品目１件選択 ===== */
	function openSearchItemModal() {
		document.getElementById("searchItemModal").style.display = "block";
		loadSearchItems(1);
	}
	function closeSearchItemModal() {
		document.getElementById("searchItemModal").style.display = "none";
	}

	function loadSearchItems(page) {
		var kwEl = document.querySelector("#searchItemBody #itemKeyword");
		var kw = kwEl ? kwEl.value : "";
		fetch("${pageContext.request.contextPath}/sales/order/item-lookup?fn=loadSearchItems&pageNum="
				+ page + "&keyword=" + encodeURIComponent(kw))
			.then(function(r) { return r.text(); })
			.then(function(html) {
				document.getElementById("searchItemBody").innerHTML = html;
				// 1건 선택: 전체선택 체크박스 숨김
				// １件選択：全体選択チェックボックスを隠す
				document.querySelectorAll("#searchItemBody thead input[type=checkbox]")
					.forEach(function(c) { c.style.display = "none"; });
			})
			.then(null, function(e) { alert("品目を読み込めませんでした。\n" + e.message); });
	}

	// 체크는 1개만 유지
	// チェックは１個だけ維持
	document.addEventListener("change", function(e) {
		var c = e.target;
		if (!c.classList || !c.classList.contains("item-pick") || !c.closest("#searchItemBody")) { return; }
		if (c.checked) {
			document.querySelectorAll("#searchItemBody .item-pick").forEach(function(o) {
				if (o !== c) { o.checked = false; }
			});
		}
	});

	function applySearchItem() {
	    var c = document.querySelector("#searchItemBody .item-pick:checked");

	    if (!c) {
	        alert("品目を選択してください。");
	        return;
	    }

	    var row = c.closest("tr");
	    var itemName = row.querySelector("td:nth-child(3)").textContent.trim();

	    document.getElementById("searchItemId").value = row.dataset.pk;
	    document.getElementById("searchItemName").value = itemName;
	    document.getElementById("searchItemNameParam").value = itemName;

	    closeSearchItemModal();
	}
	
	function clearSearchItem() {
	    document.getElementById("searchItemId").value = "";
	    document.getElementById("searchItemName").value = "";
	}
	</script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<script>
		/* ===== 검색 팝업 ===== */
		/* ===== 検索ポップアップ ===== */
		function openSearch() {
			document.getElementById("overlay").style.display = "block";
			document.getElementById("searchPanel").style.display = "block";
		}

		function closeSearch() {
			document.getElementById("overlay").style.display = "none";
			document.getElementById("searchPanel").style.display = "none";
		}

		/* ===== 주문서 수정 모달 ===== */
		/* ===== 受注書修正モーダル ===== */
		//모달 닫기
		//モーダル閉じる
		function closeModifyModal() {
			document.getElementById("modifyOverlay").style.display = "none";
			document.getElementById("modifyContent").innerHTML = "";
		}

		document.getElementById("closeModify").addEventListener("click",
				function() {
					closeModifyModal();
				});

		document.getElementById("modifyOverlay").addEventListener("click",
				function(e) {
					if (e.target === this) {
						closeModifyModal();
					}
				});

		document.addEventListener(
						"click",
						function(e) {
							const link = e.target.closest(".modify-order");
							if (!link) {
								return;
							}
							e.preventDefault();
							const orderId = link.dataset.orderId;
							if (!orderId) {
								alert("受注書番号が確認できません。");
								return;
							}

							var ctx = "${pageContext.request.contextPath}";
							var back = location.pathname.substring(ctx.length)
									+ location.search; 
							var url = ctx + "/sales/order/modify?orderId="
									+ encodeURIComponent(orderId)
									+ "&returnUrl=" + encodeURIComponent(back);
							fetch(url).then(
								function(response) {
									return response.text().then(
										function(html) {
											if (!response.ok) {
												throw new Error("HTTP "　+ response.status　+ "\n"　+ html);
											}
											document.getElementById("modifyContent").innerHTML = html;
											document.querySelectorAll("#modifyContent script").forEach(
												function(old) {
													var s = document.createElement("script");
													s.text = old.textContent;
													old.replaceWith(s);
												}
											);
											document.getElementById("modifyOverlay").style.display = "block";
										}
									);
								}
							).then(null,function(error) {
								console.error("受注書照会失敗:",　error);
								alert("受注書修正画面を呼び出せませんでした。\n"	+ error.message);
								}
							);
						});

		// 전체 선택
		// 全体選択
		var checkAll = document.getElementById("checkAll");
		if (checkAll) {
			checkAll.addEventListener("change", function() {
				var on = this.checked;
				document.querySelectorAll('input[name="orderItemId"]').forEach(
						function(c) {
							c.checked = on;
							fillQty(c);
						});
			});
		}

		// 체크하면 출고수량에 잔량을 채우고, 해제하면 비움
		// チェックすると出庫数量に残量を入れて、解除すると空ける
		function fillQty(chk) {
			var q = chk.closest("tr").querySelector('input[type=number]');
			q.value = chk.checked ? q.max : "";
		}
		document.addEventListener("change", function(e) {
			if (e.target.name === "orderItemId") {
				fillQty(e.target);
			}
		});

		// 전송 전 검사
		// 伝送前の検査
		var releaseForm = document.getElementById("releaseForm");
		if (releaseForm) {
			releaseForm.addEventListener("submit", function(e) {
				var checked = document
						.querySelectorAll('input[name="orderItemId"]:checked');
				if (checked.length === 0) {
					alert("出庫する項目を選択してください");
					e.preventDefault();
					return;
				}
				for (var i = 0; i < checked.length; i++) {
					var q = checked[i].closest("tr").querySelector(
							'input[type=number]');
					var v = Number(q.value);
					if (!(v > 0) || v > Number(q.max)) {
						alert("出庫数量は０より大きく、残りの以下にしてください。");
						e.preventDefault();
						return;
					}
				}
			});
		}
	</script>

</body>
</html>
