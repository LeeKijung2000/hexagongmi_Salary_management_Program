<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt"%>

<style>
    .item-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 0.85rem;
        border-top: 1px solid #cbd5e1;
    }

    .item-table th {
        background: #f1f5f9;
        font-weight: 700;
        padding: 12px 8px;
        border: 1px solid #e2e8f0;
        color: #0B1026;
    }

    .item-table td {
        padding: 8px;
        border: 1px solid #e2e8f0;
        color: #1e293b;
    }

    .item-table tbody tr:hover {
        background: #f8fbff;
    }
</style>

<c:set var="fn" value="${param.fn eq 'loadSearchItems' ? 'loadSearchItems' : 'loadItems'}"/>

<div style="display: flex; gap: 8px; margin-bottom: 10px;">
	<input type="text" id="itemKeyword" value="<c:out value='${keyword}'/>"
		placeholder="品目コード/品目名/規格/バーコード 検索後 Enter"
		style="flex: 1; height: 30px; border: 1px solid #cbd5e1; border-radius: 15px; padding: 0 12px;"
		onkeydown="if(event.key==='Enter'){event.preventDefault();${fn}(1);}">
	<button type="button" class="btn-primary" onclick="${fn}(1)">検索</button>
</div>

<table class="item-table">
	<thead>
		<tr>
			<th style="width: 40px;"><input type="checkbox"
				onchange="var on=this.checked; document.querySelectorAll('#itemBody .item-pick').forEach(function(c){ c.checked = on; });"></th>
			<th>品目コード</th>
			<th>品目名</th>
			<th>規格</th>
			<th>出庫単価</th>
		</tr>
	</thead>
	<tbody>
		<c:forEach var="item" items="${items}">
			<tr data-pk="${item.itemPk}"
				data-name="<c:out value='${item.itemName}'/>"
				data-spec="<c:out value='${item.spec}'/>"
				data-price="${empty item.salesPrice ? 0 : item.salesPrice}">
				<td class="center"><input type="checkbox" class="item-pick"></td>
				<td style="padding: 8px;"><c:out value="${item.itemCode}" /></td>
				<td style="padding: 8px;"><c:out value="${item.itemName}" /></td>
				<td style="padding: 8px;"><c:out
						value="${empty item.spec ? '-' : item.spec}" /></td>
				<td style="padding: 8px; text-align: right;"><fmt:formatNumber
						value="${empty item.salesPrice ? 0 : item.salesPrice}"
						type="number" groupingUsed="true" maxFractionDigits="2" /></td>
			</tr>
		</c:forEach>
		<c:if test="${empty items}">
			<tr>
				<td colspan="5" style="text-align: center; padding: 12px;">該当する品目がありません。</td>
			</tr>
		</c:if>
	</tbody>
</table>

<div class="bottom-bar" style="justify-content:center;">
	<c:if test="${pager.prev}">
		<button type="button" class="btn-outline" onclick="${fn}(${pager.startPage - 1})">&lt;</button>
	</c:if>
	<c:forEach var="num" begin="${pager.startPage}" end="${pager.endPage}">
		<button type="button" class="${num eq pager.cri.pageNum ? 'btn-primary' : 'btn-outline'}" onclick="${fn}(${num})">${num}</button>
	</c:forEach>
	<c:if test="${pager.next}">
		<button type="button" class="btn-outline" onclick="${fn}(${pager.endPage + 1})">&gt;</button>
	</c:if>
</div>