<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ taglib prefix="my" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>取引明細書<%--거래명세서--%> - ヘキサゴン ERP<%--헥사곤 ERP--%></title>
    <link href="https://cdn.jsdelivr.net/npm/@mdi/font@7.2.96/css/materialdesignicons.min.css" rel="stylesheet">
</head>
<%-- embed=1은 판매조회 모달 안의 거래명세서다. 사이드바는 숨긴다. --%>
<%-- embed=1は販売照会モーダル内の取引明細書である。サイドバーは隠す。 --%>
<body class="${embed == '1' ? 'sale-embed' : ''}">
<div class="erp-wrapper">
    <my:sideMenu />
    <div class="erp-main">
        <main class="erp-content">
            <%-- 저장/전표를 누르면 방금 저장한 전표 번호와 품목을 거래명세서로 보여 준다. 保存/伝票を押すと今保存した伝票番号と品目を取引明細書で表示する。 --%>
            <div class="page-title"><i class="mdi mdi-receipt"></i> 取引明細書<%--거래명세서--%></div>
            <div class="list-wrap">
                <div class="sale-head">
                    <div>伝票番号<%--전표번호--%> ${sale.header.saleId}</div>
                    <div>日付<%--일자--%> <fmt:formatDate value="${sale.header.saleDt}" pattern="yyyy-MM-dd"/></div>
                    <div>取引先<%--거래처--%> ${sale.header.businessPartnerName}</div>
                    <div>出荷倉庫<%--출하창고--%> ${sale.header.warehouseName}</div>
                </div>
                <table class="list-table">
                    <thead>
                    <tr><th>品目コード<%--품목코드--%></th><th>品目名<%--품목명--%></th><th>規格<%--규격--%></th><th>数量<%--수량--%></th><th>単価<%--단가--%></th><th>供給価額<%--공급가액--%></th><th>付加税<%--부가세--%></th><th>合計<%--합계--%></th></tr>
                    </thead>
                    <tbody>
                    <c:forEach var="line" items="${sale.items}">
                        <tr>
                            <td>${line.itemCode}</td>
                            <td>${line.itemNm}</td>
                            <td>${line.spec}</td>
                            <td class="col-num">${line.saleQty}</td>
                            <td class="col-num"><fmt:formatNumber value="${line.unitPrice}" pattern="#,##0"/></td>
                            <td class="col-num"><fmt:formatNumber value="${line.supplyAmt}" pattern="#,##0"/></td>
                            <td class="col-num"><fmt:formatNumber value="${line.vatAmt}" pattern="#,##0"/></td>
                            <td class="col-num"><fmt:formatNumber value="${line.lineAmt}" pattern="#,##0"/></td>
                        </tr>
                    </c:forEach>
                    </tbody>
                </table>
                <div class="sale-foot">
                    <div>供給価額<%--공급가액--%> <fmt:formatNumber value="${sale.header.currAmt}" pattern="#,##0"/></div>
                    <div>付加税<%--부가세--%> <fmt:formatNumber value="${sale.header.vatAmt}" pattern="#,##0"/></div>
                    <a class="btn-flat-sm" href="${pageContext.request.contextPath}/sales/sale/inquiry" onclick="return goInquiry(event)">リスト<%--리스트--%></a>
                </div>
            </div>
        </main>
    </div>
</div>
<style>
    .page-title{font-size:1.25rem;font-weight:700;color:#0B1026;margin-bottom:20px;display:flex;align-items:center;gap:10px}
    .page-title i{color:#4B88FF;font-size:24px}
    .list-wrap{background:#fff;border-radius:14px;border:1px solid #e2e8f0;padding:22px}
    .sale-head,.sale-foot{display:flex;flex-wrap:wrap;gap:16px;margin-bottom:16px}
    .list-table{width:100%;border-collapse:collapse}
    .list-table th,.list-table td{border-bottom:1px solid #e2e8f0;padding:8px;text-align:left;font-size:13px}
    .col-num{text-align:right}
    .btn-flat-sm{display:inline-flex;border:1px solid #e2e8f0;border-radius:8px;padding:8px 14px;text-decoration:none;color:#64748b;font-weight:700}
    body.sale-embed .erp-sidebar{display:none !important}
    body.sale-embed{overflow:auto;height:auto}
</style>
<script>
	// 모달 안의 리스트는 판매조회 프레임으로 나가지 않고 부모 모달을 닫는다.
	// モーダル内のリストは販売照会フレームへ出ず、親モーダルを閉じる。
	function goInquiry(event) {
		if ('${embed}' === '1' && window.parent && window.parent !== window) {
			event.preventDefault();
			window.parent.postMessage({ type: 'sale-saved' }, '*');
			return false;
		}
		return true;
	}
</script>
</body>
</html>
