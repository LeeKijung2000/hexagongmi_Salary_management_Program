<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="my" tagdir="/WEB-INF/tags"%>

<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>見積書入力 - Hexagon ERP</title>

<style>
/* 전체 화면 */
/* 全体画面 */
html, body {
	height: 100%;
	margin: 0;
}

.qi-body {
	background: #f5f7fc;
	color: #344b70;
	font: 12px "Yu Gothic", Meiryo, "Malgun Gothic", Arial, sans-serif;
}

.qi-body * {
	box-sizing: border-box;
}

.qi-body input, .qi-body select, .qi-body button {
	font: inherit;
}

.qi-body button {
	cursor: pointer;
}

.qi-body button:disabled {
	cursor: not-allowed;
	opacity: 0.5;
}

.qi-wrapper {
	display: flex;
	width: 100%;
	height: 100vh;
	min-height: 0;
	overflow: hidden;
}

.qi-main {
	flex: 1;
	min-width: 0;
	min-height: 0;
	height: 100%;
	overflow-x: hidden;
	overflow-y: auto !important;
	overscroll-behavior-y: contain;
}

.qi-content {
	min-height: 100%;
	padding: 16px 18px 80px;
}

.qi-title {
	margin: 0 0 13px;
	color: #182840;
	font-size: 19px;
	font-weight: bold;
}

/* 견적서 기본정보 */
/* 見積基本情報 */
.qi-card {
	padding: 16px 18px;
	margin-bottom: 11px;
	background: white;
	border: 1px solid #dce4f0;
	border-radius: 18px;
}

.qi-fields {
	display: grid;
	grid-template-columns: repeat(2, minmax(0, 1fr));
	column-gap: 19px;
	row-gap: 9px;
}

.qi-field {
	display: grid;
	grid-template-columns: 108px minmax(0, 1fr);
	align-items: center;
	gap: 9px;
	min-width: 0;
}

.qi-field.wide {
	grid-column: 1/-1;
}

.qi-field label {
	color: #7485a3;
}

.qi-required {
	color: #e15362;
}

.qi-control {
	width: 100%;
	min-width: 0;
	height: 34px;
	padding: 0 9px;
	color: #344d75;
	background: white;
	border: 1px solid #dce4f0;
	border-radius: 9px;
}

.qi-control:focus {
	outline: 1px solid #5885ea;
	border-color: #5885ea;
}

.qi-pair {
	display: flex;
	min-width: 0;
}

.qi-pair input:first-child {
	flex: 1;
	border-radius: 9px 0 0 9px;
}

.qi-pair input:last-child {
	flex: 1;
	border-radius: 0 9px 9px 0;
}

.qi-pair button {
	width: 36px;
	flex: 0 0 36px;
	background: white;
	color: #2759b5;
	border: 1px solid #dce4f0;
	border-left: 0;
	border-right: 0;
	font-size: 17px;
}

.qi-pair input[readonly] {
	background: #fafcff;
}

.qi-currency {
	display: flex;
	gap: 7px;
	min-width: 0;
}

.qi-currency select {
	flex: 1;
	min-width: 0;
}

.qi-currency input {
	flex: 0 0 115px;
	width: 115px;
	text-align: right;
}

.qi-attachment {
	display: flex;
	align-items: center;
	flex-wrap: wrap;
	gap: 7px;
}

.qi-attachment-name {
	color: #627b9e;
	overflow-wrap: anywhere;
}

/* 버튼 */
/* ボタン */
.qi-btn {
	min-height: 30px;
	padding: 5px 11px;
	color: #526986;
	background: white;
	border: 1px solid #dce4f0;
	border-radius: 12px;
	white-space: nowrap;
}

.qi-btn




:hover




:not


 


(
:disabled


 


)
{
background




:


 


#ecf2ff




;
}
.qi-btn.primary {
	color: white;
	background: #3158ea;
	border-color: #3158ea;
}

.qi-toolbar {
	display: flex;
	align-items: center;
	flex-wrap: wrap;
	gap: 6px;
	margin: 8px 0;
	position: relative;
}

.qi-spacer {
	flex: 1;
}

.qi-stock-info {
	font-size: 11px;
	color: #5678a8;
}

.qi-bottom {
	display: flex;
	align-items: center;
	flex-wrap: wrap;
	gap: 8px;
	margin-top: 12px;
}

.qi-message {
	min-height: 30px;
	padding: 10px 0;
	color: #245aab;
}

.qi-message.error {
	color: #c73648;
}

/* 찾기(F3) */
/* 画面内検索 */
.qi-find-wrap {
	position: relative;
}

.qi-find-box {
	display: none;
	position: absolute;
	top: 34px;
	left: 0;
	width: 245px;
	z-index: 100;
	padding: 8px;
	background: white;
	border: 1px solid #a6bff2;
	border-radius: 10px;
	box-shadow: 0 6px 18px rgba(20, 45, 100, 0.16);
}

.qi-find-box.open {
	display: block;
}

.qi-find-line {
	display: flex;
	gap: 5px;
}

.qi-find-line input {
	width: 100%;
	min-width: 0;
	height: 30px;
	padding: 0 8px;
	border: 1px solid #a6bff2;
	border-radius: 6px;
	outline-color: #5383eb;
}

.qi-find-info {
	display: block;
	margin-top: 5px;
	color: #7485a4;
	font-size: 11px;
}

/* 품목 테이블 */
/* 明細テーブル */
.qi-table-wrap {
	width: 100%;
	max-width: 100%;
	overflow-x: auto;
	border: 1px solid #dce4ef;
	background: white;
}

.qi-table {
	width: 100%;
	min-width: 950px;
	border-collapse: separate;
	border-spacing: 0;
	table-layout: fixed;
}

/* 재고 표시 후에도 표 전체가 유지되도록 */
/* 在庫列を表示しても表全体の配置を維持するため */
.qi-table.show-stock {
	min-width: 1180px;
}

.qi-table th, .qi-table td {
	border-right: 1px solid #dce4ef;
	border-bottom: 1px solid #dce4ef;
	padding: 3px;
}

.qi-table thead th {
	height: 35px;
	padding: 4px 3px;
	text-align: center;
	font-weight: 500;
	color: #435876;
	background: #f0f3f8;
}

.qi-table tbody td {
	height: 39px;
	background: white;
}

.qi-table tbody tr.selected td {
	background: #e1f0ff;
}

.qi-table tbody input {
	width: 100%;
	min-width: 0;
	height: 29px;
	padding: 0 5px;
	color: #344d75;
	background: transparent;
	border: 1px solid transparent;
	border-radius: 5px;
	outline: 0;
}

.qi-table tbody input:focus {
	background: white;
	border-color: #7298ed;
}

.qi-table tbody input[type="number"] {
	text-align: right;
}

.qi-table tbody input.computed {
	background: #f5f7fa;
	text-align: right;
}

.qi-table .no-cell, .qi-table .action-cell {
	text-align: center;
	white-space: nowrap;
}

.qi-table .right {
	text-align: right;
}

.qi-table tfoot td {
	height: 35px;
	background: #e9edf2;
	font-weight: bold;
}

.qi-no-btn {
	width: 25px;
	height: 25px;
	background: white;
	color: #7a8faf;
	border: 1px solid #d3dfee;
	border-radius: 7px;
}

.qi-table tr.selected .qi-no-btn {
	color: white;
	background: #2b53db;
	border-color: #2b53db;
}

.qi-circle {
	width: 23px;
	height: 23px;
	padding: 0;
	margin: 1px;
	color: white;
	background: #204aab;
	border: 0;
	border-radius: 50%;
	font-weight: bold;
}

/* 재고 열 표시 상태 */
/* 在庫列の表示状態 */

/* 처음에는 전체수량·창고수량 숨김 */
/* 初期状態では全体在庫・倉庫在庫を非表示 */
.qi-table .stock-col {
	display: none;
}

/* 재고불러오기 성공 후 두 열 표시 */
/* 在庫取得成功後に二つの列を表示 */
.qi-table.show-stock th.stock-col, .qi-table.show-stock td.stock-col {
	display: table-cell;
}

/* 재고 조회 후 수량 표시 스타일 */
/* 在庫照会後の数量表示スタイル */
.qi-table.show-stock td.stock-col {
	text-align: right;
	color: #2d5aa0;
	background: #f1f6ff;
	font-weight: bold;
}

.qi-table.show-stock tr.selected td.stock-col {
	background: #e1efff;
}

/* 열 너비 */
/* 列幅 */
/* 순서: */
/* 表示順： */
/* No, 버튼, 코드, 이름, 규격, */
/* 番号、ボタン、コード、名称、規格、 */
/* 전체수량, 창고수량, 수량, 단가, */
/* 全体在庫、倉庫在庫、数量、単価、 */
/* 공급가액, 부가세, 새로운 항목, 합계 */
/* 供給価額、付加価値税、追加項目、合計 */

/* 재고 열을 숨겼을 때 */
/* 在庫列を非表示にした状態 */
.qi-table th:nth-child(1) {
	width: 4%;
}

.qi-table th:nth-child(2) {
	width: 5%;
}

.qi-table th:nth-child(3) {
	width: 12%;
}

.qi-table th:nth-child(4) {
	width: 13%;
}

.qi-table th:nth-child(5) {
	width: 10%;
}

.qi-table th:nth-child(8) {
	width: 7%;
}

.qi-table th:nth-child(9) {
	width: 9%;
}

.qi-table th:nth-child(10) {
	width: 10%;
}

.qi-table th:nth-child(11) {
	width: 8%;
}

.qi-table th:nth-child(12) {
	width: 12%;
}

.qi-table th:nth-child(13) {
	width: 10%;
}

/* 재고불러오기 이후: 13개 열에 맞게 재배분 */
/* 在庫取得後：13列に合わせて幅を再配分 */
.qi-table.show-stock th:nth-child(1) {
	width: 4%;
}

.qi-table.show-stock th:nth-child(2) {
	width: 5%;
}

.qi-table.show-stock th:nth-child(3) {
	width: 10%;
}

.qi-table.show-stock th:nth-child(4) {
	width: 10%;
}

.qi-table.show-stock th:nth-child(5) {
	width: 8%;
}

.qi-table.show-stock th:nth-child(6) {
	width: 7%;
}

.qi-table.show-stock th:nth-child(7) {
	width: 7%;
}

.qi-table.show-stock th:nth-child(8) {
	width: 6%;
}

.qi-table.show-stock th:nth-child(9) {
	width: 8%;
}

.qi-table.show-stock th:nth-child(10) {
	width: 8%;
}

.qi-table.show-stock th:nth-child(11) {
	width: 7%;
}

.qi-table.show-stock th:nth-child(12) {
	width: 10%;
}

.qi-table.show-stock th:nth-child(13) {
	width: 10%;
}

/* 합계금액 열을 오른쪽에 고정 */
/* 合計金額列を右側に固定 */
.qi-table th.total-col, .qi-table td.total-col {
	position: sticky;
	right: 0;
	z-index: 2;
	min-width: 100px;
	box-shadow: -2px 0 4px rgba(36, 55, 90, 0.12);
}

.qi-table thead th.total-col {
	z-index: 4;
	background: #f0f3f8;
}

.qi-table tbody td.total-col {
	background: #fff;
}

.qi-table tbody tr.selected td.total-col {
	background: #e1f0ff;
}

.qi-table tfoot td.total-col {
	z-index: 3;
	background: #e9edf2;
}

.qi-table td.total-col input {
	text-align: right;
	font-variant-numeric: tabular-nums;
}

/* 찾기 노란색 강조 */
/* 検索結果を黄色で強調 */
.qi-table tbody td.find-hit, .qi-table tbody tr.selected td.find-hit,
	.qi-table tbody td.find-hit input {
	background: #fff4bb !important;
}

.qi-table tbody td.find-current, .qi-table tbody tr.selected td.find-current,
	.qi-table tbody td.find-current input {
	background: #ffdf7c !important;
}

.qi-table tbody td.find-current {
	outline: 2px solid #e3ae13;
	outline-offset: -2px;
}

/* 기준정보 조회 팝업 */
/* マスター情報検索モーダル */
.qi-overlay {
	display: none;
	position: fixed;
	inset: 0;
	z-index: 9000;
	padding: 15px;
	align-items: center;
	justify-content: center;
	background: rgba(25, 38, 60, 0.47);
}

.qi-modal {
	width: min(750px, 100%);
	background: white;
	border-radius: 12px;
	overflow: hidden;
	box-shadow: 0 15px 40px rgba(0, 0, 0, 0.2);
}

.qi-modal-head {
	padding: 13px;
	display: flex;
	align-items: center;
	justify-content: space-between;
	border-bottom: 1px solid #e1e6ef;
}

.qi-modal-head strong {
	font-size: 15px;
}

.qi-modal-body {
	padding: 13px;
}

.qi-modal-search {
	display: flex;
	gap: 8px;
}

.qi-modal-search input {
	flex: 1;
}

.qi-modal-result {
	max-height: 320px;
	overflow: auto;
	margin-top: 10px;
}

.qi-modal-table {
	width: 100%;
	border-collapse: collapse;
}

.qi-modal-table th, .qi-modal-table td {
	border: 1px solid #dce4ee;
	padding: 8px;
}

.qi-modal-table th {
	background: #f1f4f8;
}

.qi-modal-table tbody tr {
	cursor: pointer;
}

.qi-modal-table tbody tr:hover {
	background: #eaf2ff;
}

/* 반응형 */
/* レスポンシブ */
@media ( max-width : 1050px) {
	.qi-fields {
		grid-template-columns: 1fr;
	}
	.qi-field.wide {
		grid-column: auto;
	}
}

@media ( max-width : 700px) {
	html, body {
		height: auto;
		overflow-y: auto;
	}
	.qi-wrapper {
		height: auto;
		min-height: 100vh;
		flex-direction: column;
		overflow: visible;
	}
	.qi-main {
		height: auto;
		overflow: visible !important;
	}
	.qi-content {
		padding: 12px;
	}
	.qi-field {
		grid-template-columns: 100px minmax(0, 1fr);
	}
	.qi-currency input {
		width: 95px;
		flex-basis: 95px;
	}
}
</style>
</head>

<body class="qi-body">

    <div class="qi-wrapper">

        <!--
		    기존 사이드바
		    共通サイドバー
		-->
        <my:sideMenu />

        <div class="qi-main" id="qiMainScroll">

            <main class="qi-content">

                <h1 class="qi-title">見積書入力</h1>

                <!--
				    상단 기본정보
				    基本情報
				-->
                <section class="qi-card">

                    <div class="qi-fields">

                        <!--
						    일자
						    日付
						-->
                        <div class="qi-field">
                            <label for="quote_date"> 日付 <span class="qi-required">*</span>
                            </label> <input type="date" id="quote_date" class="qi-control">
                        </div>

                        <!--
						    거래처
						    取引先
						-->
                        <div class="qi-field">
                            <label for="partner_code"> 取引先 <span class="qi-required">*</span>
                            </label>

                            <div class="qi-pair">

                                <input type="text" id="partner_code" class="qi-control" placeholder="取引先コード">

                                <button type="button" data-lookup="partner" title="取引先検索">⌕</button>

                                <input type="text" id="partner_name" class="qi-control" placeholder="取引先名" readonly>

                            </div>
                        </div>

                        <!--
						    담당자
						    担当者
						-->
                        <div class="qi-field">
                            <label for="manager_code">担当者</label>

                            <div class="qi-pair">

                                <input type="text" id="manager_code" class="qi-control" placeholder="担当者コード">

                                <button type="button" data-lookup="manager" title="担当者検索">⌕</button>

                                <input type="text" id="manager_name" class="qi-control" placeholder="担当者名" readonly>

                            </div>
                        </div>

                        <!--
						    출하창고
						    出荷倉庫
						-->
                        <div class="qi-field">
                            <label for="warehouse_code">出荷倉庫</label>

                            <div class="qi-pair">

                                <input type="text" id="warehouse_code" class="qi-control" placeholder="倉庫コード">

                                <button type="button" data-lookup="warehouse" title="出荷倉庫検索">⌕</button>

                                <input type="text" id="warehouse_name" class="qi-control" placeholder="出荷倉庫名" readonly>

                            </div>
                        </div>

                        <!--
						    거래유형
						    取引区分
						-->
                        <div class="qi-field">
                            <label for="transaction_type">取引区分</label> <select id="transaction_type" class="qi-control">

                                <option value="TAXABLE">消費税適用</option>

                                <option value="EXEMPT">免税</option>

                            </select>
                        </div>

                        <!--
						    통화 / 환율
						    通貨／為替レート
						-->
                        <div class="qi-field">
                            <label for="currency_id"> 通貨 <span class="qi-required">*</span>
                            </label>

                            <div class="qi-currency">

                                <select id="currency_id" class="qi-control" disabled>

                                    <option value="">通貨を読み込んでいます...</option>

                                </select> <input type="number" id="exchange_rate" class="qi-control" min="0.000001" step="0.000001" placeholder="為替レート" aria-label="為替レート">

                            </div>
                        </div>

                        <!--
						    첨부파일
						    添付ファイル
						-->
                        <div class="qi-field">
                            <label>添付</label>

                            <div class="qi-attachment">

                                <input type="file" id="attachment_file" accept=".pdf,.png,.jpg,.jpeg,.docx,.xlsx,.txt" hidden>

                                <button type="button" id="attachBtn" class="qi-btn">＋ ファイルを添付</button>

                                <button type="button" id="removeAttachBtn" class="qi-btn">削除</button>

                                <span id="attachmentName" class="qi-attachment-name"> ファイルが選択されていません </span>

                                <button type="button" id="retryAttachmentBtn" class="qi-btn" hidden>アップロードを再試行</button>

                                <a id="attachmentDownload" hidden> 添付ファイルをダウンロード </a>

                            </div>
                        </div>

                        <!--
						    새로운 항목 추가
						    新しい項目の追加
						-->
                        <div class="qi-field wide">

                            <label for="custom_data"> 新しい項目を追加 </label> <input type="text" id="custom_data" class="qi-control" placeholder="さまざまな項目を追加して利用できます。">

                        </div>

                    </div>
                </section>

                <!--
				    테이블 상단 툴바
				    テーブル上部のツールバー
				-->
                <div class="qi-toolbar">

                    <div class="qi-find-wrap">

                        <button type="button" id="findBtn" class="qi-btn">検索（F3）</button>

                        <div id="quickFindBox" class="qi-find-box">

                            <div class="qi-find-line">

                                <input id="quickFindInput" type="text" placeholder="表内で検索する値">

                                <button type="button" id="findNextBtn" class="qi-btn">↓</button>

                                <button type="button" id="findCloseBtn" class="qi-btn">×</button>

                            </div>

                            <span id="findInfo" class="qi-find-info"> 検索キーワードを入力してください。 </span>

                        </div>
                    </div>

                    <button type="button" id="inventoryBtn" class="qi-btn">在庫取得</button>

                    <span id="stockInfo" class="qi-stock-info"></span> <span class="qi-spacer"></span>

                    <button type="button" id="deleteBtn" class="qi-btn" disabled>🗑 選択削除</button>

                    <button type="button" id="upBtn" class="qi-btn" disabled>↑</button>

                    <button type="button" id="downBtn" class="qi-btn" disabled>↓</button>

                </div>

                <!--
				    견적서 품목 테이블
				    見積書の品目テーブル
				    재고불러오기 전에는 재고열 숨김
				    在庫取得前は在庫列を非表示
				-->
                <div class="qi-table-wrap">

                    <table class="qi-table" id="quotationTable">

                        <thead>
                            <tr>

                                <!--
								    No.
								    No.
								-->
                                <th>No. <input type="checkbox" id="selectAll" title="全行を選択">
                                </th>

                                <!--
								    행 추가
								    行の追加
								-->
                                <th>
                                    <button type="button" id="headerPlus" class="qi-circle" title="行追加">+</button>
                                </th>

                                <!--
								    3~5. 품목
								    3～5. 品目欄
								-->
                                <th>品目コード</th>
                                <th>品目名</th>
                                <th>規格</th>

                                <!--
								    6~7. 재고: 처음에는 숨김
								    6～7. 在庫欄：初期状態では非表示
								-->
                                <th class="stock-col">全体在庫数量</th>

                                <th class="stock-col">倉庫在庫数量</th>

                                <!--
								    8~11. 금액
								    8～11. 金額欄
								-->
                                <th>数量</th>
                                <th>単価</th>
                                <th>供給価額</th>
                                <th>消費税</th>

                                <!--
								    사용자 입력
								    ユーザー入力欄
								-->
                                <th>新しい項目</th>

                                <!--
								    합계금액 고정
								    合計金額列を固定
								-->
                                <th class="total-col">合計金額</th>

                            </tr>
                        </thead>

                        <tbody id="itemRows"></tbody>

                        <tfoot>
                            <tr>

                                <td colspan="5">合計</td>

                                <!--
								    재고 열: 처음에는 숨김
								    在庫列：初期状態では非表示
								-->
                                <td class="stock-col"></td>
                                <td class="stock-col"></td>

                                <td id="sumQuantity" class="right">0</td>

                                <td></td>

                                <td id="sumSupply" class="right">0</td>

                                <td id="sumVat" class="right">0</td>

                                <td></td>

                                <td id="sumTotal" class="right total-col">0</td>

                            </tr>
                        </tfoot>

                    </table>
                </div>

                <!--
				    하단 버튼
				    下部の操作ボタン
				-->
                <div class="qi-bottom">

                    <button type="button" id="saveBtn" class="qi-btn primary">保存(F8)</button>

                    <button type="button" id="resetBtn" class="qi-btn">再入力</button>

                    <button type="button" id="listBtn" class="qi-btn">一覧</button>

                </div>

                <div id="message" class="qi-message" role="status"></div>

            </main>
        </div>
    </div>

    <!--
	    기준정보 조회 팝업
	    マスター検索モーダル
	-->
    <div id="lookupOverlay" class="qi-overlay" role="dialog" aria-modal="true" aria-labelledby="lookupTitle">

        <div class="qi-modal">

            <div class="qi-modal-head">

                <strong id="lookupTitle">照会</strong>

                <button type="button" id="lookupClose" class="qi-btn">閉じる ×</button>

            </div>

            <div class="qi-modal-body">

                <div class="qi-modal-search">

                    <input type="text" id="lookupKeyword" class="qi-control" placeholder="コードまたは名称で検索">

                    <button type="button" id="lookupSearchBtn" class="qi-btn primary">検索</button>

                </div>

                <div class="qi-modal-result">

                    <table class="qi-modal-table">

                        <thead id="lookupHeader"></thead>

                        <tbody id="lookupRows"></tbody>

                    </table>

                </div>
            </div>
        </div>
    </div>

    <script>
(function () {
    "use strict";

    // 기본 변수
    // 基本変数

    var ctx = "${pageContext.request.contextPath}";

    var api = ctx + "/sales/estimate/api/input";

    var tbody = document.getElementById("itemRows");

    var overlay = document.getElementById("lookupOverlay");

    var lookupType = "";
    var lookupTarget = null;

    var savedQuoteId = null;
    var saving = false;

    var findMatches = [];
    var findIndex = -1;

    function el(id) {
        return document.getElementById(id);
    }

    function num(value) {

        if (value === "" || value == null) {
            return 0;
        }

        var n = Number(value);

        return isFinite(n) ? n : 0;
    }

    function money(value) {

        return Math.round(
            (num(value) + Number.EPSILON) * 100
        ) / 100;
    }

    function formatted(value, digits) {

        return num(value).toLocaleString("ja-JP", {
            maximumFractionDigits: digits
        });
    }

    function today() {

        var d = new Date();

        return d.getFullYear() + "-"
            + String(d.getMonth() + 1).padStart(2, "0")
            + "-"
            + String(d.getDate()).padStart(2, "0");
    }

    function notice(message, error) {

        el("message").textContent = message;

        el("message").classList.toggle(
            "error",
            Boolean(error)
        );
    }

    function rows() {

        return Array.from(
            tbody.querySelectorAll("tr")
        );
    }

    function field(tr, name) {

        return tr.querySelector(
            '[data-field="' + name + '"]'
        );
    }

    function val(tr, name) {

        var input = field(tr, name);

        return input ? input.value.trim() : "";
    }

    function setVal(tr, name, value) {

        var input = field(tr, name);

        if (input) {

            input.value = value == null
                ? ""
                : value;
        }
    }

    async function getJson(response) {

        if (!response.ok) {

            var message = await response.text();

            if (message.trim().charAt(0) === "<") {

                message = "サーバーエラー HTTP "
                    + response.status
                    + " - STSコンソールの確認が必要です";
            }

            throw new Error(message);
        }

        return response.json();
    }

    // Oracle 통화 목록
    // Oracleの通貨一覧

    function applyCurrency() {

        var select = el("currency_id");

        var option = select.options[select.selectedIndex];

        el("exchange_rate").value =
            option && option.value
                ? option.dataset.exchangeRate || "1"
                : "";
    }

    function defaultCurrency() {

        var select = el("currency_id");

        var options = Array.from(select.options);

        var krw = options.find(function (option) {

            return option.dataset.currencyCode === "KRW";
        });

        var first = options.find(function (option) {

            return option.value !== "";
        });

        var option = krw || first;

        select.value = option ? option.value : "";

        applyCurrency();
    }

    async function loadCurrencies() {

        try {

            var response = await fetch(
                api + "/currencies"
            );

            var data = await getJson(response);

            var select = el("currency_id");

            select.textContent = "";

            var placeholder =
                document.createElement("option");

            placeholder.value = "";
            placeholder.textContent = "通貨を選択";

            select.appendChild(placeholder);

            data.forEach(function (currency) {

                var option =
                    document.createElement("option");

                option.value = currency.currency_id;

                option.textContent =
                    currency.currency_code
                    + " - "
                    + currency.currency_name;

                option.dataset.currencyCode =
                    currency.currency_code;

                option.dataset.exchangeRate =
                    currency.exchange_rate;

                select.appendChild(option);
            });

            select.disabled = data.length === 0;

            defaultCurrency();

        } catch (error) {

            el("currency_id").disabled = true;

            notice(
                "通貨の取得に失敗しました： " + error.message,
                true
            );
        }
    }

    // 품목 테이블 셀 생성
    // 品目テーブルのセル生成

    function createCell(
            tr, name, numeric, placeholder) {

        var td = document.createElement("td");

        var input = document.createElement("input");

        input.type = numeric ? "number" : "text";

        input.dataset.field = name;

        input.placeholder = placeholder || "";

        if (numeric) {

            input.min = "0";

            input.step = name === "quantity"
                ? "0.0001"
                : "0.01";
        }

        td.appendChild(input);

        tr.appendChild(td);

        return input;
    }

    // 재고수량 셀 생성
    // 在庫数量セルの生成
    // 규격 바로 다음에 생성
    // 規格欄の直後に生成
    // 처음에는 CSS로 숨겨짐
    // 初期状態ではCSSで非表示

    function createStockCell(tr, kind) {

        var td = document.createElement("td");

        td.className = "stock-col";

        td.dataset.stockKind = kind;

        td.textContent = "—";

        tr.appendChild(td);

        return td;
    }

    function clearStock(tr) {

        tr.querySelectorAll("[data-stock-kind]")
            .forEach(function (td) {

                td.textContent = "—";
            });
    }

    function invalidateStock() {

        rows().forEach(clearStock);

        // 기존에 표시됐던 재고 열은 유지하되,
        // 以前に表示した在庫列はそのまま維持し、
        // 값만 지우고 다시 조회하도록 안내
        // 値だけを消去して再検索を案内
        if (el("quotationTable")
                .classList.contains("show-stock")) {

            el("stockInfo").textContent =
                "在庫を再取得してください。";
        }
    }

    // 행 선택
    // 行選択

    function renumber() {

        rows().forEach(function (tr, index) {

            tr.querySelector(".qi-no-btn")
                .textContent = index + 1;
        });
    }

    function selectedRows() {

        return rows().filter(function (tr) {

            return tr.dataset.selected === "true";
        });
    }

    function selectRow(tr, selected) {

        tr.dataset.selected =
            selected ? "true" : "false";

        tr.classList.toggle(
            "selected", selected
        );

        updateTools();
    }

    function updateTools() {

        var count = selectedRows().length;
        var total = rows().length;

        el("deleteBtn").disabled =
            savedQuoteId !== null || count === 0;

        el("upBtn").disabled =
            savedQuoteId !== null || count !== 1;

        el("downBtn").disabled =
            savedQuoteId !== null || count !== 1;

        el("selectAll").checked =
            total > 0 && count === total;
    }

    // 금액 자동계산
    // 金額計算

    function calculateRow(tr) {

        var quantity = num(
            val(tr, "quantity")
        );

        var unitPrice = num(
            val(tr, "unit_price")
        );

        var rate = num(
            tr.dataset.vatRate
        );

        if (!isFinite(rate) || rate < 0) {
            rate = 10;
        }

        var taxable =
            el("transaction_type").value === "TAXABLE";

        var vatIncluded =
            tr.dataset.vatIncluded === "Y";

        var amount = money(
            quantity * unitPrice
        );

        var calculatedSupply = amount;

        if (taxable && vatIncluded && rate > 0) {

            calculatedSupply = money(
                amount / (1 + rate / 100)
            );
        }

        // 공급가액 직접 입력값이 있으면 유지
        // 供給価額を手入力した場合はその値を維持
        if (tr.dataset.manualSupply !== "true") {

            setVal(
                tr,
                "supply_amount",
                calculatedSupply.toFixed(2)
            );
        }

        var supply = num(
            val(tr, "supply_amount")
        );

        // 부가세 직접 입력값이 있으면 유지
        // 付加価値税を手入力した場合はその値を維持
        if (tr.dataset.manualVat !== "true") {

            var calculatedVat = 0;

            if (taxable) {

                if (vatIncluded
                        && tr.dataset.manualSupply !== "true") {

                    calculatedVat = money(
                        amount - calculatedSupply
                    );

                } else {

                    calculatedVat = money(
                        supply * rate / 100
                    );
                }
            }

            setVal(
                tr,
                "vat_amount",
                calculatedVat.toFixed(2)
            );
        }

        var total = money(
            supply + num(val(tr, "vat_amount"))
        );

        setVal(
            tr,
            "total_amount",
            total.toFixed(2)
        );

        calculateTotals();
    }

    function calculateTotals() {

        var quantity = 0;
        var supply = 0;
        var vat = 0;

        rows().forEach(function (tr) {

            quantity += num(
                val(tr, "quantity")
            );

            supply += num(
                val(tr, "supply_amount")
            );

            vat += num(
                val(tr, "vat_amount")
            );
        });

        el("sumQuantity").textContent =
            formatted(quantity, 4);

        el("sumSupply").textContent =
            formatted(supply, 2);

        el("sumVat").textContent =
            formatted(vat, 2);

        el("sumTotal").textContent =
            formatted(supply + vat, 2);
    }

    // 품목 선택
    // 品目選択

    function applyItem(tr, item, onlyEmpty) {

        if (!tr || savedQuoteId !== null) {
            return;
        }

        setVal(
            tr,
            "item_code_snap",
            item.code || ""
        );

        if (!onlyEmpty
                || !val(tr, "item_name_snap")) {

            setVal(
                tr,
                "item_name_snap",
                item.name || ""
            );
        }

        if (!onlyEmpty
                || !val(tr, "spec_snap")) {

            setVal(
                tr,
                "spec_snap",
                item.specification || ""
            );
        }

        tr.dataset.unitSnap =
            item.unit_name || "";

        tr.dataset.vatRate =
            item.vat_rate == null
                ? "10"
                : String(item.vat_rate);

        tr.dataset.vatIncluded =
            item.vat_included || "N";

        tr.dataset.resolvedCode =
            item.code || "";

        // 등록된 판매단가 자동입력
        // 登録済み販売単価を自動入力
        if (item.unit_price != null) {

            setVal(
                tr,
                "unit_price",
                item.unit_price
            );
        }

        tr.dataset.manualSupply = "false";
        tr.dataset.manualVat = "false";

        clearStock(tr);

        calculateRow(tr);

        performFind();
    }

    async function resolveItemCode(tr) {

        var code = val(
            tr, "item_code_snap"
        );

        if (!code
                || tr.dataset.resolvedCode === code) {
            return;
        }

        try {

            var response = await fetch(
                api + "/lookup/item?keyword="
                + encodeURIComponent(code)
            );

            var data = await getJson(response);

            var match = data.find(function (item) {

                return String(item.code).toUpperCase()
                    === code.toUpperCase();
            });

            if (match
                    && val(tr, "item_code_snap") === code) {

                applyItem(tr, match, true);
            }

        } catch (error) {

            notice(
                "品目の確認に失敗しました： " + error.message,
                true
            );
        }
    }

    // 행 추가
    // 行追加
    // 열 순서:
    // 列の表示順：
    // No, 버튼, 코드, 이름, 규격,
    // 番号、ボタン、コード、名称、規格、
    // 전체수량, 창고수량, 수량, 단가,
    // 全体在庫、倉庫在庫、数量、単価、
    // 공급가액, 부가세, 새로운 항목, 합계
    // 供給価額、付加価値税、追加項目、合計

    function addRow(afterRow) {

        if (savedQuoteId !== null) {
            return null;
        }

        var tr = document.createElement("tr");

        tr.dataset.selected = "false";
        tr.dataset.unitSnap = "";
        tr.dataset.vatRate = "10";
        tr.dataset.vatIncluded = "N";
        tr.dataset.manualSupply = "false";
        tr.dataset.manualVat = "false";
        tr.dataset.resolvedCode = "";

        // No. 버튼
        // 番号ボタン
        var noTd = document.createElement("td");

        noTd.className = "no-cell";

        var noBtn =
            document.createElement("button");

        noBtn.type = "button";
        noBtn.className = "qi-no-btn";
        noBtn.textContent = "1";

        noBtn.addEventListener("click", function () {

            selectRow(
                tr,
                tr.dataset.selected !== "true"
            );
        });

        noTd.appendChild(noBtn);

        tr.appendChild(noTd);

        // + 및 돋보기 버튼
        // 追加ボタンと検索ボタン
        var actionTd =
            document.createElement("td");

        actionTd.className = "action-cell";

        var plus =
            document.createElement("button");

        plus.type = "button";
        plus.className = "qi-circle";
        plus.textContent = "+";
        plus.title = "この行の下に追加";

        plus.addEventListener("click", function () {

            addRow(tr);
        });

        var lookup =
            document.createElement("button");

        lookup.type = "button";
        lookup.className = "qi-circle";
        lookup.textContent = "⌕";
        lookup.title = "品目検索";

        lookup.addEventListener("click", function () {

            openLookup(
                "item",
                tr,
                val(tr, "item_code_snap")
            );
        });

        actionTd.appendChild(plus);
        actionTd.appendChild(lookup);

        tr.appendChild(actionTd);

        // 품목코드
        // 品目コード
        var code = createCell(
            tr,
            "item_code_snap",
            false,
            "品目コード"
        );

        // 품목명
        // 品目名
        createCell(
            tr,
            "item_name_snap",
            false,
            "品目名"
        );

        // 규격
        // 規格
        createCell(
            tr,
            "spec_snap",
            false,
            "規格"
        );

        // 전체수량: 처음에는 숨김
        // 全体在庫：初期状態では非表示
        createStockCell(tr, "total");

        // 창고수량: 처음에는 숨김
        // 倉庫在庫：初期状態では非表示
        createStockCell(tr, "warehouse");

        // 수량
        // 数量
        var qty = createCell(
            tr,
            "quantity",
            true,
            ""
        );

        // 단가
        // 単価
        var price = createCell(
            tr,
            "unit_price",
            true,
            ""
        );

        // 공급가액
        // 供給価額
        var supply = createCell(
            tr,
            "supply_amount",
            true,
            "0.00"
        );

        // 부가세
        // 付加価値税
        var vat = createCell(
            tr,
            "vat_amount",
            true,
            "0.00"
        );

        // 새로운 항목
        // 新しい項目
        createCell(
            tr,
            "remarks",
            false,
            "自由に入力"
        );

        // 합계금액: 오른쪽 고정
        // 合計金額：右側に固定
        var total = createCell(
            tr,
            "total_amount",
            false,
            "0.00"
        );

        total.readOnly = true;
        total.className = "computed";

        total.parentElement.classList.add(
            "total-col"
        );

        // 품목코드 더블클릭
        // 品目コードをダブルクリック
        code.addEventListener("dblclick", function () {

            openLookup(
                "item",
                tr,
                code.value
            );
        });

        // 품목코드 직접 변경
        // 品目コードを直接変更
        code.addEventListener("input", function () {

            tr.dataset.resolvedCode = "";

            clearStock(tr);

            performFind();
        });

        code.addEventListener("blur", function () {

            resolveItemCode(tr);
        });

        // 수량·단가 자동계산
        // 数量と単価から自動計算
        [qty, price].forEach(function (input) {

            input.addEventListener("input", function () {

                calculateRow(tr);
                performFind();
            });
        });

        // 공급가액 직접 입력
        // 供給価額の手入力
        supply.addEventListener("input", function () {

            tr.dataset.manualSupply = "true";

            calculateRow(tr);
            performFind();
        });

        // 부가세 직접 입력
        // 付加価値税の手入力
        vat.addEventListener("input", function () {

            tr.dataset.manualVat = "true";

            calculateRow(tr);
            performFind();
        });

        tr.querySelectorAll("input[data-field]")
            .forEach(function (input) {

                input.addEventListener(
                    "input",
                    performFind
                );
            });

        if (afterRow
                && afterRow.parentNode === tbody) {

            afterRow.after(tr);

        } else {

            tbody.appendChild(tr);
        }

        renumber();
        updateTools();
        calculateTotals();
        performFind();

        return tr;
    }

    // 선택삭제 및 행 이동
    // 選択削除および行移動

    function deleteSelectedRows() {

        if (savedQuoteId !== null) {
            return;
        }

        var selected = selectedRows();

        if (!selected.length) {

            alert(
                "No.から削除する行を選択してください。"
            );

            return;
        }

        if (!confirm(
                selected.length
                + "行を削除しますか？")) {

            return;
        }

        selected.forEach(function (tr) {

            tr.remove();
        });

        if (!rows().length) {

            addRow();
        }

        renumber();
        updateTools();
        calculateTotals();
        performFind();
    }

    function moveRow(direction) {

        if (savedQuoteId !== null) {
            return;
        }

        var selected = selectedRows();

        if (selected.length !== 1) {

            alert(
                "移動する行を1行選択してください。"
            );

            return;
        }

        var tr = selected[0];

        if (direction === "up"
                && tr.previousElementSibling) {

            tr.previousElementSibling.before(tr);

        } else if (direction === "down"
                && tr.nextElementSibling) {

            tr.nextElementSibling.after(tr);
        }

        renumber();
        performFind();
    }

    // 찾기(F3)
    // 検索（F3）

    function clearFindMarks() {

        document.querySelectorAll(
            "#itemRows td.find-hit, #itemRows td.find-current"
        ).forEach(function (td) {

            td.classList.remove(
                "find-hit",
                "find-current"
            );
        });
    }

    function performFind() {

        clearFindMarks();

        findMatches = [];
        findIndex = -1;

        var keyword =
            el("quickFindInput").value
                .trim()
                .toLowerCase();

        if (!keyword) {

            el("findInfo").textContent =
                "検索キーワードを入力してください。";

            return;
        }

        var exact = [];
        var partial = [];

        rows().forEach(function (tr) {

            tr.querySelectorAll("input[data-field]")
                .forEach(function (input) {

                    var text =
                        input.value.toLowerCase();

                    if (!text
                            || text.indexOf(keyword) < 0) {

                        return;
                    }

                    var td = input.closest("td");

                    td.classList.add("find-hit");

                    if (text === keyword) {

                        exact.push(td);

                    } else {

                        partial.push(td);
                    }
                });
        });

        findMatches =
            exact.concat(partial);

        el("findInfo").textContent =
            findMatches.length + "件のセルが一致";

        if (findMatches.length) {

            findIndex = 0;

            markCurrent(false);
        }
    }

    function markCurrent(scroll) {

        document.querySelectorAll(
            "#itemRows td.find-current"
        ).forEach(function (td) {

            td.classList.remove(
                "find-current"
            );
        });

        if (findIndex < 0
                || !findMatches.length) {

            return;
        }

        var td = findMatches[findIndex];

        td.classList.add(
            "find-current"
        );

        el("findInfo").textContent =
            (findIndex + 1)
            + " / "
            + findMatches.length
            + "件一致";

        if (scroll) {

            td.scrollIntoView({
                behavior: "smooth",
                block: "nearest",
                inline: "nearest"
            });
        }
    }

    function nextFind() {

        if (!findMatches.length) {
            return;
        }

        findIndex =
            (findIndex + 1) % findMatches.length;

        markCurrent(true);
    }

    function closeFind() {

        el("quickFindBox")
            .classList.remove("open");

        el("quickFindInput").value = "";

        clearFindMarks();

        findMatches = [];
        findIndex = -1;
    }

    function toggleFind() {

        var box = el("quickFindBox");

        if (box.classList.contains("open")) {

            closeFind();

        } else {

            box.classList.add("open");

            el("quickFindInput").focus();
        }
    }

    // 기준정보 조회 팝업
    // マスター検索モーダル

    function openLookup(type, target, keyword) {

        lookupType = type;
        lookupTarget = target || null;

        var titles = {
            item: "品目検索",
            partner: "取引先検索",
            manager: "担当者検索",
            warehouse: "倉庫検索"
        };

        el("lookupTitle").textContent =
            titles[type] || "照会";

        el("lookupKeyword").value =
            keyword || "";

        if (type === "item") {

            el("lookupHeader").innerHTML =
                "<tr><th>品目コード</th>"
                + "<th>品目名</th>"
                + "<th>規格</th>"
                + "<th>販売単価</th></tr>";

        } else {

            el("lookupHeader").innerHTML =
                "<tr><th>コード</th>"
                + "<th>名称</th></tr>";
        }

        overlay.style.display = "flex";

        searchLookup();

        el("lookupKeyword").focus();
    }

    function closeLookup() {

        overlay.style.display = "none";
    }

    function lookupMessage(message) {

        var tr = document.createElement("tr");

        var td = document.createElement("td");

        td.colSpan = lookupType === "item"
            ? 4
            : 2;

        td.textContent = message;

        td.style.textAlign = "center";

        tr.appendChild(td);

        el("lookupRows").appendChild(tr);
    }

    async function searchLookup() {

        var type = lookupType;

        var keyword =
            el("lookupKeyword").value.trim();

        el("lookupRows").textContent = "";

        try {

            var response = await fetch(
                api + "/lookup/" + type
                + "?keyword="
                + encodeURIComponent(keyword)
            );

            var data = await getJson(response);

            if (overlay.style.display !== "flex"
                    || lookupType !== type) {

                return;
            }

            el("lookupRows").textContent = "";

            if (!Array.isArray(data)
                    || !data.length) {

                lookupMessage(
                    "検索結果がありません。"
                );

                return;
            }

            data.forEach(function (item) {

                var tr =
                    document.createElement("tr");

                var columns = [
                    item.code || "",
                    item.name || ""
                ];

                if (type === "item") {

                    columns.push(
                        item.specification || ""
                    );

                    columns.push(
                        item.unit_price == null
                            ? "未登録"
                            : formatted(
                                item.unit_price,
                                2
                              )
                    );
                }

                columns.forEach(function (text) {

                    var td =
                        document.createElement("td");

                    td.textContent = text;

                    tr.appendChild(td);
                });

                tr.addEventListener("click", function () {

                    chooseLookup(item);
                });

                el("lookupRows").appendChild(tr);
            });

        } catch (error) {

            el("lookupRows").textContent = "";

            lookupMessage(error.message);
        }
    }

    function chooseLookup(item) {

        if (lookupType === "item"
                && lookupTarget) {

            applyItem(
                lookupTarget,
                item,
                false
            );

        } else {

            var codeIds = {
                partner: "partner_code",
                manager: "manager_code",
                warehouse: "warehouse_code"
            };

            var nameIds = {
                partner: "partner_name",
                manager: "manager_name",
                warehouse: "warehouse_name"
            };

            el(codeIds[lookupType]).value =
                item.code || "";

            el(nameIds[lookupType]).value =
                item.name || "";

            if (lookupType === "warehouse") {

                invalidateStock();
            }
        }

        closeLookup();
    }

    // 재고불러오기
    // 在庫の取込
    // 조회 성공 후에만 전체수량·창고수량 열 표시
    // 検索成功後のみ全体在庫・倉庫在庫列を表示

    async function loadInventory() {

        var warehouseCode =
            el("warehouse_code").value.trim();

        var itemCodes = rows()
            .map(function (tr) {

                return val(
                    tr,
                    "item_code_snap"
                );
            })
            .filter(function (code) {

                return code !== "";
            });

        itemCodes = Array.from(
            new Set(itemCodes)
        );

        if (!itemCodes.length) {

            notice(
                "先に在庫を照会する品目を入力してください。",
                true
            );

            return;
        }

        var button = el("inventoryBtn");

        button.disabled = true;

        el("stockInfo").textContent =
            "在庫を照会しています...";

        try {

            var response = await fetch(
                api + "/inventory",
                {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "Accept": "application/json"
                    },
                    body: JSON.stringify({
                        warehouse_code: warehouseCode,
                        item_codes: itemCodes
                    })
                }
            );

            var result = await getJson(response);

            if (!Array.isArray(result)) {

                throw new Error(
                    "在庫照会結果の形式が正しくありません。"
                );
            }

            // Oracle에서 가져온 재고 데이터를
            // Oracleから取得した在庫データを
            // 품목코드별로 정리
            // 品目コード別に整理
            var stockMap = {};

            result.forEach(function (stock) {

                var key = String(
                    stock.item_code || ""
                ).trim().toUpperCase();

                stockMap[key] = stock;
            });

            // 각 행에 재고값 채우기
            // 各行の在庫値を反映
            rows().forEach(function (tr) {

                var code = val(
                    tr,
                    "item_code_snap"
                ).trim().toUpperCase();

                var stock = stockMap[code];

                var totalCell =
                    tr.querySelector(
                        '[data-stock-kind="total"]'
                    );

                var warehouseCell =
                    tr.querySelector(
                        '[data-stock-kind="warehouse"]'
                    );

                if (!code) {

                    totalCell.textContent = "—";
                    warehouseCell.textContent = "—";

                    return;
                }

                if (stock) {

                    // 전체수량
                    // 全体在庫数量
                    totalCell.textContent =
                        formatted(
                            stock.total_qty,
                            4
                        );

                    // 창고수량
                    // 倉庫在庫数量
                    if (warehouseCode
                            && stock.warehouse_qty != null) {

                        warehouseCell.textContent =
                            formatted(
                                stock.warehouse_qty,
                                4
                            );

                    } else {

                        warehouseCell.textContent = "—";
                    }

                } else {

                    totalCell.textContent = "—";
                    warehouseCell.textContent = "—";
                }
            });

            // 중요한 부분
            // 重要な処理
            // 실제 재고 조회에 성공한 뒤에만
            // 実際の在庫取得に成功した後のみ
            // 전체수량·창고수량 열 표시
            // 全体在庫・倉庫在庫列を表示
            el("quotationTable")
                .classList.add("show-stock");

            el("stockInfo").textContent =
                warehouseCode
                    ? "出荷倉庫 "
                        + warehouseCode
                        + " 基準"
                    : "全体在庫を照会しました・倉庫未選択";

            if (warehouseCode) {

                notice(
                    "全体在庫と倉庫在庫を取得しました。"
                );

            } else {

                notice(
                    "全体在庫を取得しました。 "
                    + "倉庫在庫を表示するには出荷倉庫を選択してください。"
                );
            }

        } catch (error) {

            notice(
                "在庫照会に失敗しました： "
                + error.message,
                true
            );

            el("stockInfo").textContent =
                "在庫照会に失敗しました";

        } finally {

            button.disabled = false;
        }
    }

    // 저장할 품목 데이터
    // 保存する品目データ

    function collectItems() {

        var result = [];

        rows().forEach(function (tr) {

            var code = val(tr, "item_code_snap");
            var name = val(tr, "item_name_snap");
            var spec = val(tr, "spec_snap");
            var qty = val(tr, "quantity");
            var price = val(tr, "unit_price");
            var supply = val(tr, "supply_amount");
            var vat = val(tr, "vat_amount");
            var remarks = val(tr, "remarks");

            var empty =
                !code && !name && !spec
                && !qty && !price
                && !supply && !vat
                && !remarks;

            if (empty) {
                return;
            }

            if (!code) {

                throw new Error(
                    "品目コードを入力してください。"
                );
            }

            if (!qty || num(qty) <= 0) {

                throw new Error(
                    "数量は0より大きい値にしてください。"
                );
            }

            if (price === ""
                    || num(price) < 0) {

                throw new Error(
                    "単価は0以上にしてください。"
                );
            }

            if (supply === ""
                    || vat === ""
                    || num(supply) < 0
                    || num(vat) < 0) {

                throw new Error(
                    "供給価額と消費税を確認してください。"
                );
            }

            result.push({

                line_no: result.length + 1,

                item_code_snap: code,
                item_name_snap: name,
                spec_snap: spec,

                unit_snap:
                    tr.dataset.unitSnap || "",

                quantity: num(qty),

                unit_price: num(price),

                supply_amount: money(supply),

                vat_amount: money(vat),

                total_amount: money(
                    num(supply) + num(vat)
                ),

                remarks: remarks
            });
        });

        if (!result.length) {

            throw new Error(
                "見積品目を1件以上入力してください。"
            );
        }

        return result;
    }

    // 첨부파일 업로드
    // 添付ファイルのアップロード

    async function uploadAttachment() {

        if (!savedQuoteId) {

            throw new Error(
                "先に見積書を保存してください。"
            );
        }

        var file =
            el("attachment_file").files[0];

        if (!file) {

            throw new Error(
                "添付ファイルを選択してください。"
            );
        }

        var form = new FormData();

        form.append("file", file);

        var response = await fetch(
            api + "/quotations/"
                + savedQuoteId
                + "/attachment",
            {
                method: "POST",
                body: form
            }
        );

        if (!response.ok) {

            throw new Error(
                "添付ファイルのアップロードに失敗しました。HTTP "
                + response.status
            );
        }

        el("attachmentDownload").href =
            api + "/quotations/"
                + savedQuoteId
                + "/attachment";

        el("attachmentDownload").hidden = false;

        el("retryAttachmentBtn").hidden = true;
    }

    // 견적서 저장(F8)
    // 見積書の保存（F8）

    async function saveQuotation() {

        if (saving || savedQuoteId !== null) {
            return;
        }

        saving = true;

        el("saveBtn").disabled = true;

        try {

            if (!el("quote_date").value) {

                throw new Error(
                    "見積日を入力してください。"
                );
            }

            if (!el("partner_code").value.trim()) {

                throw new Error(
                    "取引先を選択してください。"
                );
            }

            if (!el("currency_id").value) {

                throw new Error(
                    "通貨を選択してください。"
                );
            }

            if (!(num(
                    el("exchange_rate").value
                ) > 0)) {

                throw new Error(
                    "為替レートは0より大きい値にしてください。"
                );
            }

            var file =
                el("attachment_file").files[0];

            if (file
                    && file.size > 10 * 1024 * 1024) {

                throw new Error(
                    "添付ファイルは10MB以下にしてください。"
                );
            }

            var payload = {

                quote_date:
                    el("quote_date").value,

                partner_code:
                    el("partner_code").value.trim(),

                employee_code:
                    el("manager_code").value.trim(),

                warehouse_code:
                    el("warehouse_code").value.trim(),

                transaction_type:
                    el("transaction_type").value,

                currency_id:
                    Number(el("currency_id").value),

                exchange_rate:
                    Number(el("exchange_rate").value),

                custom_data:
                    el("custom_data").value.trim(),

                items: collectItems()
            };

            notice(
                "見積書を保存しています。"
            );

            var response = await fetch(
                api + "/quotations",
                {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "Accept": "application/json"
                    },
                    body: JSON.stringify(payload)
                }
            );

            var saved = await getJson(response);

            if (!saved.quote_id) {

                throw new Error(
                    "サーバーから見積書IDを取得できませんでした。"
                );
            }

            savedQuoteId = saved.quote_id;

            notice(
                "見積書の保存が完了しました！ID： "
                + savedQuoteId
            );

            if (file) {

                try {

                    await uploadAttachment();

                    notice(
                        "見積書と添付ファイルの保存が完了しました！"
                    );

                } catch (error) {

                    el("retryAttachmentBtn").hidden = false;

                    notice(
                        "見積書は保存されましたが、 "
                        + "添付ファイルのアップロードに失敗しました。",
                        true
                    );
                }
            }

        } catch (error) {

            notice(
                error.message,
                true
            );

        } finally {

            saving = false;

            el("saveBtn").disabled =
                savedQuoteId !== null;

            updateTools();
        }
    }

    // 다시 작성
    // 再入力

    function resetForm() {

        if (!confirm(
                "入力内容をすべて消去して "
                + "入力し直しますか？")) {

            return;
        }

        savedQuoteId = null;

        [
            "partner_code",
            "partner_name",
            "manager_code",
            "manager_name",
            "warehouse_code",
            "warehouse_name",
            "custom_data"
        ].forEach(function (id) {

            el(id).value = "";
        });

        el("quote_date").value = today();

        el("transaction_type").value =
            "TAXABLE";

        defaultCurrency();

        el("attachment_file").value = "";

        el("attachmentName").textContent =
            "ファイルが選択されていません";

        el("retryAttachmentBtn").hidden = true;

        el("attachmentDownload").hidden = true;

        el("stockInfo").textContent = "";

        // 다시 작성하면 재고 열도 다시 숨김
        // 再入力時には在庫列も再び非表示
        el("quotationTable")
            .classList.remove("show-stock");

        closeFind();

        tbody.textContent = "";

        for (var i = 0; i < 4; i++) {

            addRow();
        }

        el("saveBtn").disabled = false;

        notice("");

        updateTools();
    }

    // 버튼 이벤트
    // ボタンイベント

    // 통화 선택
    // 通貨の選択
    el("currency_id").addEventListener(
        "change",
        applyCurrency
    );

    // 거래유형 변경
    // 取引区分の変更
    el("transaction_type").addEventListener(
        "change",
        function () {

            rows().forEach(calculateRow);
        }
    );

    // 행 추가
    // 行の追加
    el("headerPlus").addEventListener(
        "click",
        function () {

            addRow();
        }
    );

    // 행 삭제
    // 行の削除
    el("deleteBtn").addEventListener(
        "click",
        deleteSelectedRows
    );

    // 위로 이동
    // 上へ移動
    el("upBtn").addEventListener(
        "click",
        function () {

            moveRow("up");
        }
    );

    // 아래로 이동
    // 下へ移動
    el("downBtn").addEventListener(
        "click",
        function () {

            moveRow("down");
        }
    );

    // 전체 선택
    // 全選択
    el("selectAll").addEventListener(
        "change",
        function () {

            var checked = this.checked;

            rows().forEach(function (tr) {

                selectRow(tr, checked);
            });
        }
    );

    // 찾기(F3)
    // 検索（F3）
    el("findBtn").addEventListener(
        "click",
        toggleFind
    );

    el("findCloseBtn").addEventListener(
        "click",
        closeFind
    );

    el("quickFindInput").addEventListener(
        "input",
        performFind
    );

    el("quickFindInput").addEventListener(
        "keydown",
        function (event) {

            if (event.key === "Enter") {

                event.preventDefault();

                nextFind();
            }

            if (event.key === "Escape") {

                closeFind();
            }
        }
    );

    el("findNextBtn").addEventListener(
        "click",
        nextFind
    );

    // 재고불러오기 버튼
    // 在庫取込ボタン
    // 사용자가 누를 때만 재고 열 표시
    // 利用者が押したときだけ在庫列を表示
    el("inventoryBtn").addEventListener(
        "click",
        loadInventory
    );

    // 창고 변경 시 재고 초기화
    // 倉庫変更時に在庫値を初期化
    el("warehouse_code").addEventListener(
        "input",
        function () {

            el("warehouse_name").value = "";

            invalidateStock();
        }
    );

    // 거래처·담당자·창고 돋보기
    // 取引先・担当者・倉庫の検索ボタン
    document.querySelectorAll("[data-lookup]")
        .forEach(function (button) {

            button.addEventListener("click", function () {

                var type = button.dataset.lookup;

                openLookup(
                    type,
                    null,
                    el(type + "_code").value
                );
            });
        });

    // 코드 더블클릭
    // コードのダブルクリック
    ["partner", "manager", "warehouse"]
        .forEach(function (type) {

            el(type + "_code").addEventListener(
                "dblclick",
                function () {

                    openLookup(
                        type,
                        null,
                        this.value
                    );
                }
            );

            if (type !== "warehouse") {

                el(type + "_code").addEventListener(
                    "input",
                    function () {

                        el(type + "_name").value = "";
                    }
                );
            }
        });

    // 조회 팝업
    // 検索モーダル
    el("lookupSearchBtn").addEventListener(
        "click",
        searchLookup
    );

    el("lookupClose").addEventListener(
        "click",
        closeLookup
    );

    el("lookupKeyword").addEventListener(
        "keydown",
        function (event) {

            if (event.key === "Enter") {

                event.preventDefault();

                searchLookup();
            }
        }
    );

    overlay.addEventListener(
        "click",
        function (event) {

            if (event.target === overlay) {

                closeLookup();
            }
        }
    );

    // 파일 선택
    // ファイルの選択
    el("attachBtn").addEventListener(
        "click",
        function () {

            el("attachment_file").click();
        }
    );

    el("attachment_file").addEventListener(
        "change",
        function () {

            var file = this.files[0];

            el("attachmentName").textContent =
                file
                    ? file.name
                    : "ファイルが選択されていません";

            if (savedQuoteId !== null) {

                el("retryAttachmentBtn").hidden =
                    !file;
            }
        }
    );

    // 첨부 선택 취소
    // 添付選択の取消
    el("removeAttachBtn").addEventListener(
        "click",
        function () {

            el("attachment_file").value = "";

            el("attachmentName").textContent =
                "ファイルが選択されていません";

            el("retryAttachmentBtn").hidden = true;
        }
    );

    // 첨부 재시도
    // 添付の再試行
    el("retryAttachmentBtn").addEventListener(
        "click",
        async function () {

            try {

                await uploadAttachment();

                notice(
                    "添付ファイルの保存が完了しました！"
                );

            } catch (error) {

                notice(
                    error.message,
                    true
                );
            }
        }
    );

    // 저장
    // 保存
    el("saveBtn").addEventListener(
        "click",
        saveQuotation
    );

    // 다시 작성
    // 再入力
    el("resetBtn").addEventListener(
        "click",
        resetForm
    );

    // 리스트
    // 一覧
    el("listBtn").addEventListener(
        "click",
        function () {

            window.location.href =
                ctx + "/sales/estimate/inquiry";
        }
    );

    // 키보드 단축키
    // キーボードショートカット
    document.addEventListener(
        "keydown",
        function (event) {

            if (event.key === "Escape") {

                closeLookup();

                if (el("quickFindBox")
                        .classList.contains("open")) {

                    closeFind();
                }
            }

            if (overlay.style.display === "flex") {

                return;
            }

            if (event.key === "F3") {

                event.preventDefault();

                toggleFind();
            }

            if (event.key === "F8") {

                event.preventDefault();

                saveQuotation();
            }
        }
    );

    // 첫 화면 초기화
    // 初期画面の初期化

    el("quote_date").value = today();

    // 처음에 재고 열 숨김
    // 初期状態で在庫列を非表示
    el("quotationTable")
        .classList.remove("show-stock");

    // 기본 4개 행 생성
    // 基本の4行を作成
    for (var i = 0; i < 4; i++) {

        addRow();
    }

    // Oracle 통화 목록 불러오기
    // Oracleから通貨一覧を取得
    loadCurrencies();

})();
</script>

</body>
</html>
