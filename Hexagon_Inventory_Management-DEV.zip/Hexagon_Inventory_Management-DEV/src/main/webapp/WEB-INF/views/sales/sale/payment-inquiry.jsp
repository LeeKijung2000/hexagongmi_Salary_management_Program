<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ taglib prefix="my" tagdir="/WEB-INF/tags"%>
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<title>決済履歴照会<%--결제내역조회--%> - ヘキサゴン ERP<%--헥사곤 ERP--%></title>
<link href="https://cdn.jsdelivr.net/npm/@mdi/font@7.2.96/css/materialdesignicons.min.css" rel="stylesheet">
</head>
<body>
	<div class="erp-wrapper">
		<my:sideMenu />
		<div class="erp-main">
			<main class="erp-content">
				<div class="page-title">
					<i class="mdi mdi-credit-card-search"></i> 決済履歴照会<%--결제내역조회--%>
				</div>
				<%-- Option, 도움말, 회계반영, 강제회계반영, 입금보고서작성, Excel, 회계전표, 미반영, My품목은 이 화면에 두지 않는다. --%>
				<%-- Option、ヘルプ、会計反映、強制会計反映、入金報告書作成、Excel、会計伝票、未反映、My品目はこの画面に置かない。 --%>
				<div class="list-wrap">
					<div class="inq-bar">
						<div class="inq-tabs">
							<button type="button" class="active">全体<%--전체--%></button>
						</div>
						<div class="inq-search">
							<input type="text" id="keyword" maxlength="100" placeholder="入力後Enter<%--입력 후 Enter--%>"
								onkeydown="if(event.key==='Enter'){event.preventDefault();search();}">
							<button type="button" class="btn-flat-sm" onclick="openFn()">Fn</button>
							<button type="button" class="btn-primary-sm" onclick="search()">Search<%--검색--%></button>
						</div>
					</div>
					<div class="list-table-wrap">
						<table class="list-table pay-table">
							<thead>
								<tr>
									<th>決済日時<%--결제 요청일시--%></th>
									<th>依頼者<%--결제 요청자. 사업자를 그대로 보인다. 決済依頼者。事業者をそのまま見せる。--%></th>
									<th>取引先<%--거래처--%></th>
									<th class="col-num">決済金額<%--결제금액--%></th>
									<th>決済方法<%--결제방법--%></th>
									<th>決済状態<%--결제상태--%></th>
									<th>承認番号<%--승인번호--%></th>
									<th>内訳<%--내역--%></th>
								</tr>
							</thead>
							<tbody id="paymentBody"></tbody>
						</table>
					</div>
					<p id="inquiryMessage" class="inq-message"></p>
					<div class="sale-foot">
						<button type="button" class="btn-primary-sm" onclick="openNew()">新規<%--신규--%></button>
					</div>
				</div>
			</main>
		</div>
	</div>

	<my:lookupModal />

	<div class="modal-overlay" id="fnOverlay">
		<div class="lookup-card fn-card">
			<div class="lookup-head">
				<h3>Fn<%--기능키--%></h3>
				<button type="button" class="modal-close" onclick="closeFn()"><i class="mdi mdi-close"></i></button>
			</div>
			<ul class="fn-list">
				<li><b>Enter / F3</b> 検索<%--검색--%></li>
				<li><b>F2</b> 新規<%--신규. 이 화면에서 등록하고 판매입력으로 이동하지 않는다. 新規。この画面で登録し、販売入力へは移動しない。--%></li>
				<li><b>F4</b> 内訳<%--선택한 결제 상세--%></li>
			</ul>
			<div class="lookup-foot">
				<button type="button" class="btn-flat-sm" onclick="closeFn()">閉じる<%--닫기--%></button>
			</div>
		</div>
	</div>

	<div class="modal-overlay" id="detailOverlay">
		<div class="lookup-card detail-card">
			<div class="lookup-head">
				<h3>内訳<%--내역--%></h3>
				<button type="button" class="modal-close" onclick="closeDetail()"><i class="mdi mdi-close"></i></button>
			</div>
			<dl id="detailBody" class="detail-list"></dl>
			<div class="lookup-foot">
				<button type="button" class="btn-flat-sm" onclick="closeDetail()">閉じる<%--닫기--%></button>
			</div>
		</div>
	</div>

	<%-- 신규는 결제 창에서 TB_PAYMENT 한 건만 넣는다. 판매 전표 금액은 다시 계산하지 않는다. --%>
	<%-- 新規は決済窓で TB_PAYMENT を1件だけ入れる。販売伝票の金額は計算し直さない。 --%>
	<div class="modal-overlay" id="newOverlay">
		<div class="pay-window">
			<div class="pay-window-head">
				<h3>決済<%--결제--%></h3>
				<button type="button" class="pay-option">Option</button>
			</div>
			<div class="pay-panel">
				<div class="pay-row">
					<label>事業者<%--사업자--%></label>
					<select id="companyCode">
						<option value="ヘキサゴン">ヘキサゴン<%--헥사곤--%></option>
					</select>
				</div>
				<div class="pay-row">
					<label>VAN</label>
					<select id="vanCode">
						<option value="KICC">KICC</option>
						<option value="KIS">KIS</option>
						<option value="KOCES">KOCES</option>
					</select>
				</div>
				<div class="pay-row pay-method">
					<label>決済方法<%--결제방법--%></label>
					<div>
						<div class="pay-radios">
							<label><input type="radio" name="payMethod" value="CARD" checked onchange="syncMethod()"> 信用決済<%--신용결제--%></label>
							<label><input type="radio" name="payMethod" value="CASH" onchange="syncMethod()"> 現金決済<%--현금결제--%></label>
							<label><input type="radio" name="payMethod" value="EASY_PAY" onchange="syncMethod()"> 簡単決済<%--간편결제--%></label>
						</div>
						<div class="pay-radios" id="cardOptions">
							<label><input type="radio" name="installment" value="LUMP" checked onchange="syncInstallment()"> 一括<%--일시불--%></label>
							<label><input type="radio" name="installment" value="INSTALLMENT" onchange="syncInstallment()"> 分割<%--할부--%></label>
							<span class="pay-months" id="installmentMonthsWrap" hidden>
								<input type="text" id="installmentMonths" inputmode="numeric" maxlength="2" autocomplete="off">
								<span>ヶ月<%--개월--%></span>
							</span>
						</div>
					</div>
				</div>
				<div class="pay-row" id="cashOptions" hidden>
					<label>領収書区分<%--영수증구분--%></label>
					<select id="receiptType">
						<option value="INCOME">消費者所得控除<%--소비자 소득공제--%></option>
						<option value="EXPENSE">事業者支出証憑<%--사업자 지출증빙--%></option>
						<option value="VOLUNTARY">自主発行<%--자진발급--%></option>
						<option value="SIMPLE">簡易領収書<%--간이영수증--%></option>
					</select>
				</div>
				<div class="pay-row" id="easyOptions" hidden>
					<label>簡単決済識別番号<%--간편결제 식별번호--%></label>
					<input type="text" class="pay-text" id="easyPaymentNo" maxlength="100" autocomplete="off">
				</div>
				<div class="pay-row">
					<label>領収書出力<%--영수증 출력여부--%></label>
					<div class="pay-radios">
						<label><input type="radio" name="receiptPrintYn" value="Y" checked> 出力<%--출력--%></label>
						<label><input type="radio" name="receiptPrintYn" value="N"> 未出力<%--미출력--%></label>
					</div>
				</div>
				<div class="pay-row">
					<label>取引先<%--거래처--%></label>
					<div class="pay-split">
						<input type="text" id="partnerName" readonly placeholder="取引先<%--거래처--%>">
						<button type="button" class="pay-search" onclick="pickPartner()"><i class="mdi mdi-magnify"></i></button>
						<input type="text" id="partnerCode" readonly>
					</div>
				</div>
				<div class="pay-row">
					<label>付加税率<%--부가세율--%></label>
					<div class="pay-suffix">
						<input type="text" id="vatRate" inputmode="decimal" value="10" autocomplete="off" oninput="calcFromPayment()">
						<span>%</span>
					</div>
				</div>
				<div class="pay-row">
					<label>決済金額<%--결제금액--%></label>
					<input type="text" id="paymentAmount" class="pay-money" inputmode="decimal" value="0" autocomplete="off" oninput="calcFromPayment()">
				</div>
				<div class="pay-row">
					<label>供給価額<%--공급가액--%></label>
					<input type="text" id="supplyAmount" class="pay-money" inputmode="decimal" value="0" autocomplete="off">
				</div>
				<div class="pay-row">
					<label>付加税<%--부가세--%></label>
					<input type="text" id="vatAmount" class="pay-money" inputmode="decimal" value="0" autocomplete="off">
				</div>
			</div>
			<p id="newMessage" class="inq-message"></p>
			<div class="pay-actions">
				<button type="button" class="pay-apply" id="saveButton" onclick="saveNew()">適用<%--적용--%></button>
				<button type="button" class="pay-dismiss" onclick="closeNew()">閉じる<%--닫기--%></button>
			</div>
		</div>
	</div>

	<script>
		<%-- 목록은 /payment-inquiry/list, 상세는 /detail, 신규는 POST /payment-inquiry, 재결제는 /repay 이다. --%>
		<%-- 一覧は /payment-inquiry/list、詳細は /detail、新規は POST /payment-inquiry、再決済は /repay である。 --%>
		<%-- 화면을 열면 전체를 조회한다. 검색은 Enter와 Search, F3이다. 판매나 다른 전표에는 연결하지 않는다. --%>
		<%-- 画面を開くと全体を照会する。検索は Enter と Search、F3 である。販売や他の伝票には繋がない。 --%>
		var ctx = '${pageContext.request.contextPath}';
		var selectedId = null;
		var rows = [];
		var partnerId = null;
		var requesterId = null;
		var saving = false;
		var METHOD = {
			CASH : '現金<%--현금--%>',
			CARD : 'カード<%--카드--%>',
			TRANSFER : '振込<%--이체--%>',
			EASY_PAY : '簡単決済<%--간편결제--%>',
			OTHER : 'その他<%--기타--%>'
		};
		var STATUS = {
			REQUESTED : '依頼中<%--요청중--%>',
			APPROVED : '承認<%--승인--%>',
			FAILED : '承認失敗<%--승인실패--%>',
			CANCELLED : '取消<%--취소--%>',
			FORCED : '強制<%--강제--%>'
		};
		var RECEIPT = {
			INCOME : '消費者所得控除<%--소비자 소득공제--%>',
			EXPENSE : '事業者支出証憑<%--사업자 지출증빙--%>',
			VOLUNTARY : '自主発行<%--자진발급--%>',
			SIMPLE : '簡易領収書<%--간이영수증--%>'
		};

		function search() {
			loadList();
		}

		function readJson(res, fallback) {
			return res.text().then(function(text) {
				var body = null;
				if (text) {
					try { body = JSON.parse(text); } catch (ignore) { body = null; }
				}
				if (!res.ok) throw new Error(body && body.message ? body.message : fallback);
				return body;
			});
		}

		function loadList() {
			var keyword = document.getElementById('keyword').value || '';
			note('', false);
			fetch(ctx + '/sales/sale/payment-inquiry/list?keyword=' + encodeURIComponent(keyword), {
				headers : { 'Accept' : 'application/json' }
			}).then(function(res) {
				return readJson(res, '照会に失敗しました。<%--조회에 실패했습니다.--%>');
			}).then(function(body) {
				rows = body.rows || [];
				selectedId = null;
				draw(body);
			}).catch(function(error) {
				document.getElementById('paymentBody').innerHTML = '';
				note(error.message, true);
			});
		}

		function draw(body) {
			var tbody = document.getElementById('paymentBody');
			if (!rows.length) {
				tbody.innerHTML = '<tr><td class="empty-cell" colspan="8">照会されたデータがありません。<%--조회된 데이터가 없습니다.--%></td></tr>';
			} else {
				tbody.innerHTML = rows.map(function(row) {
					var selected = row.paymentId === selectedId ? ' class="selected"' : '';
					return '<tr data-id="' + row.paymentId + '"' + selected + ' onclick="selectRow(' + row.paymentId + ')">'
						+ '<td>' + esc(row.requestedAt) + '</td>'
						+ '<td>' + esc(row.companyCode) + '</td>'
						+ '<td>' + esc(row.partnerName) + '</td>'
						+ '<td class="col-num">' + money(row.paymentAmount) + '</td>'
						+ '<td>' + label(METHOD, row.paymentMethod) + '</td>'
						+ '<td>' + label(STATUS, row.paymentStatus) + '</td>'
						+ '<td>' + esc(row.approvalNumber) + '</td>'
						+ '<td><button type="button" class="btn-flat-sm" onclick="openDetail(' + row.paymentId + ', event)">内訳<%--내역--%></button></td>'
						+ '</tr>';
				}).join('');
			}
			var count = body.totalCount || 0;
			var text = count + '件<%--건--%>';
			if (body.truncated) {
				text += ' / 1,000件を超えるため、新しい1,000件だけ表示しています。<%--1,000건을 넘어 최근 1,000건만 표시합니다.--%>';
			}
			note(text, false);
		}

		function selectRow(id) {
			selectedId = id;
			var trs = document.querySelectorAll('#paymentBody tr');
			for (var i = 0; i < trs.length; i++) {
				trs[i].classList.toggle('selected', String(trs[i].getAttribute('data-id')) === String(id));
			}
		}

		function openDetail(id, event) {
			if (event) event.stopPropagation();
			selectedId = id;
			fetch(ctx + '/sales/sale/payment-inquiry/detail?paymentId=' + encodeURIComponent(id), {
				headers : { 'Accept' : 'application/json' }
			}).then(function(res) {
				return readJson(res, '内訳の取得に失敗しました。<%--내역 조회에 실패했습니다.--%>');
			}).then(function(detail) {
				drawDetail(detail);
				document.getElementById('detailOverlay').classList.add('active');
			}).catch(function(error) {
				note(error.message, true);
			});
		}

		function drawDetail(detail) {
			var pairs = [
				['決済ID<%--결제ID--%>', detail.paymentId],
				['決済日時<%--결제일시--%>', detail.requestedAt],
				['依頼者<%--요청자. 사업자--%>', detail.companyCode],
				['取引先<%--거래처--%>', detail.partnerName],
				['決済方法<%--결제방법--%>', label(METHOD, detail.paymentMethod)],
				['分割月数<%--할부개월--%>', detail.installmentMonths],
				['領収書区分<%--영수증구분--%>', label(RECEIPT, detail.receiptType)],
				['簡単決済識別番号<%--간편결제 식별번호--%>', detail.easyPaymentNo],
				['決済状態<%--결제상태--%>', label(STATUS, detail.paymentStatus)],
				['供給価額<%--공급가액--%>', money(detail.supplyAmount)],
				['付加税率<%--부가세율--%>', detail.vatRate == null ? '' : detail.vatRate],
				['付加税<%--부가세--%>', money(detail.vatAmount)],
				['決済金額<%--결제금액--%>', money(detail.paymentAmount)],
				['承認番号<%--승인번호--%>', detail.approvalNumber],
				['失敗事由<%--실패사유--%>', detail.failureReason],
				['会社コード<%--회사코드--%>', detail.companyCode],
				['VANコード<%--VAN코드--%>', detail.vanCode],
				['領収書出力<%--영수증출력--%>', detail.receiptPrintYn === 'Y' ? '出力<%--출력--%>' : (detail.receiptPrintYn === 'N' ? '未出力<%--미출력--%>' : '')],
				['強制<%--강제여부--%>', detail.forcedYn],
				['取消日時<%--취소일시--%>', detail.cancelledAt]
			];
			document.getElementById('detailBody').innerHTML = pairs.map(function(pair) {
				return '<dt>' + pair[0] + '</dt><dd>' + esc(pair[1]) + '</dd>';
			}).join('');
		}

		function closeDetail() {
			document.getElementById('detailOverlay').classList.remove('active');
		}

		function openFn() {
			document.getElementById('fnOverlay').classList.add('active');
		}

		function closeFn() {
			document.getElementById('fnOverlay').classList.remove('active');
		}

		function openNew() {
			partnerId = null;
			requesterId = null;
			document.getElementById('companyCode').selectedIndex = 0;
			document.getElementById('vanCode').selectedIndex = 0;
			document.querySelector('input[name="payMethod"][value="CARD"]').checked = true;
			document.querySelector('input[name="installment"][value="LUMP"]').checked = true;
			document.getElementById('installmentMonths').value = '';
			document.getElementById('receiptType').selectedIndex = 0;
			document.getElementById('easyPaymentNo').value = '';
			document.querySelector('input[name="receiptPrintYn"][value="Y"]').checked = true;
			document.getElementById('partnerName').value = '';
			document.getElementById('partnerCode').value = '';
			document.getElementById('vatRate').value = '10';
			document.getElementById('paymentAmount').value = '0';
			document.getElementById('supplyAmount').value = '0';
			document.getElementById('vatAmount').value = '0';
			syncMethod();
			document.getElementById('newMessage').textContent = '';
			document.getElementById('saveButton').disabled = false;
			saving = false;
			document.getElementById('newOverlay').classList.add('active');
		}

		function syncMethod() {
			var method = document.querySelector('input[name="payMethod"]:checked');
			var value = method ? method.value : 'CARD';
			document.getElementById('cardOptions').hidden = value !== 'CARD';
			document.getElementById('cashOptions').hidden = value !== 'CASH';
			document.getElementById('easyOptions').hidden = value !== 'EASY_PAY';
			syncInstallment();
		}

		function syncInstallment() {
			var installment = document.querySelector('input[name="installment"]:checked');
			document.getElementById('installmentMonthsWrap').hidden = !installment || installment.value !== 'INSTALLMENT';
		}

		function closeNew() {
			document.getElementById('newOverlay').classList.remove('active');
		}

		function pickPartner() {
			CommonLookup.open('partner', function(row) {
				partnerId = row.businessPartnerId;
				document.getElementById('partnerName').value = row.businessPartnerName || '';
				document.getElementById('partnerCode').value = row.businessPartnerCode || '';
			});
		}

		function saveNew() {
			if (saving) return;
			var method = document.querySelector('input[name="payMethod"]:checked');
			var receipt = document.querySelector('input[name="receiptPrintYn"]:checked');
			var installment = document.querySelector('input[name="installment"]:checked');
			var methodValue = method ? method.value : '';
			var installmentMonths = null;
			var receiptType = null;
			var easyPaymentNo = null;
			if (methodValue === 'CARD' && installment && installment.value === 'INSTALLMENT') {
				installmentMonths = installmentMonthsOrFalse();
				if (installmentMonths === false) {
					document.getElementById('newMessage').textContent = '分割月数が正しくありません。<%--할부 개월이 올바르지 않습니다.--%>';
					return;
				}
			}
			if (methodValue === 'CASH') {
				receiptType = document.getElementById('receiptType').value;
			}
			if (methodValue === 'EASY_PAY') {
				easyPaymentNo = document.getElementById('easyPaymentNo').value.trim();
			}
			calcFromPayment();
			var body = {
				requestedAtText : nowText(),
				requesterId : requesterId,
				businessPartnerId : partnerId,
				companyCode : document.getElementById('companyCode').value,
				vanCode : document.getElementById('vanCode').value,
				paymentMethod : methodValue,
				receiptPrintYn : receipt ? receipt.value : 'Y',
				installmentMonths : installmentMonths,
				receiptType : receiptType,
				easyPaymentNo : easyPaymentNo ? easyPaymentNo : null,
				supplyAmount : numberOrNull('supplyAmount'),
				vatRate : numberOrNull('vatRate'),
				vatAmount : numberOrNull('vatAmount'),
				paymentAmount : numberOrNull('paymentAmount'),
				paymentStatus : 'REQUESTED',
				approvalNumber : null
			};
			if (body.supplyAmount === false || body.vatRate === false || body.vatAmount === false || body.paymentAmount === false) {
				document.getElementById('newMessage').textContent = '金額が正しくありません。<%--금액이 올바르지 않습니다.--%>';
				return;
			}
			if (body.supplyAmount == null) body.supplyAmount = 0;
			if (body.vatAmount == null) body.vatAmount = 0;
			if (body.paymentAmount == null) body.paymentAmount = 0;
			if (body.vatRate == null) body.vatRate = 10;
			saving = true;
			document.getElementById('saveButton').disabled = true;
			fetch(ctx + '/sales/sale/payment-inquiry', {
				method : 'POST',
				headers : { 'Content-Type' : 'application/json', 'Accept' : 'application/json' },
				body : JSON.stringify(body)
			}).then(function(res) {
				return readJson(res, '登録に失敗しました。<%--등록에 실패했습니다.--%>');
			}).then(function() {
				document.getElementById('keyword').value = '';
				closeNew();
				loadList();
			}).catch(function(error) {
				saving = false;
				document.getElementById('saveButton').disabled = false;
				document.getElementById('newMessage').textContent = error.message;
			});
		}

		<%-- 결제금액은 부가세가 포함된 금액이다. 공급가액과 부가세는 부가세율로 나누고, 둘을 더하면 결제금액이 된다. --%>
		<%-- 決済金額は付加税込みである。供給価額と付加税は付加税率で分け、二つを足すと決済金額になる。 --%>
		function calcFromPayment() {
			var payment = numberOrNull('paymentAmount');
			var rate = numberOrNull('vatRate');
			if (payment === false || rate === false) return;
			if (payment == null) payment = 0;
			if (rate == null) rate = 10;
			if (payment < 0 || rate < 0 || rate > 100) return;
			var vat = rate === 0 ? 0 : Math.round(payment * rate / (100 + rate) * 100) / 100;
			var supply = Math.round((payment - vat) * 100) / 100;
			document.getElementById('supplyAmount').value = formatMoney(supply);
			document.getElementById('vatAmount').value = formatMoney(vat);
		}

		function formatMoney(value) {
			var rounded = Math.round(value * 100) / 100;
			if (rounded === Math.trunc(rounded)) return String(rounded);
			return rounded.toFixed(2);
		}

		function installmentMonthsOrFalse() {
			var text = document.getElementById('installmentMonths').value.trim();
			if (!/^[1-9]\d?$/.test(text)) return false;
			return parseInt(text, 10);
		}

		function numberOrNull(id) {
			var text = document.getElementById(id).value.trim();
			if (text === '') return null;
			var number = Number(text);
			return isNaN(number) ? false : number;
		}

		function label(map, code) {
			if (!code) return '';
			return esc(map[code] || code);
		}

		function money(value) {
			if (value === null || value === undefined || value === '') return '';
			var number = Number(value);
			if (isNaN(number)) return '';
			return number.toLocaleString('ja-JP', { minimumFractionDigits : 0, maximumFractionDigits : 2 });
		}

		function esc(value) {
			return String(value == null ? '' : value).replace(/[&<>"']/g, function(ch) {
				return { '&' : '&amp;', '<' : '&lt;', '>' : '&gt;', '"' : '&quot;', "'" : '&#39;' }[ch];
			});
		}

		function note(text, error) {
			var el = document.getElementById('inquiryMessage');
			el.textContent = text || '';
			el.className = error ? 'inq-message error' : 'inq-message';
		}

		function nowText() {
			var date = new Date();
			var pad = function(number) { return (number < 10 ? '0' : '') + number; };
			return date.getFullYear() + '-' + pad(date.getMonth() + 1) + '-' + pad(date.getDate())
				+ 'T' + pad(date.getHours()) + ':' + pad(date.getMinutes());
		}

		function modalOpen() {
			var nodes = document.querySelectorAll('.modal-overlay.active');
			return nodes.length > 0;
		}

		document.addEventListener('keydown', function(event) {
			if (event.key === 'Escape') {
				if (document.getElementById('detailOverlay').classList.contains('active')) closeDetail();
				else if (document.getElementById('newOverlay').classList.contains('active')) closeNew();
				else if (document.getElementById('fnOverlay').classList.contains('active')) closeFn();
				return;
			}
			if (modalOpen()) return;
			if (event.key === 'F2') { event.preventDefault(); openNew(); }
			if (event.key === 'F3') { event.preventDefault(); search(); }
			if (event.key === 'F4' && selectedId) { event.preventDefault(); openDetail(selectedId); }
		});

		loadList();
	</script>
	<style>
		.page-title { font-size: 1.25rem; font-weight: 700; color: #0B1026; margin-bottom: 20px; display: flex; align-items: center; gap: 10px; }
		.page-title i { color: #4B88FF; font-size: 24px; }
		.list-wrap { background: #fff; border-radius: 14px; border: 1px solid #e2e8f0; box-shadow: 0 10px 25px -5px rgba(75, 136, 255, .08); overflow: hidden; }
		.inq-bar { display: flex; flex-wrap: wrap; gap: 12px 18px; align-items: center; padding: 18px 22px 8px; }
		.inq-tabs { display: inline-flex; }
		.inq-tabs button { border: 1px solid #4B88FF; background: #4B88FF; color: #fff; font-weight: 700; padding: 8px 16px; border-radius: 8px; }
		.inq-search, .history-tools { display: flex; align-items: center; gap: 8px; }
		.inq-search input, .history-tools input, .form-grid input, .form-grid select {
			border: 1px solid #e2e8f0; border-radius: 8px; padding: 8px 12px; font-size: 13px; outline: none; background: #fff;
		}
		.inq-search input { width: 240px; }
		.inq-search input:focus, .history-tools input:focus, .form-grid input:focus, .form-grid select:focus { border-color: #4B88FF; }
		.btn-primary-sm, .btn-flat-sm {
			display: inline-flex; align-items: center; justify-content: center; gap: 4px; cursor: pointer;
			border-radius: 8px; font-weight: 700; font-size: 13px; padding: 8px 14px;
		}
		.btn-primary-sm { background: #4B88FF; color: #fff; border: none; }
		.btn-primary-sm:hover { background: #1F3C88; }
		.btn-flat-sm { background: #f8fafc; border: 1px solid #e2e8f0; color: #64748b; }
		.btn-flat-sm:hover { background: #eef2f7; }
		.btn-flat-sm:disabled, .btn-primary-sm:disabled { opacity: .45; cursor: not-allowed; }
		.list-table-wrap { width: 100%; overflow-x: auto; }
		.list-table { width: 100%; border-collapse: collapse; }
		.pay-table { min-width: 980px; }
		.list-table th, .list-table td { border-bottom: 1px solid #e2e8f0; padding: 9px 10px; font-size: 13px; text-align: left; vertical-align: middle; }
		.list-table th { background: #f8fafc; color: #64748b; font-weight: 700; }
		.list-table tbody tr { cursor: pointer; }
		.list-table tbody tr.selected { background: #f7faff; }
		.col-num { text-align: right; }
		.sub { color: #64748b; font-size: 12px; }
		.empty-cell { text-align: center; color: #64748b; padding: 28px; }
		.inq-message { min-height: 20px; margin: 8px 22px 0; color: #64748b; font-size: 13px; }
		.inq-message.error, #newMessage, #saleMessage { color: #b91c1c; }
		#newMessage, #saleMessage { margin: 0 18px; }
		.sale-foot, .lookup-foot { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; padding: 8px 22px 22px; }
		.modal-overlay { display: none; position: fixed; inset: 0; background: rgba(11, 16, 38, .45); align-items: flex-start; justify-content: center; padding: 4vh 16px; overflow: auto; }
		.modal-overlay.active { display: flex; }
		#fnOverlay, #detailOverlay, #newOverlay { z-index: 1100; }
		.lookup-card { background: #fff; border-radius: 14px; border: 1px solid #e2e8f0; box-shadow: 0 20px 45px -10px rgba(11, 16, 38, .25); overflow: hidden; }
		.pay-card { width: min(980px, 96vw); }
		.pay-window { width: min(640px, 96vw); background: #f4f6f9; border-radius: 16px; padding: 18px 18px 16px; box-shadow: 0 20px 45px -10px rgba(11, 16, 38, .28); }
		.pay-window-head { display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; }
		.pay-window-head h3 { margin: 0; font-size: 18px; font-weight: 800; color: #1c2430; }
		.pay-option { border: 1px solid #e1e6ee; background: #fff; color: #334155; border-radius: 999px; padding: 6px 14px; font-size: 13px; font-weight: 600; cursor: default; }
		.pay-panel { background: #fff; border: 1px solid #e6ebf2; border-radius: 16px; padding: 6px 18px 10px; }
		.pay-row { display: grid; grid-template-columns: 168px 1fr; gap: 12px; align-items: center; min-height: 46px; }
		.pay-row[hidden], #cardOptions[hidden], .pay-months[hidden] { display: none; }
		.pay-row > label { color: #b0b8c4; font-size: 13px; font-weight: 600; }
		.pay-panel select, .pay-panel .pay-money, .pay-panel .pay-text, .pay-suffix input, .pay-months input {
			width: 100%; height: 36px; border: 1px solid #e3e8f0; border-radius: 999px; padding: 0 16px; background: #fff; color: #243044; font-size: 14px; outline: none;
		}
		.pay-panel select { appearance: none; background-image: linear-gradient(45deg, transparent 50%, #8b95a5 50%), linear-gradient(135deg, #8b95a5 50%, transparent 50%); background-position: calc(100% - 18px) 15px, calc(100% - 12px) 15px; background-size: 6px 6px, 6px 6px; background-repeat: no-repeat; padding-right: 32px; }
		.pay-money { text-align: right; }
		.pay-suffix { display: flex; align-items: center; gap: 8px; }
		.pay-suffix input { text-align: right; }
		.pay-suffix span { color: #64748b; font-weight: 700; }
		.pay-radios { display: flex; flex-wrap: wrap; gap: 8px 18px; min-height: 28px; align-items: center; }
		.pay-radios label { display: inline-flex; align-items: center; gap: 6px; color: #243044; font-size: 14px; font-weight: 600; cursor: pointer; }
		.pay-radios input { accent-color: #2f6bff; width: 16px; height: 16px; }
		.pay-months { display: inline-flex; align-items: center; gap: 6px; }
		.pay-months input { width: 64px; height: 32px; text-align: right; padding: 0 10px; }
		.pay-months span { color: #64748b; font-size: 13px; font-weight: 700; }
		.pay-split { display: flex; align-items: center; height: 36px; border: 1px solid #e3e8f0; border-radius: 999px; background: #fff; overflow: hidden; }
		.pay-split input { flex: 1; min-width: 0; height: 34px; border: none; padding: 0 14px; background: transparent; outline: none; font-size: 14px; }
		.pay-search { width: 36px; height: 34px; border: none; border-left: 1px solid #e6ebf2; border-right: 1px solid #e6ebf2; background: #fff; color: #64748b; cursor: pointer; }
		.pay-actions { display: flex; gap: 8px; padding: 14px 2px 0; }
		.pay-apply, .pay-dismiss { border-radius: 999px; padding: 8px 18px; font-size: 14px; font-weight: 700; cursor: pointer; }
		.pay-apply { background: #2f6bff; color: #fff; border: none; }
		.pay-apply:disabled { opacity: .45; cursor: not-allowed; }
		.pay-dismiss { background: #fff; color: #334155; border: 1px solid #e1e6ee; }
		#newOverlay { align-items: center; }
		.fn-card { width: min(460px, 96vw); }
		.detail-card { width: min(720px, 96vw); }
		.lookup-head { display: flex; align-items: center; gap: 12px; padding: 14px 16px; border-bottom: 1px solid #e2e8f0; }
		.lookup-head h3 { font-size: 1.05rem; font-weight: 800; color: #0B1026; margin-right: auto; }
		.modal-close, .icon-btn { border: none; background: #f1f5f9; color: #64748b; width: 32px; height: 32px; border-radius: 50%; cursor: pointer; }
		.field-line { display: flex; align-items: center; gap: 6px; }
		.field-line input { flex: 1; }
		.form-grid { display: grid; grid-template-columns: 140px 1fr 140px 1fr; gap: 10px 12px; padding: 16px 18px 8px; align-items: center; }
		.form-grid label { font-weight: 700; color: #334155; }
		.fn-list { list-style: none; padding: 16px 20px; display: flex; flex-direction: column; gap: 10px; color: #334155; }
		.detail-list { display: grid; grid-template-columns: 160px 1fr; gap: 8px 12px; padding: 16px 20px; }
		.detail-list dt { color: #64748b; font-weight: 700; }
		.detail-list dd { margin: 0; color: #0B1026; word-break: break-all; }
		.lookup-table-wrap { max-height: 420px; overflow: auto; }
		#saleBody tr:hover { background: #f7faff; }
		@media (max-width: 860px) {
			.form-grid { grid-template-columns: 120px 1fr; }
		}
	</style>
</body>
</html>
