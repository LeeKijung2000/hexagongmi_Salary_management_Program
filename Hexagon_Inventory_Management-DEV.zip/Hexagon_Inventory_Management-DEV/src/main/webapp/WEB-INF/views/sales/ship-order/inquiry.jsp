<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ taglib prefix="my" tagdir="/WEB-INF/tags"%>
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>出荷指示書照会</title>
<link href="https://cdn.jsdelivr.net/npm/@mdi/font@7.2.96/css/materialdesignicons.min.css" rel="stylesheet">
<link href="${pageContext.request.contextPath}/resources/css/ship.css?v=20261012b" rel="stylesheet">
<style>
/* 한국어: 목록 상태 배지 스타일 / 日本語：一覧のステータスバッジ */
.ship-table td.status-cell{min-width:108px!important;text-align:center!important}
.ship-table .status-badge{display:inline-flex!important;align-items:center!important;justify-content:center!important;gap:5px!important;min-width:76px!important;padding:6px 11px!important;border:1px solid!important;border-radius:999px!important;font-size:12px!important;font-weight:800!important;line-height:1.25!important;white-space:nowrap!important;box-sizing:border-box!important}
.ship-table .status-badge .mdi{font-size:14px!important}
.ship-table .status-badge.status-open{color:#1d4ed8!important;background:#eff6ff!important;border-color:#93c5fd!important}
.ship-table .status-badge.status-partial{color:#9a3412!important;background:#fff7ed!important;border-color:#fdba74!important}
.ship-table .status-badge.status-completed,.ship-table .status-badge.status-active{color:#166534!important;background:#f0fdf4!important;border-color:#86efac!important}
.ship-table .status-badge.status-cancelled{color:#475569!important;background:#f1f5f9!important;border-color:#cbd5e1!important}
.ship-table .status-badge.status-unknown{color:#334155!important;background:#f8fafc!important;border-color:#cbd5e1!important}
/* 한국어: 상세 모달 버튼 정렬 / 日本語：詳細モーダルのボタン配置 */
.modal-head{display:flex;align-items:center;gap:10px}.modal-head .spacer{flex:1}.modal-head .modal-close{flex:0 0 auto;margin-left:8px}
.modal-actions{display:flex;justify-content:flex-end;gap:8px;padding:14px 18px;border-top:1px solid #e2e8f0;background:#f8fafc}.modal-actions .btn{min-width:96px}
</style>
</head>
<!-- 한국어: embed 모드일 때 목록용 클래스 적용 / 日本語：embedモードの場合、一覧用クラスを適用 -->
<body class="${param.embed == '1' ? 'list-embed' : ''}"><div class="erp-wrapper">
<my:sideMenu embed="${param.embed}"/><div class="erp-main"><main class="erp-content"><div class="ship-page"><div class="ship-wrap">
<div class="ship-title">出荷指示書照会</div>
<!-- 한국어: 상태 필터와 키워드 검색 / 日本語：ステータスフィルターとキーワード検索 -->
<div class="filter-bar">
<button class="pill ${empty param.status ? 'active':''}" onclick="filterStatus('')">すべて</button>
<button class="pill ${param.status=='OPEN'?'active':''}" onclick="filterStatus('OPEN')">受付</button>
<button class="pill ${param.status=='COMPLETED'?'active':''}" onclick="filterStatus('COMPLETED')">完了</button>
<div class="search-inline"><input id="keyword" class="ship-input" value="${pageMaker.cri.keyword}" placeholder="入力後Enter" onkeydown="if(event.key==='Enter')search()"><button class="btn primary" onclick="search()">Search(F3)</button><button class="btn">Option</button><button class="btn">ヘルプ</button></div></div>
<!-- 한국어: 출하 지시서 목록 / 日本語：出荷指示書一覧 -->
<div class="table-wrap"><table class="ship-table"><thead><tr><th>No.(PK)</th><th>日付</th><th>倉庫名</th><th>品目名（概要）</th><th>数量合計</th><th>取引先名</th><th>進行状況</th><th>詳細</th></tr></thead><tbody>
<c:forEach var="row" items="${list}" varStatus="s"><tr>
<td><a class="edit-link" href="javascript:void(0)" onclick="showDetail(${row.shippingOrderId})" title="出荷指示書詳細照会">${row.shippingOrderId}</a></td>
<td><a class="edit-link" href="javascript:void(0)" onclick="showDetail(${row.shippingOrderId})" title="出荷指示書詳細照会"><c:out value="${row.shippingOrderDate}"/></a></td>
<td><a class="edit-link" href="javascript:void(0)" onclick="showDetail(${row.shippingOrderId})" title="出荷指示書詳細照会">${row.warehouseName}</a></td>
<td class="left">${row.itemSummary}</td><td style="text-align:right">${row.quantityTotal}</td><td>${row.partnerName}</td>
<!-- 한국어: 진행 상태에 따라 배지 표시 / 日本語：進行状況に応じてバッジを表示 -->
<td class="status-cell"><c:choose>
    <%-- 한국어: 접수 상태 / 日本語：受付状態 --%>
    <c:when test="${row.progressStatus == 'OPEN'}"><span class="status-badge status-open"><i class="mdi mdi-clock-outline"></i> 受付</span></c:when>
    <%-- 한국어: 진행 중 상태 / 日本語：進行中状態 --%>
    <c:when test="${row.progressStatus == 'PARTIAL'}"><span class="status-badge status-partial"><i class="mdi mdi-progress-clock"></i> 進行中</span></c:when>
    <%-- 한국어: 완료 상태 / 日本語：完了状態 --%>
    <c:when test="${row.progressStatus == 'COMPLETED'}"><span class="status-badge status-completed"><i class="mdi mdi-check-circle-outline"></i> 完了</span></c:when>
    <%-- 한국어: 취소 상태 / 日本語：取消状態 --%>
    <c:when test="${row.progressStatus == 'CANCELLED'}"><span class="status-badge status-cancelled"><i class="mdi mdi-close-circle-outline"></i> 取消</span></c:when>
    <%-- 한국어: 기타 상태 / 日本語：その他の状態 --%>
    <c:otherwise><span class="status-badge status-unknown"><c:out value="${row.progressStatus}"/></span></c:otherwise>
</c:choose></td>
<td><button class="btn small" onclick="showDetail(${row.shippingOrderId})">詳細</button></td></tr></c:forEach>
<c:if test="${empty list}"><tr><td colspan="8" class="empty">出荷指示書が見つかりません。</td></tr></c:if>
</tbody></table></div>
<!-- 한국어: 페이지 이동 / 日本語：ページ移動 -->
<div class="pager"><c:if test="${pageMaker.prev}"><a href="${pageContext.request.contextPath}/sales/ship-order/inquiry?pageNum=${pageMaker.startPage-1}&status=${pageMaker.cri.status}&keyword=${pageMaker.cri.keyword}${param.embed == '1' ? '&embed=1' : ''}">‹</a></c:if>
<c:forEach var="num" begin="${pageMaker.startPage}" end="${pageMaker.endPage}"><a class="${pageMaker.cri.pageNum==num?'on':''}" href="${pageContext.request.contextPath}/sales/ship-order/inquiry?pageNum=${num}&status=${pageMaker.cri.status}&keyword=${pageMaker.cri.keyword}${param.embed == '1' ? '&embed=1' : ''}">${num}</a></c:forEach>
<c:if test="${pageMaker.next}"><a href="${pageContext.request.contextPath}/sales/ship-order/inquiry?pageNum=${pageMaker.endPage+1}&status=${pageMaker.cri.status}&keyword=${pageMaker.cri.keyword}${param.embed == '1' ? '&embed=1' : ''}">›</a></c:if></div>
<!-- 한국어: 신규 등록과 새로고침 / 日本語：新規登録と更新 -->
<div class="footer-actions"><span class="spacer"></span><button class="btn primary" type="button" onclick="newShippingOrder()"><i class="mdi mdi-plus"></i> 新規(F2)</button><button class="btn" onclick="location.reload()"><i class="mdi mdi-refresh"></i> 更新</button></div>
</div></div></main></div></div>
<!-- 한국어: 출하 지시서 상세 모달 / 日本語：出荷指示書詳細モーダル -->
<div class="modal" id="detailModal"><div class="modal-box"><div class="modal-head">出荷指示書詳細 <span class="spacer"></span><button class="modal-close" onclick="closeDetail()">×</button></div><div class="modal-body" id="detailBody"></div><div class="modal-actions"><button class="btn primary" type="button" onclick="editCurrentDetail()"><i class="mdi mdi-pencil-outline"></i> 編集</button></div></div></div>
<script>
// 한국어: 컨텍스트 경로와 현재 선택한 출하 지시서 ID / 日本語：コンテキストパスと選択中の出荷指示書ID
const CTX='${pageContext.request.contextPath}';let currentShippingOrderId=null;
// 한국어: 신규 출하 지시서 등록 화면 / 日本語：新規出荷指示書の登録画面
function newShippingOrder(){location.href=CTX+'/sales/ship-order/input'}
// 한국어: 선택한 출하 지시서 편집 / 日本語：選択した出荷指示書を編集
function editCurrentDetail(){if(currentShippingOrderId)location.href=CTX+'/sales/ship-order/input?id='+encodeURIComponent(currentShippingOrderId)}
// 한국어: 상태 필터 적용 / 日本語：ステータスフィルターを適用
function filterStatus(s){const u=new URL(location.href);u.searchParams.set('pageNum','1');if(s)u.searchParams.set('status',s);else u.searchParams.delete('status');location.href=u.toString()}
// 한국어: 키워드 검색 / 日本語：キーワード検索
function search(){const u=new URL(location.href);u.searchParams.set('pageNum','1');const k=document.getElementById('keyword').value.trim();if(k)u.searchParams.set('keyword',k);else u.searchParams.delete('keyword');location.href=u.toString()}
// 한국어: 상세 모달 닫기 / 日本語：詳細モーダルを閉じる
function closeDetail(){document.getElementById('detailModal').classList.remove('open')}
// 한국어: HTML 특수문자 이스케이프 / 日本語：HTML特殊文字をエスケープ
function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
// 한국어: 출하 지시서 상세 조회 및 모달 표시 / 日本語：出荷指示書の詳細を取得してモーダル表示
async function showDetail(id){currentShippingOrderId=id;const r=await fetch(CTX+'/sales/ship-order/get/'+id);if(!r.ok){alert('詳細情報を取得できませんでした。');return}const x=await r.json();document.getElementById('detailBody').innerHTML='<div class="ship-grid">'+row('',x.voucherNo)+row('日付',x.shippingOrderDate)+row('取引先',x.partnerName)+row('倉庫',x.warehouseName)+row('担当者',x.managerName||'-')+row('出荷予定日',x.plannedShipDate||'-')+row('連絡先',x.contactNumber||'-')+row('郵便番号',x.postalCode||'-')+'<div class="ship-row full"><div class="ship-label">住所</div><div>'+esc(x.address||'-')+'</div></div></div><div class="table-wrap" style="margin-top:12px"><table class="modal-table"><tr><th>品目コード</th><th>品目名</th><th>規格</th><th>単位</th><th>指示数量</th><th>出荷数量</th><th>未出荷数量</th></tr>'+x.items.map(i=>'<tr><td>'+esc(i.itemCodeSnap)+'</td><td>'+esc(i.itemNameSnap)+'</td><td>'+esc(i.specSnap)+'</td><td>'+esc(i.unitSnap)+'</td><td>'+Number(i.quantity||0).toLocaleString()+'</td><td>'+Number(i.shippedQuantity||0).toLocaleString()+'</td><td>'+Number(i.availableQuantity==null?i.quantity:i.availableQuantity).toLocaleString()+'</td></tr>').join('')+'</table></div>';document.getElementById('detailModal').classList.add('open')}
// 한국어: 상세 정보 행 생성 / 日本語：詳細情報の行を生成
function row(l,v){return '<div class="ship-row"><div class="ship-label">'+l+'</div><div>'+esc(v)+'</div></div>'}
// 한국어: F2 신규 등록, Escape 모달 닫기 / 日本語：F2で新規登録、Escapeでモーダルを閉じる
document.addEventListener('keydown',function(e){if(e.key==='F2'){e.preventDefault();newShippingOrder()}if(e.key==='Escape'){document.querySelectorAll('.modal.open').forEach(function(m){m.classList.remove('open')})}});
</script>
</body></html>
