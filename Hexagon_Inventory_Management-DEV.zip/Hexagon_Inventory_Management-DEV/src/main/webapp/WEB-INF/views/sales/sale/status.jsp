<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ taglib prefix="my" tagdir="/WEB-INF/tags"%>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>販売状況<%--판매현황--%> - ヘキサゴン ERP<%--헥사곤 ERP--%></title>
<link href="https://cdn.jsdelivr.net/npm/@mdi/font@7.2.96/css/materialdesignicons.min.css" rel="stylesheet">
</head>
<body>
	<div class="erp-wrapper">
		<my:sideMenu />
		<div class="erp-main">
			<main class="erp-content">
				<div class="page-title">
					<i class="mdi mdi-poll"></i> 販売状況<%--판매현황--%>
				</div>
				<%-- Option, 도움말, 프로젝트, 시리얼/로트, 인쇄, 메일, 회계반영은 이 화면에 두지 않는다. --%>
				<%-- Option、ヘルプ、プロジェクト、シリアル/ロット、印刷、メール、会計反映はこの画面に置かない。 --%>
				<%-- 필터는 왼쪽 라벨, 오른쪽 입력이다. 화면을 열 때는 조회하지 않고, 검색이나 기간 버튼을 눌러야 결과 창이 열린다. --%>
				<%-- フィルタは左がラベル、右が入力である。画面を開いたときは照会せず、検索か期間ボタンを押して結果窓が開く。 --%>
				<div class="list-wrap">
					<div class="inq-bar">
						<div class="inq-tabs" id="statusTabs">
							<button type="button" class="active" data-tab="STATUS">現状<%--현황--%></button>
							<button type="button" data-tab="SUMMARY">集計<%--집계--%></button>
						</div>
					</div>
					<div class="status-form">
						<%-- 구분은 현황만 쓴다. 처음 값은 선택안함이고, 그때는 판매 한 줄과 월 계를 보여 준다. 월별은 계만, 품목·거래처·담당자는 그 달 안에서 묶는다. --%>
						<%-- 区分は現状だけ使う。初期値は選択なしであり、そのときは販売1行と月計を出す。月別は計だけ、品目・取引先・担当者はその月の中で束ねる。 --%>
						<div class="form-row only-status">
							<label>区分<%--구분--%></label>
							<select id="viewMode">
								<option value="" selected>選択なし<%--선택안함--%></option>
								<option value="DAY">日別<%--일별--%></option>
								<option value="MONTH">月別<%--월별--%></option>
								<option value="ITEM">品目別<%--품목별--%></option>
								<option value="PARTNER">取引先別<%--거래처별--%></option>
								<option value="MANAGER">担当者別<%--담당자별--%></option>
							</select>
						</div>
						<%-- 집계조건은 집계만 쓴다. 처음 두 칸이고, 칸이 모두 채워지면 한 칸을 더한다. 다섯 칸을 넘지 않으며 같은 조건은 두 번 고르지 못한다. --%>
						<%-- 集計条件は集計だけ使う。最初は2枠で、枠が全部埋まると1枠足す。5枠を超えず、同じ条件は二度選べない。 --%>
						<div id="groupRows" class="only-summary"></div>
						<%-- 사용안함이 아니면 조회기간과 같은 길이의 이전 기간을 결과 창 한 표의 오른쪽에 붙인다. --%>
						<%-- 使用しないでなければ、照会期間と同じ長さの前の期間を結果窓の1表の右に付ける。 --%>
						<div class="form-row">
							<label>比較期間<%--비교기간--%></label>
							<div class="seg" id="compareSeg">
								<button type="button" class="active" data-value="NONE">使用しない<%--사용안함--%></button>
								<button type="button" data-value="PREV_YEAR">前年同一期間<%--전년동일기간--%></button>
								<button type="button" data-value="PREV_MONTH">前月同一期間<%--전월동일기간--%></button>
								<button type="button" data-value="PREV_WEEK">前週同一期間<%--전주동일기간--%></button>
								<button type="button" data-value="PREV_DAY">前日同一期間<%--전일동일기간--%></button>
							</div>
						</div>
						<%-- 일자는 직접 고른다. 처음 기간은 이번 달 1일부터 오늘이고, 다시 작성도 이 값으로 되돌린다. --%>
						<%-- 日付は直接選ぶ。初期期間は今月1日から今日であり、再作成もこの値へ戻す。 --%>
						<div class="form-row">
							<label>日付<%--일자--%></label>
							<div class="field-line">
								<select id="dateMode" class="date-mode">
									<option value="DIRECT">直接入力<%--직접입력--%></option>
								</select>
								<input type="date" id="fromDate" value="${fromDate}" data-default="${fromDate}">
								<span>-</span>
								<input type="date" id="toDate" value="${toDate}" data-default="${toDate}">
							</div>
						</div>
						<%-- 거래유형은 비어 있으면 전체다. 부가세율 적용은 VAT, 미적용은 NO_VAT다. --%>
						<%-- 取引類型は空なら全体である。付加税率適用は VAT、不適用は NO_VAT である。 --%>
						<div class="form-row">
							<label>取引類型<%--거래유형--%></label>
							<div class="field-line grow">
								<button type="button" class="icon-btn" onclick="openTransaction()"><i class="mdi mdi-magnify"></i></button>
								<input type="text" id="transactionName" readonly placeholder="取引類型<%--거래유형--%>">
								<button type="button" class="icon-btn" onclick="clearTransaction()"><i class="mdi mdi-close"></i></button>
							</div>
						</div>
						<%-- 내자는 통화가 없거나 KR이다. 외자는 KR이 아닌 통화만 남긴다. --%>
						<%-- 内貨は通貨がないか KR である。外貨は KR でない通貨だけ残す。 --%>
						<div class="form-row">
							<label>内.外貨区分<%--내.외자구분--%></label>
							<div class="seg" id="currencySeg">
								<button type="button" class="active" data-value="ALL">全体<%--전체--%></button>
								<button type="button" data-value="DOMESTIC">内貨<%--내자--%></button>
								<button type="button" data-value="FOREIGN">外貨<%--외자--%></button>
							</div>
						</div>
						<%-- 출하창고, 거래처, 품목은 돋보기로 고른다. 글자를 직접 고치면 아이디를 지워 조건에서 빠진다. --%>
						<%-- 出荷倉庫、取引先、品目は虫眼鏡で選ぶ。文字を直接直すとIDを消して条件から外す。 --%>
						<div class="form-row">
							<label>出荷倉庫<%--출하창고--%></label>
							<div class="field-line grow">
								<button type="button" class="icon-btn" onclick="openWarehouse()"><i class="mdi mdi-magnify"></i></button>
								<input type="text" id="warehouseName" placeholder="出荷倉庫<%--출하창고--%>" oninput="warehouseId = null">
								<button type="button" class="icon-btn" onclick="clearWarehouse()"><i class="mdi mdi-close"></i></button>
							</div>
						</div>
						<div class="form-row">
							<label>取引先<%--거래처--%></label>
							<div class="field-line grow">
								<button type="button" class="icon-btn" onclick="openPartner()"><i class="mdi mdi-magnify"></i></button>
								<input type="text" id="partnerName" placeholder="取引先<%--거래처--%>" oninput="partnerId = null">
								<button type="button" class="icon-btn" onclick="clearPartner()"><i class="mdi mdi-close"></i></button>
							</div>
						</div>
						<div class="form-row">
							<label>品目コード<%--품목코드--%></label>
							<div class="field-line grow">
								<button type="button" class="icon-btn" onclick="openItem()"><i class="mdi mdi-magnify"></i></button>
								<input type="text" id="itemCode" placeholder="品目コード<%--품목코드--%>" oninput="itemId = null">
								<button type="button" class="icon-btn" onclick="clearItem()"><i class="mdi mdi-close"></i></button>
							</div>
						</div>
					</div>
					<%-- 금일부터 전월+금월은 기간을 넣고 바로 조회한다. 다시 작성만 조회하지 않는다. 정렬은 현황에서 고르면 다시 조회한다. --%>
					<%-- 今日から前月+今月は期間を入れてすぐ照会する。再作成だけ照会しない。並べ替えは現状で選ぶと照会し直す。 --%>
					<div class="sale-foot">
						<button type="button" class="btn-primary-sm" onclick="search()">検索<%--검색--%></button>
						<button type="button" class="btn-flat-sm" onclick="setToday()">今日<%--금일--%></button>
						<button type="button" class="btn-flat-sm" onclick="setYesterday()">前日<%--전일--%></button>
						<button type="button" class="btn-flat-sm" onclick="setThisWeek()">今週<%--금주--%></button>
						<button type="button" class="btn-flat-sm" onclick="setLastWeek()">先週<%--전주--%></button>
						<button type="button" class="btn-flat-sm" onclick="setThisMonth()">今月<%--금월--%></button>
						<button type="button" class="btn-flat-sm" onclick="setLastMonth()">前月<%--전월--%></button>
						<button type="button" class="btn-flat-sm" onclick="setTwoMonths()">前月+今月<%--전월+금월--%></button>
						<button type="button" class="btn-flat-sm" onclick="resetConditions()">再作成<%--다시 작성--%></button>
						<button type="button" class="btn-flat-sm only-status" onclick="openSort()">並べ替え<%--정렬기준 설정--%></button>
					</div>
					<p id="statusMessage" class="inq-message"></p>
				</div>
			</main>
		</div>
	</div>

	<my:lookupModal />

	<%-- 집계조건, 거래유형, 정렬이 같이 쓰는 선택 창이다. 이미 고른 집계조건은 목록에서 빼 둔다. --%>
	<%-- 集計条件、取引類型、並べ替えが一緒に使う選択窓である。すでに選んだ集計条件は一覧から外しておく。 --%>
	<div class="modal-overlay" id="choiceOverlay">
		<div class="lookup-card choice-card">
			<div class="lookup-head">
				<h3 id="choiceTitle"></h3>
				<button type="button" class="modal-close" onclick="closeChoice()"><i class="mdi mdi-close"></i></button>
			</div>
			<div id="choiceBody" class="choice-body"></div>
		</div>
	</div>

	<%-- 결과는 필터 아래가 아니라 이 창이다. 현황은 제목 판매현황과 오른쪽 판매, 집계는 판매현황집계와 회사명, 기간, 쪽, 시각이다. --%>
	<%-- 結果はフィルタの下ではなくこの窓である。現状は題の販売状況と右の販売、集計は販売状況集計と会社名、期間、ページ、時刻である。 --%>
	<%-- 비교기간이면 표를 두 개로 나누지 않고 한 표를 좌우로 잇는다. 월 계의 굵은 글씨는 그 칸에만 남는다. --%>
	<%-- 比較期間なら表を二つに分けず、1表を左右へつなぐ。月計の太い文字はその枠だけに残る。 --%>
	<div id="reportOverlay" class="report-overlay" hidden>
		<div class="report-window" id="reportWindow" role="dialog" aria-modal="true" aria-labelledby="reportTitle">
			<div class="report-top">
				<button type="button" class="report-close" onclick="closeReport()">×</button>
				<span id="reportTitle" class="report-title">販売状況<%--판매현황--%></span>
				<span id="reportMark" class="report-mark">販売<%--판매--%></span>
			</div>
			<div class="report-meta">
				<div class="report-company">会社名 : ヘキサゴン<%--회사명 : 헥사곤--%></div>
				<div id="reportPeriod" class="report-period"></div>
			</div>
			<div class="report-sheet" id="reportSheet">
				<table class="report-table" id="reportTable">
					<thead id="reportHead"></thead>
					<tbody id="reportBody"></tbody>
				</table>
				<div id="reportCompare" class="report-compare" hidden></div>
			</div>
			<div id="reportFoot" class="report-foot" hidden>
				<span>[P.1]</span>
				<span id="reportStamp"></span>
			</div>
		</div>
	</div>

	<script>
		<%-- 현황은 /status/lines, 집계는 /status/summary를 부른다. 월 계와 품목별 묶음은 서버가 아니라 이 화면에서 만든다. --%>
		<%-- 現状は /status/lines、集計は /status/summary を呼ぶ。月計と品目別の束ねはサーバーではなくこの画面で作る。 --%>
		<%-- 금액은 저장된 공급가액, 부가세, 합계를 그대로 쓴다. 페이지를 열거나 탭만 바꿔서는 조회하지 않는다. --%>
		<%-- 金額は保存された供給価額、付加税、合計をそのまま使う。ページを開いたりタブだけ変えては照会しない。 --%>
		var ctx = '${pageContext.request.contextPath}';
		var currentTab = 'STATUS';
		var currencyScope = 'ALL';
		var warehouseId = null;
		var partnerId = null;
		var itemId = null;
		var groupRows = [ { code : '', name : '' }, { code : '', name : '' } ];
		var compareMode = 'NONE';
		var transactionType = '';
		var sortKey = 'DATE';
		var lastResult = null;
		<%-- 집계조건 후보. 화면에는 최대 다섯 칸이고, 이미 고른 코드는 다음 창에서 빼 둔다. --%>
		<%-- 集計条件の候補。画面は最大5枠で、すでに選んだコードは次の窓から外す。 --%>
		var GROUP_CHOICES = [
			{ code : 'SALE_DATE', name : '日別<%--일별--%>' },
			{ code : 'MONTH', name : '月別<%--월별--%>' },
			{ code : 'YEAR', name : '年別<%--연별--%>' },
			{ code : 'MANAGER', name : '担当者別<%--담당자별--%>' },
			{ code : 'WAREHOUSE', name : '出荷倉庫別<%--출하창고별--%>' },
			{ code : 'TRANSACTION', name : '取引類型別<%--거래유형별--%>' },
			{ code : 'PARTNER', name : '取引先別<%--거래처별--%>' }
		];

		<%-- 탭을 바꾸면 보이는 조건만 바꾸고 조회하지 않는다. 열려 있던 결과 창은 닫는다. --%>
		<%-- タブを変えると見える条件だけ変え、照会しない。開いていた結果窓は閉じる。 --%>
		document.getElementById('statusTabs').addEventListener('click', function(event) {
			var button = event.target.closest('button');
			if (!button)
				return;
			Array.prototype.forEach.call(this.querySelectorAll('button'), function(item) {
				item.classList.remove('active');
			});
			button.classList.add('active');
			currentTab = button.getAttribute('data-tab');
			applyTab();
			closeReport();
		});

		bindSeg('currencySeg', function(value) { currencyScope = value; });
		bindSeg('compareSeg', function(value) { compareMode = value; });

		<%-- 비교기간과 내외자 버튼은 하나만 선택된다. 값을 바꿔도 바로 조회하지 않는다. --%>
		<%-- 比較期間と内外貨のボタンは一つだけ選ばれる。値を変えてもすぐ照会しない。 --%>
		function bindSeg(id, apply) {
			document.getElementById(id).addEventListener('click', function(event) {
				var button = event.target.closest('button');
				if (!button)
					return;
				Array.prototype.forEach.call(this.querySelectorAll('button'), function(item) {
					item.classList.remove('active');
				});
				button.classList.add('active');
				apply(button.getAttribute('data-value'));
			});
		}

		<%-- 현황만 구분과 정렬을 보여주고, 집계만 집계조건 칸을 보여 준다. 탭을 바꿔도 조회하지 않고 열려 있던 결과 창은 닫는다. --%>
		<%-- 現状だけ区分と並べ替えを出し、集計だけ集計条件の枠を出す。タブを変えても照会せず、開いていた結果窓は閉じる。 --%>
		function applyTab() {
			var summary = currentTab === 'SUMMARY';
			Array.prototype.forEach.call(document.querySelectorAll('.only-status'), function(el) {
				el.style.display = summary ? 'none' : '';
			});
			Array.prototype.forEach.call(document.querySelectorAll('.only-summary'), function(el) {
				el.style.display = summary ? '' : 'none';
			});
		}

		<%-- 집계는 조건이 한 칸도 없으면 서버에 가기 전에 막는다. 1,000건을 넘으면 목록만 자르고 합계는 전 건이라고 알린다. --%>
		<%-- 集計は条件が1枠もなければサーバーへ行く前に止める。1,000件を超えると一覧だけ切り、合計は全件だと知らせる。 --%>
		function search() {
			var fromDate = document.getElementById('fromDate').value;
			var toDate = document.getElementById('toDate').value;
			if (!fromDate || !toDate) {
				showMessage('基準日付を入力してください。'); // 기준일자를 입력하세요.
				return;
			}
			if (currentTab === 'SUMMARY' && !filledGroupCodes().length) {
				showMessage('集計条件を選択してください。'); // 집계조건을 선택하세요.
				clearGrid();
				return;
			}
			if (fromDate > toDate) {
				showMessage('開始日が終了日より後です。'); // 시작일이 종료일보다 뒤입니다.
				clearGrid();
				return;
			}
			var url = ctx + (currentTab === 'SUMMARY' ? '/sales/sale/status/summary?' : '/sales/sale/status/lines?')
					+ queryString();
			fetch(url, { headers : { 'Accept' : 'application/json' } }).then(function(res) {
				return res.json().then(function(body) {
					return { ok : res.ok, body : body || {} };
				});
			}).then(function(result) {
				if (!result.ok) {
					showMessage(result.body.message || '照会できませんでした。'); // 조회하지 못했습니다.
					clearGrid();
					return;
				}
				lastResult = result.body;
				var message = '';
				if (result.body.truncated)
					message = '1,000件を超えるため先頭1,000件だけ表示します。合計は全件です。'; // 1,000건을 넘으면 앞 1,000건만 표시합니다. 합계는 전 건입니다.
				showMessage(message);
				showReport(result.body);
			}).catch(function() {
				showMessage('照会できませんでした。'); // 조회하지 못했습니다.
			});
		}

		<%-- 현황은 구분을 보내고 집계는 채워진 조건만 group1부터 보낸다. 빈 구분은 서버가 일별로 받는다. --%>
		<%-- 現状は区分を送り、集計は埋まった条件だけ group1 から送る。空の区分はサーバーが日別として受ける。 --%>
		function queryString() {
			var parts = [
				'fromDate=' + encodeURIComponent(document.getElementById('fromDate').value),
				'toDate=' + encodeURIComponent(document.getElementById('toDate').value),
				'compare=' + encodeURIComponent(compareMode),
				'transactionType=' + encodeURIComponent(transactionType || ''),
				'currencyScope=' + encodeURIComponent(currencyScope),
				'sortKey=' + encodeURIComponent(sortKey)
			];
			if (warehouseId)
				parts.push('warehouseId=' + encodeURIComponent(warehouseId));
			if (partnerId)
				parts.push('partnerId=' + encodeURIComponent(partnerId));
			if (itemId)
				parts.push('itemId=' + encodeURIComponent(itemId));
			if (currentTab === 'SUMMARY') {
				filledGroupCodes().forEach(function(code, index) {
					parts.push('group' + (index + 1) + '=' + encodeURIComponent(code));
				});
			} else {
				parts.push('viewMode=' + encodeURIComponent(document.getElementById('viewMode').value));
			}
			return parts.join('&');
		}

		<%-- 결과는 별도 창이다. 비교기간이 사용안함이 아니면 한 표를 좌우로 나누고, 집계는 회사명과 시각을 붙인다. --%>
		<%-- 結果は別窓である。比較期間が使用しないでなければ1表を左右に分け、集計は会社名と時刻を付ける。 --%>
		function showReport(body) {
			var summary = currentTab === 'SUMMARY';
			var fromDate = document.getElementById('fromDate').value;
			var toDate = document.getElementById('toDate').value;
			document.getElementById('reportWindow').classList.toggle('is-summary', summary);
			document.getElementById('reportTitle').textContent = summary ? '販売状況集計<%--판매현황집계--%>' : '販売状況<%--판매현황--%>';
			document.getElementById('reportMark').hidden = summary;
			document.getElementById('reportFoot').hidden = !summary;
			document.getElementById('reportPeriod').textContent = slashDate(fromDate) + ' ~ ' + slashDate(toDate);
			if (summary) {
				document.getElementById('reportStamp').textContent = reportStamp();
				if (compareMode === 'NONE')
					renderSummarySheet(body.summaries || [], body);
				else
					renderSummaryCompare(body);
			} else if (compareMode === 'NONE') {
				renderLineSheet(body.lines || []);
			} else {
				renderLineCompare(body);
			}
			document.getElementById('reportOverlay').hidden = false;
		}

		<%-- 결과 창만 닫는다. 검색 조건은 그대로 둔다. --%>
		<%-- 結果窓だけ閉じる。検索条件はそのままにする。 --%>
		function closeReport() {
			document.getElementById('reportOverlay').hidden = true;
		}

		<%-- 기간 머리글은 하이픈 대신 슬래시다. --%>
		<%-- 期間の見出しはハイフンの代わりにスラッシュである。 --%>
		function slashDate(value) {
			return value ? String(value).replace(/-/g, '/') : '';
		}

		<%-- 비교를 쓰지 않을 때의 현황 표. 열은 일자-No, 거래처명, 품목명(규격), 수량, 단가, 공급가액, 부가세, 합계다. --%>
		<%-- 比較を使わないときの現状表。列は日付-No、取引先名、品目名(規格)、数量、単価、供給価額、付加税、合計である。 --%>
		function renderLineSheet(lines) {
			showSingleTable();
			var built = buildLineTable(lines);
			document.getElementById('reportHead').innerHTML = built.head;
			document.getElementById('reportBody').innerHTML = built.body;
		}

		<%-- 판매를 월로 나눈 뒤 구분에 맞게 줄을 만든다. 달이 바뀌면 그 달의 계를 먼저 넣고 다음 달로 넘어간다. --%>
		<%-- 販売を月で分けたあと区分に合わせて行を作る。月が変わるとその月の計を先に入れ、次の月へ移る。 --%>
		function buildLineTable(lines) {
			var mode = document.getElementById('viewMode').value;
			var head = '<tr><th>日付-No.<%--일자-No.--%></th><th>取引先名<%--거래처명--%></th><th>品目名(規格)<%--품목명(규격)--%></th><th class="num">数量<%--수량--%></th>'
					+ '<th class="num">単価<%--단가--%></th><th class="num">供給価額<%--공급가액--%></th><th class="num">付加税<%--부가세--%></th><th class="num">合計<%--합계--%></th></tr>';
			var sorted = lines.slice().sort(function(a, b) {
				return String(a.saleDate || '').localeCompare(String(b.saleDate || ''))
						|| (Number(a.saleId) - Number(b.saleId))
						|| (Number(a.lineNo) - Number(b.lineNo));
			});
			var html = '';
			var month = '';
			var bucket = [];
			<%-- 달이 바뀌거나 목록이 끝나면 그 달의 줄과 계를 표에 넣고 통을 비운다. --%>
			<%-- 月が変わるか一覧が終わると、その月の行と計を表に入れて入れ物を空にする。 --%>
			function flush() {
				if (!month)
					return;
				html += rowsForMonth(sortBucket(bucket), mode, false);
				html += monthRow(bucket, month, false);
				bucket = [];
			}
			sorted.forEach(function(line) {
				var key = String(line.saleDate || '').slice(0, 7);
				if (month && key !== month)
					flush();
				month = key;
				bucket.push(line);
			});
			flush();
			return {
				head : head,
				body : html || '<tr><td colspan="8" class="report-empty">照会された販売がありません。<%--조회된 판매가 없습니다.--%></td></tr>'
			};
		}

		<%-- 조회기간을 왼쪽, 비교기간을 오른쪽에 둔다. 전표가 서로 짝이 아니므로 줄 순서로 붙이고 짧은 쪽은 빈 칸으로 맞춘다. --%>
		<%-- 照会期間を左、比較期間を右に置く。伝票が互いに組ではないので行の順で付け、短い側は空欄で合わせる。 --%>
		function renderLineCompare(body) {
			var fromDate = document.getElementById('fromDate').value;
			var toDate = document.getElementById('toDate').value;
			var left = buildLineTable(body.lines || []);
			var right = buildLineTable(body.compareLines || []);
			var cols = 8;
			var head = '<tr class="period-head"><th colspan="' + cols + '">' + esc(periodText(fromDate, toDate))
					+ '</th><th colspan="' + cols + '">' + esc(periodText(shiftIso(fromDate, -1), shiftIso(toDate, -1)))
					+ '</th></tr><tr>' + lineHeadCells() + lineHeadCells() + '</tr>';
			showCompareHost('<table class="report-table compare-table">' + lineColgroup() + '<thead>' + head
					+ '</thead><tbody>' + zipRows(left.body, right.body, cols) + '</tbody></table>');
		}

		<%-- 비교표는 같은 머리글을 좌우에 한 번씩 둔다. --%>
		<%-- 比較表は同じ見出しを左右に一度ずつ置く。 --%>
		function lineHeadCells() {
			return '<th>日付-No.<%--일자-No.--%></th><th>取引先名<%--거래처명--%></th><th>品目名(規格)<%--품목명(규격)--%></th><th class="num">数量<%--수량--%></th><th class="num">単価<%--단가--%></th><th class="num">供給価額<%--공급가액--%></th><th class="num">付加税<%--부가세--%></th><th class="num">合計<%--합계--%></th>';
		}

		<%-- 열이 열여섯 개라 창 너비에 맞춰 고정한다. 표마다 최소 너비를 주면 창 안에서 깨진다. --%>
		<%-- 列が十六個なので窓幅に合わせて固定する。表ごとに最小幅を付けると窓の中で崩れる。 --%>
		function lineColgroup() {
			var widths = [ '8%', '7%', '8%', '5%', '5%', '7%', '5%', '5%' ];
			return '<colgroup>' + widths.concat(widths).map(function(width) {
				return '<col style="width:' + width + '">';
			}).join('') + '</colgroup>';
		}

		<%-- 왼쪽 행과 오른쪽 행의 안쪽 칸만 떼어 한 줄로 잇는다. 오른쪽 첫 칸에 세로 구분선을 준다. --%>
		<%-- 左の行と右の行の内側の枠だけ外して1行へつなぐ。右の最初の枠に縦の区切り線を付ける。 --%>
		function zipRows(leftHtml, rightHtml, cols) {
			var left = rowInners(leftHtml);
			var right = rowInners(rightHtml);
			var count = Math.max(left.length, right.length, 1);
			var empty = '<td colspan="' + cols + '"></td>';
			var html = '';
			for (var i = 0; i < count; i++) {
				html += '<tr>' + (left[i] || empty) + markSplit(right[i] || empty) + '</tr>';
			}
			return html;
		}

		<%-- 표에서 tr 안쪽만 꺼낸다. 월 계의 굵은 글씨는 칸에 있으므로 반대편으로 번지지 않는다. --%>
		<%-- 表から tr の内側だけ取り出す。月計の太い文字は枠にあるので反対側へ広がらない。 --%>
		function rowInners(html) {
			var rows = [];
			var pattern = /<tr[^>]*>([\s\S]*?)<\/tr>/g;
			var match;
			while ((match = pattern.exec(html)))
				rows.push(match[1]);
			return rows;
		}

		<%-- 오른쪽 절반의 첫 칸에 구분선을 붙여 조회기간과 비교기간 사이를 가른다. --%>
		<%-- 右半分の最初の枠に区切り線を付け、照会期間と比較期間の間を分ける。 --%>
		function markSplit(inner) {
			return inner.replace(/<(td|th)([^>]*)>/, function(_, tag, attrs) {
				if (attrs.indexOf('class="') >= 0)
					return '<' + tag + attrs.replace('class="', 'class="compare-split ') + '>';
				return '<' + tag + ' class="compare-split"' + attrs + '>';
			});
		}

		<%-- 비교표 위의 기간은 yyyy/MM/dd ~ yyyy/MM/dd다. --%>
		<%-- 比較表の上の期間は yyyy/MM/dd ~ yyyy/MM/dd である。 --%>
		function periodText(fromDate, toDate) {
			return slashDate(fromDate) + ' ~ ' + slashDate(toDate);
		}

		<%-- 정렬은 월 묶음 안의 줄 순서를 바꾼다. 계의 합은 순서와 관계없이 같다. --%>
		<%-- 並べ替えは月の束の中の行順を変える。計の合計は順と関係なく同じである。 --%>
		function sortBucket(bucket) {
			return bucket.slice().sort(function(a, b) {
				if (sortKey === 'PARTNER')
					return String(a.partnerName || '').localeCompare(String(b.partnerName || ''));
				if (sortKey === 'ITEM')
					return String(a.itemName || '').localeCompare(String(b.itemName || ''));
				if (sortKey === 'QTY')
					return Number(b.quantity || 0) - Number(a.quantity || 0);
				if (sortKey === 'SUPPLY')
					return Number(b.supplyAmount || 0) - Number(a.supplyAmount || 0);
				if (sortKey === 'TOTAL')
					return Number(b.totalAmount || 0) - Number(a.totalAmount || 0);
				return String(a.saleDate || '').localeCompare(String(b.saleDate || ''))
						|| (Number(a.saleId) - Number(b.saleId))
						|| (Number(a.lineNo) - Number(b.lineNo));
			});
		}

		<%-- 구분이 비었거나 일별이면 판매 한 줄씩이다. 월별은 줄을 만들지 않아 계만 남고, 나머지는 그 달 안에서 품목, 거래처, 담당자로 묶는다. --%>
		<%-- 区分が空か日別なら販売1行ずつである。月別は行を作らず計だけ残り、残りはその月の中で品目、取引先、担当者に束ねる。 --%>
		function rowsForMonth(bucket, mode, compare) {
			if (mode === 'MONTH')
				return '';
			if (!mode || mode === 'DAY') {
				return bucket.map(function(line) {
					return lineRow(displayDateNo(line.dateNo), line.partnerName || '', itemLabel(line),
							line.quantity, line.compareQuantity, line.unitPrice, line.supplyAmount, line.vatAmount, line.totalAmount, compare);
				}).join('');
			}
			var groups = {};
			var order = [];
			bucket.forEach(function(line) {
				var key = mode === 'PARTNER' ? String(line.partnerId || '')
						: mode === 'MANAGER' ? String(line.managerName || '')
						: String(line.itemId || '');
				if (!groups[key]) {
					groups[key] = blankSum();
					groups[key].label = mode === 'PARTNER' ? (line.partnerName || '')
							: mode === 'MANAGER' ? (line.managerName || '')
							: itemLabel(line);
					order.push(key);
				}
				addSum(groups[key], line);
			});
			return order.map(function(key) {
				var row = groups[key];
				var cells = mode === 'PARTNER' ? [ '', row.label, '' ]
						: mode === 'MANAGER' ? [ row.label, '', '' ]
						: [ '', '', row.label ];
				return lineRow(cells[0], cells[1], cells[2], row.qty, row.hasCompare ? row.compareQty : null,
						row.price, row.supply, row.vat, row.total, compare);
			}).join('');
		}

		<%-- 달이 바뀌면 YYYY/MM 계를 굵게 넣는다. 단가는 평균이 아니라 그 달 단가를 더한다. --%>
		<%-- 月が変わると YYYY/MM 計を太く入れる。単価は平均ではなくその月の単価を足す。 --%>
		function monthRow(bucket, monthKey, compare) {
			var sum = blankSum();
			bucket.forEach(function(line) { addSum(sum, line); });
			var label = monthKey.replace('-', '/') + ' 計<%--계--%>';
			return '<tr class="month-row"><td class="month-row" colspan="3">' + esc(label) + '</td>'
					+ numCell(sum.qty).replace('<td class="num">', '<td class="num month-row">')
					+ (compare ? numCell(sum.hasCompare ? sum.compareQty : null).replace('<td class="num">', '<td class="num month-row">')
							+ numCell(sum.hasCompare ? sum.qty - sum.compareQty : null).replace('<td class="num">', '<td class="num month-row">') : '')
					+ numCell(sum.price).replace('<td class="num">', '<td class="num month-row">')
					+ numCell(sum.supply).replace('<td class="num">', '<td class="num month-row">')
					+ numCell(sum.vat).replace('<td class="num">', '<td class="num month-row">')
					+ numCell(sum.total).replace('<td class="num">', '<td class="num month-row">')
					+ '</tr>';
		}

		<%-- 현황의 데이터 한 줄. 좌우 비교표는 비교 열을 따로 만들지 않도록 이 비교 표시를 끄고 부른다. --%>
		<%-- 現状のデータの1行。左右の比較表は比較列を別に作らないよう、この比較表示を消して呼ぶ。 --%>
		function lineRow(dateNo, partner, item, qty, compareQty, price, supply, vat, total, compare) {
			return '<tr><td>' + esc(dateNo) + '</td><td>' + esc(partner) + '</td><td>' + esc(item) + '</td>'
					+ numCell(qty)
					+ (compare ? numCell(compareQty) + numCell(diff(qty, compareQty)) : '')
					+ numCell(price) + numCell(supply) + numCell(vat) + numCell(total)
					+ '</tr>';
		}

		<%-- 월 계와 집계 계가 더할 수량, 단가, 공급가액, 부가세, 합계의 빈 통이다. --%>
		<%-- 月計と集計の計が足す数量、単価、供給価額、付加税、合計の空の入れ物である。 --%>
		function blankSum() {
			return { qty : 0, compareQty : 0, price : 0, supply : 0, vat : 0, total : 0, hasCompare : false };
		}

		<%-- 저장된 금액을 그대로 더한다. 비교수량이 있는 줄만 비교 합계에 넣는다. --%>
		<%-- 保存された金額をそのまま足す。比較数量がある行だけ比較合計に入れる。 --%>
		function addSum(sum, line) {
			sum.qty += Number(line.quantity) || 0;
			sum.price += Number(line.unitPrice) || 0;
			sum.supply += Number(line.supplyAmount) || 0;
			sum.vat += Number(line.vatAmount) || 0;
			sum.total += Number(line.totalAmount) || 0;
			if (line.compareQuantity !== null && line.compareQuantity !== undefined && line.compareQuantity !== '') {
				sum.compareQty += Number(line.compareQuantity) || 0;
				sum.hasCompare = true;
			}
		}

		<%-- 서버의 2026/09/03-2를 화면의 2026/09/03 -2로 띄운다. --%>
		<%-- サーバーの 2026/09/03-2 を画面の 2026/09/03 -2 で出す。 --%>
		function displayDateNo(value) {
			var text = String(value || '');
			var cut = text.lastIndexOf('-');
			if (cut < 0)
				return text;
			return text.slice(0, cut) + ' -' + text.slice(cut + 1);
		}

		<%-- 규격이 있으면 품목명 뒤에 [규격]을 붙인다. 규격이 없으면 이름만 둔다. --%>
		<%-- 規格があれば品目名の後に [規格] を付ける。規格がなければ名前だけにする。 --%>
		function itemLabel(line) {
			var name = line.itemName || '';
			var spec = String(line.spec || '').trim();
			return spec ? name + ' [' + spec + ']' : name;
		}

		<%-- 현황 숫자는 빈 값이면 칸만 남긴다. --%>
		<%-- 現状の数字は空の値なら枠だけ残す。 --%>
		function numCell(value) {
			return '<td class="num">' + money(value) + '</td>';
		}

		<%-- 비어 있거나 같은 집계조건을 빼고, 남은 것을 group1부터 순서대로 보낸다. --%>
		<%-- 空か同じ集計条件を除き、残ったものを group1 から順に送る。 --%>
		function filledGroupCodes() {
			var codes = [];
			groupRows.forEach(function(row) {
				if (row.code && codes.indexOf(row.code) < 0)
					codes.push(row.code);
			});
			return codes;
		}

		<%-- 값 행 다음에 그 이름 계를 붙이고 마지막에 총합계를 둔다. 조건이 둘 이상이면 첫째 조건이 바뀔 때 계를 끊는다. --%>
		<%-- 値の行の次にその名前の計を付け、最後に総合計を置く。条件が二つ以上なら一つ目の条件が変わるとき計を切る。 --%>
		function renderSummarySheet(rows, body) {
			showSingleTable();
			var codes = filledGroupCodes();
			var textCols = Math.max(codes.length, 1);
			var head = '<tr>';
			if (!codes.length)
				head += '<th>集計<%--집계--%></th>';
			codes.forEach(function(code) {
				head += '<th>' + esc(groupTitle(code)) + '</th>';
			});
			head += '<th class="num">数量<%--수량--%></th><th class="num">供給価額<%--공급가액--%></th><th class="num">付加税<%--부가세--%></th><th class="num">合計<%--합계--%></th></tr>';
			document.getElementById('reportHead').innerHTML = head;
			if (!rows.length) {
				document.getElementById('reportBody').innerHTML = '<tr><td colspan="' + (textCols + 4)
						+ '" class="report-empty">照会された販売がありません。<%--조회된 판매가 없습니다.--%></td></tr>';
				return;
			}
			var html = '';
			if (!codes.length) {
				html += summaryLabelRow('総合計<%--총합계--%>', 1, body, 'grand-row');
			} else if (codes.length === 1) {
				rows.forEach(function(row) {
					var name = displayGroupName(row.group1Name);
					html += '<tr><td class="group-label">' + esc(name) + '</td>' + summaryAmounts(row) + '</tr>';
					html += summaryLabelRow(name + ' 計<%--계--%>', 1, row, 'subtotal-row');
				});
				html += summaryLabelRow('総合計<%--총합계--%>', 1, body, 'grand-row');
			} else {
				var buckets = [];
				var current = null;
				rows.forEach(function(row) {
					var key = String(row.group1Name || '');
					if (!current || current.key !== key) {
						current = { key : key, name : displayGroupName(row.group1Name), rows : [], sum : blankSum() };
						buckets.push(current);
					}
					current.rows.push(row);
					addSum(current.sum, row);
				});
				buckets.forEach(function(bucket) {
					bucket.rows.forEach(function(row) {
						html += '<tr>' + groupNameCells(row, codes.length) + summaryAmounts(row) + '</tr>';
					});
					html += summaryLabelRow(bucket.name + ' 計<%--계--%>', codes.length, bucket.sum, 'subtotal-row');
				});
				html += summaryLabelRow('総合計<%--총합계--%>', codes.length, body, 'grand-row');
			}
			document.getElementById('reportBody').innerHTML = html;
		}

		<%-- 집계 비교는 한 표다. 위에는 두 기간, 아래에는 같은 열을 좌우로 두고 총합계도 양쪽에 둔다. --%>
		<%-- 集計の比較は1表である。上には二つの期間、下には同じ列を左右に置き、総合計も両側に置く。 --%>
		function renderSummaryCompare(body) {
			var codes = filledGroupCodes();
			var span = codes.length + 4;
			var fromDate = document.getElementById('fromDate').value;
			var toDate = document.getElementById('toDate').value;
			var compareFrom = shiftIso(fromDate, -1);
			var compareTo = shiftIso(toDate, -1);
			var head = '<tr class="period-head"><th colspan="' + span + '">' + esc(periodText(fromDate, toDate))
					+ '</th><th class="compare-split" colspan="' + span + '">' + esc(periodText(compareFrom, compareTo)) + '</th></tr><tr>'
					+ summaryHeadCells(codes) + markSplit(summaryHeadCells(codes)) + '</tr>';
			var rows = mergeSummaryRows(body.summaries || [], body.compareSummaries || [], codes.length);
			var html = rows.map(function(pair) {
				return '<tr>' + summaryNameCells(pair.base, codes.length) + summaryAmountCells(pair.base)
						+ markSplit(summaryNameCells(pair.compare, codes.length)) + summaryAmountCells(pair.compare) + '</tr>';
			}).join('');
			html += '<tr class="grand-row">' + summaryTotalCells('総合計<%--총합계--%>', codes.length, body)
					+ markSplit(summaryTotalCells('総合計<%--총합계--%>', codes.length, {
						quantity : body.compareQuantity,
						supplyAmount : body.compareSupplyAmount,
						vatAmount : body.compareVatAmount,
						totalAmount : body.compareTotalAmount
					})) + '</tr>';
			if (!rows.length)
				html = '<tr><td colspan="' + (span * 2) + '" class="report-empty">照会された販売がありません。<%--조회된 판매가 없습니다.--%></td></tr>' + html;
			showCompareHost('<table class="report-table compare-table">' + summaryColgroup(codes.length, span)
					+ '<thead>' + head + '</thead><tbody>' + html + '</tbody></table>');
		}

		<%-- 이름 칸과 금액 칸의 너비를 나눠 열이 많은 표가 창을 넘지 않게 한다. --%>
		<%-- 名前の枠と金額の枠の幅を分け、列が多い表が窓を超えないようにする。 --%>
		function summaryColgroup(nameCount, span) {
			var widths = [];
			var nameWidth = Math.max(8, Math.floor(28 / Math.max(nameCount, 1)));
			var numWidth = Math.floor((50 - nameWidth * nameCount) / 4);
			for (var i = 0; i < nameCount; i++)
				widths.push(nameWidth + '%');
			for (var n = 0; n < 4; n++)
				widths.push(numWidth + '%');
			while (widths.length < span)
				widths.push('6%');
			return '<colgroup>' + widths.concat(widths).map(function(width) {
				return '<col style="width:' + width + '">';
			}).join('') + '</colgroup>';
		}

		<%-- 고른 집계조건 이름을 수량, 공급가액, 부가세, 합계 앞에 둔다. --%>
		<%-- 選んだ集計条件の名前を数量、供給価額、付加税、合計の前に置く。 --%>
		function summaryHeadCells(codes) {
			return codes.map(function(code) {
				return '<th>' + esc(groupTitle(code)) + '</th>';
			}).join('') + '<th class="num">数量<%--수량--%></th><th class="num">供給価額<%--공급가액--%></th><th class="num">付加税<%--부가세--%></th><th class="num">合計<%--합계--%></th>';
		}

		<%-- 한쪽에만 있는 묶음은 반대편 이름을 빈 칸으로 둔다. --%>
		<%-- 片方にしかない束は反対側の名前を空欄にする。 --%>
		function summaryNameCells(row, count) {
			if (!row) {
				var blank = '';
				for (var i = 0; i < count; i++)
					blank += '<td></td>';
				return blank;
			}
			return groupNameCells(row, count);
		}

		<%-- 없는 쪽의 수량과 금액은 0이 아니라 빈 칸이다. --%>
		<%-- ない側の数量と金額は 0 ではなく空欄である。 --%>
		function summaryAmountCells(row) {
			if (!row)
				return '<td class="num"></td><td class="num"></td><td class="num"></td><td class="num"></td>';
			return summaryAmounts(row);
		}

		<%-- 총합계는 이름 칸을 하나로 합치고 금액은 서버가 준 전 건 합계를 쓴다. --%>
		<%-- 総合計は名前の枠を一つに合わせ、金額はサーバーが渡した全件合計を使う。 --%>
		function summaryTotalCells(label, count, row) {
			return '<td colspan="' + count + '">' + esc(label) + '</td>' + summaryAmounts(row || {});
		}

		<%-- 좌우를 표시 이름으로 맞춘다. 조회기간에만 있는 행은 오른쪽이 비고, 비교기간에만 있는 행은 왼쪽이 빈다. --%>
		<%-- 左右を表示名で合わせる。照会期間にだけある行は右が空き、比較期間にだけある行は左が空く。 --%>
		function mergeSummaryRows(baseRows, compareRows, count) {
			var order = [];
			var map = {};
			function take(list, side) {
				list.forEach(function(row) {
					var key = summaryKey(row, count);
					if (!map[key]) {
						map[key] = { base : null, compare : null };
						order.push(key);
					}
					map[key][side] = row;
				});
			}
			take(baseRows, 'base');
			take(compareRows, 'compare');
			return order.map(function(key) { return map[key]; });
		}

		<%-- 집계조건 이름을 이어 같은 행인지 판단한다. 날짜는 슬래시로 바꾼 뒤 비교한다. --%>
		<%-- 集計条件の名前をつないで同じ行か判断する。日付はスラッシュに変えたあと比べる。 --%>
		function summaryKey(row, count) {
			var parts = [];
			for (var i = 1; i <= count; i++)
				parts.push(displayGroupName(row['group' + i + 'Name']));
			return parts.join('|');
		}

		<%-- 기간 머리글과 표를 따로 그리던 조각이다. 비교 결과는 이제 한 표로 그리므로 호출하지 않는다. --%>
		<%-- 期間の見出しと表を別に描いていた断片である。比較結果は今は1表で描くので呼ばない。 --%>
		function periodPane(fromDate, toDate, built) {
			return '<section class="compare-pane"><div class="period-banner">' + esc(slashDate(fromDate) + ' ~ ' + slashDate(toDate))
					+ '</div><table class="report-table"><thead>' + built.head + '</thead><tbody>' + built.body + '</tbody></table></section>';
		}

		<%-- 비교가 아닐 때는 기본 표를 쓰고 비교용 칸은 비운다. --%>
		<%-- 比較でないときは基本の表を使い、比較用の枠は空にする。 --%>
		function showSingleTable() {
			document.getElementById('reportWindow').classList.remove('is-compare');
			document.getElementById('reportTable').hidden = false;
			var box = document.getElementById('reportCompare');
			box.hidden = true;
			box.innerHTML = '';
		}

		<%-- 비교 표는 기본 표 자리에 통째로 넣고 창을 넓혀 열이 줄바꿈되지 않게 한다. --%>
		<%-- 比較表は基本の表の位置に丸ごと入れ、窓を広げて列が折り返されないようにする。 --%>
		function showCompareHost(html) {
			document.getElementById('reportWindow').classList.add('is-compare');
			document.getElementById('reportTable').hidden = true;
			document.getElementById('reportHead').innerHTML = '';
			document.getElementById('reportBody').innerHTML = '';
			var box = document.getElementById('reportCompare');
			box.hidden = false;
			box.innerHTML = html;
		}

		<%-- 결과 창 오른쪽 기간. 서버와 같이 전년, 전월, 전주, 전일로 옮긴다. --%>
		<%-- 結果窓の右の期間。サーバーと同じく前年、前月、前週、前日へ移す。 --%>
		function shiftIso(value, direction) {
			var parts = String(value || '').split('-');
			if (parts.length < 3)
				return value;
			var date = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
			if (compareMode === 'PREV_YEAR')
				date.setFullYear(date.getFullYear() + direction);
			else if (compareMode === 'PREV_MONTH')
				date = addMonths(date, direction);
			else if (compareMode === 'PREV_WEEK')
				date.setDate(date.getDate() + direction * 7);
			else
				date.setDate(date.getDate() + direction);
			return fmt(date);
		}

		<%-- 31일에서 한 달을 옮기면 그 달의 마지막 날로 맞춘다. --%>
		<%-- 31日から一月移すとその月の最終日に合わせる。 --%>
		function addMonths(date, months) {
			var day = date.getDate();
			var next = new Date(date.getFullYear(), date.getMonth() + months, 1);
			var last = new Date(next.getFullYear(), next.getMonth() + 1, 0).getDate();
			next.setDate(Math.min(day, last));
			return next;
		}

		<%-- 마지막 이름만 파란색이다. 날짜는 슬래시로 보여 준다. --%>
		<%-- 最後の名前だけ青色である。日付はスラッシュで見せる。 --%>
		function groupNameCells(row, count) {
			var html = '';
			for (var i = 1; i <= count; i++) {
				var name = displayGroupName(row['group' + i + 'Name']);
				html += '<td' + (i === count ? ' class="group-label"' : '') + '>' + esc(name) + '</td>';
			}
			return html;
		}

		<%-- 결과 창 머리글도 검색 화면과 같이 일본어로 보여 준다. --%>
		<%-- 結果窓の見出しも検索画面と同じく日本語で見せる。 --%>
		function groupTitle(code) {
			return {
				SALE_DATE : '日別<%--일별--%>',
				MONTH : '月別<%--월별--%>',
				YEAR : '年別<%--연별--%>',
				TRANSACTION : '取引類型別<%--거래유형별--%>',
				WAREHOUSE : '出荷倉庫別<%--출하창고별--%>',
				MANAGER : '担当者別<%--담당자별--%>',
				PARTNER : '取引先別<%--거래처별--%>'
			}[code] || '';
		}

		<%-- yyyy-MM-dd와 yyyy-MM은 슬래시로 바꾼다. 서버의 合計는 그대로 合計로 보여 준다. --%>
		<%-- yyyy-MM-dd と yyyy-MM はスラッシュに変える。サーバーの 合計 はそのまま 合計 で見せる。 --%>
		function displayGroupName(value) {
			var text = String(value == null ? '' : value);
			if (/^\d{4}-\d{2}(-\d{2})?$/.test(text))
				return text.replace(/-/g, '/');
			if (text === '合計')
				return '合計<%--합계--%>';
			return text;
		}

		<%-- 집계 수량은 소수 둘째 자리, 금액은 소수 없이 보여 준다. --%>
		<%-- 集計の数量は小数第二位、金額は小数なしで見せる。 --%>
		function summaryAmounts(row) {
			var qty = row.quantity != null ? row.quantity : row.qty;
			var supply = row.supplyAmount != null ? row.supplyAmount : row.supply;
			var vat = row.vatAmount != null ? row.vatAmount : row.vat;
			var total = row.totalAmount != null ? row.totalAmount : row.total;
			return qtyCell(qty) + amtCell(supply) + amtCell(vat) + amtCell(total);
		}

		<%-- 이름 계와 총합계처럼 앞 칸을 합친 굵은 줄이다. --%>
		<%-- 名前の計と総合計のように前の枠を合わせた太い行である。 --%>
		function summaryLabelRow(label, span, row, cls) {
			return '<tr class="' + cls + '"><td colspan="' + span + '">' + esc(label) + '</td>' + summaryAmounts(row) + '</tr>';
		}

		<%-- 집계 수량 칸. 소수 둘째 자리까지 맞춘다. --%>
		<%-- 集計の数量枠。小数第二位まで合わせる。 --%>
		function qtyCell(value) {
			return '<td class="num">' + qtyText(value) + '</td>';
		}

		<%-- 집계 금액 칸. 공급가액, 부가세, 합계는 소수 없이 보여 준다. --%>
		<%-- 集計の金額枠。供給価額、付加税、合計は小数なしで見せる。 --%>
		function amtCell(value) {
			return '<td class="num">' + amtText(value) + '</td>';
		}

		<%-- 빈 수량은 0으로 채우지 않고 칸을 비운다. --%>
		<%-- 空の数量は 0 で埋めず枠を空ける。 --%>
		function qtyText(value) {
			if (value === null || value === undefined || value === '')
				return '';
			var number = Number(value);
			if (isNaN(number))
				return '';
			return number.toLocaleString('ko-KR', { minimumFractionDigits : 2, maximumFractionDigits : 2 });
		}

		<%-- 빈 금액은 0으로 채우지 않고 칸을 비운다. --%>
		<%-- 空の金額は 0 で埋めず枠を空ける。 --%>
		function amtText(value) {
			if (value === null || value === undefined || value === '')
				return '';
			var number = Number(value);
			if (isNaN(number))
				return '';
			return number.toLocaleString('ko-KR', { maximumFractionDigits : 0 });
		}

		<%-- 집계 창 아래 시각. yyyy/MM/dd (요일) 오전 또는 오후 h:mm:ss를 일본어로 보여 준다. --%>
		<%-- 集計窓の下の時刻。yyyy/MM/dd (曜日) 午前または午後 h:mm:ss を日本語で見せる。 --%>
		function reportStamp() {
			var now = new Date();
			var days = [ '日<%--일--%>', '月<%--월--%>', '火<%--화--%>', '水<%--수--%>', '木<%--목--%>', '金<%--금--%>', '土<%--토--%>' ];
			var hour = now.getHours();
			var ampm = hour < 12 ? '午前<%--오전--%>' : '午後<%--오후--%>';
			var shown = hour % 12 || 12;
			return now.getFullYear() + '/' + pad2(now.getMonth() + 1) + '/' + pad2(now.getDate())
					+ ' (' + days[now.getDay()] + ') ' + ampm + ' ' + shown + ':'
					+ pad2(now.getMinutes()) + ':' + pad2(now.getSeconds());
		}

		<%-- 월, 일, 분, 초를 두 자리로 맞춘다. --%>
		<%-- 月、日、分、秒を二桁に合わせる。 --%>
		function pad2(value) {
			return ('0' + value).slice(-2);
		}

		<%-- 조회가 거절되면 결과 창을 닫고 이전 표를 지운다. --%>
		<%-- 照会が拒まれると結果窓を閉じ、前の表を消す。 --%>
		function clearGrid() {
			lastResult = null;
			closeReport();
			document.getElementById('reportHead').innerHTML = '';
			document.getElementById('reportBody').innerHTML = '';
			document.getElementById('reportTable').hidden = false;
			var box = document.getElementById('reportCompare');
			box.hidden = true;
			box.innerHTML = '';
		}


		<%-- 거래처, 출하창고, 품목은 공통 조회 창에서 고른다. 품목은 첫 번째 선택만 조건으로 쓴다. --%>
		<%-- 取引先、出荷倉庫、品目は共通照会窓で選ぶ。品目は最初の選択だけ条件に使う。 --%>
		function openPartner() {
			CommonLookup.open('partner', function(row) {
				partnerId = row.businessPartnerId;
				document.getElementById('partnerName').value = row.businessPartnerName || '';
			});
		}
		function openWarehouse() {
			CommonLookup.open('warehouse', function(row) {
				warehouseId = row.warehousePk;
				document.getElementById('warehouseName').value = row.warehouseName || '';
			});
		}
		function openItem() {
			CommonLookup.open('item', function(rows) {
				var row = rows && rows.length ? rows[0] : null;
				if (!row)
					return;
				itemId = row.itemPk;
				document.getElementById('itemCode').value = row.itemCode || '';
			});
		}
		<%-- 지우면 이름과 아이디를 같이 비워 그 조건 없이 조회하게 한다. --%>
		<%-- 消すと名前とIDを一緒に空にし、その条件なしで照会させる。 --%>
		function clearPartner() { partnerId = null; document.getElementById('partnerName').value = ''; }
		function clearWarehouse() { warehouseId = null; document.getElementById('warehouseName').value = ''; }
		function clearItem() { itemId = null; document.getElementById('itemCode').value = ''; }

		<%-- 집계조건 칸을 다시 그린다. 번호는 1부터이고 돋보기로만 고른다. --%>
		<%-- 集計条件の枠を描き直す。番号は1からで、虫眼鏡でだけ選ぶ。 --%>
		function renderGroupRows() {
			var host = document.getElementById('groupRows');
			host.innerHTML = groupRows.map(function(row, index) {
				return '<div class="form-row"><label>集計条件' + (index + 1) + '<%--집계조건--%></label>'
						+ '<div class="field-line grow">'
						+ '<button type="button" class="icon-btn" onclick="openGroup(' + index + ')"><i class="mdi mdi-magnify"></i></button>'
						+ '<input type="text" readonly placeholder="集計条件' + (index + 1) + '" value="' + esc(row.name) + '">'
						+ '<button type="button" class="icon-btn" onclick="clearGroupRow(' + index + ')"><i class="mdi mdi-close"></i></button>'
						+ '</div></div>';
			}).join('');
		}

		<%-- 칸이 모두 채워지면 빈 칸을 하나 더한다. 다섯 칸을 넘기지 않고, 빈 칸이 두 개 이어지면 마지막 빈 칸을 지운다. 처음 두 칸은 비어 있어도 남긴다. --%>
		<%-- 枠が全部埋まると空枠を一つ足す。5枠を超えず、空枠が二つ続くと最後の空枠を消す。最初の2枠は空でも残す。 --%>
		function ensureGroupRow() {
			var filled = groupRows.length > 0 && groupRows.every(function(row) { return !!row.code; });
			if (filled && groupRows.length < 5)
				groupRows.push({ code : '', name : '' });
			while (groupRows.length > 2 && !groupRows[groupRows.length - 1].code && !groupRows[groupRows.length - 2].code)
				groupRows.pop();
			renderGroupRows();
		}

		<%-- 다른 칸이 이미 고른 조건은 목록에서 빼 같은 조건을 두 번 고르지 못하게 한다. --%>
		<%-- 他の枠がすでに選んだ条件は一覧から外し、同じ条件を二度選べなくする。 --%>
		function openGroup(index) {
			var used = groupRows.map(function(row, rowIndex) {
				return rowIndex === index ? '' : row.code;
			});
			var choices = GROUP_CHOICES.filter(function(choice) {
				return used.indexOf(choice.code) < 0;
			});
			openChoice('集計条件' + (index + 1) + '<%--집계조건--%>', choices, function(choice) {
				groupRows[index] = { code : choice.code, name : choice.name };
				ensureGroupRow();
			});
		}

		<%-- 그 칸만 비우고 빈 칸이 남으면 다섯 칸 규칙을 다시 적용한다. --%>
		<%-- その枠だけ空にし、空枠が残れば5枠の規則を掛け直す。 --%>
		function clearGroupRow(index) {
			groupRows[index] = { code : '', name : '' };
			ensureGroupRow();
		}

		<%-- 거래유형은 전체, 부가세율 적용, 부가세율 미적용이다. 전체를 고르면 조건에서 빼 빈 칸으로 둔다. --%>
		<%-- 取引類型は全体、付加税率適用、付加税率不適用である。全体を選ぶと条件から外して空欄にする。 --%>
		function openTransaction() {
			openChoice('取引類型<%--거래유형--%>', [
				{ code : '', name : '全体<%--전체--%>' },
				{ code : 'VAT', name : '付加税率適用<%--부가세율 적용--%>' },
				{ code : 'NO_VAT', name : '付加税率不適用<%--부가세율 미적용--%>' }
			], function(choice) {
				transactionType = choice.code;
				document.getElementById('transactionName').value = choice.code ? choice.name : '';
			});
		}

		<%-- 거래유형을 비워 전체로 조회하게 한다. --%>
		<%-- 取引類型を空にして全体で照会させる。 --%>
		function clearTransaction() {
			transactionType = '';
			document.getElementById('transactionName').value = '';
		}

		<%-- 정렬을 고르면 그 기준으로 바로 다시 조회한다. 설정과 그래프는 두지 않는다. --%>
		<%-- 並べ替えを選ぶとその基準ですぐ照会し直す。設定とグラフは置かない。 --%>
		function openSort() {
			openChoice('並べ替え<%--정렬기준--%>', [
				{ code : 'DATE', name : '日付<%--일자--%>' },
				{ code : 'PARTNER', name : '取引先<%--거래처--%>' },
				{ code : 'ITEM', name : '品目<%--품목--%>' },
				{ code : 'QTY', name : '数量<%--수량--%>' },
				{ code : 'SUPPLY', name : '供給価額<%--공급가액--%>' },
				{ code : 'TOTAL', name : '合計<%--합계--%>' }
			], function(choice) {
				sortKey = choice.code;
				search();
			});
		}

		<%-- 집계조건, 거래유형, 정렬이 같이 쓰는 선택 창이다. --%>
		<%-- 集計条件、取引類型、並べ替えが一緒に使う選択窓である。 --%>
		function openChoice(title, choices, onSelect) {
			document.getElementById('choiceTitle').textContent = title;
			document.getElementById('choiceBody').innerHTML = choices.map(function(choice, index) {
				return '<button type="button" data-index="' + index + '">' + choice.name + '</button>';
			}).join('');
			document.getElementById('choiceBody').onclick = function(event) {
				var button = event.target.closest('button');
				if (!button)
					return;
				onSelect(choices[Number(button.getAttribute('data-index'))]);
				closeChoice();
			};
			document.getElementById('choiceOverlay').classList.add('active');
		}
		<%-- 선택 창만 닫고 조건은 그대로 둔다. --%>
		<%-- 選択窓だけ閉じ、条件はそのままにする。 --%>
		function closeChoice() {
			document.getElementById('choiceOverlay').classList.remove('active');
		}

		<%-- 금일, 전일, 금주, 전주, 금월, 전월, 전월+금월은 기간을 계산한 뒤 바로 검색한다. 한 주는 월요일에 시작한다. --%>
		<%-- 今日、前日、今週、先週、今月、前月、前月+今月は期間を計算したあとすぐ検索する。一週は月曜日に始まる。 --%>
		function setToday() { var day = today(); setRange(day, day); }
		function setYesterday() { var day = addDays(today(), -1); setRange(day, day); }
		function setThisWeek() { var day = today(); setRange(monday(day), day); }
		function setLastWeek() {
			var start = addDays(monday(today()), -7);
			setRange(start, addDays(start, 6));
		}
		function setThisMonth() {
			var day = today();
			setRange(new Date(day.getFullYear(), day.getMonth(), 1), day);
		}
		function setLastMonth() {
			var day = today();
			setRange(new Date(day.getFullYear(), day.getMonth() - 1, 1), new Date(day.getFullYear(), day.getMonth(), 0));
		}
		function setTwoMonths() {
			var day = today();
			setRange(new Date(day.getFullYear(), day.getMonth() - 1, 1), day);
		}
		<%-- 기간 버튼은 날짜를 넣은 뒤 바로 검색한다. 다시 작성은 이 함수를 타지 않는다. --%>
		<%-- 期間ボタンは日付を入れたあとすぐ検索する。再作成はこの関数を通らない。 --%>
		function setRange(from, to) {
			document.getElementById('fromDate').value = fmt(from);
			document.getElementById('toDate').value = fmt(to);
			search();
		}
		<%-- 시각을 떼고 날짜만 쓴다. 금주의 시작은 월요일이고 일요일은 그 주의 마지막이다. --%>
		<%-- 時刻を外して日付だけ使う。今週の始まりは月曜日であり、日曜日はその週の最後である。 --%>
		function today() {
			var now = new Date();
			return new Date(now.getFullYear(), now.getMonth(), now.getDate());
		}
		function addDays(date, days) {
			var next = new Date(date.getTime());
			next.setDate(next.getDate() + days);
			return next;
		}
		function monday(date) {
			var day = date.getDay();
			return addDays(date, day === 0 ? -6 : 1 - day);
		}
		function fmt(date) {
			var month = ('0' + (date.getMonth() + 1)).slice(-2);
			var day = ('0' + date.getDate()).slice(-2);
			return date.getFullYear() + '-' + month + '-' + day;
		}

		<%-- 다시 작성은 구분을 선택안함으로, 집계조건을 빈 두 칸으로, 날짜를 화면을 열 때의 값으로 되돌린다. 조회하지 않는다. --%>
		<%-- 再作成は区分を選択なしに、集計条件を空の2枠に、日付を画面を開いたときの値へ戻す。照会しない。 --%>
		function resetConditions() {
			currentTab = 'STATUS';
			Array.prototype.forEach.call(document.querySelectorAll('#statusTabs button'), function(button) {
				button.classList.toggle('active', button.getAttribute('data-tab') === 'STATUS');
			});
			document.getElementById('viewMode').value = '';
			compareMode = 'NONE';
			setSeg('compareSeg', 'NONE');
			clearTransaction();
			setSeg('currencySeg', 'ALL');
			currencyScope = 'ALL';
			clearWarehouse();
			clearPartner();
			clearItem();
			groupRows = [ { code : '', name : '' }, { code : '', name : '' } ];
			renderGroupRows();
			sortKey = 'DATE';
			document.getElementById('fromDate').value = document.getElementById('fromDate').getAttribute('data-default');
			document.getElementById('toDate').value = document.getElementById('toDate').getAttribute('data-default');
			applyTab();
			closeReport();
			showMessage('');
		}

		<%-- 다시 작성할 때 비교기간과 내외자 버튼의 선택 표시를 처음 값에 맞춘다. --%>
		<%-- 再作成のとき比較期間と内外貨ボタンの選択表示を初期値に合わせる。 --%>
		function setSeg(id, value) {
			Array.prototype.forEach.call(document.getElementById(id).querySelectorAll('button'), function(button) {
				button.classList.toggle('active', button.getAttribute('data-value') === value);
			});
		}

		<%-- 기준 수량에서 비교 수량을 뺀다. 좌우 비교표는 각 기간의 수량만 보여 이 값을 쓰지 않는다. --%>
		<%-- 基準数量から比較数量を引く。左右の比較表は各期間の数量だけ見せ、この値を使わない。 --%>
		function diff(base, compare) {
			if (compare === null || compare === undefined || compare === '')
				return null;
			return Number(base || 0) - Number(compare || 0);
		}
		<%-- 현황 숫자의 자릿수. 집계는 수량과 금액을 따로 맞춘다. --%>
		<%-- 現状の数字の桁。集計は数量と金額を別に合わせる。 --%>
		function money(value) {
			if (value === null || value === undefined || value === '')
				return '';
			var number = Number(value);
			if (isNaN(number))
				return '';
			return number.toLocaleString('ja-JP', { maximumFractionDigits : 4 });
		}
		<%-- 거래처명과 품목명에 있는 특수문자가 표를 깨지 않게 바꾼다. --%>
		<%-- 取引先名と品目名にある特殊文字が表を壊さないよう変える。 --%>
		function esc(value) {
			return String(value == null ? '' : value).replace(/[&<>"']/g, function(ch) {
				return { '&' : '&amp;', '<' : '&lt;', '>' : '&gt;', '"' : '&quot;', "'" : '&#39;' }[ch];
			});
		}
		<%-- 거절 메시지와 1,000건 안내는 필터 아래에 둔다. 결과 창 안이 아니다. --%>
		<%-- 拒否メッセージと1,000件の案内はフィルタの下に置く。結果窓の中ではない。 --%>
		function showMessage(text) {
			document.getElementById('statusMessage').textContent = text || '';
		}

		applyTab();
		renderGroupRows();
	</script>
	<%-- 비교 표는 창 너비에 맞춘다. 현황 표의 최소 너비보다 뒤에 두어, 비교일 때는 그 최소 너비를 끈다. --%>
	<%-- 比較表は窓幅に合わせる。現状表の最小幅より後に置き、比較のときはその最小幅を消す。 --%>
	<style>
		.page-title { font-size: 1.25rem; font-weight: 700; color: #0B1026; margin-bottom: 20px; display: flex; align-items: center; gap: 10px; }
		.page-title i { color: #4B88FF; font-size: 24px; }
		.list-wrap { background: #fff; border-radius: 14px; border: 1px solid #e2e8f0; box-shadow: 0 10px 25px -5px rgba(75, 136, 255, .08); overflow: hidden; }
		.inq-bar { display: flex; flex-wrap: wrap; gap: 12px 18px; align-items: center; padding: 18px 22px 8px; }
		.inq-tabs { display: inline-flex; }
		.inq-tabs button, .seg button { border: 1px solid #e2e8f0; background: #fff; color: #64748b; font-weight: 700; padding: 8px 14px; cursor: pointer; }
		.inq-tabs button:first-child, .seg button:first-child { border-radius: 8px 0 0 8px; }
		.inq-tabs button:last-child, .seg button:last-child { border-radius: 0 8px 8px 0; }
		.inq-tabs button + button, .seg button + button { margin-left: -1px; }
		.inq-tabs button.active, .seg button.active { background: #4B88FF; color: #fff; border-color: #4B88FF; position: relative; }
		.seg { display: inline-flex; flex-wrap: wrap; }
		.field-line { display: flex; align-items: center; gap: 6px; }
		.status-form { display: flex; flex-direction: column; gap: 10px; padding: 8px 22px 4px; }
		.form-row { display: grid; grid-template-columns: 120px minmax(0, 1fr); align-items: center; gap: 12px; }
		.form-row > label { font-size: 13px; font-weight: 700; color: #334155; }
		.form-row select, .field-line input { border: 1px solid #e2e8f0; border-radius: 8px; padding: 8px 10px; font-size: 13px; background: #fff; outline: none; }
		.form-row select:focus, .field-line input:focus { border-color: #4B88FF; }
		.field-line.grow { flex: 1; }
		.field-line.grow input { flex: 1; min-width: 180px; }
		.date-mode { width: 120px; flex: 0 0 auto; }
		#groupRows .form-row + .form-row { margin-top: 10px; }
		.icon-btn { border: 1px solid #e2e8f0; background: #f8fafc; color: #1F3C88; width: 34px; height: 34px; border-radius: 8px; cursor: pointer; flex: 0 0 auto; }
		.btn-primary-sm, .btn-flat-sm {
			display: inline-flex; align-items: center; justify-content: center; gap: 4px; cursor: pointer;
			border-radius: 8px; font-weight: 700; font-size: 13px; padding: 8px 14px;
		}
		.btn-primary-sm { background: #4B88FF; color: #fff; border: none; }
		.btn-primary-sm:hover { background: #1F3C88; }
		.btn-flat-sm { background: #f8fafc; border: 1px solid #e2e8f0; color: #64748b; }
		.btn-flat-sm:hover { background: #eef2f7; }
		.sale-foot { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; padding: 12px 22px; }
		.inq-message { min-height: 20px; margin: 0 22px; color: #b91c1c; font-size: 13px; }
		.list-table-wrap { width: 100%; overflow-x: auto; }
		.list-table { width: 100%; border-collapse: collapse; min-width: 980px; }
		.list-table th, .list-table td { border-bottom: 1px solid #e2e8f0; padding: 9px 10px; font-size: 13px; text-align: left; white-space: nowrap; }
		.list-table th { background: #f8fafc; color: #64748b; font-weight: 700; position: sticky; top: 0; }
		.col-num { text-align: right; font-variant-numeric: tabular-nums; }
		.date-link { border: none; background: transparent; color: #1F3C88; font-weight: 700; cursor: pointer; padding: 0; font-size: 13px; }
		.date-link:hover { text-decoration: underline; }
		.empty-cell { text-align: center; color: #64748b; padding: 28px; }
		.subtotal-row td { background: #f7faff; font-weight: 700; color: #1F3C88; }
		.total-row td { background: #f8fafc; font-weight: 800; }
		.modal-overlay { display: none; position: fixed; inset: 0; background: rgba(11, 16, 38, .45); align-items: flex-start; justify-content: center; padding: 6vh 16px; z-index: 1300; overflow: auto; }
		.modal-overlay.active { display: flex; }
		.choice-card { width: min(420px, 96vw); }
		.choice-body { display: flex; flex-direction: column; padding: 8px; }
		.choice-body button { text-align: left; background: #fff; border: none; border-bottom: 1px solid #e2e8f0; padding: 12px 14px; font-weight: 700; cursor: pointer; }
		.choice-body button:hover { background: #f7faff; }
		.choice-extra { display: flex; align-items: center; gap: 8px; padding: 12px; }
		.choice-extra select { border: 1px solid #e2e8f0; border-radius: 8px; padding: 8px 10px; }
		.lookup-head { display: flex; align-items: center; gap: 12px; padding: 14px 16px; border-bottom: 1px solid #e2e8f0; }
		.lookup-head h3 { font-size: 1.05rem; font-weight: 800; color: #0B1026; margin-right: auto; }
		.modal-close { border: none; background: #f1f5f9; color: #64748b; width: 32px; height: 32px; border-radius: 50%; cursor: pointer; }
		.sale-input-view { width: min(1400px, 98vw); height: min(92vh, 980px); display: flex; flex-direction: column; background: #fff; border-radius: 14px; overflow: hidden; }
		.sale-input-frame { flex: 1; width: 100%; border: 0; background: #f4f7fc; }
		#saleInputOverlay { z-index: 1500; }
		.report-overlay { position: fixed; inset: 0; background: rgba(11, 16, 38, .45); z-index: 1400; display: flex; align-items: flex-start; justify-content: center; padding: 4vh 16px; overflow: auto; }
		.report-overlay[hidden] { display: none; }
		.report-window { width: min(1100px, 96vw); background: #fff; border: 1px solid #d7dee8; box-shadow: 0 18px 40px rgba(15, 23, 42, .2); }
		.report-top { display: flex; align-items: center; gap: 10px; padding: 10px 16px; border-bottom: 1px solid #e5eaf1; }
		.report-close { border: none; background: transparent; font-size: 22px; line-height: 1; cursor: pointer; color: #64748b; }
		.report-title { font-weight: 800; font-size: 16px; color: #0B1026; }
		.report-mark { margin-left: auto; font-size: 28px; font-weight: 800; letter-spacing: 2px; color: #0B1026; }
		.report-mark[hidden] { display: none; }
		.report-company { padding: 12px 18px 0; font-size: 13px; }
		.report-period { text-align: center; font-weight: 700; padding: 6px 18px 12px; }
		.report-window.is-summary .report-top { position: relative; justify-content: center; border-bottom: none; padding-top: 18px; }
		.report-window.is-summary .report-close { position: absolute; left: 12px; top: 10px; }
		.report-window.is-summary .report-title { font-size: 28px; letter-spacing: 1px; }
		.report-window.is-summary .report-meta { display: flex; justify-content: space-between; align-items: flex-end; padding: 4px 16px 10px; }
		.report-window.is-summary .report-company, .report-window.is-summary .report-period { padding: 0; text-align: left; }
		.report-foot { display: flex; justify-content: space-between; padding: 8px 12px 14px; font-size: 12px; color: #334155; }
		.report-foot[hidden] { display: none; }
		.report-sheet { overflow: auto; max-height: 68vh; }
		.report-window.is-compare { width: min(1360px, 98vw); }
		.report-compare[hidden], .report-table[hidden] { display: none; }
		.compare-table { width: 100%; min-width: 0; table-layout: fixed; }
		.report-window.is-summary .compare-table { min-width: 0; }
		.compare-table th, .compare-table td { overflow: hidden; text-overflow: ellipsis; }
		.compare-table .period-head th { background: #fff; font-size: 13px; font-weight: 800; color: #0B1026; }
		.compare-table td.compare-split, .compare-table th.compare-split { border-left: 2px solid #94a3b8; }
		.report-table td.month-row { font-weight: 800; background: #f7f9fc; }
		.report-table { width: 100%; border-collapse: collapse; min-width: 860px; }
		.report-table th, .report-table td { border: 1px solid #d7dee8; padding: 7px 8px; font-size: 12px; white-space: nowrap; }
		.report-table th { background: #f4f7fb; text-align: center; font-weight: 700; color: #334155; }
		.report-table td.num, .report-table th.num { text-align: right; font-variant-numeric: tabular-nums; }
		.report-table .month-row td { font-weight: 800; background: #f7f9fc; }
		.report-table td.group-label { color: #1d4ed8; font-weight: 700; }
		.report-table tr.subtotal-row td, .report-table tr.grand-row td { font-weight: 800; color: #0B1026; }
		.report-window.is-summary .report-table { min-width: 640px; }
		.report-window.is-summary .compare-table,
		.report-window.is-compare .compare-table { min-width: 0; width: 100%; table-layout: fixed; }
		.report-empty { text-align: center; color: #64748b; padding: 28px; }
		@media (max-width: 1100px) {
			.form-row { grid-template-columns: 96px minmax(0, 1fr); }
		}
	</style>
</body>
</html>
