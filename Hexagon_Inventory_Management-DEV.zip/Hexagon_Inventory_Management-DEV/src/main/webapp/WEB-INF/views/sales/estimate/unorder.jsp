<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="my" tagdir="/WEB-INF/tags"%>
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>未受注状況 - Hexagon ERP</title>

<style>
* {
	box-sizing: border-box;
}

body {
	margin: 0;
	font: 13px "Yu Gothic", Meiryo, "Malgun Gothic", Arial, sans-serif;
	color: #294263;
	background: #f4f7fd;
}

button, input, select {
	font: inherit;
}

button {
	cursor: pointer;
}

button:disabled {
	opacity: .5;
	cursor: not-allowed;
}

[hidden] {
	display: none !important;
}

.layout {
	display: flex;
	min-height: 100vh;
}

.main {
	flex: 1;
	min-width: 0;
	height: 100vh;
	overflow: auto;
}

.content {
	padding: 19px 20px 60px;
}

.top, .flex, .meta, .modal-head, .modal-foot, .lookup-field, .code-group
	{
	display: flex;
	align-items: center;
	gap: 9px;
}

.top, .meta, .modal-head, .modal-foot {
	justify-content: space-between;
}

.top, .flex, .modal-foot {
	flex-wrap: wrap;
}

.top {
	margin-bottom: 16px;
}

.top h1 {
	margin: 0;
	font-size: 23px;
	color: #1d3251;
}

.btn {
	min-height: 36px;
	padding: 7px 13px;
	border: 1px solid #d5e0ef;
	border-radius: 11px;
	background: #fff;
	color: #385679;
	white-space: nowrap;
}

.btn:hover:not (:disabled ), .icon-btn:hover {
	background: #edf3ff;
}

.btn.primary {
	background: #2c51dd;
	color: #fff;
	border-color: #2c51dd;
}

.input, .select {
	width: 100%;
	min-width: 0;
	height: 39px;
	padding: 7px 11px;
	border: 1px solid #d6e1ef;
	border-radius: 9px;
	color: #304b72;
	background: #fff;
	outline: none;
}

.input:focus, .select:focus {
	border-color: #4b76e8;
	box-shadow: 0 0 0 2px rgba(45, 85, 220, .09);
}

.input::placeholder {
	color: #a8b8cc;
}

.input[readonly] {
	background: #f2f5fa;
}

.message {
	margin: 10px 0;
	min-height: 18px;
	color: #426fc0;
}

.message.error {
	color: #c23e53;
}

.hint {
	font-size: 11px;
	color: #8397b2;
}

/* 검색 결과 */
/* 検索結果 */
.report {
	padding: 18px 15px;
	background: #fff;
	border: 1px solid #dbe4f0;
	border-radius: 14px;
}

.report-title {
	margin: 3px 0 23px;
	text-align: center;
	font-size: 25px;
	color: #193153;
}

.meta {
	margin-bottom: 10px;
	color: #617b9e;
}

.table-wrap {
	width: 100%;
	overflow-x: auto;
}

.result-table {
	width: 100%;
	border-collapse: collapse;
	table-layout: fixed;
	font-size: 12px;
}

.result-table th, .result-table td {
	padding: 9px 6px;
	border: 1px solid #d9e2ef;
	overflow-wrap: anywhere;
}

.result-table th {
	background: #edf2fa;
	text-align: center;
}

.result-table tbody tr:nth-child(even) {
	background: #fafbfd;
}

.result-table tbody tr:hover {
	background: #ebf2ff;
}

.result-table tfoot td {
	background: #e6edfa;
	font-weight: bold;
}

.right {
	text-align: right;
}

.center {
	text-align: center;
}

.link {
	border: 0;
	padding: 0;
	background: transparent;
	color: #285bb4;
	text-decoration: underline;
}

.link:hover {
	color: #153f97;
}

.count {
	margin-top: 10px;
	text-align: right;
	color: #7188a7;
}

/* 모달 */
/* モーダル */
.overlay {
	display: none;
	position: fixed;
	inset: 0;
	z-index: 8000;
	padding: 14px;
	align-items: center;
	justify-content: center;
	background: rgba(13, 25, 48, .55);
}

.overlay.open {
	display: flex !important;
}

.modal {
	display: flex;
	flex-direction: column;
	width: min(1230px, 96vw);
	max-height: 94vh;
	min-height: 0;
	overflow: hidden;
	border-radius: 15px;
	background: #f7f9fd;
	box-shadow: 0 15px 45px rgba(0, 0, 0, .22);
}

.modal-head {
	padding: 13px 20px;
	background: #254bd4;
	color: #fff;
}

.modal-head h2 {
	margin: 0;
	font-size: 18px;
}

.modal-tabs {
	padding: 10px 20px;
	background: #fff;
	border-bottom: 1px solid #dfe7f2;
}

.modal-tabs span {
	display: inline-block;
	padding: 6px 12px;
	border-bottom: 2px solid #2c54d9;
	color: #2856b5;
	font-weight: bold;
}

.modal-body {
	flex: 1;
	min-height: 0;
	overflow-y: auto;
	padding: 16px;
}

.modal-foot {
	padding: 11px 16px;
	border-top: 1px solid #dfe6f2;
	background: #fff;
}

.card {
	padding: 17px;
	border: 1px solid #dbe5f1;
	border-radius: 14px;
	background: #fff;
}

.search-field {
	display: grid;
	grid-template-columns: 170px minmax(0, 1fr);
	gap: 13px;
	align-items: center;
	min-height: 57px;
}

.search-field>label, .search-label {
	color: #5f7899;
}

.lookup-field {
	min-width: 0;
}

.lookup-field .input {
	flex: 1;
}

.icon-btn {
	width: 40px;
	min-width: 40px;
	height: 39px;
	border: 1px solid #d7e2f1;
	border-radius: 9px;
	background: #fff;
	color: #2b5cc0;
	font-size: 20px;
}

.range, .date-fields {
	display: flex;
	align-items: center;
	gap: 9px;
}

.range .input {
	flex: 1;
}

.date-fields .input {
	max-width: 230px;
}

.radio-group {
	display: flex;
	align-items: center;
	gap: 20px;
}

.radio-group label {
	cursor: pointer;
}

.radio-group input {
	accent-color: #3156df;
}

.preset {
	padding: 8px;
	border: 0;
	background: transparent;
	border-radius: 8px;
	color: #385c8e;
}

.preset:hover {
	background: #eaf1ff;
}

/* 품목/기준정보 조회 */
/* 品目／マスター検索 */
#lookupOverlay {
	z-index: 9800;
}

.lookup-modal {
	width: min(850px, 95vw);
}

.lookup-table {
	width: 100%;
	border-collapse: collapse;
	background: #fff;
}

.lookup-table th, .lookup-table td {
	padding: 10px;
	border: 1px solid #d9e3ef;
}

.lookup-table th {
	background: #edf2fa;
}

.lookup-table tbody tr:hover {
	background: #eaf2ff;
	cursor: pointer;
}

.stock-value {
	color: #235db7;
	font-weight: bold;
	text-align: right;
}

/* 견적서 수정 모달 */
/* 見積書の編集モーダル */
#editOverlay {
	z-index: 9000;
}

.edit-grid {
	display: grid;
	grid-template-columns: 1fr 1fr;
	gap: 12px 20px;
}

.edit-field {
	display: grid;
	grid-template-columns: 98px minmax(0, 1fr);
	gap: 9px;
	align-items: center;
}

.edit-field.wide {
	grid-column: 1/-1;
}

.edit-field>label {
	color: #647c9c;
}

.code-group {
	min-width: 0;
}

.code-group .input {
	flex: 1;
	width: 30%;
}

.edit-toolbar {
	display: flex;
	align-items: center;
	gap: 9px;
	margin: 12px 0;
}

.edit-table {
	width: 100%;
	min-width: 1040px;
	border-collapse: collapse;
	background: #fff;
}

.edit-table th, .edit-table td {
	padding: 6px;
	border: 1px solid #dce4ef;
}

.edit-table th {
	background: #edf2f9;
}

.edit-table


 


input




:not


 


(
[
type
=
checkbox
]


 


)
{
width




:


 


100%;
min-width




:


 


0;
height




:


 


33
px




;
padding




:


 


5
px




;
border




:


 


1
px


 


solid


 


#d6e1f0




;
border-radius




:


 


6
px




;
}
.edit-table input[readonly] {
	background: #f2f5fa;
}

.edit-table tfoot td {
	background: #edf2f9;
	font-weight: bold;
}

.locked {
	margin-bottom: 10px;
	padding: 12px;
	border-radius: 9px;
	background: #fff3df;
	color: #916229;
}

@media ( max-width :850px) {
	.search-field {
		grid-template-columns: 105px minmax(0, 1fr);
	}
	.edit-grid {
		grid-template-columns: 1fr;
	}
	.edit-field.wide {
		grid-column: auto;
	}
	.content {
		padding: 12px;
	}
}

/* 견적서조회(inquiry.jsp) 수정 모달과 동일한 화면 규격 */
/* 見積書照会（inquiry.jsp）の編集モーダルと同一の画面仕様 */
#editOverlay {
	padding: 18px;
}

#editOverlay .modal {
	width: min(1180px, 97vw);
	max-height: 93vh;
	background: #f5f7fb;
	border-radius: 14px;
}

#editOverlay .modal-head {
	padding: 12px 16px;
	background: #254bd4;
}

#editOverlay .modal-head h2 {
	margin: 0;
	font-size: 16px;
	font-weight: 700;
}

#editOverlay .modal-body {
	padding: 15px;
	background: #f5f7fb;
}

#editOverlay .card {
	margin-bottom: 12px;
	padding: 15px;
	border: 1px solid #dce4f0;
	border-radius: 14px;
	background: white;
}

#editOverlay .edit-grid {
	display: grid;
	grid-template-columns: 1fr 1fr;
	gap: 11px 17px;
}

#editOverlay .edit-line, #editOverlay .edit-field {
	display: grid;
	grid-template-columns: 98px minmax(0, 1fr);
	align-items: center;
	gap: 8px;
}

#editOverlay .edit-line.wide, #editOverlay .edit-field.wide {
	grid-column: 1/-1;
}

#editOverlay .edit-line>label, #editOverlay .edit-field>label {
	color: #60789b;
}

#editOverlay .field, #editOverlay .input, #editOverlay .select {
	width: 100%;
	min-width: 0;
	min-height: 35px;
	height: 35px;
	padding: 6px 10px;
	border: 1px solid #d8e2f0;
	border-radius: 9px;
	background: #fff;
	color: #304b73;
}

#editOverlay input[readonly] {
	background: #f3f5f9;
}

#editOverlay .code-set, #editOverlay .code-group {
	display: flex;
	align-items: center;
	gap: 4px;
	min-width: 0;
}

#editOverlay .code-set .field, #editOverlay .code-group .input {
	flex: 1;
	width: 40%;
}

#editOverlay .icon-btn {
	width: auto;
	min-width: 34px;
	height: 32px;
	padding: 5px 10px;
	border: 1px solid #d8e2f1;
	border-radius: 13px;
	background: #fff;
	color: #365176;
	font-size: 13px;
}

#editOverlay .btn {
	min-height: 32px;
	padding: 5px 13px;
	border-radius: 13px;
}

#editOverlay .btn.blue, #editOverlay .btn.primary {
	background: #3052e8;
	border-color: #3052e8;
	color: #fff;
}

#editOverlay .tools, #editOverlay .edit-toolbar {
	display: flex;
	gap: 8px;
	margin: 0 0 9px !important;
	align-items: center;
}

#editOverlay .table-wrap {
	overflow-x: auto;
	width: 100%;
}

#editOverlay .edit-table {
	width: 100%;
	min-width: 850px;
	border-collapse: collapse;
	background: #fff;
}

#editOverlay .edit-table th, #editOverlay .edit-table td {
	border: 1px solid #dce4ee;
	padding: 6px;
}

#editOverlay .edit-table th {
	text-align: center;
	background: #edf2f9;
}

#editOverlay

 

.edit-table

 

td

 

input


:not

 

(
[
type
=
checkbox
]

 

)
{
width


:

 

100%;
min-width


:

 

0;
min-height


:

 

35
px


;
height


:

 

35
px


;
padding


:

 

6
px

 

10
px


;
border


:

 

1
px

 

solid

 

#d8e2f0


;
border-radius


:

 

9
px


;
background


:

 

#fff


;
color


:

 

#304b73


;
}
#editOverlay .edit-table td input[readonly] {
	background: #f3f5f9;
}

#editOverlay .edit-table tfoot td {
	background: #edf2f9;
	font-weight: bold;
}

#editOverlay .footer, #editOverlay .modal-foot {
	display: flex;
	align-items: center;
	justify-content: flex-end;
	gap: 8px;
	padding: 10px 15px;
	background: #fff;
	border-top: 1px solid #dce4f0;
}

#editOverlay .footer>.hint, #editOverlay .modal-foot>.hint {
	display: none;
}

#editOverlay .locked {
	margin-bottom: 12px;
}

#editOverlay .message {
	font-size: 12px;
}

@media ( max-width :850px) {
	#editOverlay .edit-grid {
		grid-template-columns: 1fr;
	}
	#editOverlay .edit-line.wide, #editOverlay .edit-field.wide {
		grid-column: auto;
	}
}
</style>
</head>

<body>
    <div class="layout">
        <my:sideMenu />

        <div class="main">
            <main class="content">

                <div class="top">
                    <h1>未受注状況</h1>
                    <div class="flex">
                        <input id="quickKeyword" class="input" style="width: 200px" placeholder="入力後Enter">
                        <button id="openSearchBtn" type="button" class="btn primary">Search(F3)</button>
                    </div>
                </div>

                <section class="report">
                    <h2 class="report-title">未受注状況</h2>
                    <div class="meta">
                        <span>会社名：Hexagon ERP</span> <span id="reportPeriod">照会前</span>
                    </div>

                    <div class="table-wrap">
                        <table class="result-table">
                            <colgroup>
                                <col style="width: 16%">
                                <col style="width: 20%">
                                <col style="width: 8%">
                                <col style="width: 9%">
                                <col style="width: 12%">
                                <col style="width: 11%">
                                <col style="width: 12%">
                                <col style="width: 12%">
                            </colgroup>
                            <thead>
                                <tr>
                                    <th>日付-No.</th>
                                    <th>品目名（規格）</th>
                                    <th>数量</th>
                                    <th>未受注数量</th>
                                    <th>未受注供給価額</th>
                                    <th>未受注消費税</th>
                                    <th>取引先名</th>
                                    <th>新しい項目を追加</th>
                                </tr>
                            </thead>
                            <tbody id="resultRows">
                                <tr>
                                    <td colspan="8" class="center">検索（F8）を押して照会してください。</td>
                                </tr>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="2" class="center">合計</td>
                                    <td id="sumQuote" class="right">0</td>
                                    <td id="sumRemain" class="right">0</td>
                                    <td id="sumSupply" class="right">0</td>
                                    <td id="sumVat" class="right">0</td>
                                    <td colspan="2"></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>

                    <div id="resultCount" class="count">照会0行</div>
                </section>

                <p id="pageMessage" class="message" role="status"></p>
            </main>
        </div>
    </div>

    <!--
        미주문현황 검색 조건
        未受注見積書の検索条件
    -->
    <div id="searchOverlay" class="overlay open" role="dialog" aria-modal="true">

        <div class="modal">
            <div class="modal-head">
                <h2>未受注状況 - 検索条件</h2>
                <button id="closeSearchTop" type="button" class="btn">閉じる ×</button>
            </div>

            <div class="modal-tabs">
                <span>基本</span>
            </div>

            <div class="modal-body">
                <div class="card">

                    <div class="search-field">
                        <span class="search-label">区分</span>
                        <div class="radio-group">
                            <label> <input type="radio" name="groupType" value="ITEM"> 品目別
                            </label> <label> <input type="radio" name="groupType" value="LINE" checked> 明細行別
                            </label>
                        </div>
                    </div>

                    <div class="search-field">
                        <label for="baseDate">基準日（営業サイクル）</label> <input id="baseDate" type="date" class="input" style="max-width: 230px">
                    </div>

                    <div class="search-field">
                        <label for="voucherNo">見積No.</label> <input id="voucherNo" class="input" placeholder="見積番号を入力">
                    </div>

                    <div class="search-field">
                        <label for="warehouseKeyword">倉庫</label>
                        <div class="lookup-field">
                            <input id="warehouseKeyword" class="input" placeholder="倉庫コードまたは倉庫名">
                            <button type="button" class="icon-btn" data-search-lookup="warehouse" data-target="warehouseKeyword" aria-label="倉庫検索">⌕</button>
                        </div>
                    </div>

                    <div class="search-field">
                        <label for="partnerKeyword">取引先</label>
                        <div class="lookup-field">
                            <input id="partnerKeyword" class="input" placeholder="取引先コードまたは取引先名">
                            <button type="button" class="icon-btn" data-search-lookup="partner" data-target="partnerKeyword" aria-label="取引先検索">⌕</button>
                        </div>
                    </div>

                    <div class="search-field">
                        <label for="itemKeyword">品目コード</label>
                        <div class="lookup-field">
                            <input id="itemKeyword" class="input" placeholder="品目コードまたは品目名">
                            <button type="button" class="icon-btn" data-search-lookup="item" data-target="itemKeyword" aria-label="品目検索">⌕</button>
                        </div>
                    </div>

                    <div class="search-field">
                        <label for="managerKeyword">担当者</label>
                        <div class="lookup-field">
                            <input id="managerKeyword" class="input" placeholder="担当者コードまたは担当者名">
                            <button type="button" class="icon-btn" data-search-lookup="manager" data-target="managerKeyword" aria-label="担当者検索">⌕</button>
                        </div>
                    </div>

                    <div class="search-field">
                        <span class="search-label">未受注数量</span>
                        <div class="range">
                            <input id="minQty" type="number" min="0" step="any" class="input" placeholder="最小数量"> <span>~</span> <input id="maxQty" type="number" min="0" step="any" class="input" placeholder="最大数量">
                        </div>
                    </div>

                    <div class="search-field">
                        <label for="progressStatus">進捗状態</label> <select id="progressStatus" class="select">
                            <option value="">すべて</option>
                            <option value="OPEN">進行中</option>
                            <option value="PARTIAL">一部受注</option>
                        </select>
                    </div>

                    <p id="periodHint" class="hint">完了していない見積書のうち、未受注数量が残っている品目を検索します。</p>
                    <p id="searchMessage" class="message" role="status"></p>

                </div>
            </div>

            <div class="modal-foot">
                <div class="flex">
                    <button type="button" class="preset" data-period="today">本日</button>
                    <button type="button" class="preset" data-period="yesterday">前日</button>
                    <button type="button" class="preset" data-period="week">今週（本日まで）</button>
                    <button type="button" class="preset" data-period="lastweek">先週</button>
                    <button type="button" class="preset" data-period="month">今月（本日まで）</button>
                    <button type="button" class="preset" data-period="lastmonth">先月</button>
                    <button type="button" class="preset" data-period="last30">直近30日</button>
                    <button type="button" class="preset" data-period="year">今年</button>
                </div>

                <div class="flex">
                    <button id="resetSearchBtn" type="button" class="btn">再入力</button>
                    <button id="runSearchBtn" type="button" class="btn primary">検索（F8）</button>
                    <button id="closeSearchBottom" type="button" class="btn">閉じる</button>
                </div>
            </div>
        </div>
    </div>

    <!--
        품목, 거래처, 창고, 담당자 조회
        品目・取引先・倉庫・担当者の検索
    -->
    <div id="lookupOverlay" class="overlay" role="dialog" aria-modal="true">

        <div class="modal lookup-modal">
            <div class="modal-head">
                <h2 id="lookupTitle">マスター情報検索</h2>
                <button id="closeLookupBtn" type="button" class="btn">閉じる ×</button>
            </div>

            <div class="modal-body">
                <div class="flex" style="margin-bottom: 12px">
                    <input id="lookupKeyword" class="input" style="flex: 1" placeholder="コードまたは名称を入力">
                    <button id="lookupSearchBtn" type="button" class="btn primary">検索</button>
                </div>

                <div class="table-wrap">
                    <table class="lookup-table">
                        <thead id="lookupHead"></thead>
                        <tbody id="lookupRows"></tbody>
                    </table>
                </div>

                <p id="lookupMessage" class="message"></p>
            </div>
        </div>
    </div>

    <!--
        견적서입력 수정
        見積書入力の編集
    -->
    <div id="editOverlay" class="overlay" role="dialog" aria-modal="true">

        <div class="modal">
            <div class="modal-head">
                <h2 id="editTitle">見積書入力（編集）</h2>
                <button id="closeEditTop" type="button" class="btn">閉じる ×</button>
            </div>

            <div id="editBody" class="modal-body">
                <div id="editLocked" class="locked" hidden>関連する受注伝票または売上伝票があるため、照会のみ可能です。</div>

                <div class="card">
                    <div class="edit-grid">

                        <div class="edit-field">
                            <label for="edDate">日付</label> <input id="edDate" type="date" class="input">
                        </div>

                        <div class="edit-field">
                            <label>取引先</label>
                            <div class="code-group">
                                <input id="edPartnerCode" class="input" placeholder="取引先コード">
                                <button type="button" class="icon-btn" data-edit-lookup="partner">⌕</button>
                                <input id="edPartnerName" class="input" readonly>
                            </div>
                        </div>

                        <div class="edit-field">
                            <label>担当者</label>
                            <div class="code-group">
                                <input id="edManagerCode" class="input" placeholder="担当者コード">
                                <button type="button" class="icon-btn" data-edit-lookup="manager">⌕</button>
                                <input id="edManagerName" class="input" readonly>
                            </div>
                        </div>

                        <div class="edit-field">
                            <label>出荷倉庫</label>
                            <div class="code-group">
                                <input id="edWarehouseCode" class="input" placeholder="倉庫コード">
                                <button type="button" class="icon-btn" data-edit-lookup="warehouse">⌕</button>
                                <input id="edWarehouseName" class="input" readonly>
                            </div>
                        </div>

                        <div class="edit-field">
                            <label for="edTransaction">取引区分</label> <select id="edTransaction" class="select">
                                <option value="TAXABLE">消費税適用</option>
                                <option value="EXEMPT">免税</option>
                            </select>
                        </div>

                        <div class="edit-field">
                            <label>通貨 / 為替レート</label>
                            <div class="code-group">
                                <select id="edCurrency" class="select"></select> <input id="edRate" type="number" min="0" step="any" class="input">
                            </div>
                        </div>

                        <div class="edit-field">
                            <label for="edValid">有効期限</label> <input id="edValid" type="date" class="input">
                        </div>

                        <div class="edit-field">
                            <label>添付</label>
                            <div class="flex">
                                <a id="edAttachmentLink" href="#" target="_blank" rel="noopener" hidden> 添付ファイルをダウンロード </a> <input id="edAttachment" type="file" accept=".pdf,.png,.jpg,.jpeg,.txt,.docx,.xlsx">
                            </div>
                        </div>

                        <div class="edit-field wide">
                            <label for="edCustom">新しい項目を追加</label> <input id="edCustom" class="input" placeholder="追加情報">
                        </div>

                    </div>
                </div>

                <div class="edit-toolbar">
                    <button id="edAddRow" type="button" class="btn">＋ 行追加</button>
                    <button id="edDeleteRows" type="button" class="btn">選択行を削除</button>
                </div>

                <div class="table-wrap">
                    <table class="edit-table">
                        <thead>
                            <tr>
                                <th>選択</th>
                                <th>品目コード</th>
                                <th>品目名</th>
                                <th>規格</th>
                                <th>数量</th>
                                <th>単価</th>
                                <th>供給価額</th>
                                <th>消費税</th>
                                <th>合計金額</th>
                            </tr>
                        </thead>
                        <tbody id="edItems"></tbody>
                        <tfoot>
                            <tr>
                                <td colspan="6">合計</td>
                                <td id="edSupplySum" class="right">0</td>
                                <td id="edVatSum" class="right">0</td>
                                <td id="edTotalSum" class="right">0</td>
                            </tr>
                        </tfoot>
                    </table>
                </div>

                <p id="edMessage" class="message" role="status"></p>
            </div>

            <div class="modal-foot">
                <span class="hint">既存の見積書更新APIを使用</span>
                <div class="flex">
                    <button id="edSave" type="button" class="btn primary">保存(F8)</button>
                    <button id="closeEditBottom" type="button" class="btn">閉じる</button>
                </div>
            </div>
        </div>
    </div>

    <script>
(function () {
    "use strict";

    var API = "${pageContext.request.contextPath}"
            + "/sales/estimate/api";

    var sourceRows = [];
    var hasSearched = false;
    var periodStart = "";
    var periodEnd = "";
    var searchSerial = 0;

    var lookupType = "";
    var lookupCallback = null;
    var lookupSerial = 0;

    var editQuoteId = null;
    var editReadOnly = false;
    var editSaving = false;

    // 공통 함수
    // 共通関数

    function E(id) {
        return document.getElementById(id);
    }

    function text(v) {
        return v == null ? "" : String(v);
    }

    function value(id) {
        return E(id).value.trim();
    }

    function setValue(id, v) {
        E(id).value = text(v);
    }

    function number(v) {
        var n = Number(v);
        return isFinite(n) ? n : 0;
    }

    function money(v) {
        return number(v).toLocaleString("ja-JP", {
            maximumFractionDigits: 2
        });
    }

    function qty(v) {
        return number(v).toLocaleString("ja-JP", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 4
        });
    }

    function dateText(d) {
        return d.getFullYear() + "-"
            + ("0" + (d.getMonth() + 1)).slice(-2) + "-"
            + ("0" + d.getDate()).slice(-2);
    }

    function today() {
        var d = new Date();
        return new Date(
            d.getFullYear(),
            d.getMonth(),
            d.getDate()
        );
    }

    function notify(id, message, error) {
        E(id).textContent = message;
        E(id).className = error ? "message error" : "message";
    }

    function open(id) {
        E(id).classList.add("open");
    }

    function close(id) {
        E(id).classList.remove("open");
    }

    function cell(tr, content, className) {
        var td = document.createElement("td");
        td.textContent = text(content);
        if (className) td.className = className;
        tr.appendChild(td);
        return td;
    }

    function requestJson(url, options) {
        var settings = Object.assign({
            credentials: "same-origin",
            headers: { Accept: "application/json" }
        }, options || {});

        settings.headers = Object.assign(
            { Accept: "application/json" },
            settings.headers || {}
        );

        return fetch(url, settings).then(function (res) {
            return res.text().then(function (raw) {
                var data = null;

                try {
                    data = raw ? JSON.parse(raw) : null;
                } catch (ignore) {}

                if (!res.ok) {
                    throw new Error(
                        (data && data.message)
                        || raw.substring(0, 150)
                        || "HTTP " + res.status
                    );
                }

                if (data && data.success === false) {
                    throw new Error(
                        data.message || "リクエストに失敗しました"
                    );
                }

                return data;
            });
        });
    }

    // 검색창 열기 / 닫기
    // 検索欄を開く／閉じる

    function openSearch() {
        open("searchOverlay");
    }

    function closeSearch() {
        close("searchOverlay");
    }

    E("openSearchBtn").addEventListener("click", openSearch);
    E("closeSearchTop").addEventListener("click", closeSearch);
    E("closeSearchBottom").addEventListener("click", closeSearch);

    function resetSearch() {
        [
            "voucherNo",
            "warehouseKeyword",
            "partnerKeyword",
            "itemKeyword",
            "managerKeyword",
            "minQty",
            "maxQty"
        ].forEach(function (id) {
            setValue(id, "");
        });

        setValue("baseDate", dateText(today()));
        setValue("progressStatus", "");

        document.querySelector(
            'input[name="groupType"][value="LINE"]'
        ).checked = true;

        periodStart = "";
        periodEnd = "";

        E("periodHint").textContent =
            "完了していない見積書のうち、 "
            + "未受注数量が残っている品目を検索します。";

        notify("searchMessage", "", false);
    }

    E("resetSearchBtn").addEventListener(
        "click", resetSearch
    );

    // 날짜 단축 버튼
    // 日付のクイック選択ボタン

    function applyPeriod(kind) {
        var now = today();
        var start = new Date(now);
        var end = new Date(now);
        var mondayOffset = (now.getDay() + 6) % 7;

        if (kind === "yesterday") {
            start.setDate(start.getDate() - 1);
            end = new Date(start);
        } else if (kind === "week") {
            start.setDate(start.getDate() - mondayOffset);
        } else if (kind === "lastweek") {
            start.setDate(
                start.getDate() - mondayOffset - 7
            );
            end.setDate(
                end.getDate() - mondayOffset - 1
            );
        } else if (kind === "month") {
            start = new Date(
                now.getFullYear(), now.getMonth(), 1
            );
        } else if (kind === "lastmonth") {
            start = new Date(
                now.getFullYear(), now.getMonth() - 1, 1
            );
            end = new Date(
                now.getFullYear(), now.getMonth(), 0
            );
        } else if (kind === "last30") {
            start.setDate(start.getDate() - 29);
        } else if (kind === "year") {
            start = new Date(now.getFullYear(), 0, 1);
        }

        periodStart = dateText(start);
        periodEnd = dateText(end);

        setValue("baseDate", periodEnd);

        E("periodHint").textContent =
            "見積日 : " + periodStart
            + " ~ " + periodEnd;

        return search();
    }

    document.querySelectorAll("[data-period]")
        .forEach(function (button) {
            button.addEventListener("click", function () {
                applyPeriod(button.dataset.period);
            });
        });

    E("baseDate").addEventListener("change", function () {
        periodStart = "";
        periodEnd = "";
    });

    // Oracle 미주문현황 조회
    // Oracleから未受注見積書現況を取得

    function searchUrl() {
        var params = new URLSearchParams();

        var fields = {
            base_date: "baseDate",
            voucher_no: "voucherNo",
            warehouse_keyword: "warehouseKeyword",
            partner_keyword: "partnerKeyword",
            item_keyword: "itemKeyword",
            manager_keyword: "managerKeyword",
            min_unordered_qty: "minQty",
            max_unordered_qty: "maxQty",
            progress_status: "progressStatus"
        };

        Object.keys(fields).forEach(function (key) {
            var v = value(fields[key]);
            if (v !== "") params.set(key, v);
        });

        return API + "/unordered?" + params.toString();
    }

    function search() {
        var min = value("minQty");
        var max = value("maxQty");

        if (min && number(min) < 0) {
            notify("searchMessage",
                "最小数量は0以上にしてください。", true);
            return Promise.resolve();
        }

        if (max && number(max) < 0) {
            notify("searchMessage",
                "最大数量は0以上にしてください。", true);
            return Promise.resolve();
        }

        if (min && max && number(min) > number(max)) {
            notify("searchMessage",
                "最小数量が最大数量を超えています。", true);
            return Promise.resolve();
        }

        var serial = ++searchSerial;

        E("runSearchBtn").disabled = true;
        notify("searchMessage",
            "Oracleからデータを取得しています。", false);

        return requestJson(searchUrl()).then(function (data) {
            if (serial !== searchSerial) return;

            if (!Array.isArray(data)) {
                throw new Error("検索データが配列ではありません。");
            }

            sourceRows = data;
            hasSearched = true;

            render();
            closeSearch();

            E("reportPeriod").textContent =
                periodStart && periodEnd
                    ? periodStart + " ~ " + periodEnd
                    : "基準日 : " + value("baseDate");

            notify("searchMessage", "", false);
            notify("pageMessage",
                "未受注状況の照会が完了しました： "
                + data.length + "件の元品目行", false);

        }).catch(function (error) {
            if (serial !== searchSerial) return;

            notify("searchMessage",
                "照会に失敗しました： " + error.message, true);
            notify("pageMessage",
                "照会に失敗しました： " + error.message, true);

        }).then(function () {
            if (serial === searchSerial) {
                E("runSearchBtn").disabled = false;
            }
        });
    }

    E("runSearchBtn").addEventListener("click", search);

    // 라인별 / 품목별
    // 明細行別／品目別

    function currentGroup() {
        var radio = document.querySelector(
            'input[name="groupType"]:checked'
        );
        return radio ? radio.value : "LINE";
    }

    function filteredRows() {
        var keyword = value("quickKeyword").toLowerCase();

        return sourceRows.filter(function (row) {
            var d = text(row.quote_date).substring(0, 10);

            if (periodStart && d < periodStart) return false;
            if (periodEnd && d > periodEnd) return false;

            if (!keyword) return true;

            return [
                row.quote_date,
                row.voucher_no,
                row.partner_name,
                row.manager_name,
                row.warehouse_name,
                row.item_code_snap,
                row.item_name_snap,
                row.spec_snap,
                row.custom_data
            ].map(text).join(" ")
             .toLowerCase().indexOf(keyword) >= 0;
        });
    }

    // 품목별:
    // 品目別集計：
    // 같은 견적서 안의 동일 품목을 합산한다.
    // 同じ見積書内の同一品目を合算します。
    // 집계 기준:
    // 集計キー：
    // quote_id + item_id + 코드 + 이름 + 규격
    // quote_id＋item_id＋コード＋名称＋規格
    function groupByItem(list) {
        var groups = new Map();

        list.forEach(function (row) {
            var key = [
                row.quote_id,
                row.item_id,
                row.item_code_snap,
                row.item_name_snap,
                row.spec_snap
            ].map(text).join("|");

            if (!groups.has(key)) {
                groups.set(key, {
                    quote_id: row.quote_id,
                    quote_date: row.quote_date,
                    voucher_no: row.voucher_no,
                    item_id: row.item_id,
                    item_code_snap: row.item_code_snap,
                    item_name_snap: row.item_name_snap,
                    spec_snap: row.spec_snap,
                    partner_name: row.partner_name,
                    custom_data: row.custom_data,
                    quote_qty: 0,
                    ordered_qty: 0,
                    unordered_qty: 0,
                    unordered_supply_amount: 0,
                    unordered_vat_amount: 0
                });
            }

            var group = groups.get(key);

            group.quote_qty += number(row.quote_qty);
            group.ordered_qty += number(row.ordered_qty);
            group.unordered_qty += number(row.unordered_qty);
            group.unordered_supply_amount +=
                number(row.unordered_supply_amount);
            group.unordered_vat_amount +=
                number(row.unordered_vat_amount);
        });

        return Array.from(groups.values());
    }

    function render() {
        if (!hasSearched) return;

        var rows = filteredRows();

        if (currentGroup() === "ITEM") {
            rows = groupByItem(rows);
        }

        var body = E("resultRows");
        body.textContent = "";

        var sums = {
            quote: 0,
            remain: 0,
            supply: 0,
            vat: 0
        };

        if (!rows.length) {
            var empty = document.createElement("tr");
            cell(empty,
                "条件に一致する未受注状況がありません。",
                "center").colSpan = 8;
            body.appendChild(empty);
        }

        rows.forEach(function (row) {
            var tr = document.createElement("tr");

            var dateTd = document.createElement("td");
            var link = document.createElement("button");

            link.type = "button";
            link.className = "link";
            link.textContent =
                text(row.quote_date).substring(0, 10)
                + " - " + text(row.voucher_no);
            link.title = "見積書入力（編集）";

            link.addEventListener("click", function () {
                openEdit(row.quote_id);
            });

            dateTd.appendChild(link);
            tr.appendChild(dateTd);

            var itemName = text(row.item_name_snap);

            if (row.spec_snap) {
                itemName += " [" + row.spec_snap + "]";
            }

            cell(tr, itemName);
            cell(tr, qty(row.quote_qty), "right");
            cell(tr, qty(row.unordered_qty), "right");
            cell(tr, money(row.unordered_supply_amount), "right");
            cell(tr, money(row.unordered_vat_amount), "right");
            cell(tr, row.partner_name);
            cell(tr, row.custom_data);

            body.appendChild(tr);

            sums.quote += number(row.quote_qty);
            sums.remain += number(row.unordered_qty);
            sums.supply +=
                number(row.unordered_supply_amount);
            sums.vat +=
                number(row.unordered_vat_amount);
        });

        E("sumQuote").textContent = qty(sums.quote);
        E("sumRemain").textContent = qty(sums.remain);
        E("sumSupply").textContent = money(sums.supply);
        E("sumVat").textContent = money(sums.vat);

        E("resultCount").textContent =
            "照会 " + rows.length + "行 / "
            + (currentGroup() === "ITEM"
                ? "見積書別・品目別"
                : "明細行別");
    }

    document.querySelectorAll('input[name="groupType"]')
        .forEach(function (radio) {
            radio.addEventListener("change", render);
        });

    E("quickKeyword").addEventListener(
        "keydown", function (event) {
            if (event.key !== "Enter") return;

            event.preventDefault();

            if (hasSearched) {
                render();
            } else {
                openSearch();
            }
        }
    );

    // 기준정보 조회
    // マスター検索

    function openLookup(type, keyword, callback) {
        lookupType = type;
        lookupCallback = callback;

        var titles = {
            warehouse: "倉庫検索",
            partner: "取引先検索",
            item: "品目検索",
            manager: "担当者検索"
        };

        E("lookupTitle").textContent =
            titles[type] || "マスター情報検索";

        setValue("lookupKeyword", keyword);
        open("lookupOverlay");

        lookupSearch();
    }

    function closeLookup() {
        lookupSerial++;
        lookupCallback = null;
        close("lookupOverlay");
    }

    function normalizeLookup(raw) {
        return {
            code: text(raw.code != null ? raw.code : raw.CODE),
            name: text(raw.name != null ? raw.name : raw.NAME),
            spec: text(
                raw.spec != null
                    ? raw.spec
                    : raw.specification != null
                        ? raw.specification
                        : raw.SPEC
            ),
            unit_name: text(raw.unit_name),
            unit_price: raw.unit_price,
            vat_rate: raw.vat_rate,
            total_qty: null
        };
    }

    // 기존 Oracle 재고 API 재사용
    // 既存のOracle在庫APIを再利用
    // 창고코드를 비우면 전체재고 조회
    // 倉庫コードが空なら全体在庫を検索
    function loadTotalInventory(items) {
        var codes = [];

        items.forEach(function (item) {
            if (item.code && codes.indexOf(item.code) < 0) {
                codes.push(item.code);
            }
        });

        if (!codes.length) {
            return Promise.resolve("");
        }

        var stockMap = {};
        var batches = [];

        for (var i = 0; i < codes.length; i += 100) {
            batches.push(codes.slice(i, i + 100));
        }

        var chain = Promise.resolve();

        batches.forEach(function (batch) {
            chain = chain.then(function () {
                return requestJson(
                    API + "/input/inventory",
                    {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify({
                            warehouse_code: "",
                            item_codes: batch
                        })
                    }
                ).then(function (stocks) {
                    if (!Array.isArray(stocks)) {
                        throw new Error("在庫データの応答形式エラー");
                    }

                    stocks.forEach(function (stock) {
                        stockMap[
                            text(stock.item_code).toUpperCase()
                        ] = stock.total_qty;
                    });
                });
            });
        });

        return chain.then(function () {
            items.forEach(function (item) {
                var key = item.code.toUpperCase();

                if (Object.prototype.hasOwnProperty.call(
                    stockMap, key
                )) {
                    item.total_qty = stockMap[key];
                }
            });

            return "";
        });
    }

    function renderLookup(items, inventoryError) {
        var head = E("lookupHead");
        var body = E("lookupRows");

        head.textContent = "";
        body.textContent = "";

        var cols = lookupType === "item"
            ? ["コード", "品目名", "規格", "全体在庫"]
            : ["コード", "名称"];

        var trHead = document.createElement("tr");

        cols.forEach(function (title) {
            var th = document.createElement("th");
            th.textContent = title;
            trHead.appendChild(th);
        });

        head.appendChild(trHead);

        items.forEach(function (item) {
            var tr = document.createElement("tr");

            cell(tr, item.code);
            cell(tr, item.name);

            if (lookupType === "item") {
                cell(tr, item.spec);
                cell(
                    tr,
                    inventoryError
                        ? "照会に失敗しました"
                        : item.total_qty == null
                            ? "—"
                            : qty(item.total_qty),
                    "stock-value"
                );
            }

            tr.addEventListener("click", function () {
                var callback = lookupCallback;
                closeLookup();

                if (callback) callback(item);
            });

            body.appendChild(tr);
        });

        if (!items.length) {
            var empty = document.createElement("tr");
            cell(empty, "該当するマスター情報がありません。",
                "center").colSpan = cols.length;
            body.appendChild(empty);
        }

        notify(
            "lookupMessage",
            inventoryError
                ? "品目は取得できましたが、全体在庫の照会に失敗しました： "
                  + inventoryError
                : items.length + "件 照会",
            !!inventoryError
        );
    }

    function lookupSearch() {
        var serial = ++lookupSerial;

        notify("lookupMessage",
            "マスター情報を照会しています。", false);

        return requestJson(
            API + "/quotation-lookup/"
            + encodeURIComponent(lookupType)
            + "?keyword="
            + encodeURIComponent(value("lookupKeyword"))
        ).then(function (data) {

            if (serial !== lookupSerial) return;

            if (!Array.isArray(data)) {
                throw new Error("マスター情報の応答形式エラー");
            }

            var items = data.map(normalizeLookup);

            if (lookupType !== "item") {
                renderLookup(items, "");
                return;
            }

            notify("lookupMessage",
                "Oracleから全体在庫を取得しています。", false);

            return loadTotalInventory(items).then(function () {
                if (serial !== lookupSerial) return;
                renderLookup(items, "");

            }).catch(function (error) {
                if (serial !== lookupSerial) return;
                renderLookup(items, error.message);
            });

        }).catch(function (error) {
            if (serial !== lookupSerial) return;

            notify("lookupMessage",
                "照会に失敗しました： " + error.message, true);
            E("lookupRows").textContent = "";
        });
    }

    document.querySelectorAll("[data-search-lookup]")
        .forEach(function (button) {
            button.addEventListener("click", function () {
                var type = button.dataset.searchLookup;
                var target = button.dataset.target;

                openLookup(type, value(target), function (item) {
                    // Oracle Mapper가 코드/이름 둘 다 검색함
                    // Oracle Mapperがコードと名称の両方を検索
                    setValue(target, item.code || item.name);
                });
            });
        });

    E("lookupSearchBtn").addEventListener(
        "click", lookupSearch
    );

    E("lookupKeyword").addEventListener(
        "keydown", function (event) {
            if (event.key === "Enter") {
                event.preventDefault();
                lookupSearch();
            }
        }
    );

    E("closeLookupBtn").addEventListener(
        "click", closeLookup
    );

    // 견적서 수정
    // 見積書の編集

    function closeEdit() {
        close("editOverlay");
        editQuoteId = null;
        editReadOnly = false;
    }

    E("closeEditTop").addEventListener("click", closeEdit);
    E("closeEditBottom").addEventListener("click", closeEdit);

    function setEditDisabled(disabled) {
        E("editBody").querySelectorAll("input,select,button")
            .forEach(function (control) {
                control.disabled = disabled;
            });
    }

    function loadCurrencies(selectedId) {
        var select = E("edCurrency");
        select.textContent = "";

        return requestJson(
            API + "/input/currencies"
        ).then(function (response) {

            var data = Array.isArray(response)
                ? response
                : (response && response.data) || [];

            data.forEach(function (currency) {
                var option = document.createElement("option");
                option.value = currency.currency_id;
                option.textContent =
                    text(currency.currency_code)
                    + " - "
                    + text(currency.currency_name);
                select.appendChild(option);
            });

        }).catch(function (error) {
            notify("edMessage",
                "通貨の取得に失敗しました： " + error.message, true);

        }).then(function () {
            if (selectedId == null) return;

            var exists = Array.from(select.options)
                .some(function (o) {
                    return o.value === String(selectedId);
                });

            if (!exists) {
                var option = document.createElement("option");
                option.value = selectedId;
                option.textContent = "通貨 ID " + selectedId;
                select.appendChild(option);
            }

            select.value = String(selectedId);
        });
    }

    function openEdit(quoteId) {
        if (quoteId == null) {
            alert("見積書IDがありません。");
            return;
        }

        editQuoteId = quoteId;
        editReadOnly = false;

        setEditDisabled(false);
        E("editTitle").textContent = "見積書入力（編集）";
        E("editLocked").hidden = true;
        E("edSave").hidden = true;
        E("edItems").textContent = "";

        notify("edMessage", "見積書を照会しています。", false);
        open("editOverlay");

        return requestJson(
            API + "/quotations/" + quoteId + "/detail"
        ).then(function (detail) {

            if (String(editQuoteId) !== String(quoteId)) {
                return;
            }

            var h = detail.header || {};
            var items = detail.items || [];

            setValue("edDate",
                text(h.quote_date).substring(0, 10));
            setValue("edValid",
                text(h.valid_until).substring(0, 10));

            setValue("edPartnerCode", h.partner_code);
            setValue("edPartnerName", h.partner_name);
            setValue("edManagerCode", h.manager_code);
            setValue("edManagerName", h.manager_name);
            setValue("edWarehouseCode", h.warehouse_code);
            setValue("edWarehouseName", h.warehouse_name);

            setValue("edTransaction",
                h.transaction_type || "TAXABLE");
            setValue("edRate",
                h.exchange_rate == null ? 1 : h.exchange_rate);
            setValue("edCustom", h.custom_data);

            E("editTitle").textContent = "見積書入力（編集）";

            return loadCurrencies(h.currency_id).then(function () {

                if (String(editQuoteId) !== String(quoteId)) {
                    return;
                }

                E("edAttachmentLink").hidden =
                    !h.attachment_path;

                if (h.attachment_path) {
                    E("edAttachmentLink").href =
                        API + "/input/quotations/"
                        + quoteId + "/attachment";
                }

                E("edAttachment").value = "";
                E("edItems").textContent = "";

                items.forEach(addEditRow);

                if (!items.length) {
                    addEditRow({});
                }

                calculateTotals();

                editReadOnly = !!detail.linked;
                E("editLocked").hidden = !editReadOnly;

                setEditDisabled(editReadOnly);
                E("edSave").hidden = editReadOnly;

                notify(
                    "edMessage",
                    editReadOnly
                        ? "関連伝票があるため、照会のみ可能です。"
                        : "",
                    false
                );
            });

        }).catch(function (error) {
            notify("edMessage",
                "見積書の照会に失敗しました： " + error.message, true);
            E("edSave").hidden = true;
        });
    }

    // 견적서 수정 품목행
    // 見積書編集時の品目行

    function rowField(row, name) {
        return row.querySelector(
            '[data-field="' + name + '"]'
        );
    }

    function rowValue(row, name) {
        return rowField(row, name).value.trim();
    }

    function makeInput(name, v, type) {
        var input = document.createElement("input");
        input.dataset.field = name;
        input.type = type || "text";
        input.value = text(v);

        if (type === "number") {
            input.min = "0";
            input.step = "any";
            input.style.textAlign = "right";
        }

        return input;
    }

    function calculateTotals() {
        var supply = 0;
        var vat = 0;

        E("edItems").querySelectorAll("tr")
            .forEach(function (row) {
                supply += number(
                    rowValue(row, "supply_amount"));
                vat += number(
                    rowValue(row, "vat_amount"));
            });

        E("edSupplySum").textContent = money(supply);
        E("edVatSum").textContent = money(vat);
        E("edTotalSum").textContent = money(supply + vat);
    }

    function calculateRow(row, automatic) {
        if (automatic) {
            var supply = Math.round(
                number(rowValue(row, "quantity"))
                * number(rowValue(row, "unit_price"))
                * 100
            ) / 100;

            var rate = number(row.dataset.vatRate || 10);

            var vat = value("edTransaction") === "EXEMPT"
                ? 0
                : Math.round(supply * rate) / 100;

            rowField(row, "supply_amount").value =
                supply.toFixed(2);
            rowField(row, "vat_amount").value =
                vat.toFixed(2);
        }

        rowField(row, "total_amount").value = (
            number(rowValue(row, "supply_amount"))
            + number(rowValue(row, "vat_amount"))
        ).toFixed(2);

        calculateTotals();
    }

    function addEditRow(item) {
        item = item || {};

        var tr = document.createElement("tr");
        tr.dataset.unitName = text(item.unit_name);
        tr.dataset.vatRate =
            text(item.vat_rate == null ? 10 : item.vat_rate);

        var checkTd = document.createElement("td");
        var check = document.createElement("input");
        check.type = "checkbox";
        check.className = "row-check";
        checkTd.appendChild(check);
        tr.appendChild(checkTd);

        var codeTd = document.createElement("td");
        var group = document.createElement("div");
        group.className = "code-group";

        var code = makeInput("item_code", item.item_code);

        var lookupBtn = document.createElement("button");
        lookupBtn.type = "button";
        lookupBtn.className = "icon-btn";
        lookupBtn.textContent = "⌕";

        function selectItem() {
            if (editReadOnly) return;

            openLookup("item", code.value, function (selected) {
                rowField(tr, "item_code").value =
                    selected.code;
                rowField(tr, "item_name").value =
                    selected.name;
                rowField(tr, "spec").value =
                    selected.spec;

                tr.dataset.unitName =
                    text(selected.unit_name);
                tr.dataset.vatRate =
                    text(selected.vat_rate == null
                        ? 10 : selected.vat_rate);

                if (selected.unit_price != null) {
                    rowField(tr, "unit_price").value =
                        selected.unit_price;
                }

                calculateRow(tr, true);
            });
        }

        lookupBtn.addEventListener("click", selectItem);
        code.addEventListener("dblclick", selectItem);

        group.appendChild(code);
        group.appendChild(lookupBtn);
        codeTd.appendChild(group);
        tr.appendChild(codeTd);

        [
            ["item_name", "text"],
            ["spec", "text"],
            ["quantity", "number"],
            ["unit_price", "number"],
            ["supply_amount", "number"],
            ["vat_amount", "number"],
            ["total_amount", "text"]
        ].forEach(function (field) {

            var name = field[0];
            var td = document.createElement("td");
            var input = makeInput(
                name, item[name], field[1]
            );

            if (name === "total_amount") {
                input.readOnly = true;
            }

            if (name === "quantity" ||
                name === "unit_price") {
                input.addEventListener("input", function () {
                    calculateRow(tr, true);
                });
            }

            if (name === "supply_amount" ||
                name === "vat_amount") {
                input.addEventListener("input", function () {
                    calculateRow(tr, false);
                });
            }

            td.appendChild(input);
            tr.appendChild(td);
        });

        E("edItems").appendChild(tr);
        calculateTotals();
    }

    E("edAddRow").addEventListener("click", function () {
        if (!editReadOnly) addEditRow({});
    });

    E("edDeleteRows").addEventListener("click", function () {
        if (editReadOnly) return;

        E("edItems").querySelectorAll("tr")
            .forEach(function (tr) {
                if (tr.querySelector(".row-check").checked) {
                    tr.remove();
                }
            });

        if (!E("edItems").querySelector("tr")) {
            addEditRow({});
        }

        calculateTotals();
    });

    E("edTransaction").addEventListener(
        "change", function () {
            E("edItems").querySelectorAll("tr")
                .forEach(function (tr) {
                    calculateRow(tr, true);
                });
        }
    );

    document.querySelectorAll("[data-edit-lookup]")
        .forEach(function (button) {
            button.addEventListener("click", function () {
                if (editReadOnly) return;

                var type = button.dataset.editLookup;

                var fields = {
                    partner: ["edPartnerCode", "edPartnerName"],
                    manager: ["edManagerCode", "edManagerName"],
                    warehouse: ["edWarehouseCode", "edWarehouseName"]
                }[type];

                openLookup(
                    type,
                    value(fields[0]),
                    function (selected) {
                        setValue(fields[0], selected.code);
                        setValue(fields[1], selected.name);
                    }
                );
            });
        });

    // 견적서 수정 저장
    // 見積書修正内容の保存

    function collectItems() {
        var items = [];

        E("edItems").querySelectorAll("tr")
            .forEach(function (row) {

                var code = rowValue(row, "item_code");
                var name = rowValue(row, "item_name");
                var quantityValue = rowValue(row, "quantity");

                if (!code && !name && !quantityValue) return;

                if (!code || number(quantityValue) <= 0) {
                    throw new Error(
                        "品目コードと0より大きい数量を入力してください。"
                    );
                }

                items.push({
                    item_code: code,
                    item_name: name,
                    spec: rowValue(row, "spec"),
                    unit_name: row.dataset.unitName || "",
                    quantity: quantityValue,
                    unit_price: rowValue(row, "unit_price"),
                    supply_amount: rowValue(row, "supply_amount"),
                    vat_amount: rowValue(row, "vat_amount")
                });
            });

        if (!items.length) {
            throw new Error(
                "品目を1件以上入力してください。"
            );
        }

        return items;
    }

    function saveEdit() {
        if (editQuoteId == null ||
            editReadOnly || editSaving) {
            return Promise.resolve();
        }

        var payload;

        try {
            payload = {
                quote_date: value("edDate"),
                valid_until: value("edValid"),
                partner_code: value("edPartnerCode"),
                manager_code: value("edManagerCode"),
                warehouse_code: value("edWarehouseCode"),
                transaction_type: value("edTransaction"),
                currency_id: value("edCurrency"),
                exchange_rate: value("edRate"),
                custom_data: value("edCustom"),
                items: collectItems()
            };
        } catch (error) {
            notify("edMessage",
                "更新に失敗しました： " + error.message, true);
            return Promise.resolve();
        }

        var quoteId = editQuoteId;
        editSaving = true;

        E("edSave").disabled = true;
        notify("edMessage", "保存しています。", false);

        return requestJson(
            API + "/quotations/" + quoteId,
            {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(payload)
            }
        ).then(function () {

            var file = E("edAttachment").files[0];

            if (!file) return "";

            var form = new FormData();
            form.append("file", file);

            return requestJson(
                API + "/input/quotations/"
                + quoteId + "/attachment",
                {
                    method: "POST",
                    body: form
                }
            ).then(function () {
                return "";
            }).catch(function (error) {
                return error.message;
            });

        }).then(function (attachmentError) {
            closeEdit();

            return search().then(function () {
                notify(
                    "pageMessage",
                    attachmentError
                        ? "見積書は更新されましたが、添付ファイルの保存に失敗しました： "
                          + attachmentError
                        : "見積書の更新が完了しました。",
                    !!attachmentError
                );
            });

        }).catch(function (error) {
            notify("edMessage",
                "更新に失敗しました： " + error.message, true);

        }).then(function () {
            editSaving = false;
            E("edSave").disabled = false;
        });
    }

    E("edSave").addEventListener("click", saveEdit);

    // 키보드 단축키
    // キーボードショートカット

    document.addEventListener("keydown", function (event) {

        if (event.key === "Escape") {
            if (E("lookupOverlay").classList.contains("open")) {
                closeLookup();
            } else if (E("editOverlay").classList.contains("open")) {
                closeEdit();
            } else if (E("searchOverlay").classList.contains("open")) {
                closeSearch();
            }
            return;
        }

        if (event.key === "F3") {
            if (!E("editOverlay").classList.contains("open")
                && !E("lookupOverlay").classList.contains("open")) {
                event.preventDefault();
                openSearch();
            }
        }

        if (event.key === "F8") {
            if (E("lookupOverlay").classList.contains("open")) {
                return;
            }

            if (E("editOverlay").classList.contains("open")) {
                event.preventDefault();
                saveEdit();
            } else if (
                E("searchOverlay").classList.contains("open")
            ) {
                event.preventDefault();
                search();
            }
        }
    });

    // 최초 화면 실행
    // 初期画面の起動

    resetSearch();

    // JavaScript 오류와 관계없이 HTML에서도
    // JavaScriptエラーとは無関係にHTML上でも
    // 검색 모달이 처음부터 열려 있다.
    // 検索モーダルが初期状態で開いている。
    openSearch();

    console.log("[未受注状況] 初期化が完了しました");

})();
</script>

</body>
</html>
