<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ taglib prefix="my" tagdir="/WEB-INF/tags"%>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>注文書修正 - ヘキサゴンERP</title>
<link
	href="https://cdn.jsdelivr.net/npm/@mdi/font@7.2.96/css/materialdesignicons.min.css"
	rel="stylesheet">
<style>
.uploadResult {
	grid-column: 1/-1;
	width: 100%;
	background-color: #94a3b8;
	border-radius: 10px;
}

.uploadResult ul {
	display: flex;
	flex-flow: row wrap;
	justify-content: flex-start;
	margin: 0;
	padding: 0;
}

.uploadResult ul li {
	list-style: none;
	padding: 10px;
	text-align: center;
	max-width: 140px;
}

.uploadResult ul li img {
	width: 100px;
}

.uploadResult ul li span {
	color: #fff;
	word-break: break-all;
}

.in-top {
	display: flex;
	align-items: center;
	justify-content: space-between;
	margin-bottom: 14px;
}

.in-title {
	font-size: 1.1rem;
	font-weight: 700;
	color: #0B1026;
	display: flex;
	align-items: center;
	gap: 6px;
}

.in-title .mdi-star {
	color: #cbd5e1;
}

.btn-primary {
	background: #1e5eff;
	color: #fff;
	border: none;
	padding: 7px 18px;
	border-radius: 999px;
	font-size: 0.85rem;
	cursor: pointer;
}

.btn-outline {
	background: #fff;
	color: #333;
	border: 1px solid #cbd5e1;
	padding: 6px 14px;
	border-radius: 999px;
	font-size: 0.85rem;
	cursor: pointer;
}

.btn-pill {
	background: #1e5eff;
	color: #fff;
	border: none;
	padding: 6px 16px;
	border-radius: 999px;
	font-size: 0.85rem;
	margin-bottom: 14px;
}

/* ===== 헤더 입력 영역 ===== */
.head-card {
	background: #fff;
	border: 1px solid #e2e8f0;
	border-radius: 20px;
	padding: 20px 24px;
	box-shadow: 0 10px 25px -5px rgba(75, 136, 255, 0.08);
}

.head-grid {
	display: grid;
	grid-template-columns: 1fr 1fr;
	column-gap: 40px;
	row-gap: 10px;
}

.field {
	display: grid;
	grid-template-columns: 120px 1fr;
	align-items: center;
}

.field.full {
	grid-column: 1/-1;
}

.field label {
	color: #64748b;
	font-size: 0.85rem;
}

.field input[type=text], .field input[type=date], .field select {
	width: 100%;
	height: 30px;
	box-sizing: border-box;
	border: 1px solid #cbd5e1;
	border-radius: 15px;
	padding: 0 12px;
	font-size: 0.85rem;
	background: #fff;
}

.field input:focus, .field select:focus {
	outline: none;
	border-color: #4B88FF;
}

.attach-box {
	height: 30px;
	border: 1px solid #e2e8f0;
	border-radius: 15px;
	background: #f8fafc;
	text-align: center;
	line-height: 28px;
	color: #94a3b8;
}

/* ===== 툴바 ===== */
.tool-bar {
	display: flex;
	gap: 6px;
	margin: 16px 0 8px;
	flex-wrap: wrap;
}

.tool-bar .btn-outline {
	padding: 3px 12px;
	font-size: 0.8rem;
}

/* ===== 품목 테이블 ===== */
.item-table {
	width: 100%;
	border-collapse: collapse;
	font-size: 0.85rem;
	border-top: 2px solid #4B88FF;
}

.item-table th {
	background: #f1f5f9;
	font-weight: 600;
	padding: 10px 6px;
	border: 1px solid #e2e8f0;
	color: #0B1026;
}

.item-table td {
	border: 1px solid #e2e8f0;
	padding: 0;
	height: 40px;
}

.item-table td.center {
	text-align: center;
	width: 44px;
}

.item-table td input {
	width: 100%;
	height: 100%;
	min-height: 38px;
	box-sizing: border-box;
	border: none;
	padding: 0 8px;
	font-size: 0.85rem;
	background: transparent;
}

.item-table td input[type=number] {
	text-align: right;
}

.item-table td input:focus {
	outline: none;
	background: #f0f6ff;
}

.row-no {
	display: inline-block;
	width: 22px;
	height: 22px;
	line-height: 20px;
	border: 1px solid #cbd5e1;
	border-radius: 50%;
	text-align: center;
	font-size: 0.75rem;
	color: #94a3b8;
}

.del-btn {
	border: none;
	background: transparent;
	color: #94a3b8;
	cursor: pointer;
	font-size: 18px;
}

.del-btn:hover {
	color: #e03131;
}

.item-table tfoot td {
	background: #f1f5f9;
	font-weight: 700;
	text-align: right;
	padding: 0 8px;
}

/* ===== 하단 버튼 ===== */
.bottom-bar {
	display: flex;
	gap: 6px;
	margin-top: 16px;
}
</style>
</head>
<body>
	<div class="erp-wrapper">

		<div class="erp-main">
			<main class="erp-content">

				<div class="in-top">
					<div class="in-title">
						<i class="mdi mdi-star"></i> 注文書修正
					</div>
				</div>

				<div class="btn-pill" style="display: inline-block;">注文書修正</div>

				<!-- 주문서 수정 폼 -->
				<!-- 注文書修正フォーム -->
				<form method="post" action="modify"
					onsubmit="return prepareSubmit();">
					<input type="hidden" name="order.orderId" value="${order.orderId}">
					<input type="hidden" name="returnUrl" value="${ returnUrl}">
					<!-- 헤더 -->
					<!-- ヘッダー -->
					<div class="head-card">
						<div class="head-grid">
							<!-- 일자 -->
							<!-- 日付 -->
							<div class="field">
								<label>日付</label> <input type="date" name="order.orderDate"
									value="${order.orderDate}" required>
							</div>
							<!-- 거래처 -->
							<!-- 取引先 -->
							<div class="field">
								<label>取引先</label> <select name="order.businessPartnerId">
									<c:forEach var="partner" items="${partners }">
										<option value="${partner.businessPartnerId }"
											${partner.businessPartnerId eq order.businessPartnerId ? 'selected' : '' }>${partner.businessPartnerName }</option>
									</c:forEach>
								</select>
							</div>
							<!-- 담당자 -->
							<!-- 担当者 -->
							<div class="field">
								<label>担当者</label> <select name="order.managerId">
									<c:forEach var="manager" items="${managers }">
										<option value="${manager.managerId }"
											${manager.managerId eq order.managerId ? 'selected' :'' }>${manager.employeeName }</option>
									</c:forEach>
								</select>
							</div>
							<!-- 출하창고 -->
							<!-- 出荷倉庫 -->
							<div class="field">
								<label>出荷倉庫</label> <select name="order.warehouseId">
									<c:forEach var="warehouse" items="${warehouses }">
										<option value="${warehouse.warehousePk }"
											${warehouse.warehousePk eq order.warehouseId ? 'selected' :'' }>${warehouse.warehouseName }</option>
									</c:forEach>
								</select>

							</div>
							<!-- 거래유형 -->
							<!-- 取引類型 -->
							<div class="field">
								<label>取引類型</label> <select name="order.transactionType"
									onchange="recalcAll()">
									<option value="Y"
										${order.transactionType eq 'Y' ? 'selected' : '' }>付加税率適用</option>
									<option value="N"
										${order.transactionType eq 'N' ? 'selected' : '' }>付加税率未適用</option>
								</select>
							</div>
							<!-- 통화 -->
							<!-- 通貨 -->
							<div class="field">
								<label>通貨</label> <select name="order.currencyId">
									<c:forEach var="currency" items="${currencies }">
										<option value="${currency.currencyId }"
											${currency.currencyId eq order.currencyId ? 'selected' : '' }>${currency.code }</option>
									</c:forEach>
								</select>

							</div>
							<!-- 납기일자 -->
							<!-- 納期日付 -->
							<div class="field">
								<label>納期日付</label> <input type="date" name="order.dueDate"
									value="${order.dueDate }" required>
							</div>
							<!-- 비고 -->
							<!-- 備考 -->
							<div class="field">
								<label>備考</label> <input type="text" name="order.remarks"
									value="${order.remarks }">
							</div>
							<!-- 첨부 -->
							<!-- 添付 -->
							<div class="field full">
								<label>添付</label> <input type="file" name="uploadFile"
									multiple="multiple">
								<div class="uploadResult">
									<ul></ul>
								</div>
							</div>
						</div>
					</div>

					<!-- 툴바 -->
					<!-- ツールバー -->
					<div class="tool-bar">
						<button type="button" class="btn-outline"
							onclick="openQuoteModal()">見積を呼び出す</button>
						<button type="button" class="btn-outline" onclick="addItem()">+
							品目追加</button>
						<button type="button" class="btn-outline"
							onclick="openItemModal()">品目検索</button>
					</div>

					<!-- 품목 테이블 -->
					<!-- 品目テーブル -->
					<table class="item-table">
						<thead>
							<tr>
								<th style="width: 44px;"></th>
								<th>品目コード</th>
								<th>品目名</th>
								<th>規格</th>
								<th>数量</th>
								<th>単価</th>
								<th>供給価格</th>
								<th>付加税</th>
								<th>備考</th>
								<th style="width: 44px;"></th>
							</tr>
						</thead>
						<tbody id="itemList">
							<c:forEach var="it" items="${items}" varStatus="st">
								<tr class="item-row">
									<!-- 주문서 품목 ID -->
									<!-- 注文書品目ID -->
									<td class="center"><span class="row-no">${st.count}</span>
										<input type="hidden" name="items[${st.index}].orderItemId"
										value="${it.orderItemId}"></td>
									<!-- 품목코드 -->
									<!-- 品目コード -->
									<td><input type="text" name="items[${st.index}].itemId"
										value="${it.itemId}"></td>
									<!-- 품목코드 -->
									<!-- 品目コード -->
									<td><input type="text"
										name="items[${st.index}].itemNameSnap"
										value="${it.itemNameSnap}"></td>
									<!-- 규격 -->
									<!-- 規格 -->
									<td><input type="text" name="items[${st.index}].specSnap"
										value="${it.specSnap}"></td>
									<!-- 수량 -->
									<!-- 数量 -->
									<td><input type="number"
										name="items[${st.index}].quantity" value="${it.quantity}"
										oninput="calcRow(this)"></td>
									<!-- 단가 -->
									<!-- 単価 -->
									<td><input type="number"
										name="items[${st.index}].unitPrice" value="${it.unitPrice}"
										oninput="calcRow(this)"></td>
									<!-- 공급가액 -->
									<!-- 供給価格 -->
									<td><input type="number"
										name="items[${st.index}].supplyAmount"
										value="${it.supplyAmount}" oninput="calcTotal()"></td>
									<!-- 부가세 -->
									<!-- 付加税 -->
									<td><input type="number"
										name="items[${st.index}].vatAmount" value="${it.vatAmount}"
										oninput="calcTotal()"></td>
									<!-- 적요 -->
									<!-- 備考 -->
									<td><input type="text" name="items[${st.index}].remarks"
										value="${it.remarks}"></td>
									<!-- 품목 제거 버튼 -->
									<!-- 品目削除ボタン -->
									<td class="center"><button type="button" class="del-btn"
											onclick="removeItem(this)">&times;</button></td>
								</tr>
							</c:forEach>
						</tbody>
						<!-- 합계 -->
						<!-- 合計 -->
						<tfoot>
							<tr>
								<td></td>
								<td colspan="3"></td>
								<!-- 수량 합계 -->
								<!-- 数量合計 -->
								<td id="sumQty">0</td>
								<td></td>
								<!-- 공급가액 합계 -->
								<!-- 供給価格合計 -->
								<td id="sumSupply">0</td>
								<!-- 부가세 합계 -->
								<!-- 付加税合計 -->
								<td id="sumVat">0</td>
								<td colspan="2"></td>
							</tr>
						</tfoot>
					</table>

					<!-- 하단 버튼 -->
					<!-- 下端ボタン -->
					<div class="bottom-bar">
						<button type="submit" class="btn-primary">保存</button>
					</div>
				</form>

			</main>
		</div>
	</div>

	<!-- 견적서 불러오기 -->
	<!-- 見積書呼び出し -->
	<div id="quoteModal"
		style="display: none; position: fixed; inset: 0; background: rgba(0, 0, 0, 0.4); z-index: 2000;">

		<div
			style="background: #fff; width: 1100px; max-width: 95%; margin: 40px auto; padding: 24px; border-radius: 10px; max-height: 85vh; overflow: auto; box-sizing: border-box;">

			<table class="item-table"
				style="width: 100%; min-width: 900px; font-size: 14px;">
				<thead>
					<tr>
						<th style="width: 40px;"></th>
						<th style="min-width: 120px;">日付-No.</th>
						<th style="min-width: 150px;">取引先名</th>
						<th style="min-width: 150px;">社員（担当）名</th>
						<th style="min-width: 200px;">品目名（要約）</th>
						<th style="min-width: 150px;">見積金額合計</th>
					</tr>
				</thead>
				<tbody id="quoteBody"></tbody>
			</table>

			<div class="bottom-bar">
				<button type="button" class="btn-primary"
					onclick="applyQuotes('remain')">残りの数量適用</button>
				<button type="button" class="btn-primary"
					onclick="applyQuotes('all')">全量適用</button>
				<button type="button" class="btn-outline"
					onclick="closeQuoteModal()">閉じる</button>
			</div>
		</div>
	</div>

	<!-- 품목 조회 -->
	<!-- 品目照会 -->
	<div id="itemModal"
		style="display: none; position: fixed; inset: 0; background: rgba(0, 0, 0, 0.4); z-index: 2000;">
		<div
			style="background: #fff; width: 900px; max-width: 95%; margin: 40px auto; padding: 20px; border-radius: 10px; max-height: 85vh; overflow: auto;">
			<div style="text-align: right; margin-bottom: 8px;"></div>
			<div id="itemBody"></div>
			<button type="button" class="btn-primary" onclick="applyItems()">選択</button>
			<button type="button" class="btn-outline" onclick="closeItemModal()">閉じる</button>
		</div>
	</div>

	<script>
		var MIN_ROWS = 3; // 품목 최소 줄 수 品目最低行数

		// 품목 칸을 최소 줄 수까지 채움
		// 品目欄を最低行数まで作る
		for (var n = document.querySelectorAll("#itemList .item-row").length; n < MIN_ROWS; n++) {
			addItem();
		}

		// 페이지 진입할 때 합계가 보이도록 계산
		// ページに進入する時に合計が見えるように計算
		calcTotal();

		// 전송 직전: 빈 줄은 보내지 않고, 나머지는 번호를 0부터 다시 매김
		// 伝送直前：空いている行は送らないで、残りは番号を０からまた付ける
		function prepareSubmit() {
			var rows = document.querySelectorAll("#itemList .item-row");

			// 입력 검사: 품목이 1줄 이상 있어야 하고, 내용이 있는 줄은 품목코드가 필요
			// 入力検査 : 品目が一行以上あって、内容がある行は品目コードが必要
			var filled = 0;
			for (var r = 0; r < rows.length; r++) {
				var ins = rows[r]
						.querySelectorAll('input:not([name$=".quoteItemId"])');
				var any = false;
				for (var s = 0; s < ins.length; s++) {
					if (ins[s].value !== "") {
						any = true;
					}
				}
				if (any) {
					filled++;
					if (rows[r].querySelector('[name$=".itemId"]').value === "") {
						alert((r + 1) + "番目の行の品目コードを入力してください");
						return false;
					}
					
					// 수량 검사
					// 数量検査
					var qty = Number(rows[r].querySelector('[name$=".quantity"]').value);
					if (qty == null || qty == '') {
						alert("数量を入力してください。");
						return false;
					}
					
					// 단가 검사
					// 数量検査
					var unitPrice = Number(rows[r].querySelector('[name$=".unitPrice"]').value);
					if (unitPrice == null || unitPrice == '') {
						alert("単価を入力してください。");
						return false;
					}
					
				}
			}
			if (filled === 0) {
				alert("品目を一つ以上入力してください。");
				return false;
			}

			// 빈 줄은 전송에서 제외하고, 나머지는 items[0]부터 번호 다시 매김
			// 空いている行は伝送から除いて、残りはitems[0]から番号をまた付ける
			var idx = 0;
			for (var i = 0; i < rows.length; i++) {
				var inputs = rows[i].querySelectorAll("input");
				var judge = rows[i]
						.querySelectorAll('input:not([name$=".quoteItemId"])');
				var empty = true;
				for (var j = 0; j < judge.length; j++) {
					if (judge[j].value !== "") {
						empty = false;
					}
				}
				for (var k = 0; k < inputs.length; k++) {
					if (empty) {
						inputs[k].disabled = true;
					} else {
						inputs[k].name = inputs[k].name.replace(/items\[\d+\]/,
								"items[" + idx + "]");
					}
				}
				if (!empty) {
					idx++;
				}
			}
			return true;
		}

		// 품목 한 줄 추가
		// 品目一行追加
		function addItem() {
			var itemList = document.getElementById("itemList");

			var row = document.createElement("tr");
			row.className = "item-row";
			row.innerHTML = '<td class="center"><span class="row-no"></span>'
					+ '<input type="hidden" name="items[0].quoteItemId"></td>'
					+ '<td><input type="text" name="items[0].itemId"></td>'
					+ '<td><input type="text" name="items[0].itemNameSnap"></td>'
					+ '<td><input type="text" name="items[0].specSnap"></td>'
					+ '<td><input type="number" name="items[0].quantity" oninput="calcRow(this)"></td>'
					+ '<td><input type="number" name="items[0].unitPrice" oninput="calcRow(this)"></td>'
					+ '<td><input type="number" name="items[0].supplyAmount" oninput="calcTotal()"></td>'
					+ '<td><input type="number" name="items[0].vatAmount" oninput="calcTotal()"></td>'
					+ '<td><input type="text" name="items[0].remarks"></td>'
					+ '<td class="center"><button type="button" class="del-btn" onclick="removeItem(this)">&times;</button></td>';

			itemList.appendChild(row);
			renumber();
		}

		// 품목 한 줄 삭제
		// 品目一行削除
		function removeItem(button) {
			var tr = button.closest("tr");
			// 최소 줄 수 이하이면 줄을 지우지 않고 내용만 지움
			// 最低行数以下なら行を消さないで内容だけ消す
			if (document.querySelectorAll("#itemList .item-row").length <= MIN_ROWS) {
				var ins = tr.querySelectorAll("input");
				for (var k = 0; k < ins.length; k++) {
					ins[k].value = "";
				}
				calcTotal();
				return;
			}
			tr.remove();
			renumber();
			calcTotal();
		}

		// 줄 순서대로 items[0], items[1]... 번호를 다시 매김
		// 行の順番通りにitems[0], items[1]...番号をまた付ける
		function renumber() {
			var rows = document.querySelectorAll("#itemList .item-row");

			for (var i = 0; i < rows.length; i++) {
				var inputs = rows[i].querySelectorAll("input");
				for (var j = 0; j < inputs.length; j++) {
					inputs[j].name = inputs[j].name.replace(/items\[\d+\]/,
							"items[" + i + "]");
				}
				rows[i].querySelector(".row-no").textContent = i + 1;
			}
		}

		// 한 줄 계산: 공급가액 = 수량 * 단가, 부가세 = 공급가액 * 10% (거래유형이 Y일 때)
		// 一行計算：供給価格　＝　数量*単価、付加税　＝　供給価格*１０％（取引類型がYの時）
		function calcRow(el) {
			var row = el.closest("tr");
			var qtyEl = row.querySelector('[name$=".quantity"]');
			var priceEl = row.querySelector('[name$=".unitPrice"]');
			var supplyEl = row.querySelector('[name$=".supplyAmount"]');
			var vatEl = row.querySelector('[name$=".vatAmount"]');

			// 수량과 단가가 둘 다 비어 있으면 빈 줄로 유지
			// 数量と単価がどっちも空いていれば、空いている行を維持
			if (qtyEl.value === "" && priceEl.value === "") {
				supplyEl.value = "";
				vatEl.value = "";
				calcTotal();
				return;
			}

			var supply = (Number(qtyEl.value) || 0)
					* (Number(priceEl.value) || 0);
			var applyVat = document
					.querySelector('[name="order.transactionType"]').value === "Y";

			supplyEl.value = supply;
			vatEl.value = applyVat ? Math.floor(supply * 0.1) : 0;
			calcTotal();
		}

		// 거래유형이 바뀌면 모든 줄 다시 계산
		// 取引類型が変われば、全ての行をまた計算
		function recalcAll() {
			var rows = document.querySelectorAll("#itemList .item-row");
			for (var i = 0; i < rows.length; i++) {
				calcRow(rows[i].querySelector('[name$=".quantity"]'));
			}
		}

		// 합계 계산 (수량, 공급가액, 부가세)
		// 合計計算（数量、供給価格、付加税)
		function calcTotal() {
			var qty = 0, supply = 0, vat = 0;
			var rows = document.querySelectorAll("#itemList .item-row");
			for (var i = 0; i < rows.length; i++) {
				qty += Number(rows[i].querySelector('[name$=".quantity"]').value) || 0;
				supply += Number(rows[i]
						.querySelector('[name$=".supplyAmount"]').value) || 0;
				vat += Number(rows[i].querySelector('[name$=".vatAmount"]').value) || 0;
			}
			document.getElementById("sumQty").textContent = qty
					.toLocaleString();
			document.getElementById("sumSupply").textContent = supply
					.toLocaleString();
			document.getElementById("sumVat").textContent = vat
					.toLocaleString();
		}
	</script>
	<script>
		var CTX = "${pageContext.request.contextPath}";

		// 견적서 목록 모달 열기
		// 見積書目録のモーダルを開く
		function openQuoteModal() {
			fetch(CTX + "/sales/order/quote-list")
					.then(function(r) {
						return r.json();
					})
					.then(
							function(list) {
								var html = "";
								list
										.forEach(function(q) {
											html += '<tr><td class="center"><input type="checkbox" name="quoteId" value="' + q.QUOTEID + '"></td>'
											+ '<td class="center">'
											+ q.QUOTEDATE
											+ "-"
											+ q.DAYNO
											+ '</td>'
											+ '<td class="center">'
											+ q.BUSINESSPARTNERNAME
											+ '</td>'
											+ '<td>'
											+ q.MANAGERNAME
											+ '</td>'
											+ '<td>'
											+ q.ITEMNAME + (q.ITEMCOUNT == 1 ? '' : ' 外' + (q.ITEMCOUNT - 1) + '件')
											+ '</td>'
											+ '<td>'
											+ q.TOTALAMOUNT
											+ '</td>'
											+ '</tr>';
										});
								if (list.length === 0) {
									html = '<tr><td colspan="4" class="center">견적서가 없습니다.</td></tr>';
								}
								document.getElementById("quoteBody").innerHTML = html;
								document.getElementById("quoteModal").style.display = "block";
							}).then(null, function(e) {
						alert("見積書目録を呼び出せませんでした。\n" + e.message);
					});
		}

		function closeQuoteModal() {
			document.getElementById("quoteModal").style.display = "none";
		}

		//선택한 견적서 적용
		//選択した見積書を適用
		function applyQuotes(mode) {
			var ids = [];
			document.querySelectorAll(
					'#quoteBody input[name="quoteId"]:checked').forEach(
					function(c) {
						ids.push(c.value);
					});
			if (ids.length === 0) {
				alert("見積書を選択してください。");
				return;
			}

			var qs = ids.map(function(id) {
				return "quoteId=" + encodeURIComponent(id);
			}).join("&");
			fetch(CTX + "/sales/order/quote-load?" + qs + "&mode=" + mode)
					.then(function(r) {
						if (!r.ok) {
							throw new Error("HTTP " + r.status);
						}
						return r.json();
					}).then(function(data) {
						if (!data.items || data.items.length === 0) {
							alert("適用する残りの数量がありません。");
							return;
						}
						fillFromQuote(data);
						closeQuoteModal();
					}).then(null, function(e) {
						alert("見積書を呼び出せませんでした.\n" + e.message);
					});
		}

		function setVal(name, v) {
			var el = document.querySelector('[name="' + name + '"]');
			if (el) {
				el.value = (v === undefined || v === null) ? "" : v;
			}
		}

		// 입력 화면 채우기
		// 入力画面を埋める
		// 수정 화면용: 가져온 품목을 빈 줄이나 새 줄에 채움
		// 修正画面用：持ってきた品目を開いている行や新しい行に埋める
		function fillFromQuote(data) {
			(data.items || [])
					.forEach(function(it) {
						var target = null;
						var rows = document
								.querySelectorAll("#itemList .item-row");
						for (var i = 0; i < rows.length; i++) {
							var vis = rows[i]
									.querySelectorAll('input:not([type=hidden])');
							var empty = true;
							for (var j = 0; j < vis.length; j++) {
								if (vis[j].value !== "") {
									empty = false;
								}
							}
							if (empty
									&& !rows[i]
											.querySelector('[name$=".orderItemId"]')) {
								target = rows[i];
								break;
							}
						}
						if (!target) {
							addItem();
							var all = document
									.querySelectorAll("#itemList .item-row");
							target = all[all.length - 1];
						}
						function put(suffix, v) {
							var el = target.querySelector('[name$="' + suffix
									+ '"]');
							if (el) {
								el.value = (v === undefined || v === null) ? ""
										: v;
							}
						}
						put(".itemId", it.itemId);
						put(".quoteItemId", it.quoteItemId);
						put(".itemNameSnap", it.itemNameSnap);
						put(".specSnap", it.specSnap);
						put(".quantity", it.quantity);
						put(".unitPrice", it.unitPrice);
						put(".remarks", it.remarks);
						calcRow(target.querySelector('[name$=".quantity"]'));
					});
			calcTotal();
		}
	</script>
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<script type="text/javascript">
		$(document)
				.ready(
						function() {

							var formObj = $("form");

							// 저장 시: 화면에 남아 있는 첨부 목록을 hidden input으로 만들어 함께 전송
							// 保存時：画面に残っている添付リストをhidden inputで作って一緒に送る
							formObj
									.on(
											"submit",
											function() {
												formObj.find(
														"input.attach-hidden")
														.remove();
												var str = "";
												$(".uploadResult ul li")
														.each(
																function(i, obj) {
																	var jobj = $(obj);
																	str += "<input type='hidden' class='attach-hidden' name='attachList["
																			+ i
																			+ "].fileName' value='"
																			+ jobj
																					.data("filename")
																			+ "'>";
																	str += "<input type='hidden' class='attach-hidden' name='attachList["
																			+ i
																			+ "].uuid' value='"
																			+ jobj
																					.data("uuid")
																			+ "'>";
																	str += "<input type='hidden' class='attach-hidden' name='attachList["
																			+ i
																			+ "].uploadPath' value='"
																			+ jobj
																					.data("path")
																			+ "'>";
																	str += "<input type='hidden' class='attach-hidden' name='attachList["
																			+ i
																			+ "].fileType' value='"
																			+ jobj
																					.data("type")
																			+ "'>";
																});
												formObj.append(str);
											});

							// 기존 첨부 불러오기
							// 既存の添付を呼び出す
							(function() {
								var orderId = '<c:out value="${order.orderId}"/>';
								$
										.getJSON(
												CTX
														+ "/sales/order/getAttachList",
												{
													orderId : orderId
												},
												function(arr) {
													var str = "";
													$(arr)
															.each(
																	function(i,
																			attach) {
																		str += "<li data-path='" + attach.uploadPath + "' data-uuid='" + attach.uuid
					+ "' data-filename='" + attach.fileName + "' data-type='" + attach.fileType + "'><div>";
																		str += "<span>"
																				+ attach.fileName
																				+ "</span><br>";
																		str += "<button type='button' class='btn-outline' style='padding:0 8px;'>&times;</button><br>";
																		if (attach.fileType) {
																			var thumb = encodeURIComponent(attach.uploadPath
																					+ "/s_"
																					+ attach.uuid
																					+ "_"
																					+ attach.fileName);
																			str += "<img src='"
																					+ CTX
																					+ "/display?fileName="
																					+ thumb
																					+ "'>";
																		} else {
																			str += "<i class='mdi mdi-file-document-outline' style='font-size:48px;color:#fff;'></i>";
																		}
																		str += "</div></li>";
																	});
													$(".uploadResult ul").html(
															str);
												});
							})();

							// X 버튼: 서버 파일은 지우지 않고 목록에서만 제거 (저장 시 남은 목록으로 DB 교체)
							// Xボタン：サーバーのファイルは消さず、リストからだけ削除
							$(".uploadResult").on("click", "button",
									function() {
										if (confirm("この添付を削除しますか?")) {
											$(this).closest("li").remove();
										}
									});

							var regex = new RegExp("(.*?)\\.(exe|sh|zip|alz)$");
							var maxSize = 5242880;

							function checkExtension(fileName, fileSize) {
								if (fileSize >= maxSize) {
									alert("ファイルサイズが超過しました。");
									return false;
								}
								if (regex.test(fileName)) {
									alert("このファイルはアップロードできません。");
									return false;
								}
								return true;
							}

							// 파일 선택 시 업로드
							// ファイル選択時にアップロード
							$("input[type='file']")
									.change(
											function() {
												var formData = new FormData();
												var files = $("input[name='uploadFile']")[0].files;

												for (var i = 0; i < files.length; i++) {
													if (!checkExtension(
															files[i].name,
															files[i].size)) {
														return false;
													}
													formData.append(
															"uploadFile",
															files[i]);
												}

												$
														.ajax({
															url : CTX
																	+ '/uploadAjaxAction',
															processData : false,
															contentType : false,
															data : formData,
															type : 'POST',
															dataType : 'json',
															success : function(
																	result) {
																showUploadResult(result);
															}
														});
											});

							function showUploadResult(arr) {
								if (!arr || arr.length == 0) {
									return;
								}
								var str = "";
								$(arr)
										.each(
												function(i, obj) {
													str += "<li data-path='" + obj.uploadPath + "' data-uuid='" + obj.uuid
				+ "' data-filename='" + obj.fileName + "' data-type='" + obj.image + "'><div>";
													str += "<span>"
															+ obj.fileName
															+ "</span><br>";
													str += "<button type='button' class='btn-outline' style='padding:0 8px;'>&times;</button><br>";
													if (obj.image) {
														var thumb = encodeURIComponent(obj.uploadPath
																+ "/s_"
																+ obj.uuid
																+ "_"
																+ obj.fileName);
														str += "<img src='"
																+ CTX
																+ "/display?fileName="
																+ thumb + "'>";
													} else {
														str += "<i class='mdi mdi-file-document-outline' style='font-size:48px;color:#fff;'></i>";
													}
													str += "</div></li>";
												});
								$(".uploadResult ul").append(str);
							}
						});
	</script>
	<!-- 품목 가져오기 -->
	<!-- 品目読み込み -->
	<script>
		function openItemModal() {
			document.getElementById("itemModal").style.display = "block";
			loadItems(1);
		}
		function closeItemModal() {
			document.getElementById("itemModal").style.display = "none";
		}

		// 품목 목록을 모달에 넣음 (검색어와 페이지는 그대로 유지)
		// 品目目録をモーダルに入れる（検索語とページはそのまま）
		function loadItems(page) {
			var kwEl = document.getElementById("itemKeyword");
			var kw = kwEl ? kwEl.value : "";
			fetch(
					CTX + "/sales/order/item-lookup?pageNum=" + page
							+ "&keyword=" + encodeURIComponent(kw)).then(
					function(r) {
						return r.text();
					}).then(function(html) {
				document.getElementById("itemBody").innerHTML = html;
			}).then(null, function(e) {
				alert("品目を読み込めませんでした。\n" + e.message);
			});
		}

		// 행을 누르면 주문서 줄에 채우고 닫음
		// 行を押すと受注書の行に埋めてから閉じる
		function applyItems() {
			var checked = document
					.querySelectorAll("#itemBody .item-pick:checked");
			if (checked.length === 0) {
				alert("品目を選択してください。");
				return;
			}
			checked.forEach(function(c) {
				var tr = c.closest("tr");
				fillItemRow({
					itemId : tr.dataset.pk,
					itemName : tr.dataset.name,
					spec : tr.dataset.spec,
					salesPrice : tr.dataset.price
				});
			});
			closeItemModal();
		}
		// 빈 줄에 채우고, 없으면 줄 추가
		// 空いている行を埋め、なければ行を追加
		function fillItemRow(it) {
			var target = null;
			var rows = document.querySelectorAll("#itemList .item-row");
			for (var i = 0; i < rows.length; i++) {
				var vis = rows[i].querySelectorAll("input:not([type=hidden])");
				var empty = true;
				for (var j = 0; j < vis.length; j++) {
					if (vis[j].value !== "") {
						empty = false;
					}
				}
				if (empty && !rows[i].querySelector('[name$=".orderItemId"]')) {
					target = rows[i];
					break;
				}
			}
			if (!target) {
				addItem();
				var all = document.querySelectorAll("#itemList .item-row");
				target = all[all.length - 1];
			}
			function put(suffix, v) {
				var el = target.querySelector('[name$="' + suffix + '"]');
				if (el) {
					el.value = (v === undefined || v === null) ? "" : v;
				}
			}
			put(".itemId", it.itemId);
			put(".itemNameSnap", it.itemName);
			put(".specSnap", it.spec);
			put(".unitPrice", it.salesPrice);
			calcRow(target.querySelector('[name$=".quantity"]'));
		}
	</script>
</body>
</html>
