<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ taglib prefix="my" tagdir="/WEB-INF/tags"%>
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>出荷照会</title>
<link href="https://cdn.jsdelivr.net/npm/@mdi/font@7.2.96/css/materialdesignicons.min.css" rel="stylesheet">
<link href="${pageContext.request.contextPath}/resources/css/ship.css?v=20261012b" rel="stylesheet">
<style>
/* 한국어: 목록 상태 배지 스타일 / 日本語：一覧のステータスバッジ */
.ship-table td.status-cell{min-width:108px!important;text-align:center!important}
.ship-table .status-badge{display:inline-flex!important;align-items:center!important;justify-content:center!important;gap:5px!important;min-width:76px!important;padding:6px 11px!important;border:1px solid!important;border-radius:999px!important;font-size:12px!important;font-weight:800!important;line-height:1.25!important;white-space:nowrap!important;box-sizing:border-box!important}
.ship-table .status-badge .mdi{font-size:14px!important}
.ship-table .status-badge.status-active{color:#166534!important;background:#f0fdf4!important;border-color:#86efac!important}
.ship-table .status-badge.status-cancelled{color:#475569!important;background:#f1f5f9!important;border-color:#cbd5e1!important}
.ship-table .status-badge.status-unknown{color:#334155!important;background:#f8fafc!important;border-color:#cbd5e1!important}
/* 한국어: 상세 모달 버튼 정렬 / 日本語：詳細モーダルのボタン配置 */
.modal-head{display:flex;align-items:center;gap:10px}.modal-head .spacer{flex:1}.modal-head .modal-close{flex:0 0 auto;margin-left:8px}
.modal-actions{display:flex;justify-content:flex-end;gap:8px;padding:14px 18px;border-top:1px solid #e2e8f0;background:#f8fafc}.modal-actions .btn{min-width:96px}
</style>
</head>
<!-- 한국어: embed 모드일 때 목록용 클래스 적용 / 日本語：embedモードの場合、一覧用クラスを適用 -->
<body class="${param.embed == '1' ? 'list-embed' : ''}">
<div class="erp-wrapper">
    <my:sideMenu embed="${param.embed}" />
    <div class="erp-main"><main class="erp-content"><div class="ship-page"><div class="ship-wrap">
        <div class="ship-title">出荷照会</div>
        <!-- 한국어: 상태 필터와 키워드 검색 / 日本語：ステータスフィルターとキーワード検索 -->
        <div class="filter-bar">
            <button class="pill ${empty param.status ? 'active':''}" onclick="filterStatus('')">すべて</button>
            <button class="pill ${param.status=='ACTIVE'?'active':''}" onclick="filterStatus('ACTIVE')">正常</button>
            <div class="search-inline">
                <input id="keyword" class="ship-input" value="${pageMaker.cri.keyword}" placeholder="入力後Enter" onkeydown="if(event.key==='Enter')search()">
                <button class="btn primary" onclick="search()">Search(F3)</button><button class="btn">Option</button><button class="btn">ヘルプ</button>
            </div>
        </div>
        <!-- 한국어: 출하 목록 테이블 / 日本語：出荷一覧テーブル -->
        <div class="table-wrap"><table class="ship-table"><thead><tr><th>No.(PK)</th><th>日付</th><th>倉庫名</th><th>品目名（概要）</th><th>数量合計</th><th>取引先名</th><th>状態</th><th>詳細</th></tr></thead><tbody>
            <c:forEach var="row" items="${list}"><tr>
                <td><a class="edit-link" href="javascript:void(0)" onclick="showDetail(${row.shipmentId})" title="出荷詳細照会">${row.shipmentId}</a></td>
                <td><a class="edit-link" href="javascript:void(0)" onclick="showDetail(${row.shipmentId})" title="出荷詳細照会"><c:out value="${row.shipmentDate}"/></a></td>
                <td><a class="edit-link" href="javascript:void(0)" onclick="showDetail(${row.shipmentId})" title="出荷詳細照会">${row.warehouseName}</a></td>
                <td class="left">${row.itemSummary}</td><td style="text-align:right">${row.quantityTotal}</td><td>${row.partnerName}</td>
                <!-- 한국어: 상태값에 따라 배지 표시 / 日本語：ステータスに応じてバッジを表示 -->
                <td class="status-cell"><c:choose>
                    <%-- 한국어: 정상 상태 / 日本語：正常状態 --%>
                    <c:when test="${row.voucherStatus == 'ACTIVE'}"><span class="status-badge status-active"><i class="mdi mdi-check-circle-outline"></i> 正常</span></c:when>
                    <%-- 한국어: 취소 상태 / 日本語：取消状態 --%>
                    <c:when test="${row.voucherStatus == 'CANCELLED'}"><span class="status-badge status-cancelled"><i class="mdi mdi-close-circle-outline"></i> 取消</span></c:when>
                    <%-- 한국어: 기타 상태 / 日本語：その他の状態 --%>
                    <c:otherwise><span class="status-badge status-unknown"><c:out value="${row.voucherStatus}"/></span></c:otherwise>
                </c:choose></td>
                <td><button class="btn small" onclick="showDetail(${row.shipmentId})">詳細</button></td>
            </tr></c:forEach>
            <c:if test="${empty list}"><tr><td colspan="8" class="empty">出荷伝票が見つかりません。</td></tr></c:if>
        </tbody></table></div>
        <!-- 한국어: 페이지 이동 / 日本語：ページ移動 -->
        <div class="pager">
            <c:if test="${pageMaker.prev}"><a href="${pageContext.request.contextPath}/sales/ship/inquiry?pageNum=${pageMaker.startPage-1}&status=${pageMaker.cri.status}&keyword=${pageMaker.cri.keyword}${param.embed == '1' ? '&embed=1' : ''}">‹</a></c:if>
            <c:forEach var="num" begin="${pageMaker.startPage}" end="${pageMaker.endPage}"><a class="${pageMaker.cri.pageNum==num?'on':''}" href="${pageContext.request.contextPath}/sales/ship/inquiry?pageNum=${num}&status=${pageMaker.cri.status}&keyword=${pageMaker.cri.keyword}${param.embed == '1' ? '&embed=1' : ''}">${num}</a></c:forEach>
            <c:if test="${pageMaker.next}"><a href="${pageContext.request.contextPath}/sales/ship/inquiry?pageNum=${pageMaker.endPage+1}&status=${pageMaker.cri.status}&keyword=${pageMaker.cri.keyword}${param.embed == '1' ? '&embed=1' : ''}">›</a></c:if>
        </div>
        <!-- 한국어: 신규 등록 및 새로고침 / 日本語：新規登録と更新 -->
        <div class="footer-actions"><span class="spacer"></span><button class="btn primary" type="button" onclick="newShipment()"><i class="mdi mdi-plus"></i> 新規(F2)</button><button class="btn" onclick="location.reload()"><i class="mdi mdi-refresh"></i> 更新</button></div>
    </div></div></main></div>
</div>
<!-- 한국어: 출하 상세 모달 / 日本語：出荷詳細モーダル -->
<div class="modal" id="detailModal"><div class="modal-box"><div class="modal-head">出荷詳細 <span class="spacer"></span><button class="modal-close" onclick="document.getElementById('detailModal').classList.remove('open')">×</button></div><div class="modal-body" id="detailBody"></div><div class="modal-actions"><button class="btn primary" type="button" onclick="editCurrentDetail()"><i class="mdi mdi-pencil-outline"></i> 編集</button></div></div></div>
<script>
// 한국어: 컨텍스트 경로와 현재 선택된 출하 ID / 日本語：コンテキストパスと選択中の出荷ID
const CTX='${pageContext.request.contextPath}';let currentShipmentId=null;
// 한국어: 신규 출하 등록 화면으로 이동 / 日本語：新規出荷登録画面へ移動
function newShipment(){location.href=CTX+'/sales/ship/input'}
// 한국어: 선택한 출하 편집 화면으로 이동 / 日本語：選択した出荷の編集画面へ移動
function editCurrentDetail(){if(currentShipmentId)location.href=CTX+'/sales/ship/input?id='+encodeURIComponent(currentShipmentId)}
// 한국어: 상태 필터 적용 / 日本語：ステータスフィルターを適用
function filterStatus(s){const u=new URL(location.href);u.searchParams.set('pageNum','1');if(s)u.searchParams.set('status',s);else u.searchParams.delete('status');location.href=u.toString()}
// 한국어: 키워드 검색 / 日本語：キーワード検索
function search(){const u=new URL(location.href);u.searchParams.set('pageNum','1');const k=document.getElementById('keyword').value.trim();if(k)u.searchParams.set('keyword',k);else u.searchParams.delete('keyword');location.href=u.toString()}
// 한국어: HTML 특수문자 이스케이프 / 日本語：HTML特殊文字をエスケープ
function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
// 한국어: 출하 상세 API 호출 후 모달 표시 / 日本語：出荷詳細APIを呼び出してモーダル表示
async function showDetail(id){currentShipmentId=id;const r=await fetch(CTX+'/sales/ship/get/'+id);if(!r.ok){alert('詳細情報を取得できませんでした。');return}const x=await r.json();document.getElementById('detailBody').innerHTML='<div class="ship-grid">'+row('',x.voucherNo)+row('日付',x.shipmentDate)+row('取引先',x.partnerName)+row('倉庫',x.warehouseName)+row('担当者',x.managerName||'-')+row('連絡先',x.contactNumber||'-')+row('郵便番号',x.postalCode||'-')+'<div class="ship-row full"><div class="ship-label">住所</div><div>'+esc(x.address||'-')+'</div></div></div><div class="table-wrap" style="margin-top:12px"><table class="modal-table"><tr><th>出荷指示書</th><th>品目コード</th><th>品目名</th><th>規格</th><th>単位</th><th>数量</th></tr>'+x.items.map(i=>'<tr><td>'+esc(i.sourceVoucherNo||' 登録')+'</td><td>'+esc(i.itemCodeSnap)+'</td><td>'+esc(i.itemNameSnap)+'</td><td>'+esc(i.specSnap)+'</td><td>'+esc(i.unitSnap)+'</td><td>'+Number(i.quantity||0).toLocaleString()+'</td></tr>').join('')+'</table></div>';document.getElementById('detailModal').classList.add('open')}
// 한국어: 상세 정보 행 생성 / 日本語：詳細情報の行を生成
function row(l,v){return '<div class="ship-row"><div class="ship-label">'+l+'</div><div>'+esc(v)+'</div></div>'}
// 한국어: F2는 신규 등록, Escape는 모달 닫기 / 日本語：F2で新規登録、Escapeでモーダルを閉じる
document.addEventListener('keydown',function(e){if(e.key==='F2'){e.preventDefault();newShipment()}if(e.key==='Escape'){document.querySelectorAll('.modal.open').forEach(function(m){m.classList.remove('open')})}});
</script>
</body></html>
