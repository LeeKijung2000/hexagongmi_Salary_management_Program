<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="my" tagdir="/WEB-INF/tags"%>
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>見積状況 - Hexagon ERP</title>
<style>
* {
	box-sizing: border-box;
}

body {
	margin: 0;
	background: #f4f7fc;
	color: #263c5c;
	font: 13px "Yu Gothic", Meiryo, "Malgun Gothic", Arial, sans-serif;
}

button, input, select {
	font: inherit;
}

button {
	cursor: pointer;
}

button:disabled {
	opacity: .5;
	cursor: not-allowed;
}

[hidden] {
	display: none !important;
}

.layout {
	display: flex;
	min-height: 100vh;
}

.main {
	flex: 1;
	min-width: 0;
	height: 100vh;
	overflow-y: auto;
}

.content {
	padding: 20px 22px 65px;
}

.top, .meta, .footer, .modal-head, .tools, .flex, .lookup-field,
	.code-set {
	display: flex;
	align-items: center;
	gap: 9px;
}

.top, .meta, .footer, .modal-head {
	justify-content: space-between;
}

.top, .footer, .tools, .flex {
	flex-wrap: wrap;
}

h1 {
	margin: 0;
	font-size: 24px;
	color: #1d3151;
}

h2 {
	margin: 0;
}

.btn {
	min-height: 36px;
	padding: 7px 14px;
	border: 1px solid #d6e1f0;
	border-radius: 11px;
	background: #fff;
	color: #36567f;
	white-space: nowrap;
}

.btn
:hover
:not
 
(
:disabled
 
)
{
background
:
 
#edf3ff
;


}
.btn.blue {
	background: #2b50dc;
	color: #fff;
	border-color: #2b50dc;
}

.field {
	min-width: 0;
	width: 100%;
	height: 39px;
	padding: 7px 11px;
	border: 1px solid #d6e1ef;
	border-radius: 9px;
	background: #fff;
	color: #2c476b;
}

.field:focus {
	outline: 2px solid #acc5fa;
}

.field[readonly] {
	background: #f2f5fa;
}

.field::placeholder {
	color: #a0afc4;
}

.report {
	margin-top: 16px;
	padding: 19px 16px;
	background: #fff;
	border: 1px solid #dbe5f1;
	border-radius: 14px;
}

.report-title {
	text-align: center;
	font-size: 26px;
	margin: 5px 0 26px;
	color: #1b3355;
}

.meta {
	margin-bottom: 10px;
	color: #6280a1;
}

.table-wrap {
	width: 100%;
	overflow-x: auto;
}

.table {
	width: 100%;
	table-layout: fixed;
	border-collapse: collapse;
	font-size: 12px;
}

.table th, .table td {
	border: 1px solid #d9e3ef;
	padding: 9px 7px;
	overflow-wrap: anywhere;
}

.table th {
	background: #ecf2fa;
}

.table tbody tr:nth-child(even) {
	background: #f9fbff;
}

.table tfoot td {
	background: #e7effb;
	font-weight: bold;
}

.right {
	text-align: right;
}

.center {
	text-align: center;
}

.link {
	border: 0;
	padding: 0;
	background: transparent;
	color: #225bb7;
	text-decoration: underline;
}

.message {
	margin-top: 12px;
	min-height: 19px;
	color: #3866b5;
}

.message.error {
	color: #c33b53;
}
/* 모달 공통 */
/* 共通モーダル */
.overlay {
	display: none;
	position: fixed;
	inset: 0;
	z-index: 8000;
	padding: 14px;
	align-items: center;
	justify-content: center;
	background: rgba(13, 25, 48, .55);
}

.overlay.open {
	display: flex !important;
}

.modal {
	display: flex;
	flex-direction: column;
	width: min(1150px, 96vw);
	max-height: 94vh;
	min-height: 0;
	overflow: hidden;
	border-radius: 15px;
	background: #f7f9fd;
	box-shadow: 0 15px 45px #0003;
}

.modal-head {
	padding: 13px 20px;
	background: #254bd4;
	color: #fff;
}

.modal-head h2 {
	font-size: 18px;
}

.tabs {
	padding: 10px 20px;
	background: #fff;
	border-bottom: 1px solid #dfe7f2;
}

.tabs b {
	display: inline-block;
	padding: 6px 12px;
	border-bottom: 2px solid #2c54d9;
	color: #2856b5;
}

.modal-body {
	flex: 1;
	min-height: 0;
	overflow-y: auto;
	padding: 16px;
}

.footer {
	padding: 11px 16px;
	border-top: 1px solid #dfe6f2;
	background: #fff;
}

.card {
	background: #fff;
	border: 1px solid #dbe5f1;
	border-radius: 14px;
	padding: 17px;
}

.search-row {
	display: grid;
	grid-template-columns: 150px minmax(0, 1fr);
	gap: 12px;
	align-items: center;
	min-height: 54px;
}

.search-row>label {
	color: #5f7899;
}

.lookup-field {
	min-width: 0;
}

.lookup-field .field {
	flex: 1;
}

.icon-btn {
	min-width: 39px;
	width: 39px;
	height: 39px;
	border: 1px solid #d7e2f1;
	background: #fff;
	border-radius: 9px;
	color: #2b5cc0;
	font-size: 20px;
}

.dates {
	display: flex;
	gap: 10px;
	align-items: center;
	flex-wrap: wrap;
}

.dates .field {
	max-width: 190px;
}

.preset {
	padding: 8px;
	border: 0;
	border-radius: 8px;
	background: transparent;
	color: #385c8e;
}

.preset:hover {
	background: #eaf1ff;
}

.hint {
	margin: 10px 0 0;
	color: #8a9db5;
	font-size: 11px;
}
/* 기준정보 조회 */
/* マスター検索 */
#lookupOverlay {
	z-index: 9900;
}

#editOverlay {
	z-index: 9000;
}

.lookup-modal {
	width: min(770px, 95vw);
}

.lookup-table {
	width: 100%;
	border-collapse: collapse;
	background: #fff;
}

.lookup-table th, .lookup-table td {
	padding: 10px;
	border: 1px solid #d9e3ef;
	text-align: left;
}

.lookup-table th {
	background: #edf2fa;
}

.lookup-table tbody tr:hover {
	background: #eaf2ff;
	cursor: pointer;
}
/* 견적서 수정 */
/* 見積書の編集 */
.edit-grid {
	display: grid;
	grid-template-columns: 1fr 1fr;
	gap: 12px 20px;
}

.edit-line {
	display: grid;
	grid-template-columns: 95px minmax(0, 1fr);
	align-items: center;
	gap: 8px;
}

.edit-line.wide {
	grid-column: 1/-1;
}

.code-set {
	min-width: 0;
}

.code-set .field {
	flex: 1;
	width: 30%;
}

.edit-table {
	width: 100%;
	min-width: 1040px;
	border-collapse: collapse;
	background: #fff;
}

.edit-table th, .edit-table td {
	border: 1px solid #dce4ef;
	padding: 5px;
}

.edit-table th {
	background: #edf2f9;
}

.edit-table
 
input
:not
 
(
[
type
=
checkbox
]
 
)
{
width
:
 
100%;
min-width
:
 
0;
height
:
 
33
px
;

	
padding
:
 
5
px
;

	
border
:
 
1
px
 
solid
 
#d6e1f0
;

	
border-radius
:
 
6
px
;


}
.edit-table input[readonly] {
	background: #f2f5fa;
}

.edit-table tfoot td {
	font-weight: bold;
	background: #edf2f9;
}

.locked {
	margin-bottom: 10px;
	padding: 12px;
	background: #fff3df;
	color: #916229;
	border-radius: 9px;
}

@media ( max-width :800px) {
	.content {
		padding: 12px;
	}
	.search-row {
		grid-template-columns: 102px minmax(0, 1fr);
	}
	.edit-grid {
		grid-template-columns: 1fr;
	}
	.edit-line.wide {
		grid-column: auto;
	}
	.table th, .table td {
		padding: 5px 4px;
		font-size: 10px;
	}
}
/* 견적서조회(inquiry.jsp) 수정 모달과 동일한 화면 규격 */
/* 見積書照会（inquiry.jsp）の編集モーダルと同一の画面仕様 */
#editOverlay {
	padding: 18px;
}

#editOverlay .modal {
	width: min(1180px, 97vw);
	max-height: 93vh;
	background: #f5f7fb;
	border-radius: 14px;
}

#editOverlay .modal-head {
	padding: 12px 16px;
	background: #254bd4;
}

#editOverlay .modal-head h2 {
	margin: 0;
	font-size: 16px;
	font-weight: 700;
}

#editOverlay .modal-body {
	padding: 15px;
	background: #f5f7fb;
}

#editOverlay .card {
	margin-bottom: 12px;
	padding: 15px;
	border: 1px solid #dce4f0;
	border-radius: 14px;
	background: white;
}

#editOverlay .edit-grid {
	display: grid;
	grid-template-columns: 1fr 1fr;
	gap: 11px 17px;
}

#editOverlay .edit-line, #editOverlay .edit-field {
	display: grid;
	grid-template-columns: 98px minmax(0, 1fr);
	align-items: center;
	gap: 8px;
}

#editOverlay .edit-line.wide, #editOverlay .edit-field.wide {
	grid-column: 1/-1;
}

#editOverlay .edit-line>label, #editOverlay .edit-field>label {
	color: #60789b;
}

#editOverlay .field, #editOverlay .input, #editOverlay .select {
	width: 100%;
	min-width: 0;
	min-height: 35px;
	height: 35px;
	padding: 6px 10px;
	border: 1px solid #d8e2f0;
	border-radius: 9px;
	background: #fff;
	color: #304b73;
}

#editOverlay input[readonly] {
	background: #f3f5f9;
}

#editOverlay .code-set, #editOverlay .code-group {
	display: flex;
	align-items: center;
	gap: 4px;
	min-width: 0;
}

#editOverlay .code-set .field, #editOverlay .code-group .input {
	flex: 1;
	width: 40%;
}

#editOverlay .icon-btn {
	width: auto;
	min-width: 34px;
	height: 32px;
	padding: 5px 10px;
	border: 1px solid #d8e2f1;
	border-radius: 13px;
	background: #fff;
	color: #365176;
	font-size: 13px;
}

#editOverlay .btn {
	min-height: 32px;
	padding: 5px 13px;
	border-radius: 13px;
}

#editOverlay .btn.blue, #editOverlay .btn.primary {
	background: #3052e8;
	border-color: #3052e8;
	color: #fff;
}

#editOverlay .tools, #editOverlay .edit-toolbar {
	display: flex;
	gap: 8px;
	margin: 0 0 9px !important;
	align-items: center;
}

#editOverlay .table-wrap {
	overflow-x: auto;
	width: 100%;
}

#editOverlay .edit-table {
	width: 100%;
	min-width: 850px;
	border-collapse: collapse;
	background: #fff;
}

#editOverlay .edit-table th, #editOverlay .edit-table td {
	border: 1px solid #dce4ee;
	padding: 6px;
}

#editOverlay .edit-table th {
	text-align: center;
	background: #edf2f9;
}

#editOverlay
 
.edit-table
 
td
 
input
:not
 
(
[
type
=
checkbox
]
 
)
{
width
:
 
100%;
min-width
:
 
0;
min-height
:
 
35
px
;

	
height
:
 
35
px
;

	
padding
:
 
6
px
 
10
px
;

	
border
:
 
1
px
 
solid
 
#d8e2f0
;

	
border-radius
:
 
9
px
;

	
background
:
 
#fff
;

	
color
:
 
#304b73
;


}
#editOverlay .edit-table td input[readonly] {
	background: #f3f5f9;
}

#editOverlay .edit-table tfoot td {
	background: #edf2f9;
	font-weight: bold;
}

#editOverlay .footer, #editOverlay .modal-foot {
	display: flex;
	align-items: center;
	justify-content: flex-end;
	gap: 8px;
	padding: 10px 15px;
	background: #fff;
	border-top: 1px solid #dce4f0;
}

#editOverlay .footer>.hint, #editOverlay .modal-foot>.hint {
	display: none;
}

#editOverlay .locked {
	margin-bottom: 12px;
}

#editOverlay .message {
	font-size: 12px;
}

@media ( max-width :850px) {
	#editOverlay .edit-grid {
		grid-template-columns: 1fr;
	}
	#editOverlay .edit-line.wide, #editOverlay .edit-field.wide {
		grid-column: auto;
	}
}
</style>
</head>
<body>
    <div class="layout">
        <my:sideMenu />
        <div class="main">
            <main class="content">
                <div class="top">
                    <h1>見積状況</h1>
                    <div class="flex">
                        <input id="quick" class="field" style="width: 190px" placeholder="入力後Enter">
                        <button id="openSearch" type="button" class="btn blue">Search(F3)</button>
                    </div>
                </div>
                <section class="report">
                    <h2 class="report-title">見積状況明細</h2>
                    <div class="meta">
                        <span>会社名：Hexagon ERP</span> <span id="period">照会前</span>
                    </div>
                    <div class="table-wrap">
                        <table class="table">
                            <colgroup>
                                <col style="width: 17%">
                                <col style="width: 24%">
                                <col style="width: 9%">
                                <col style="width: 10%">
                                <col style="width: 13%">
                                <col style="width: 16%">
                                <col style="width: 11%">
                            </colgroup>
                            <thead>
                                <tr>
                                    <th>日付-No.</th>
                                    <th>品目名（規格）</th>
                                    <th>数量</th>
                                    <th>単価</th>
                                    <th>供給価額</th>
                                    <th>取引先名</th>
                                    <th>新しい項目を追加</th>
                                </tr>
                            </thead>
                            <tbody id="results">
                                <tr>
                                    <td colspan="7" class="center">検索条件を設定してください。</td>
                                </tr>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="2" class="center">合計</td>
                                    <td id="sumQty" class="right">0</td>
                                    <td></td>
                                    <td id="sumSupply" class="right">0</td>
                                    <td colspan="2"></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                    <p id="count" class="hint" style="text-align: right">照会前</p>
                </section>
                <p id="pageMessage" class="message" role="status"></p>
            </main>
        </div>
    </div>
    <!--
    견적서현황 검색 모달
    見積書現況の検索モーダル
    중요: class="overlay open"
    重要：class="overlay open"
    처음부터 검색창을 화면에 표시
    初期状態から検索画面を表示
-->
    <div id="searchOverlay" class="overlay open" role="dialog" aria-modal="true" aria-label="見積状況 検索条件">
        <div class="modal">
            <div class="modal-head">
                <h2>見積状況 - 検索条件</h2>
                <button id="searchCloseTop" type="button" class="btn">閉じる ×</button>
            </div>
            <div class="tabs">
                <b>基本</b>
            </div>
            <div class="modal-body">
                <div class="card">
                    <div class="search-row">
                        <label>基準日</label>
                        <div class="dates">
                            <input id="from" type="date" class="field"> <span>~</span> <input id="to" type="date" class="field">
                        </div>
                    </div>
                    <div class="search-row">
                        <label for="voucher"> 見積No. </label> <input id="voucher" class="field" placeholder="見積番号を入力">
                    </div>
                    <div class="search-row">
                        <label for="partner">取引先</label>
                        <div class="lookup-field">
                            <input id="partner" class="field" placeholder="取引先名 検索">
                            <button type="button" class="icon-btn" data-search="partner" aria-label="取引先検索">⌕</button>
                        </div>
                    </div>
                    <div class="search-row">
                        <label for="item">品目コード</label>
                        <div class="lookup-field">
                            <input id="item" class="field" placeholder="品目コードまたは品目名">
                            <button type="button" class="icon-btn" data-search="item" aria-label="品目検索">⌕</button>
                        </div>
                    </div>
                    <div class="search-row">
                        <label for="manager">担当者</label>
                        <div class="lookup-field">
                            <input id="manager" class="field" placeholder="担当者名 検索">
                            <button type="button" class="icon-btn" data-search="manager" aria-label="担当者検索">⌕</button>
                        </div>
                    </div>
                    <div class="search-row">
                        <label for="progress"> 進捗状態 </label> <select id="progress" class="field">
                            <option value="">すべて</option>
                            <option value="OPEN">進行中</option>
                            <option value="PARTIAL">一部受注</option>
                            <option value="COMPLETED">完了</option>
                        </select>
                    </div>
                    <p class="hint">既存のOracle見積状況の検索条件を使用します。</p>
                    <p id="searchMessage" class="message" role="status"></p>
                </div>
            </div>
            <div class="footer">
                <div class="flex">
                    <button type="button" class="preset" data-period="today">本日</button>
                    <button type="button" class="preset" data-period="yesterday">前日</button>
                    <button type="button" class="preset" data-period="week">今週（本日まで）</button>
                    <button type="button" class="preset" data-period="lastweek">先週</button>
                    <button type="button" class="preset" data-period="month">今月（本日まで）</button>
                    <button type="button" class="preset" data-period="lastmonth">先月</button>
                    <button type="button" class="preset" data-period="last30">直近30日</button>
                    <button type="button" class="preset" data-period="year">今年</button>
                </div>
                <div class="flex">
                    <button id="resetSearch" type="button" class="btn">再入力</button>
                    <button id="runSearch" type="button" class="btn blue">検索（F8）</button>
                    <button id="searchCloseBottom" type="button" class="btn">閉じる</button>
                </div>
            </div>
        </div>
    </div>
    <!--
    기준정보 돋보기 모달
    マスター検索モーダル
-->
    <div id="lookupOverlay" class="overlay" role="dialog" aria-modal="true" aria-label="マスター情報検索">
        <div class="modal lookup-modal">
            <div class="modal-head">
                <h2 id="lookupTitle">マスター情報検索</h2>
                <button id="lookupClose" type="button" class="btn">閉じる ×</button>
            </div>
            <div class="modal-body">
                <div class="flex" style="margin-bottom: 12px">
                    <input id="lookupKeyword" class="field" style="flex: 1" placeholder="コードまたは名称で検索">
                    <button id="lookupRun" type="button" class="btn blue">検索</button>
                </div>
                <table class="lookup-table">
                    <thead id="lookupHead"></thead>
                    <tbody id="lookupRows"></tbody>
                </table>
                <p id="lookupMessage" class="hint"></p>
            </div>
        </div>
    </div>
    <!--
    견적서입력 수정 모달
    見積書入力の編集モーダル
-->
    <div id="editOverlay" class="overlay" role="dialog" aria-modal="true" aria-label="見積書入力の編集">
        <div class="modal">
            <div class="modal-head">
                <h2 id="editTitle">見積書入力（編集）</h2>
                <button id="editCloseTop" type="button" class="btn">閉じる ×</button>
            </div>
            <div id="editBody" class="modal-body">
                <div id="editLocked" class="locked" hidden>関連する受注伝票または売上伝票があるため、照会のみ可能です。</div>
                <div class="card">
                    <div class="edit-grid">
                        <div class="edit-line">
                            <label>日付</label> <input id="edDate" class="field" type="date">
                        </div>
                        <div class="edit-line">
                            <label>取引先</label>
                            <div class="code-set">
                                <input id="edPartnerCode" class="field" placeholder="取引先コード">
                                <button class="icon-btn" type="button" data-edit-lookup="partner">⌕</button>
                                <input id="edPartnerName" class="field" readonly>
                            </div>
                        </div>
                        <div class="edit-line">
                            <label>担当者</label>
                            <div class="code-set">
                                <input id="edManagerCode" class="field" placeholder="担当者コード">
                                <button class="icon-btn" type="button" data-edit-lookup="manager">⌕</button>
                                <input id="edManagerName" class="field" readonly>
                            </div>
                        </div>
                        <div class="edit-line">
                            <label>出荷倉庫</label>
                            <div class="code-set">
                                <input id="edWarehouseCode" class="field" placeholder="倉庫コード">
                                <button class="icon-btn" type="button" data-edit-lookup="warehouse">⌕</button>
                                <input id="edWarehouseName" class="field" readonly>
                            </div>
                        </div>
                        <div class="edit-line">
                            <label>取引区分</label> <select id="edTransaction" class="field">
                                <option value="TAXABLE">消費税適用</option>
                                <option value="EXEMPT">免税</option>
                            </select>
                        </div>
                        <div class="edit-line">
                            <label>通貨 / 為替レート</label>
                            <div class="code-set">
                                <select id="edCurrency" class="field">
                                </select> <input id="edRate" class="field" type="number" min="0" step="any">
                            </div>
                        </div>
                        <div class="edit-line">
                            <label>有効期限</label> <input id="edValid" class="field" type="date">
                        </div>
                        <div class="edit-line">
                            <label>添付</label>
                            <div class="flex">
                                <a id="edDownload" href="#" target="_blank" rel="noopener" hidden> 添付ファイルをダウンロード </a> <input id="edFile" type="file" accept=".png,.jpg,.jpeg,.pdf,.txt,.docx,.xlsx">
                            </div>
                        </div>
                        <div class="edit-line wide">
                            <label>新しい項目を追加</label> <input id="edCustom" class="field">
                        </div>
                    </div>
                </div>
                <div class="tools" style="margin: 12px 0">
                    <button id="addRow" class="btn" type="button">＋ 行追加</button>
                    <button id="deleteRows" class="btn" type="button">選択行を削除</button>
                </div>
                <div class="table-wrap">
                    <table class="edit-table">
                        <thead>
                            <tr>
                                <th>選択</th>
                                <th>品目コード</th>
                                <th>品目名</th>
                                <th>規格</th>
                                <th>数量</th>
                                <th>単価</th>
                                <th>供給価額</th>
                                <th>消費税</th>
                                <th>合計金額</th>
                            </tr>
                        </thead>
                        <tbody id="editRows"></tbody>
                        <tfoot>
                            <tr>
                                <td colspan="6">合計</td>
                                <td id="editSupply" class="right">0</td>
                                <td id="editVat" class="right">0</td>
                                <td id="editTotal" class="right">0</td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                <p id="editMessage" class="message" role="status"></p>
            </div>
            <div class="footer">
                <span class="hint"> 既存の見積書更新APIを使用 </span>
                <div class="flex">
                    <button id="editSave" type="button" class="btn blue">保存(F8)</button>
                    <button id="editCloseBottom" type="button" class="btn">閉じる</button>
                </div>
            </div>
        </div>
    </div>
    <script>
(function () {
"use strict";
// 견적서현황
// 見積書現況
// async/await 대신 Promise 사용
// async/awaitの代わりにPromiseを使用
function init() {
var context = "${pageContext.request.contextPath}";
var api = context + "/sales/estimate/api";
var rows = [];
var searched = false;
var searchNo = 0;
var lookupNo = 0;
var lookupType = "";
var lookupMode = "";
var lookupCallback = null;
var editId = null;
var readOnly = false;
var saving = false;
// 공통 함수
// 共通関数
function E(id) {
return document.getElementById(id);
}
function V(id) {
return E(id).value.trim();
}
function S(id, value) {
E(id).value =
value == null ? "" : String(value);
}
function T(value) {
return value == null ? "" : String(value);
}
function N(value) {
var x = Number(value);
return isFinite(x) ? x : 0;
}
function M(value) {
return N(value).toLocaleString("ja-JP", {
maximumFractionDigits: 2
});
}
function Q(value) {
return N(value).toLocaleString("ja-JP", {
minimumFractionDigits: 2,
maximumFractionDigits: 4
});
}
function date(d) {
return d.getFullYear()
+ "-"
+ ("0" + (d.getMonth() + 1)).slice(-2)
+ "-"
+ ("0" + d.getDate()).slice(-2);
}
function today() {
var d = new Date();
return new Date(
d.getFullYear(),
d.getMonth(),
d.getDate()
);
}
function note(id, text, bad) {
E(id).textContent = text;
E(id).className = bad
? "message error"
: "message";
}
function open(id) {
E(id).classList.add("open");
}
function close(id) {
E(id).classList.remove("open");
}
function cell(tr, value, cls) {
var td = document.createElement("td");
td.textContent = T(value);
if (cls) {
td.className = cls;
}
tr.appendChild(td);
return td;
}
// API 공통 호출
// APIの共通呼出し
function req(url, options) {
var settings = Object.assign(
{ credentials: "same-origin" },
options || {}
);
settings.headers = Object.assign(
{ Accept: "application/json" },
settings.headers || {}
);
return fetch(url, settings).then(
function (response) {
return response.text().then(
function (raw) {
var json = null;
try {
json = raw
? JSON.parse(raw)
: null;
} catch (ignore) {
}
if (!response.ok) {
throw Error(
(json && json.message)
|| raw.substring(0, 160)
|| ("HTTP " + response.status)
);
}
if (
json
&& json.success === false
) {
throw Error(
json.message || "処理に失敗しました"
);
}
return json;
}
);
}
);
}
// 날짜 초기화
// 日付の初期化
function setDates() {
var d = today();
S(
"from",
date(
new Date(
d.getFullYear(),
d.getMonth(),
1
)
)
);
S("to", date(d));
}
// 검색 조건 다시작성
// 検索条件の再入力
function reset() {
S("voucher", "");
S("partner", "");
S("item", "");
S("manager", "");
S("progress", "");
setDates();
note("searchMessage", "");
}
// Oracle 견적서현황 조회
// Oracleから見積書現況を取得
function doSearch() {
var from = V("from");
var to = V("to");
if (from && to && from > to) {
note(
"searchMessage",
"開始日が終了日より後になっています。",
true
);
return Promise.resolve();
}
var params = new URLSearchParams();
[
["start_date", from],
["end_date", to],
["voucher_no", V("voucher")],
["partner_name", V("partner")],
["item_keyword", V("item")],
["manager_name", V("manager")],
["progress_status", V("progress")]
].forEach(function (entry) {
params.set(entry[0], entry[1]);
});
var serial = ++searchNo;
E("runSearch").disabled = true;
note(
"searchMessage",
"Oracleからデータを取得しています。"
);
return req(
api + "/status?" + params.toString()
).then(function (data) {
if (serial !== searchNo) {
return;
}
if (!Array.isArray(data)) {
throw Error(
"検索結果が配列ではありません。"
);
}
rows = data;
searched = true;
S("quick", "");
E("period").textContent =
from + " ~ " + to;
render();
close("searchOverlay");
note(
"pageMessage",
"照会完了 : 品目 "
+ data.length
+ "行"
);
note("searchMessage", "");
}).catch(function (error) {
note(
"searchMessage",
"照会に失敗しました： " + error.message,
true
);
note(
"pageMessage",
"照会に失敗しました： " + error.message,
true
);
}).then(function () {
E("runSearch").disabled = false;
});
}
// 검색 결과표
// 検索結果テーブル
function render() {
if (!searched) {
return;
}
var keyword = V("quick").toLowerCase();
var list = rows.filter(function (r) {
if (!keyword) {
return true;
}
return [
r.quote_date,
r.voucher_no,
r.partner_name,
r.manager_name,
r.item_code_snap,
r.item_name_snap,
r.spec_snap,
r.custom_data
].map(T).join(" ").toLowerCase()
.indexOf(keyword) >= 0;
});
var body = E("results");
body.textContent = "";
var qtySum = 0;
var supplySum = 0;
var ids = {};
list.forEach(function (r) {
var tr = document.createElement("tr");
var td = document.createElement("td");
var link = document.createElement("button");
link.type = "button";
link.className = "link";
link.textContent =
T(r.quote_date).substring(0, 10)
+ " - "
+ T(r.voucher_no);
link.addEventListener(
"click",
function () {
showEdit(r.quote_id);
}
);
td.appendChild(link);
tr.appendChild(td);
var itemName = T(r.item_name_snap);
if (r.spec_snap) {
itemName +=
" [" + r.spec_snap + "]";
}
cell(tr, itemName);
cell(
tr,
Q(r.quantity),
"right"
);
cell(
tr,
M(r.unit_price),
"right"
);
cell(
tr,
M(r.supply_amount),
"right"
);
cell(tr, r.partner_name);
// Oracle TB_QUOTATION.CUSTOM_DATA 표시
// OracleのTB_QUOTATION.CUSTOM_DATAを表示
cell(tr, T(r.custom_data).trim() || "—");
body.appendChild(tr);
qtySum += N(r.quantity);
supplySum += N(r.supply_amount);
ids[r.quote_id] = true;
});
if (!list.length) {
var empty = document.createElement("tr");
cell(
empty,
"条件に一致する見積書がありません。",
"center"
).colSpan = 7;
body.appendChild(empty);
}
E("sumQty").textContent = Q(qtySum);
E("sumSupply").textContent = M(supplySum);
E("count").textContent =
"見積書 "
+ Object.keys(ids).length
+ "件 / 品目 "
+ list.length
+ "行";
}
// 날짜 단축 버튼
// 日付のクイック選択ボタン
function preset(kind) {
var d = today();
var start = new Date(d);
var end = new Date(d);
var weekday = (d.getDay() + 6) % 7;
if (kind === "yesterday") {
start.setDate(start.getDate() - 1);
end = new Date(start);
} else if (kind === "week") {
start.setDate(
start.getDate() - weekday
);
} else if (kind === "lastweek") {
start.setDate(
start.getDate() - weekday - 7
);
end.setDate(
end.getDate() - weekday - 1
);
} else if (kind === "month") {
start = new Date(
d.getFullYear(),
d.getMonth(),
1
);
} else if (kind === "lastmonth") {
start = new Date(
d.getFullYear(),
d.getMonth() - 1,
1
);
end = new Date(
d.getFullYear(),
d.getMonth(),
0
);
} else if (kind === "last30") {
start.setDate(
start.getDate() - 29
);
} else if (kind === "year") {
start = new Date(
d.getFullYear(),
0,
1
);
}
S("from", date(start));
S("to", date(end));
doSearch();
}
// 기준정보 돋보기
// マスター検索ボタン
function closeLookup() {
lookupNo++;
close("lookupOverlay");
}
function showLookup(
type,
mode,
keyword,
callback
) {
lookupType = type;
lookupMode = mode;
lookupCallback = callback;
var titles = {
partner: "取引先",
manager: "担当者",
warehouse: "倉庫",
item: "品目"
};
E("lookupTitle").textContent =
(titles[type] || "マスター情報")
+ " 照会";
S("lookupKeyword", keyword);
open("lookupOverlay");
runLookup();
}
function runLookup() {
var type = lookupType;
var mode = lookupMode;
var keyword = V("lookupKeyword");
var serial = ++lookupNo;
E("lookupMessage").textContent =
"照会しています。";
E("lookupRows").textContent = "";
var load;
// 담당자는 기존 기준정보 API 사용
// 担当者は既存のマスター検索APIを使用
// 담당자 코드까지 가져오기 위해 필요
// 担当者コードも取得するため必要
if (
mode === "master"
|| type === "manager"
) {
load = req(
api
+ "/quotation-lookup/"
+ type
+ "?keyword="
+ encodeURIComponent(keyword)
);
} else {
// 견적서에 존재하는 거래처와 품목 조회
// 見積書に含まれる取引先と品目を取得
var params = new URLSearchParams();
params.set(
type === "partner"
? "partner_name"
: "item_keyword",
keyword
);
load = req(
api
+ "/status?"
+ params.toString()
).then(function (data) {
var unique = {};
(data || []).forEach(function (r) {
var code =
type === "item"
? T(r.item_code_snap)
: T(r.business_partner_id);
var name =
type === "item"
? T(r.item_name_snap)
: T(r.partner_name);
unique[code + "|" + name] = {
code: code,
name: name,
spec: type === "item"
? T(r.spec_snap)
: ""
};
});
return Object.keys(unique)
.map(function (key) {
return unique[key];
});
});
}
return load.then(function (data) {
if (serial !== lookupNo) {
return;
}
if (!Array.isArray(data)) {
throw Error(
"検索データの形式エラー"
);
}
var list = data.map(function (r) {
return {
code: T(r.code || r.CODE),
name: T(r.name || r.NAME),
spec: T(r.spec || r.SPEC),
unit_name: T(r.unit_name),
unit_price: r.unit_price,
vat_rate: r.vat_rate,
total_qty: null
};
});
// 품목 조회 시 단가 대신 전체재고
// 品目検索時は単価の代わりに全体在庫を表示
if (type !== "item" || !list.length) {
return list;
}
var codes = list.map(function (r) {
return r.code;
}).filter(Boolean);
if (!codes.length) {
return list;
}
return req(
api + "/input/inventory",
{
method: "POST",
headers: {
"Content-Type": "application/json"
},
body: JSON.stringify({
warehouse_code: "",
item_codes: codes
})
}
).then(function (stocks) {
var stockMap = {};
(stocks || []).forEach(function (r) {
stockMap[
T(r.item_code).toUpperCase()
] = r.total_qty;
});
list.forEach(function (r) {
var key = r.code.toUpperCase();
if (
Object.prototype.hasOwnProperty.call(
stockMap,
key
)
) {
r.total_qty = stockMap[key];
}
});
return list;
}).catch(function (error) {
E("lookupMessage").textContent =
"在庫を取得できませんでした： "
+ error.message;
return list;
});
}).then(function (list) {
if (serial !== lookupNo) {
return;
}
var head = E("lookupHead");
var body = E("lookupRows");
head.textContent = "";
body.textContent = "";
var header = document.createElement("tr");
var titles =
type === "item"
? [
"コード",
"品目名",
"規格",
"全体在庫"
]
: [
"コード",
"名称"
];
titles.forEach(function (title) {
var th = document.createElement("th");
th.textContent = title;
header.appendChild(th);
});
head.appendChild(header);
list.forEach(function (r) {
var tr = document.createElement("tr");
cell(tr, r.code);
cell(tr, r.name);
if (type === "item") {
cell(tr, r.spec);
cell(
tr,
r.total_qty == null
? "—"
: Q(r.total_qty),
"right"
);
}
tr.addEventListener(
"click",
function () {
var callback = lookupCallback;
closeLookup();
if (callback) {
callback(r);
}
}
);
body.appendChild(tr);
});
if (!list.length) {
var empty = document.createElement("tr");
cell(
empty,
"検索結果がありません。"
).colSpan =
type === "item" ? 4 : 2;
body.appendChild(empty);
}
if (
E("lookupMessage").textContent
.indexOf("在庫を") !== 0
) {
E("lookupMessage").textContent =
list.length + "件 照会";
}
}).catch(function (error) {
if (serial !== lookupNo) {
return;
}
E("lookupMessage").textContent =
"マスター情報の照会に失敗しました： "
+ error.message;
});
}
// 견적서 수정 모달
// 見積書の編集モーダル
function showEdit(id) {
if (id == null) {
note(
"pageMessage",
"見積書IDがありません。",
true
);
return;
}
editId = id;
readOnly = false;
E("editTitle").textContent =
"見積書入力（編集）";
E("editSave").hidden = true;
E("editRows").textContent = "";
note(
"editMessage",
"見積書を照会しています。"
);
open("editOverlay");
req(
api + "/quotations/" + id + "/detail"
).then(function (detail) {
if (editId !== id) {
return;
}
var header = detail.header || {};
var items = detail.items || [];
[
[
"edDate",
T(header.quote_date).substring(0, 10)
],
[
"edValid",
T(header.valid_until).substring(0, 10)
],
["edPartnerCode", header.partner_code],
["edPartnerName", header.partner_name],
["edManagerCode", header.manager_code],
["edManagerName", header.manager_name],
["edWarehouseCode", header.warehouse_code],
["edWarehouseName", header.warehouse_name],
[
"edTransaction",
header.transaction_type || "TAXABLE"
],
[
"edRate",
header.exchange_rate == null
? 1
: header.exchange_rate
],
["edCustom", header.custom_data]
].forEach(function (entry) {
S(entry[0], entry[1]);
});
E("editTitle").textContent = "見積書入力（編集）";
E("edFile").value = "";
E("edDownload").hidden =
!header.attachment_path;
if (header.attachment_path) {
E("edDownload").href =
api
+ "/input/quotations/"
+ id
+ "/attachment";
}
// Oracle 통화 목록
// Oracleの通貨一覧
return req(
api + "/input/currencies"
).then(function (currencies) {
var select = E("edCurrency");
select.textContent = "";
var list = Array.isArray(currencies)
? currencies
: (
currencies
&& currencies.data
) || [];
list.forEach(function (currency) {
var option =
document.createElement("option");
option.value =
currency.currency_id;
option.textContent =
T(currency.currency_code)
+ " - "
+ T(currency.currency_name);
select.appendChild(option);
});
if (header.currency_id != null) {
var hasCurrency =
Array.from(select.options)
.some(function (option) {
return option.value
=== T(header.currency_id);
});
if (!hasCurrency) {
var option =
document.createElement("option");
option.value =
header.currency_id;
option.textContent =
"通貨 ID "
+ header.currency_id;
select.appendChild(option);
}
select.value =
T(header.currency_id);
}
}).catch(function (error) {
note(
"editMessage",
"通貨の取得に失敗しました： "
+ error.message,
true
);
}).then(function () {
E("editRows").textContent = "";
items.forEach(addEditRow);
if (!items.length) {
addEditRow({});
}
calcTotals();
readOnly = !!detail.linked;
E("editLocked").hidden =
!readOnly;
E("editBody")
.querySelectorAll(
"input,select,button"
)
.forEach(function (control) {
control.disabled = readOnly;
});
E("editSave").hidden =
readOnly;
if (!readOnly) {
note("editMessage", "");
}
});
}).catch(function (error) {
note(
"editMessage",
"見積書の詳細照会に失敗しました： "
+ error.message,
true
);
});
}
// 수정 행 함수
// 編集行の処理関数
function ef(tr, key) {
return tr.querySelector(
'[data-f="' + key + '"]'
);
}
function ev(tr, key) {
return ef(tr, key).value.trim();
}
function mk(key, value, type) {
var input =
document.createElement("input");
input.dataset.f = key;
input.type = type || "text";
input.value = T(value);
if (type === "number") {
input.min = "0";
input.step = "any";
input.style.textAlign = "right";
}
return input;
}
function calcRow(tr, automatic) {
if (automatic) {
var supply = Math.round(
N(ev(tr, "quantity"))
* N(ev(tr, "unit_price"))
* 100
) / 100;
var vat =
V("edTransaction") === "EXEMPT"
? 0
: Math.round(
supply
* N(tr.dataset.vatRate || 10)
) / 100;
ef(tr, "supply_amount").value =
supply.toFixed(2);
ef(tr, "vat_amount").value =
vat.toFixed(2);
}
ef(tr, "total_amount").value = (
N(ev(tr, "supply_amount"))
+ N(ev(tr, "vat_amount"))
).toFixed(2);
calcTotals();
}
function calcTotals() {
var supply = 0;
var vat = 0;
E("editRows")
.querySelectorAll("tr")
.forEach(function (tr) {
supply += N(
ev(tr, "supply_amount")
);
vat += N(
ev(tr, "vat_amount")
);
});
E("editSupply").textContent =
M(supply);
E("editVat").textContent =
M(vat);
E("editTotal").textContent =
M(supply + vat);
}
function addEditRow(item) {
item = item || {};
var tr = document.createElement("tr");
tr.dataset.unitName =
T(item.unit_name);
tr.dataset.vatRate =
T(
item.vat_rate == null
? 10
: item.vat_rate
);
var checkTd =
document.createElement("td");
var check =
document.createElement("input");
check.type = "checkbox";
check.className = "row-check";
checkTd.appendChild(check);
tr.appendChild(checkTd);
var codeTd =
document.createElement("td");
var group =
document.createElement("div");
group.className = "code-set";
var code = mk(
"item_code",
item.item_code
);
var button =
document.createElement("button");
button.type = "button";
button.className = "icon-btn";
button.textContent = "⌕";
function choose() {
if (readOnly) {
return;
}
showLookup(
"item",
"master",
code.value,
function (result) {
ef(tr, "item_code").value =
T(result.code);
ef(tr, "item_name").value =
T(result.name);
ef(tr, "spec").value =
T(result.spec);
tr.dataset.unitName =
T(result.unit_name);
tr.dataset.vatRate =
T(
result.vat_rate == null
? 10
: result.vat_rate
);
if (
result.unit_price != null
) {
ef(tr, "unit_price").value =
result.unit_price;
}
calcRow(tr, true);
}
);
}
button.addEventListener(
"click",
choose
);
code.addEventListener(
"dblclick",
choose
);
group.appendChild(code);
group.appendChild(button);
codeTd.appendChild(group);
tr.appendChild(codeTd);
[
["item_name", "text"],
["spec", "text"],
["quantity", "number"],
["unit_price", "number"],
["supply_amount", "number"],
["vat_amount", "number"],
["total_amount", "text"]
].forEach(function (definition) {
var name = definition[0];
var td =
document.createElement("td");
var input = mk(
name,
item[name],
definition[1]
);
if (name === "total_amount") {
input.readOnly = true;
}
if (
name === "quantity"
|| name === "unit_price"
) {
input.addEventListener(
"input",
function () {
calcRow(tr, true);
}
);
}
if (
name === "supply_amount"
|| name === "vat_amount"
) {
input.addEventListener(
"input",
function () {
calcRow(tr, false);
}
);
}
td.appendChild(input);
tr.appendChild(td);
});
E("editRows").appendChild(tr);
calcTotals();
}
// 견적서 수정 저장
// 見積書修正内容の保存
function saveEdit() {
if (
editId == null
|| readOnly
|| saving
) {
return;
}
var items = [];
try {
E("editRows")
.querySelectorAll("tr")
.forEach(function (tr) {
var code =
ev(tr, "item_code");
var name =
ev(tr, "item_name");
var qty =
ev(tr, "quantity");
if (
!code
&& !name
&& !qty
) {
return;
}
if (
!code
|| N(qty) <= 0
) {
throw Error(
"品目コードと0より大きい数量を入力してください。"
);
}
items.push({
item_code: code,
item_name: name,
spec: ev(tr, "spec"),
unit_name:
tr.dataset.unitName || "",
quantity: qty,
unit_price:
ev(tr, "unit_price"),
supply_amount:
ev(tr, "supply_amount"),
vat_amount:
ev(tr, "vat_amount")
});
});
if (!items.length) {
throw Error(
"品目を入力してください。"
);
}
} catch (error) {
note(
"editMessage",
error.message,
true
);
return;
}
var id = editId;
var payload = {
quote_date:
V("edDate"),
valid_until:
V("edValid"),
partner_code:
V("edPartnerCode"),
manager_code:
V("edManagerCode"),
warehouse_code:
V("edWarehouseCode"),
transaction_type:
V("edTransaction"),
currency_id:
V("edCurrency"),
exchange_rate:
V("edRate"),
custom_data:
V("edCustom"),
items: items
};
saving = true;
E("editSave").disabled = true;
note(
"editMessage",
"保存しています。"
);
req(
api + "/quotations/" + id,
{
method: "PUT",
headers: {
"Content-Type":
"application/json"
},
body:
JSON.stringify(payload)
}
).then(function () {
var file =
E("edFile").files[0];
if (!file) {
return "";
}
var form = new FormData();
form.append("file", file);
return req(
api
+ "/input/quotations/"
+ id
+ "/attachment",
{
method: "POST",
body: form
}
).then(function () {
return "";
}).catch(function (error) {
return error.message;
});
}).then(function (uploadError) {
close("editOverlay");
editId = null;
return doSearch().then(function () {
note(
"pageMessage",
uploadError
? "見積書は保存されましたが、添付ファイルのアップロードに失敗しました： "
+ uploadError
: "見積書が更新されました。",
!!uploadError
);
});
}).catch(function (error) {
note(
"editMessage",
"更新に失敗しました： " + error.message,
true
);
}).then(function () {
saving = false;
E("editSave").disabled = false;
});
}
// 클릭 이벤트 등록
// クリックイベントの登録
E("openSearch").addEventListener(
"click",
function () {
open("searchOverlay");
}
);
E("searchCloseTop").addEventListener(
"click",
function () {
close("searchOverlay");
}
);
E("searchCloseBottom").addEventListener(
"click",
function () {
close("searchOverlay");
}
);
E("resetSearch").addEventListener(
"click",
reset
);
E("runSearch").addEventListener(
"click",
doSearch
);
E("quick").addEventListener(
"keydown",
function (event) {
if (event.key === "Enter") {
event.preventDefault();
if (searched) {
render();
} else {
open("searchOverlay");
}
}
}
);
// 날짜 단축 버튼
// 日付のクイック選択ボタン
document.querySelectorAll(
"[data-period]"
).forEach(function (button) {
button.addEventListener(
"click",
function () {
preset(
button.dataset.period
);
}
);
});
// 검색 조건 돋보기
// 検索条件のマスター検索
document.querySelectorAll(
"[data-search]"
).forEach(function (button) {
button.addEventListener(
"click",
function () {
var type =
button.dataset.search;
var targets = {
partner: "partner",
item: "item",
manager: "manager"
};
var target = targets[type];
showLookup(
type,
"status",
V(target),
function (result) {
S(
target,
type === "item"
? (
result.code
|| result.name
)
: result.name
);
}
);
}
);
});
E("lookupRun").addEventListener(
"click",
runLookup
);
E("lookupClose").addEventListener(
"click",
closeLookup
);
E("lookupKeyword").addEventListener(
"keydown",
function (event) {
if (event.key === "Enter") {
event.preventDefault();
runLookup();
}
}
);
// 수정창 닫기
// 編集画面を閉じる
function closeEdit() {
close("editOverlay");
editId = null;
}
E("editCloseTop").addEventListener(
"click",
closeEdit
);
E("editCloseBottom").addEventListener(
"click",
closeEdit
);
E("addRow").addEventListener(
"click",
function () {
if (!readOnly) {
addEditRow({});
}
}
);
E("deleteRows").addEventListener(
"click",
function () {
if (readOnly) {
return;
}
E("editRows")
.querySelectorAll("tr")
.forEach(function (tr) {
if (
tr.querySelector(
".row-check"
).checked
) {
tr.remove();
}
});
if (
!E("editRows").querySelector("tr")
) {
addEditRow({});
}
calcTotals();
}
);
E("edTransaction").addEventListener(
"change",
function () {
E("editRows")
.querySelectorAll("tr")
.forEach(function (tr) {
calcRow(tr, true);
});
}
);
// 견적서 수정창 돋보기
// 見積書編集画面のマスター検索
document.querySelectorAll(
"[data-edit-lookup]"
).forEach(function (button) {
button.addEventListener(
"click",
function () {
if (readOnly) {
return;
}
var type =
button.dataset.editLookup;
var fields = {
partner: [
"edPartnerCode",
"edPartnerName"
],
manager: [
"edManagerCode",
"edManagerName"
],
warehouse: [
"edWarehouseCode",
"edWarehouseName"
]
}[type];
showLookup(
type,
"master",
V(fields[0]),
function (result) {
S(
fields[0],
result.code
);
S(
fields[1],
result.name
);
}
);
}
);
});
E("editSave").addEventListener(
"click",
saveEdit
);
// 키보드 단축키
// キーボードショートカット
document.addEventListener(
"keydown",
function (event) {
if (event.key === "Escape") {
if (
E("lookupOverlay")
.classList.contains("open")
) {
closeLookup();
} else if (
E("editOverlay")
.classList.contains("open")
) {
closeEdit();
} else if (
E("searchOverlay")
.classList.contains("open")
) {
close("searchOverlay");
}
}
if (
event.key === "F3"
&& !E("editOverlay")
.classList.contains("open")
&& !E("lookupOverlay")
.classList.contains("open")
) {
event.preventDefault();
open("searchOverlay");
}
if (event.key === "F8") {
if (
E("editOverlay")
.classList.contains("open")
) {
event.preventDefault();
saveEdit();
} else if (
E("searchOverlay")
.classList.contains("open")
&& !E("lookupOverlay")
.classList.contains("open")
) {
event.preventDefault();
doSearch();
}
}
}
);
// 최초 실행
// 初回実行
setDates();
open("searchOverlay");
console.info(
"[status.jsp] 検索モーダルの初期化が完了しました"
);
}
// 초기화 오류 표시
// 初期化エラーを表示
function start() {
try {
init();
} catch (error) {
console.error(error);
var message =
document.getElementById(
"searchMessage"
);
if (message) {
message.textContent =
"画面の初期化エラー： "
+ error.message;
}
}
}
if (document.readyState === "loading") {
document.addEventListener(
"DOMContentLoaded",
start
);
} else {
start();
}
})();
</script>
</body>
</html>
