<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt"%>
<%@ taglib prefix="my" tagdir="/WEB-INF/tags"%>

<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>【受注書照会】 - ヘキサゴンERP</title>

<link
	href="https://cdn.jsdelivr.net/npm/@mdi/font@7.2.96/css/materialdesignicons.min.css"
	rel="stylesheet">

<style>

/* ===== 검색 팝업 ===== */
/* ===== 検索ポップアップ ===== */
#overlay {
	display: none;
	position: fixed;
	inset: 0;
	background: rgba(0, 0, 0, 0.4);
	z-index: 1000;
}

#searchPanel {
	display: none;
	position: fixed;
	top: 50%;
	left: 50%;
	transform: translate(-50%, -50%);
	width: 600px;
	max-width: 90%;
	max-height: 85vh;
	overflow-y: auto;
	padding: 30px;
	box-sizing: border-box;
	background: white;
	border-radius: 10px;
	z-index: 1001;
	line-height: 2;
}

/* ===== 수정 모달 ===== */
/* ===== 修正モーダル ===== */
#modifyOverlay {
	display: none;
	position: fixed;
	inset: 0;
	overflow-y: auto;
	background: rgba(0, 0, 0, 0.45);
	z-index: 2000;
}

#modifyModal {
	position: relative;
	width: 95%;
	max-width: 1400px;
	min-height: 200px;
	margin: 30px auto;
	padding: 20px;
	box-sizing: border-box;
	background: #fff;
	border-radius: 12px;
}

#closeModify {
	display: block;
	margin-left: auto;
	margin-bottom: 15px;
}

/* ===== 페이지 공통 ===== */
/* ===== ページ共通 ===== */
.inq-card {
	background: #fff;
	padding: 16px 20px;
	border-radius: 12px;
	box-shadow: 0 10px 25px -5px rgba(75, 136, 255, 0.08);
	border: 1px solid #e2e8f0;
}

.inq-top {
	display: flex;
	align-items: center;
	justify-content: space-between;
	margin-bottom: 14px;
}

.inq-top-left, .inq-top-right {
	display: flex;
	align-items: center;
	gap: 8px;
}

.inq-title {
	font-size: 1.1rem;
	font-weight: 700;
	color: #0B1026;
	margin-right: 8px;
	display: flex;
	align-items: center;
	gap: 6px;
}

.inq-title .mdi-star {
	color: #cbd5e1;
}

/* ===== 진행상태 버튼 ===== */
/* ===== 進行状態ボタン ===== */
.status-form {
	display: flex;
	align-items: center;
	gap: 6px;
	margin: 0;
}

.pill {
	border: none;
	background: #e8f0ff;
	color: #4B88FF;
	padding: 5px 14px;
	border-radius: 999px;
	font-size: 0.85rem;
	cursor: pointer;
}

.pill:hover {
	background: #d5e5ff;
}

.pill.active {
	background: #4B88FF;
	color: #fff;
	font-weight: 600;
}

/* ===== 버튼 ===== */
/* ===== ボタン ===== */
.btn-primary {
	background: #1e5eff;
	color: #fff;
	border: none;
	padding: 7px 16px;
	border-radius: 999px;
	font-size: 0.85rem;
	cursor: pointer;
}

.btn-outline {
	background: #fff;
	color: #333;
	border: 1px solid #cbd5e1;
	padding: 6px 14px;
	border-radius: 999px;
	font-size: 0.85rem;
	cursor: pointer;
}

/* ===== 페이지네이션 ===== */
/* ===== ページネーション ===== */
.page-bar {
	display: flex;
	align-items: center;
	justify-content: space-between;
	margin-bottom: 8px;
}

.page-bar form {
	display: flex;
	align-items: center;
	gap: 4px;
	margin: 0;
}

.pg {
	width: 26px;
	height: 26px;
	border-radius: 50%;
	border: none;
	background: transparent;
	color: #64748b;
	font-size: 0.85rem;
	cursor: pointer;
}

.pg:hover {
	background: #e8f0ff;
}

.pg.current {
	background: #1e5eff;
	color: #fff;
	font-weight: 700;
}

.pg-input {
	width: 36px;
	height: 24px;
	border: 1px solid #cbd5e1;
	border-radius: 12px;
	text-align: center;
	font-size: 0.85rem;
}

.page-total {
	color: #475569;
	font-size: 0.85rem;
	margin-left: 4px;
}

.date-range {
	font-size: 0.85rem;
	color: #0B1026;
}

/* ===== 테이블 ===== */
/* ===== テーブル ===== */
.inq-table {
	width: 100%;
	border-collapse: collapse;
	font-size: 0.85rem;
	border-top: 1px solid #cbd5e1;
}

.inq-table th {
	background: #f1f5f9;
	font-weight: 700;
	padding: 12px 8px;
	border: 1px solid #e2e8f0;
	border-top: none;
	color: #0B1026;
}

.inq-table td {
	padding: 8px;
	border-bottom: 1px solid #e2e8f0;
	border-left: 1px solid #e2e8f0;
	border-right: 1px solid #e2e8f0;
	color: #1e293b;
}

.inq-table tbody tr:hover {
	background: #f8fbff;
}

.inq-table td.center {
	text-align: center;
}

.inq-table td.num {
	text-align: right;
}

.row-no {
	display: inline-block;
	width: 22px;
	height: 22px;
	line-height: 20px;
	border: 1px solid #cbd5e1;
	border-radius: 50%;
	text-align: center;
	font-size: 0.75rem;
	color: #94a3b8;
}

.inq-table a {
	color: #1e5eff;
	text-decoration: none;
}

.inq-table a:hover {
	text-decoration: underline;
}

.badge-view {
	display: inline-block;
	background: #ffe6d2;
	color: #e8590c;
	border: 1px solid #ff922b;
	border-radius: 4px;
	padding: 0 6px;
	font-size: 0.75rem;
}

/* ===== 하단 액션바 ===== */
/* ===== 下端アクションバー ===== */
.action-bar {
	display: flex;
	gap: 6px;
	margin-top: 16px;
	padding-top: 12px;
	border-top: 1px solid #e2e8f0;
}

.action-bar .btn-outline {
	padding: 5px 14px;
}

#statusMenu {
	display: none;
	position: fixed;
	z-index: 1500;
	min-width: 150px;
	background: #fff;
	border-radius: 12px;
	box-shadow: 0 8px 24px rgba(0, 0, 0, 0.18);
	padding: 8px 0;
	font-size: 0.85rem;
}

#statusMenu .sm-group {
	padding: 6px 14px;
	color: #475569;
	font-weight: 600;
	cursor: default;
}

#statusMenu .sm-group::before {
	content: "▾ ";
}

#statusMenu .sm-item {
	padding: 6px 14px 6px 30px;
	cursor: pointer;
}

#statusMenu .sm-item:hover {
	background: #f1f5f9;
}
</style>
</head>

<body class="${param.embed == '1' ? 'list-embed' : ''}">
	<div class="erp-wrapper">
		<my:sideMenu embed="${param.embed}" />

		<div class="erp-main">
			<main class="erp-content">
				<div class="inq-card">

					<!-- 제목 및 진행상태 -->
					<!-- タイトルと進行状態 -->
					<div class="inq-top">
						<div class="inq-top-left">
							<div class="inq-title">
								<i class="mdi mdi-star"></i> 受注書照会
							</div>

							<!-- 진행상태 -->
							<!-- 進行状態 -->
							<form action="inquiry" method="get" class="status-form">
								<c:forEach var="entry" items="${paramMap}">
									<c:if
										test="${entry.key != 'progressStatus' and entry.key != 'pageNum'}">
										<input type="hidden" name="${entry.key}"
											value="${entry.value}">
									</c:if>
								</c:forEach>

								<!-- 페이지 번호는 1로 고정 -->
								<!-- ページ番号は１に固定 -->
								<input type="hidden" name="pageNum" value="1">

								<button type="submit" name="progressStatus" value=""
									class="pill ${empty paramMap.progressStatus ? 'active' : ''}">
									全体</button>

								<button type="submit" name="progressStatus" value="UNCONFIRMED"
									class="pill ${paramMap.progressStatus eq 'UNCONFIRMED' ? 'active' : ''}">
									未確認</button>

								<button type="submit" name="progressStatus" value="CONFIRMED"
									class="pill ${paramMap.progressStatus eq 'CONFIRMED' ? 'active' : ''}">
									確認</button>

								<button type="submit" name="progressStatus" value="IN_PROGRESS"
									class="pill ${paramMap.progressStatus eq 'IN_PROGRESS' ? 'active' : ''}">
									進行中</button>

								<button type="submit" name="progressStatus" value="COMPLETED"
									class="pill ${paramMap.progressStatus eq 'COMPLETED' ? 'active' : ''}">
									完了</button>
							</form>
						</div>

						<!-- 검색팝업 버튼 -->
						<!-- 検索ポップアップボタン -->
						<div class="inq-top-right">
							<button type="button" class="btn-primary" onclick="openSearch()">検索条件</button>
						</div>
					</div>

					<!-- 검색 팝업 -->
					<!-- 検索ポップアップ -->
					<div id="overlay" onclick="closeSearch()"></div>

					<div id="searchPanel">
						<form action="inquiry" method="get">
							<c:if test="${param.embed == '1'}">
								<input type="hidden" name="embed" value="1">
							</c:if>
							<!-- 기준일자 -->
							<!-- 基準日付 -->
							基準日付 : <input type="date" name="startDate"
								value="${paramMap.startDate}"> ~ <input type="date"
								name="endDate" value="${paramMap.endDate}"><br>

							<!-- 내외자구분 -->
							<!-- 内外資区分 -->
							内外資区分 : <input type="radio" name="currencyType" value=""
								${paramMap.currencyType eq '' ? 'checked' : ''}>全体 <input
								type="radio" name="currencyType" value="内資"
								${paramMap.currencyType eq '内資' ? 'checked' : ''}>内資 <input
								type="radio" name="currencyType" value="外資"
								${paramMap.currencyType eq '外資' ? 'checked' : ''}>外資<br>

							<!-- 창고 -->
							<!-- 倉庫 -->
							倉庫 : <select name="warehouseId">
								<option value="">선택안함</option>
								<c:forEach var="warehouse" items="${warehouses }">
									<option value="${warehouse.warehousePk }"
										${warehouse.warehousePk eq paramMap.warehouseId ? 'selected' : '' }>${warehouse.warehouseName }</option>
								</c:forEach>
							</select> <br>

							<!-- 거래처 -->
							<!-- 取引先 -->
							取引先 : <select name="businessPartnerId">
								<option value="">선택안함</option>
								<c:forEach var="partner" items="${partners }">
									<option value="${partner.businessPartnerId }"
										${partner.businessPartnerId eq paramMap.businessPartnerId ? 'selected' : '' }>${partner.businessPartnerName }</option>
								</c:forEach>
							</select><br> 
							<!-- 품목코드 -->
							<!-- 品目コード -->
							品目コード : <input type="text" id="searchItemName"
								value="<c:out value='${paramMap.itemName}'/>" readonly
								style="background: #f3f4f6;"> <input type="hidden"
								name="itemId" id="searchItemId" value="${paramMap.itemId}">
							<input type="hidden" name="itemName" id="searchItemNameParam"
								value="<c:out value='${paramMap.itemName}'/>">
							<!-- 검색에 사용할 품목 ID -->
							<input type="hidden" name="itemId" id="searchItemId"
								value="${paramMap.itemId}">
							<button type="button" class="btn-outline"
								onclick="openSearchItemModal()">検索</button>
							<button type="button" class="btn-outline"
								onclick="clearSearchItem()">クリア</button>
							<br>
							<!-- 납기일자 -->
							<!-- 納期日付 -->
							納期日付 : <input type="date" name="dueStartDate"
								value="${paramMap.dueStartDate}"> ~ <input type="date"
								name="dueEndDate" value="${paramMap.dueEndDate}"><br>

							<!-- 규격 -->
							<!-- 規格 -->
							規格 : <input type="text" name="spec" value="${paramMap.spec}"><br>

							<!-- 담당자 -->
							<!-- 担当者 -->
							担当者 : <select name="managerId">
								<option value="">선택안함</option>
								<c:forEach var="manager" items="${managers }">
									<option value="${manager.managerId }"
										${manager.managerId eq paramMap.managerId ? 'selected' : '' }>${manager.employeeName }</option>
								</c:forEach>
							</select> <br>
							<!-- 거래처관리담당자 -->
							<!-- 取引先管理担当者 -->
							取引先管理担当者 : <select name="businessPartnerManagerId">
								<option value="">선택안함</option>
								<c:forEach var="businessPartnerManager" items="${managers }">
									<option value="${businessPartnerManager.managerId }"
										${businessPartnerManager.managerId eq paramMap.businessPartnerManagerId ? 'selected' : '' }>${businessPartnerManager.employeeName }</option>
								</c:forEach>
							</select> <br>

							<!-- 거래유형 -->
							<!-- 取引類型 -->
							取引類型 : <input type="radio" name="transactionType" value=""
								${paramMap.transactionType eq '' ? 'checked' : ''}>全体 <input
								type="radio" name="transactionType" value="Y"
								${paramMap.transactionType eq 'Y' ? 'checked' : ''}>付加税率適用
							<input type="radio" name="transactionType" value="N"
								${paramMap.transactionType eq 'N' ? 'checked' : ''}>付加税率未適用
							<br>
							<!-- 비고 -->
							<!-- 備考 -->
							備考 : <input type="text" name="orderRemarks"
								value="${paramMap.orderRemarks}"><br>
							<!-- 비고(품목) -->
							<!-- 備考（品目） -->
							備考（品目） : <input type="text" name="itemRemarks"
								value="${paramMap.itemRemarks}"><br>
							<!-- 최초작성일자 -->
							<!-- 最初作成日付 -->
							最初作成日付 : <input type="date" name="createdStartDate"
								value="${paramMap.createdStartDate}"> ~ <input
								type="date" name="createdEndDate"
								value="${paramMap.createdEndDate}"><br>
							<!-- 최종수정일자 -->
							<!-- 最終修正日付 -->
							最終修正日付 :<input type="date" name="updatedStartDate"
								value="${paramMap.updatedStartDate}"> ~ <input
								type="date" name="updatedEndDate"
								value="${paramMap.updatedEndDate}"><br>
							<!-- 삭제구분 -->
							<!-- 削除区分 -->
							削除区分 : <input type="radio" name="deletedYn" value=""
								${paramMap.deletedYn eq '' ? 'checked' : ''}>全体 <input
								type="radio" name="deletedYn" value="N"
								${paramMap.deletedYn eq 'N' ? 'checked' : ''}>未削除 <input
								type="radio" name="deletedYn" value="Y"
								${paramMap.deletedYn eq 'Y' ? 'checked' : ''}>削除<br>

							<!-- 기타 -->
							<!-- その外 -->
							その他 : <input type="checkbox" name="sortByUpdated" value="true"
								${paramMap.sortByUpdated eq 'true' ? 'checked' : ''}>
							修正日付順<br>

							<button type="submit" class="btn-primary">検索</button>
							<button type="button" class="btn-outline" onclick="closeSearch()">閉じる</button>
						</form>
					</div>

					<!-- 페이지번호 -->
					<!-- ページ番号 -->
					<div class="page-bar">
						<div style="display: flex; align-items: center; gap: 6px;">

							<form action="inquiry" method="get">
								<c:forEach var="entry" items="${paramMap}">
									<c:if test="${entry.key != 'pageNum'}">
										<input type="hidden" name="${entry.key}"
											value="${entry.value}">
									</c:if>
								</c:forEach>

								<button type="submit" name="pageNum" value="1" class="pg">
									&laquo;</button>

								<c:if test="${pageMaker.prev}">
									<button type="submit" name="pageNum"
										value="${pageMaker.startPage - 10}" class="pg">&lt;</button>
								</c:if>

								<c:forEach var="num" begin="${pageMaker.startPage}"
									end="${pageMaker.endPage}">
									<button type="submit" name="pageNum" value="${num}"
										class="pg ${num eq paramMap.pageNum ? 'current' : ''}">
										${num}</button>
								</c:forEach>

								<c:if test="${pageMaker.next}">
									<button type="submit" name="pageNum"
										value="${pageMaker.endPage + 1}" class="pg">&gt;</button>
								</c:if>

								<button type="submit" name="pageNum"
									value="${pageMaker.realEndPage}" class="pg">&raquo;</button>
							</form>

							<!-- 페이지 직접 이동 -->
							<!-- ページ直接移動 -->
							<form action="inquiry" method="get">
								<c:forEach var="entry" items="${paramMap}">
									<c:if test="${entry.key != 'pageNum'}">
										<input type="hidden" name="${entry.key}"
											value="${entry.value}">
									</c:if>
								</c:forEach>

								<input type="number" name="pageNum" class="pg-input" min="1"
									max="${pageMaker.realEndPage}"> <span
									class="page-total"> / <c:out
										value="${pageMaker.realEndPage}" />
								</span>
							</form>
						</div>

						<div class="date-range">
							<c:if test="${not empty paramMap.startDate}">
                            ${paramMap.startDate} ~ ${paramMap.endDate}
                        </c:if>
						</div>
					</div>

					<!-- 주문서 목록 -->
					<!-- 受注書目録 -->
					<form id="removeForm" method="post" action="remove">
						<input type="hidden" name="returnUrl" id="returnUrl">
						<table class="inq-table">
							<thead>
								<tr>
									<th style="width: 40px;"><input type="checkbox"
										id="checkAll"></th>
									<th>日付-No.</th>
									<th>取引先名</th>
									<th>社員（担当）名</th>
									<th>品目名(要約)</th>
									<th>納期日付</th>
									<th>受注金額合計</th>
									<th>進行状態</th>
								</tr>
							</thead>

							<tbody>
								<c:forEach var="order" items="${orders}" varStatus="st">
									<tr>
										<!-- 주문서번호(체크박스) -->
										<!-- 受注書番号（チェックボックス） -->
										<td class="center"><input type="checkbox" name="orderId"
											value="${order.orderId}"></td>
										<!-- 일자-No. -->
										<!-- 日付-No. -->
										<td class="center"><a href="#" class="modify-order"
											data-order-id="${order.orderId}">${order.orderDateStr}-${order.dayNo}</a></td>
										<!-- 거래처명 -->
										<!-- 取引先名 -->
										<td>${order.businessPartnerName}</td>
										<!-- 사원(담당)명 -->
										<!-- 社員（担当）名 -->
										<td>${order.managerName}</td>
										<!-- 품목명(요약) -->
										<!-- 品目名（要約） -->
										<td>${order.itemName}<c:if test="${order.itemCount gt 1}">
                                        	他 ${order.itemCount - 1}件
                                    		</c:if>
										</td>
										<!-- 납기일자 -->
										<!-- 納期日付 -->
										<td class="center">${order.dueDate}</td>
										<!-- 주문금액합계 -->
										<!-- 受注金額合計 -->
										<td class="num"><fmt:formatNumber
												value="${order.totalAmount}" pattern="#,##0" /></td>
										<!-- 진행상태 -->
										<!-- 進行状態 -->
										<td class="center"><a href="#" class="status-link"
											data-order-id="${order.orderId}"> <c:choose>
													<c:when test="${order.progressStatus eq 'UNCONFIRMED'}">未確認</c:when>
													<c:when test="${order.progressStatus eq 'IN_PROGRESS'}">進行中</c:when>
													<c:when test="${order.progressStatus eq 'COMPLETED'}">完了</c:when>

												</c:choose>
										</a></td>
									</tr>
								</c:forEach>
							</tbody>
						</table>

						<!-- 하단 액션바 -->
						<!-- 下端アクションバー -->
						<div class="action-bar">
							<!-- 주문서 삭제 -->
							<!-- 受注書削除 -->
							<button type="submit" class="btn-outline" formaction="remove"
								onclick="return confirm('選択した受注書を削除しますか')">選択削除</button>
							<!-- 진행상태변경 -->
							<!-- 進行状態変更 -->
							<button type="button" class="btn-outline" id="bulkStatusBtn">進行状態変更▲</button>
							<button type="button" class="btn-outline" onclick="openHistory()">履歴照会</button>
						</div>
					</form>
				</div>
			</main>
		</div>
	</div>

	<!-- 주문서 수정 모달 -->
	<!-- 受注書修正モーダル -->
	<div id="modifyOverlay">
		<div id="modifyModal">
			<button type="button" id="closeModify" class="btn-outline">
				閉じる</button>

			<div id="modifyContent"></div>
		</div>
	</div>

	<!-- 진행상태 일괄 변경 -->
	<!-- 進行状態一括変更 -->
	<div id="statusMenu">
		<div class="sm-group">未確認</div>
		<div class="sm-item" data-status="UNCONFIRMED">未確認</div>
		<div class="sm-group">確認</div>
		<div class="sm-item" data-status="IN_PROGRESS">進行中</div>
		<div class="sm-item" data-status="COMPLETED">完了</div>
	</div>

	<!-- 팝업 메시지 -->
	<!-- ポップアップメッセージ -->
	<c:if test="${not empty msg}">
		<script>
			alert("${msg}");
		</script>
	</c:if>

	<!-- 이력조회 모달 -->
	<div id="historyModal"
		style="display: none; position: fixed; inset: 0; background: rgba(0, 0, 0, 0.4); z-index: 2000;">
		<div
			style="background: #fff; width: 1100px; max-width: 95%; margin: 40px auto; padding: 20px; border-radius: 10px; max-height: 85vh; overflow: auto;">
			<div
				style="display: flex; justify-content: space-between; margin-bottom: 12px;">
				<strong>受注書履歴照会</strong>
				<button type="button" class="btn-outline" onclick="closeHistory()">閉じる</button>
			</div>
			<div id="historyBody"></div>
		</div>
	</div>

	<!-- 품목 선택 (검색 조건용, 1건) -->
	<!-- 品目選択（検索条件用、1件） -->
	<div id="searchItemModal"
		style="display: none; position: fixed; inset: 0; background: rgba(0, 0, 0, 0.4); z-index: 3000;">
		<div
			style="background: #fff; width: 900px; max-width: 95%; margin: 40px auto; padding: 20px; border-radius: 10px; max-height: 85vh; overflow: auto;">
			<div id="searchItemBody"></div>
			<div class="action-bar" style="border-top: none;">
				<button type="button" class="btn-primary"
					onclick="applySearchItem()">選択</button>
				<button type="button" class="btn-outline"
					onclick="closeSearchItemModal()">閉じる</button>
			</div>
		</div>
	</div>

	<script>
	/* ===== 검색 조건: 품목 1건 선택 ===== */
	/* ===== 検索条件：品目１件選択 ===== */
	function openSearchItemModal() {
		document.getElementById("searchItemModal").style.display = "block";
		loadSearchItems(1);
	}
	function closeSearchItemModal() {
		document.getElementById("searchItemModal").style.display = "none";
	}

	function loadSearchItems(page) {
		var kwEl = document.querySelector("#searchItemBody #itemKeyword");
		var kw = kwEl ? kwEl.value : "";
		fetch("${pageContext.request.contextPath}/sales/order/item-lookup?fn=loadSearchItems&pageNum="
				+ page + "&keyword=" + encodeURIComponent(kw))
			.then(function(r) { return r.text(); })
			.then(function(html) {
				document.getElementById("searchItemBody").innerHTML = html;
				// 1건 선택: 전체선택 체크박스 숨김
				// １件選択：全体選択チェックボックスを隠す
				document.querySelectorAll("#searchItemBody thead input[type=checkbox]")
					.forEach(function(c) { c.style.display = "none"; });
			})
			.then(null, function(e) { alert("品目を読み込めませんでした。\n" + e.message); });
	}

	// 체크는 1개만 유지
	// チェックは１個だけ維持
	document.addEventListener("change", function(e) {
		var c = e.target;
		if (!c.classList || !c.classList.contains("item-pick") || !c.closest("#searchItemBody")) { return; }
		if (c.checked) {
			document.querySelectorAll("#searchItemBody .item-pick").forEach(function(o) {
				if (o !== c) { o.checked = false; }
			});
		}
	});

	function applySearchItem() {
	    var c = document.querySelector("#searchItemBody .item-pick:checked");

	    if (!c) {
	        alert("品目を選択してください。");
	        return;
	    }

	    var row = c.closest("tr");
	    var itemName = row.querySelector("td:nth-child(3)").textContent.trim();

	    document.getElementById("searchItemId").value = row.dataset.pk;
	    document.getElementById("searchItemName").value = itemName;
	    document.getElementById("searchItemNameParam").value = itemName;

	    closeSearchItemModal();
	}
	
	function clearSearchItem() {
	    document.getElementById("searchItemId").value = "";
	    document.getElementById("searchItemName").value = "";
	}
	
	</script>
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<script>
		/* ===== 검색 팝업 ===== */
		/* ===== 検索ポップアップ ===== */
		function openSearch() {
			document.getElementById("overlay").style.display = "block";
			document.getElementById("searchPanel").style.display = "block";
		}

		function closeSearch() {
			document.getElementById("overlay").style.display = "none";
			document.getElementById("searchPanel").style.display = "none";
		}

		/* ===== 주문서 수정 모달 ===== */
		/* ===== 受注書修正モーダル ===== */
		//모달 닫기
		function closeModifyModal() {
			document.getElementById("modifyOverlay").style.display = "none";
			document.getElementById("modifyContent").innerHTML = "";
		}
		
		document.getElementById("closeModify").addEventListener("click",
				function() {
					closeModifyModal();
		});
		
		document.getElementById("modifyOverlay").addEventListener("click",
				function(e) {
					if (e.target === this) {
						closeModifyModal();
					}
		});

		//모달 열기
		document.addEventListener("click",function(e) {
			const link = e.target.closest(".modify-order");
			if (!link) {return;}
			e.preventDefault();
			const orderId = link.dataset.orderId;
			if (!orderId) {
				alert("受注書番号が確認できません。");
				return;
			}
			
			//모달 url
			const url = "${pageContext.request.contextPath}/sales/order/modify?orderId=" + encodeURIComponent(orderId);
			fetch(url).then(function(response) {
				return response.text().then(function(html) {
					if (!response.ok) {
						throw new Error("HTTP " + response.status + "\n"+ html);
					}
				document.getElementById("modifyContent").innerHTML = html;
				document.querySelectorAll("#modifyContent script").forEach(
					function(old) {
						var s = document.createElement("script");
						s.text = old.textContent;
						old.replaceWith(s);
					});
				document.getElementById("modifyOverlay").style.display = "block";
				});
			}).then(null,function(error) {
				console.error("受注書照会失敗:",error);
				alert("受注書修正画面が呼び出せませんでした。\n" + error.message);
				});
		});

		/* ===== 주문서 삭제 처리 =====*/
		/* ===== 受注書削除処理 =====*/
		var checkAll = document.getElementById("checkAll");
		if (checkAll) {
			checkAll.addEventListener("change", function() {
				var on = this.checked;
				document.querySelectorAll('input[name="orderId"]').forEach(
						function(c) {
							c.checked = on;
						});
			});
		}

		var removeForm = document.getElementById("removeForm");
		if (removeForm) {
			removeForm.addEventListener("submit", function(e) {
				var n = document.querySelectorAll('input[name="orderId"]:checked').length;
				if (n === 0) {
					alert("削除する受注書を選択してください");
					e.preventDefault();
					return;
				}
				var ctx = "${pageContext.request.contextPath}";
				document.getElementById("returnUrl").value = location.pathname.substring(ctx.length)+ location.search;
			});
		}
		
		/* ===== 진행상태 변경 메뉴 ===== */
		/* ===== 進行状態変更メニュー ===== */
		var STATUS_URL = "${pageContext.request.contextPath}/sales/order/progress";
		var statusMenu = document.getElementById("statusMenu");
		var statusTargets = [];   // 바꿀 주문서 번호목록　変える受注書番号目録

		function openStatusMenu(anchor, ids) {
		    statusTargets = ids;
		    statusMenu.style.display = "block";

		    var r = anchor.getBoundingClientRect();
		    var h = statusMenu.offsetHeight;
		    var w = statusMenu.offsetWidth;
		    // 아래에 공간이 없으면 위로 열기
		    // 下に空間がなければ上で開く
		    var top = (r.bottom + h > window.innerHeight) ? r.top - h : r.bottom;
		    statusMenu.style.top = Math.max(top, 4) + "px";
		    statusMenu.style.left = Math.min(r.left, window.innerWidth - w - 8) + "px";
		}

		function applyStatus(status) {
		    var ids = statusTargets;
		    statusMenu.style.display = "none";

		    var body = new URLSearchParams();
		    ids.forEach(function(id) { body.append("orderId", id); });
		    body.append("newStatus", status);

		    fetch(STATUS_URL, {
		        method: "POST",
		        headers: { "Content-Type": "application/x-www-form-urlencoded" },
		        body: body
		    }).then(function(res) {
		        return res.text().then(function(text) {
		            if (!res.ok) { throw new Error(text); }
		            // 성공: 화면의 상태 글자를 바로 바꿈
		            // 成功: 画面の状態文字をすぐ変える
		            ids.forEach(function(id) {
		                var a = document.querySelector('.status-link[data-order-id="' + id + '"]');
		                if (a) { a.textContent = (status==='UNCONFIRMED')?'未確認':((status==='COMPLETED')?'完了':'進行中'); }
		            });
		        });
		    }).catch(function(err) {
		        alert(err.message);
		    });
		}

		document.addEventListener("click", function(e) {
		    // 행의 상태 글자 → 1건
		    // 行の状態文字　→　一件
		    var link = e.target.closest(".status-link");
		    if (link) {
		        e.preventDefault();
		        openStatusMenu(link, [link.dataset.orderId]);
		        return;
		    }
		    // 하단 버튼 → 체크한 주문서 전체
		    // 下端ボタン　→　チェックした受注書状態
		    var bulk = e.target.closest("#bulkStatusBtn");
		    if (bulk) {
		        var ids = Array.prototype.map.call(
		            document.querySelectorAll('input[name="orderId"]:checked'),
		            function(c) { return c.value; });
		        if (ids.length === 0) { alert("注文書を選択してください。"); return; }
		        openStatusMenu(bulk, ids);
		        return;
		    }
		    // 메뉴 항목 선택
		    // メニュー項目選択
		    var item = e.target.closest("#statusMenu .sm-item");
		    if (item) { applyStatus(item.dataset.status); return; }
		    // 메뉴 제목(미확인/확인)을 누른 경우는 열어 둠
		    // メニュータイトル（未確認・確認）を押した場合は開いておく
		    if (e.target.closest("#statusMenu")) { return; }
		    // 그 밖의 곳을 누르면 닫기
		    // その外のところを押すと閉じる
		    statusMenu.style.display = "none";
		});
		
		//주문서 이력 조회
		//受注書履歴照会
		function openHistory() {
			fetch("${pageContext.request.contextPath}/sales/order/history")
				.then(function(r) { return r.text(); })
				.then(function(html) {
					document.getElementById("historyBody").innerHTML = html;
					document.getElementById("historyModal").style.display = "block";
				})
				.then(null, function(e) { alert("이력을 불러오지 못했습니다.\n" + e.message); });
		}
		function closeHistory() {
			document.getElementById("historyModal").style.display = "none";
		}
	</script>

</body>
</html>
