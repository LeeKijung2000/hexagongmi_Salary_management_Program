<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ taglib prefix="my" tagdir="/WEB-INF/tags"%>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>販売照会<%--판매조회--%> - ヘキサゴン ERP<%--헥사곤 ERP--%></title>
<link href="https://cdn.jsdelivr.net/npm/@mdi/font@7.2.96/css/materialdesignicons.min.css" rel="stylesheet">
</head>
<body>
	<div class="erp-wrapper">
		<my:sideMenu />
		<div class="erp-main">
			<main class="erp-content">
				<div class="page-title">
					<i class="mdi mdi-cash-register"></i> 販売照会<%--판매조회--%>
				</div>
				<%-- 이메일, 보내기, 바코드, 전자결재, 엑셀, 회계반영여부는 이 화면에 두지 않는다. --%>
				<%-- メール、送信、バーコード、電子決裁、エクセル、会計反映可否はこの画面に置かない。 --%>
				<div class="list-wrap">
					<div class="inq-bar">
						<div class="inq-tabs" id="statusTabs">
							<button type="button" class="active" data-tab="ALL">全体<%--전체--%></button>
							<button type="button" data-tab="UNCONFIRMED">未確認<%--미확인--%></button>
							<button type="button" data-tab="CONFIRMED">確認<%--확인--%></button>
						</div>
						<div class="inq-search">
							<input type="text" id="keyword" placeholder="取引先、品目、日付-No.<%--거래처, 품목, 일자-No.--%>"
								onkeydown="if(event.key==='Enter'){event.preventDefault();searchFirst();}">
							<button type="button" class="btn-primary-sm" onclick="searchFirst()">Search<%--검색--%></button>
						</div>
						<div class="inq-period">
							<label>照会期間<%--조회기간--%></label>
							<input type="date" id="fromDate" value="${fromDate}">
							<span>~</span>
							<input type="date" id="toDate" value="${toDate}">
						</div>
					</div>
					<div class="list-table-wrap">
						<table class="list-table" id="inquiryGrid">
							<colgroup>
								<col style="width: 42px;">
								<col style="width: 64px;">
								<col style="width: 16%;">
								<col style="width: 16%;">
								<col style="width: 18%;">
								<col style="width: 11%;">
								<col style="width: 12%;">
								<col style="width: 12%;">
								<col style="width: 80px;">
								<col style="width: 110px;">
							</colgroup>
							<thead>
								<tr>
									<th><input type="checkbox" id="checkAll" onclick="toggleAll(this)"></th>
									<th class="col-num">行<%--행번호--%></th>
									<th>日付-No.<%--일자-No.--%></th>
									<th>取引先名<%--거래처명--%></th>
									<th>品目名<%--품목명--%></th>
									<th class="col-num">金額合計<%--금액합계--%></th>
									<th>取引類型<%--거래유형--%></th>
									<th>倉庫名<%--창고명--%></th>
									<th>状態<%--상태--%></th>
									<th>読込伝票<%--불러온전표--%></th>
								</tr>
							</thead>
							<tbody id="inquiryBody"></tbody>
						</table>
					</div>
					<div class="inq-pages" id="pageBar"></div>
					<p id="inquiryMessage" class="inq-message"></p>
					<div class="sale-foot">
						<button type="button" class="btn-primary-sm" onclick="openSaleModal('new')">新規<%--신규--%></button>
						<%-- 체크한 행만 확인 또는 미확인으로 바꾼다. 이미 그 상태인 행은 건너뛴다. --%>
						<%-- チェックした行だけ確認または未確認へ変える。すでにその状態の行は飛ばす。 --%>
						<button type="button" class="btn-flat-sm" onclick="changeProgress('CONFIRMED')">確認<%--확인--%></button>
						<button type="button" class="btn-flat-sm" onclick="changeProgress('UNCONFIRMED')">未確認<%--미확인--%></button>
						<button type="button" class="btn-flat-sm" onclick="deleteSelected()">選択削除<%--선택삭제--%></button>
						<%-- 버튼은 고른 행의 이력, 화살표는 판매입력1과 판매입력2의 신규, 수정, 삭제 목록이다. --%>
						<%-- ボタンは選んだ行の履歴、矢印は販売入力1と販売入力2の新規、修正、削除の一覧である。 --%>
						<div class="history-split">
							<button type="button" class="btn-flat-sm history-main" onclick="openSelectedHistory()">履歴照会<%--이력조회--%></button>
							<button type="button" class="btn-flat-sm history-arrow" onclick="toggleHistoryMenu(event)">
								<i class="mdi mdi-chevron-up"></i>
							</button>
							<div id="historyMenu" class="history-menu">
								<button type="button" onclick="openInputHistory('NORMAL')">販売入力1<%--판매입력1--%></button>
								<button type="button" onclick="openInputHistory('POS')">販売入力2<%--판매입력2--%></button>
							</div>
						</div>
					</div>
				</div>
			</main>
		</div>
	</div>

	<%-- 신규는 빈 판매입력1이다. 일자-No는 그 전표의 판매입력(수정)이고, 판매입력2 전표는 판매입력2(수정)을 연다. --%>
	<%-- 新規は空の販売入力1である。日付-Noはその伝票の販売入力(修正)であり、販売入力2の伝票は販売入力2(修正)を開く。 --%>
	<div class="modal-overlay" id="saleInputOverlay">
		<div class="lookup-card sale-input-view">
			<div class="lookup-head">
				<h3 id="saleInputTitle">販売入力<%--판매입력--%></h3>
				<button type="button" class="modal-close" onclick="closeSaleModal()">
					<i class="mdi mdi-close"></i>
				</button>
			</div>
			<iframe id="saleInputFrame" class="sale-input-frame" title="販売入力"></iframe>
		</div>
	</div>

	<div class="modal-overlay" id="historyOverlay">
		<div class="lookup-card history-card">
			<div class="lookup-head">
				<h3>販売履歴照会<%--판매 이력조회--%></h3>
				<div class="history-tools">
					<input type="text" id="historyKeyword" placeholder="取引先、品目、伝票番号<%--거래처, 품목, 전표번호--%>"
						onkeydown="if(event.key==='Enter'||event.key==='F3'){event.preventDefault();searchHistory();}">
					<button type="button" class="btn-primary-sm" onclick="searchHistory()">Search(F3)</button>
				</div>
				<button type="button" class="modal-close" onclick="closeHistory()">
					<i class="mdi mdi-close"></i>
				</button>
			</div>
			<div class="history-period">
				<input type="date" id="historyFrom">
				<span>~</span>
				<input type="date" id="historyTo">
			</div>
			<div class="lookup-table-wrap">
				<table class="list-table history-table">
					<thead>
						<tr>
							<th>作業日付<%--작업일자--%></th>
							<th>伝票番号<%--전표번호--%></th>
							<th>行為<%--행위--%></th>
							<th>取引先コード<%--거래처코드--%></th>
							<th>取引先名<%--거래처명--%></th>
							<th>品目名<%--품목명--%></th>
							<th>担当者コード<%--담당자코드--%></th>
							<th>担当者名<%--담당자명--%></th>
							<th>作業者<%--작업자--%></th>
							<th>伝票状態<%--전표상태--%></th>
							<th>履歴<%--이력--%></th>
						</tr>
					</thead>
					<tbody id="historyBody"></tbody>
				</table>
			</div>
		</div>
	</div>

	<div class="modal-overlay" id="slipHistoryOverlay">
		<div class="lookup-card slip-history-card">
			<div class="lookup-head">
				<h3>履歴<%--이력--%></h3>
				<button type="button" class="modal-close" onclick="closeSlipHistory()">
					<i class="mdi mdi-close"></i>
				</button>
			</div>
			<p id="slipHistoryNo" class="slip-history-no"></p>
			<div class="lookup-table-wrap">
				<table class="list-table slip-history-table">
					<thead>
						<tr>
							<th></th>
							<th>作業者ID<%--작업자ID--%></th>
							<th>作業日時<%--작업일시--%></th>
							<th>伝票状態<%--전표상태--%></th>
							<th>進行状態<%--진행상태--%></th>
							<th>状態<%--상태--%></th>
						</tr>
					</thead>
					<tbody id="slipHistoryBody"></tbody>
				</table>
			</div>
			<div class="lookup-foot">
				<button type="button" class="btn-flat-sm" onclick="closeSlipHistory()">閉じる<%--닫기--%></button>
			</div>
		</div>
	</div>

	<div class="modal-overlay" id="sourceOverlay">
		<div class="lookup-card hold-card">
			<div class="lookup-head">
				<h3>読込伝票<%--불러온전표--%></h3>
				<button type="button" class="modal-close" onclick="closeSources()">
					<i class="mdi mdi-close"></i>
				</button>
			</div>
			<div class="lookup-table-wrap">
				<table class="list-table">
					<thead>
						<tr>
							<th>区分<%--구분--%></th>
							<th>日付-No.<%--일자-No.--%></th>
							<th>取引先<%--거래처--%></th>
							<th>品目<%--품목--%></th>
						</tr>
					</thead>
					<tbody id="sourceBody"></tbody>
				</table>
			</div>
			<div class="lookup-foot">
				<button type="button" class="btn-flat-sm" onclick="closeSources()">閉じる<%--닫기--%></button>
			</div>
		</div>
	</div>

	<script>
		var ctx = '${pageContext.request.contextPath}';
		var currentTab = 'ALL';
		var currentPage = 1;
		// 이력 모달이 지금 보고 있는 범위. inputType은 판매입력1(NORMAL), 판매입력2(POS)이고 saleId는 한 전표다.
		// 履歴モーダルが見ている範囲。inputTypeは販売入力1(NORMAL)、販売入力2(POS)であり、saleIdは1伝票である。
		var historyScope = { inputType : null, saleId : null };

		// 판매입력 모달이 저장이나 닫기를 알리면 목록을 다시 읽거나 제목만 바꾼다.
		// 販売入力モーダルが保存や閉じるを知らせたら一覧を読み直すか、題名だけ変える。
		window.addEventListener('message', function(event) {
			var data = event.data || {};
			if (data.type === 'sale-saved') {
				closeSaleModal();
				loadList();
			} else if (data.type === 'sale-close') {
				closeSaleModal();
			} else if (data.type === 'sale-title') {
				setSaleTitle(data.mode === 'edit' ? 'edit' : 'new', data.inputType);
			}
		});

		document.getElementById('statusTabs').addEventListener('click', function(event) {
			var button = event.target.closest('button');
			if (!button)
				return;
			Array.prototype.forEach.call(this.querySelectorAll('button'), function(item) {
				item.classList.remove('active');
			});
			button.classList.add('active');
			currentTab = button.getAttribute('data-tab');
			currentPage = 1;
			loadList();
		});

		function searchFirst() {
			currentPage = 1;
			loadList();
		}

		// 목록은 /inquiry/list 를 부른다. 기간이 없거나 시작일이 종료일보다 늦으면 서버에 가기 전에 막는다.
		// 一覧は /inquiry/list を呼ぶ。期間がないか開始日が終了日より遅ければ、サーバーへ行く前に止める。
		function loadList() {
			var fromDate = document.getElementById('fromDate').value;
			var toDate = document.getElementById('toDate').value;
			if (!fromDate || !toDate) {
				showMessage('照会期間を入力してください。'); // 조회기간을 입력하세요.
				return;
			}
			if (fromDate > toDate) {
				showMessage('開始日が終了日より後です。'); // 시작일이 종료일보다 뒤입니다.
				document.getElementById('inquiryBody').innerHTML = '';
				document.getElementById('pageBar').innerHTML = '';
				return;
			}
			var url = ctx + '/sales/sale/inquiry/list?fromDate=' + encodeURIComponent(fromDate)
					+ '&toDate=' + encodeURIComponent(toDate)
					+ '&tab=' + encodeURIComponent(currentTab)
					+ '&page=' + encodeURIComponent(currentPage)
					+ '&keyword=' + encodeURIComponent(document.getElementById('keyword').value || '');
			fetch(url, { headers : { 'Accept' : 'application/json' } }).then(function(res) {
				return res.json().then(function(body) {
					return { ok : res.ok, body : body || {} };
				});
			}).then(function(result) {
				if (!result.ok) {
					showMessage(result.body.message || '照会できませんでした。'); // 조회하지 못했습니다.
					return;
				}
				showMessage('');
				currentPage = result.body.page || 1;
				renderRows(result.body.rows || []);
				renderPages(result.body.page, result.body.totalPages);
			}).catch(function() {
				showMessage('照会できませんでした。'); // 조회하지 못했습니다.
			});
		}

		// 일자-No를 누르면 그 전표의 판매입력을 연다. 불러오기는 연결이 있는 행만 누를 수 있다.
		// 日付-Noを押すとその伝票の販売入力を開く。読込は接続がある行だけ押せる。
		function renderRows(rows) {
			var body = document.getElementById('inquiryBody');
			document.getElementById('checkAll').checked = false;
			if (!rows.length) {
				body.innerHTML = '<tr><td colspan="10" class="empty-cell">照会された販売がありません。<%--조회된 판매가 없습니다.--%></td></tr>';
				return;
			}
			body.innerHTML = rows.map(function(row) {
				var source = row.hasSource ? '<button type="button" class="btn-flat-sm source-btn" data-sale-id="'
						+ esc(row.saleId) + '">読込<%--불러오기--%></button>'
						: '<button type="button" class="btn-flat-sm source-btn" disabled>読込<%--불러오기--%></button>';
				return '<tr data-sale-id="' + esc(row.saleId) + '"><td><input type="checkbox" class="row-check" value="'
						+ esc(row.saleId) + '"></td><td class="col-num">' + esc(row.rowNo) + '</td><td><button type="button" class="date-link" data-sale-id="'
						+ esc(row.saleId) + '" data-input-type="' + esc(row.saleInputType || 'NORMAL') + '">' + esc(row.dateNo) + '</button></td><td>' + esc(row.partnerName)
						+ '</td><td>' + esc(row.itemName) + '</td><td class="col-num">' + money(row.supplyAmount)
						+ '</td><td>' + esc(row.transactionName) + '</td><td>' + esc(row.warehouseName)
						+ '</td><td>' + esc(row.progressName) + '</td><td>' + source + '</td></tr>';
			}).join('');
		}

		document.getElementById('inquiryBody').addEventListener('click', function(event) {
			var dateLink = event.target.closest('.date-link');
			if (dateLink) {
				openSaleModal('edit', dateLink.getAttribute('data-sale-id'), dateLink.getAttribute('data-input-type'));
				return;
			}
			var source = event.target.closest('.source-btn');
			if (source && !source.disabled)
				openSources(source.getAttribute('data-sale-id'));
		});

		function renderPages(page, totalPages) {
			var bar = document.getElementById('pageBar');
			totalPages = totalPages || 1;
			page = page || 1;
			var html = '<button type="button" data-page="' + (page - 1) + '"' + (page <= 1 ? ' disabled' : '') + '>前<%--이전--%></button>';
			var start = Math.max(1, page - 2);
			var end = Math.min(totalPages, start + 4);
			start = Math.max(1, end - 4);
			for (var no = start; no <= end; no++)
				html += '<button type="button" data-page="' + no + '"' + (no === page ? ' class="active"' : '') + '>' + no + '</button>';
			html += '<button type="button" data-page="' + (page + 1) + '"' + (page >= totalPages ? ' disabled' : '') + '>次<%--다음--%></button>';
			bar.innerHTML = html;
		}

		document.getElementById('pageBar').addEventListener('click', function(event) {
			var button = event.target.closest('button');
			if (!button || button.disabled)
				return;
			currentPage = Number(button.getAttribute('data-page'));
			loadList();
		});

		function toggleAll(box) {
			Array.prototype.forEach.call(document.querySelectorAll('.row-check'), function(item) {
				item.checked = box.checked;
			});
		}

		function selectedIds() {
			return Array.prototype.map.call(document.querySelectorAll('.row-check:checked'), function(box) {
				return box.value;
			});
		}

		// 체크한 행만 확인 또는 미확인으로 보낸다. 이미 그 상태인 행은 서버가 건너뛴다.
		// チェックした行だけ確認または未確認へ送る。すでにその状態の行はサーバーが飛ばす。
		function changeProgress(progressStatus) {
			var ids = selectedIds();
			if (!ids.length) {
				showMessage('販売を選択してください。'); // 판매를 선택하세요.
				return;
			}
			postIds(ctx + '/sales/sale/inquiry/progress', ids, {
				progressStatus : progressStatus
			});
		}

		// 선택삭제는 확인을 받은 뒤에만 보낸다. 재고를 되돌리고 이력을 남기는 일은 서버가 한다.
		// 選択削除は確認を受けたあとだけ送る。在庫を戻し履歴を残すのはサーバーが行う。
		function deleteSelected() {
			var ids = selectedIds();
			if (!ids.length) {
				showMessage('販売を選択してください。'); // 판매를 선택하세요.
				return;
			}
			if (!window.confirm('選択した販売を削除しますか。')) // 선택한 판매를 삭제할까요.
				return;
			postIds(ctx + '/sales/sale/inquiry/delete', ids);
		}

		function postIds(url, ids, extra) {
			var params = new URLSearchParams();
			ids.forEach(function(id) {
				params.append('saleIds', id);
			});
			if (extra) {
				Object.keys(extra).forEach(function(key) {
					params.append(key, extra[key]);
				});
			}
			fetch(url, {
				method : 'POST',
				headers : {
					'Content-Type' : 'application/x-www-form-urlencoded',
					'Accept' : 'application/json'
				},
				body : params.toString()
			}).then(function(res) {
				return res.json().then(function(body) {
					return { ok : res.ok, body : body || {} };
				}, function() {
					return { ok : res.ok, body : {} };
				});
			}).then(function(result) {
				if (!result.ok) {
					showMessage(result.body.message || '処理できませんでした。'); // 처리하지 못했습니다.
					return;
				}
				showMessage('');
				loadList();
			}).catch(function() {
				showMessage('処理できませんでした。'); // 처리하지 못했습니다.
			});
		}

		function toggleHistoryMenu(event) {
			event.preventDefault();
			event.stopPropagation();
			document.getElementById('historyMenu').classList.toggle('open');
		}

		document.addEventListener('click', function() {
			var menu = document.getElementById('historyMenu');
			if (menu) {
				menu.classList.remove('open');
			}
		});

		document.addEventListener('keydown', function(event) {
			if (event.key === 'F3' && document.getElementById('historyOverlay').classList.contains('active')) {
				event.preventDefault();
				searchHistory();
			}
		});

		// 체크한 행 하나의 신규, 수정, 삭제만 연다.
		// チェックした行1件の新規、修正、削除だけ開く。
		function openSelectedHistory() {
			var ids = selectedIds();
			if (ids.length !== 1) {
				showMessage('販売を1件選択してください。'); // 판매를 1건 선택하세요.
				return;
			}
			openSlipHistory(ids[0]);
		}

		// 화살표에서 고른 판매입력의 이력 전체를 연다.
		// 矢印で選んだ販売入力の履歴全体を開く。
		function openInputHistory(inputType) {
			document.getElementById('historyMenu').classList.remove('open');
			historyScope = { inputType : inputType, saleId : null };
			document.getElementById('historyFrom').value = document.getElementById('fromDate').value;
			document.getElementById('historyTo').value = document.getElementById('toDate').value;
			document.getElementById('historyKeyword').value = '';
			loadHistory();
		}

		// 이력 표의 H는 그 전표의 작업일시, 진행상태, 상태를 추가 창으로 연다.
		// 履歴表の H はその伝票の作業日時、進行状態、状態を追加の窓で開く。
		function openSlipHistory(saleId) {
			historyScope = { inputType : null, saleId : saleId };
			document.getElementById('historyKeyword').value = '';
			loadHistory();
		}

		function searchHistory() {
			loadHistory();
		}

		// 한 전표를 고르면 기간 없이 그 전표만 본다. 화살표로 열면 판매입력1 또는 판매입력2와 기간으로 좁힌다.
		// 1伝票を選ぶと期間なしでその伝票だけ見る。矢印で開くと販売入力1または販売入力2と期間で絞る。
		function loadHistory() {
			var params = new URLSearchParams();
			if (historyScope.saleId) {
				params.append('saleId', historyScope.saleId);
			} else {
				params.append('inputType', historyScope.inputType || 'NORMAL');
				if (document.getElementById('historyFrom').value) {
					params.append('fromDate', document.getElementById('historyFrom').value);
				}
				if (document.getElementById('historyTo').value) {
					params.append('toDate', document.getElementById('historyTo').value);
				}
			}
			var keyword = document.getElementById('historyKeyword').value;
			if (keyword) {
				params.append('keyword', keyword);
			}
			fetch(ctx + '/sales/sale/inquiry/history?' + params.toString(), {
				headers : { 'Accept' : 'application/json' }
			}).then(function(res) {
				return res.json().then(function(body) {
					return { ok : res.ok, body : body };
				});
			}).then(function(result) {
				if (!result.ok) {
					showMessage((result.body && result.body.message) || '履歴を照会できませんでした。'); // 이력을 조회하지 못했습니다.
					return;
				}
				showMessage('');
				renderHistory(result.body || []);
				document.getElementById('historyOverlay').classList.add('active');
			}).catch(function() {
				showMessage('履歴を照会できませんでした。'); // 이력을 조회하지 못했습니다.
			});
		}

		function renderHistory(rows) {
			var body = document.getElementById('historyBody');
			if (!rows.length) {
				body.innerHTML = '<tr><td colspan="11" class="empty-cell">履歴がありません。<%--이력이 없습니다.--%></td></tr>';
				return;
			}
			body.innerHTML = rows.map(function(row) {
				return '<tr><td>' + esc(row.workedAt) + '</td><td>' + esc(row.dateNo || row.documentId) + '</td><td>'
						+ esc(row.actionName) + '</td><td>' + esc(row.partnerCode) + '</td><td>' + esc(row.partnerName)
						+ '</td><td>' + esc(row.itemName) + '</td><td>' + esc(row.managerCode) + '</td><td>'
						+ esc(row.managerName) + '</td><td>' + esc(row.workerName) + '</td><td>' + esc(row.progressName)
						+ '</td><td><button type="button" class="history-mark" data-sale-id="' + esc(row.documentId)
						+ '" data-date-no="' + esc(row.dateNo || '') + '">H</button></td></tr>';
			}).join('');
		}

		document.getElementById('historyBody').addEventListener('click', function(event) {
			var mark = event.target.closest('.history-mark');
			if (!mark) {
				return;
			}
			openSlipDetail(mark.getAttribute('data-sale-id'), mark.getAttribute('data-date-no'));
		});

		function openSlipDetail(saleId, dateNo) {
			document.getElementById('slipHistoryNo').textContent = dateNo ? '[' + dateNo + ']' : '';
			document.getElementById('slipHistoryBody').innerHTML = '';
			fetch(ctx + '/sales/sale/inquiry/history/slip?saleId=' + encodeURIComponent(saleId), {
				headers : { 'Accept' : 'application/json' }
			}).then(function(res) {
				return res.json().then(function(body) {
					return { ok : res.ok, body : body };
				});
			}).then(function(result) {
				if (!result.ok) {
					showMessage((result.body && result.body.message) || '履歴を照会できませんでした。'); // 이력을 조회하지 못했습니다.
					return;
				}
				var page = result.body || {};
				if (page.dateNo) {
					document.getElementById('slipHistoryNo').textContent = '[' + page.dateNo + ']';
				}
				renderSlipHistory(page.rows || []);
				document.getElementById('slipHistoryOverlay').classList.add('active');
			}).catch(function() {
				showMessage('履歴を照会できませんでした。'); // 이력을 조회하지 못했습니다.
			});
		}

		function renderSlipHistory(rows) {
			var body = document.getElementById('slipHistoryBody');
			if (!rows.length) {
				body.innerHTML = '<tr><td colspan="6" class="empty-cell">履歴がありません。<%--이력이 없습니다.--%></td></tr>';
				return;
			}
			body.innerHTML = rows.map(function(row, index) {
				return '<tr><td>' + (index + 1) + '</td><td><span class="worker-id">' + esc(row.workerName)
						+ '</span></td><td>' + esc(row.workedAt) + '</td><td>' + esc(row.slipStatusName) + '</td><td>'
						+ esc(row.progressName) + '</td><td>' + esc(row.actionName) + '</td></tr>';
			}).join('');
		}

		function closeSlipHistory() {
			document.getElementById('slipHistoryOverlay').classList.remove('active');
		}

		function closeHistory() {
			document.getElementById('historyOverlay').classList.remove('active');
		}

		// 불러온 전표는 주문, 견적, 원판매다. 원판매의 일자-No만 그 판매입력을 연다.
		// 読込伝票は注文、見積、元販売である。元販売の日付-Noだけその販売入力を開く。
		function openSources(saleId) {
			fetch(ctx + '/sales/sale/inquiry/sources?saleId=' + encodeURIComponent(saleId), {
				headers : { 'Accept' : 'application/json' }
			}).then(function(res) {
				return res.json();
			}).then(function(rows) {
				var body = document.getElementById('sourceBody');
				var list = rows || [];
				if (!list.length) {
					body.innerHTML = '<tr><td colspan="4" class="empty-cell">読込伝票がありません。<%--불러온 전표가 없습니다.--%></td></tr>';
				} else {
					body.innerHTML = list.map(function(row) {
						var dateCell = row.srcType === 'SALE'
								? '<button type="button" class="date-link" data-sale-id="' + esc(row.documentId) + '">' + esc(row.dateNo) + '</button>'
								: esc(row.dateNo);
						return '<tr><td>' + esc(sourceLabel(row.srcType)) + '</td><td>' + dateCell + '</td><td>'
								+ esc(row.partnerName) + '</td><td>' + esc(row.itemName) + '</td></tr>';
					}).join('');
				}
				document.getElementById('sourceOverlay').classList.add('active');
			});
		}

		document.getElementById('sourceBody').addEventListener('click', function(event) {
			var link = event.target.closest('.date-link');
			if (!link)
				return;
			closeSources();
			openSaleModal('edit', link.getAttribute('data-sale-id'));
		});

		function closeSources() {
			document.getElementById('sourceOverlay').classList.remove('active');
		}

		function sourceLabel(type) {
			if (type === 'ORDER')
				return '注文'; // 주문
			if (type === 'QUOTE')
				return '見積'; // 견적
			if (type === 'SALE')
				return '販売'; // 판매
			return type || '';
		}

		// 신규는 빈 판매입력1이다. 수정은 판매입력1 전표면 판매입력(수정), 판매입력2 전표면 판매입력2(수정)이다.
		// 新規は空の販売入力1である。修正は販売入力1の伝票なら販売入力(修正)、販売入力2の伝票なら販売入力2(修正)である。
		function openSaleModal(mode, saleId, inputType) {
			setSaleTitle(mode, inputType);
			var url = ctx + (inputType === 'POS' ? '/sales/sale/input2' : '/sales/sale/input') + '?embed=1';
			if (mode === 'edit' && saleId)
				url += '&saleId=' + encodeURIComponent(saleId);
			document.getElementById('saleInputFrame').src = url;
			document.getElementById('saleInputOverlay').classList.add('active');
		}

		function setSaleTitle(mode, inputType) {
			var pos = inputType === 'POS';
			if (mode === 'edit')
				document.getElementById('saleInputTitle').textContent = pos ? '販売入力2(修正)' : '販売入力(修正)'; // 판매입력2(수정), 판매입력(수정)
			else
				document.getElementById('saleInputTitle').textContent = pos ? '販売入力2' : '販売入力'; // 판매입력2, 판매입력
		}

		function closeSaleModal() {
			document.getElementById('saleInputOverlay').classList.remove('active');
			document.getElementById('saleInputFrame').src = 'about:blank';
		}

		function showMessage(text) {
			document.getElementById('inquiryMessage').textContent = text || '';
		}

		function money(value) {
			if (value === null || value === undefined || value === '')
				return '';
			var number = Number(value);
			if (isNaN(number))
				return '';
			return number.toLocaleString('ja-JP', { maximumFractionDigits : 4 });
		}

		function esc(value) {
			return String(value == null ? '' : value).replace(/[&<>"']/g, function(ch) {
				return { '&' : '&amp;', '<' : '&lt;', '>' : '&gt;', '"' : '&quot;', "'" : '&#39;' }[ch];
			});
		}

		loadList();
	</script>
	<style>
		.page-title { font-size: 1.25rem; font-weight: 700; color: #0B1026; margin-bottom: 20px; display: flex; align-items: center; gap: 10px; }
		.page-title i { color: #4B88FF; font-size: 24px; }
		.list-wrap { background: #fff; border-radius: 14px; border: 1px solid #e2e8f0; box-shadow: 0 10px 25px -5px rgba(75, 136, 255, .08); overflow: hidden; }
		.inq-bar { display: flex; flex-wrap: wrap; gap: 12px 18px; align-items: center; padding: 18px 22px 8px; }
		.inq-tabs { display: inline-flex; }
		.inq-tabs button { border: 1px solid #e2e8f0; background: #fff; color: #64748b; font-weight: 700; padding: 8px 16px; cursor: pointer; }
		.inq-tabs button:first-child { border-radius: 8px 0 0 8px; }
		.inq-tabs button:last-child { border-radius: 0 8px 8px 0; }
		.inq-tabs button + button { margin-left: -1px; }
		.inq-tabs button.active { background: #4B88FF; color: #fff; border-color: #4B88FF; position: relative; }
		.inq-search, .inq-period { display: flex; align-items: center; gap: 8px; }
		.inq-period label { font-weight: 700; color: #0B1026; }
		.inq-search input, .inq-period input {
			border: 1px solid #e2e8f0; border-radius: 8px; padding: 8px 12px; font-size: 13px; outline: none; background: #fff;
		}
		.inq-search input { width: 240px; }
		.inq-search input:focus, .inq-period input:focus { border-color: #4B88FF; }
		.btn-primary-sm, .btn-flat-sm {
			display: inline-flex; align-items: center; justify-content: center; gap: 4px; cursor: pointer;
			border-radius: 8px; font-weight: 700; font-size: 13px; padding: 8px 14px;
		}
		.btn-primary-sm { background: #4B88FF; color: #fff; border: none; }
		.btn-primary-sm:hover { background: #1F3C88; }
		.btn-flat-sm { background: #f8fafc; border: 1px solid #e2e8f0; color: #64748b; }
		.btn-flat-sm:hover { background: #eef2f7; }
		.btn-flat-sm:disabled { opacity: .45; cursor: not-allowed; }
		.list-table-wrap { width: 100%; overflow-x: auto; }
		.list-table { width: 100%; border-collapse: collapse; table-layout: fixed; }
		.list-table th, .list-table td { border-bottom: 1px solid #e2e8f0; padding: 9px 10px; font-size: 13px; text-align: left; }
		.list-table th { background: #f8fafc; color: #64748b; font-weight: 700; }
		.col-num { text-align: right; }
		.date-link { border: none; background: transparent; color: #1F3C88; font-weight: 700; cursor: pointer; padding: 0; font-size: 13px; }
		.date-link:hover { text-decoration: underline; }
		.source-btn { padding: 6px 10px; }
		.empty-cell { text-align: center; color: #64748b; padding: 28px; }
		.inq-pages { display: flex; gap: 6px; justify-content: center; padding: 14px 22px 0; }
		.inq-pages button { min-width: 34px; height: 34px; border: 1px solid #e2e8f0; background: #fff; border-radius: 8px; cursor: pointer; font-weight: 700; color: #334155; }
		.inq-pages button.active { background: #4B88FF; color: #fff; border-color: #4B88FF; }
		.inq-pages button:disabled { opacity: .4; cursor: not-allowed; }
		.inq-message { min-height: 20px; margin: 8px 22px 0; color: #b91c1c; font-size: 13px; }
		.sale-foot { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; padding: 8px 22px 22px; }
		.history-split { position: relative; display: inline-flex; }
		.history-main { border-radius: 8px 0 0 8px; border-right: none; }
		.history-arrow { border-radius: 0 8px 8px 0; padding: 8px 8px; }
		.history-menu {
			display: none; position: absolute; left: 0; bottom: 40px; min-width: 140px; background: #fff;
			border: 1px solid #e2e8f0; border-radius: 8px; box-shadow: 0 8px 20px rgba(11, 16, 38, .12); z-index: 30; overflow: hidden;
		}
		.history-menu.open { display: block; }
		.history-menu button {
			display: block; width: 100%; text-align: left; background: #fff; border: none; padding: 10px 14px; font-weight: 700; cursor: pointer;
		}
		.history-menu button:hover { background: #f7faff; }
		.history-card { width: min(1280px, 98vw); }
		.history-tools { display: flex; gap: 8px; align-items: center; }
		.history-tools input { border: 1px solid #e2e8f0; border-radius: 8px; padding: 8px 12px; width: 220px; }
		.history-period { display: flex; gap: 8px; align-items: center; justify-content: flex-end; padding: 10px 16px 0; color: #64748b; }
		.history-period input { border: 1px solid #e2e8f0; border-radius: 8px; padding: 6px 10px; }
		.history-table { min-width: 1100px; }
		.history-mark { border: none; background: transparent; color: #1F3C88; font-weight: 800; cursor: pointer; }
		#slipHistoryOverlay { z-index: 1600; }
		.slip-history-card { width: min(920px, 96vw); }
		.slip-history-no { margin: 0; padding: 16px 18px 8px; font-weight: 700; color: #334155; }
		.slip-history-table th, .slip-history-table td { text-align: center; }
		.worker-id { color: #1F3C88; font-weight: 700; }
		.modal-overlay { display: none; position: fixed; inset: 0; background: rgba(11, 16, 38, .45); align-items: flex-start; justify-content: center; padding: 3vh 16px; z-index: 1400; overflow: auto; }
		.modal-overlay.active { display: flex; }
		.lookup-card { background: #fff; border-radius: 14px; border: 1px solid #e2e8f0; box-shadow: 0 20px 45px -10px rgba(11, 16, 38, .25); overflow: hidden; }
		.sale-input-view { width: min(1400px, 98vw); height: min(92vh, 980px); display: flex; flex-direction: column; }
		.hold-card { width: min(860px, 96vw); }
		.lookup-head { display: flex; align-items: center; gap: 12px; padding: 14px 16px; border-bottom: 1px solid #e2e8f0; }
		.lookup-head h3 { font-size: 1.05rem; font-weight: 800; color: #0B1026; margin-right: auto; }
		.modal-close { border: none; background: #f1f5f9; color: #64748b; width: 32px; height: 32px; border-radius: 50%; cursor: pointer; }
		.sale-input-frame { flex: 1; width: 100%; border: 0; background: #f4f7fc; }
		.lookup-table-wrap { max-height: 420px; overflow: auto; }
		.lookup-foot { display: flex; gap: 8px; padding: 14px 16px; }
	</style>
</body>
</html>
