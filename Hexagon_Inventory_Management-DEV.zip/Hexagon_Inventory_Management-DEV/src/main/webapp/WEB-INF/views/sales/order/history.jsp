<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<table class="inq-table">
	<thead>
		<tr>
			<th>作業日付</th>
			<th>伝票番号</th>
			<th>行為</th>
			<th>取引先コード</th>
			<th>取引先名</th>
			<th>品目名</th>
			<th>担当者コード</th>
			<th>担当者名</th>
			<th>伝票状態</th>
		</tr>
	</thead>
	<tbody>
		<c:forEach var="h" items="${histories}">
			<tr>
				<td>${h.workDateStr}</td>
				<td>${h.orderDateStr}&nbsp;-${h.dayNo}</td>
				<td><c:choose>
						<c:when test="${h.actionType == 'CREATE'}">新規</c:when>
						<c:when test="${h.actionType == 'UPDATE'}">修正</c:when>
						<c:when test="${h.actionType == 'STATUS'}">状態変更</c:when>
						<c:when test="${h.actionType == 'CANCEL'}">削除</c:when>
						<c:otherwise>${h.actionType}</c:otherwise>
					</c:choose></td>
				<td>${h.partnerCode}</td>
				<td>${h.partnerName}</td>
				<td>${h.itemName}<c:if test="${h.itemCount > 1}"> 他 ${h.itemCount - 1}件</c:if></td>
				<td>${h.employeeCode}</td>
				<td>${h.managerName}</td>
				<c:choose>
					<c:when test="${h.beforeStatus eq 'IN_PROGRESS' }">
						<td>進行中</td>
					</c:when>
					<c:when test="${h.beforeStatus eq 'COMPLETED' }">
						<td>完了</td>
					</c:when>
					<c:when test="${h.beforeStatus eq 'UNCONFIRMED' }">
						<td>未確認</td>
					</c:when>
				</c:choose>
			</tr>
		</c:forEach>
		<c:if test="${empty histories}">
			<tr>
				<td colspan="9" style="text-align: center;">履歴がありません。</td>
			</tr>
		</c:if>
	</tbody>
</table>