<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %><%@ taglib prefix="my" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html><html lang="ja"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title><c:out value="${empty editId ? '出荷入力' : '出荷編集'}"/></title><link href="https://cdn.jsdelivr.net/npm/@mdi/font@7.2.96/css/materialdesignicons.min.css" rel="stylesheet"><link href="${pageContext.request.contextPath}/resources/css/ship.css" rel="stylesheet"></head>
<body class="${param.modal == '1' ? 'modal-page' : ''}"><div class="erp-wrapper"><my:sideMenu/><div class="erp-main"><main class="erp-content"><div class="ship-page"><div class="ship-wrap">
<div class="ship-title"><c:out value="${empty editId ? '出荷入力' : '出荷編集'}"/></div>
<section class="ship-card"><div class="ship-grid">
<div class="ship-row"><div class="ship-label">日付-No.</div><div class="date-line"><input id="shipmentDate" type="date" class="ship-input"><span class="hint"><c:choose><c:when test="${empty editId}">保存時に伝票番号を自動採番</c:when><c:otherwise>既存の出荷伝票を編集します。</c:otherwise></c:choose></span></div></div>
<div class="ship-row"><div class="ship-label">取引先</div><div class="lookup"><input id="partnerName" class="ship-input ship-readonly" readonly placeholder="取引先"><button class="lookup-btn" type="button" onclick="openPartnerModal()"><i class="mdi mdi-magnify"></i></button><input id="businessPartnerId" type="hidden"></div></div>
<div class="ship-row"><div class="ship-label">担当者</div><select id="managerId" class="ship-select"><option value="">担当者</option><c:forEach var="m" items="${managers}"><option value="${m.id}">${m.name}</option></c:forEach></select></div>
<div class="ship-row"><div class="ship-label">出荷倉庫</div><select id="warehouseId" class="ship-select"><option value="">出荷倉庫</option><c:forEach var="w" items="${warehouses}"><option value="${w.id}">${w.name}</option></c:forEach></select></div>
<div class="ship-row"><div class="ship-label">連絡先</div><input id="contactNumber" class="ship-input" placeholder="連絡先"></div>
<div class="ship-row"><div class="ship-label">郵便番号</div><div class="lookup"><button type="button" class="btn small" onclick="postcodeSearch()">住所検索</button><input id="postalCode" class="ship-input" placeholder="郵便番号"></div></div>
<div class="ship-row full"><div class="ship-label">住所</div><textarea id="address" class="ship-input ship-address" placeholder="住所"></textarea></div>
<div class="ship-row full"><div class="ship-label">備考</div><input id="remarks" class="ship-input" placeholder="新しい項目を追加"></div>
</div></section>
<div class="action-row"><button id="openSourceOrderButton" class="btn primary" type="button" onclick="addSourceItem()">出荷指示書を読み込み／変更</button><button id="resetSourceOrderButton" class="btn" type="button" onclick="resetSourceOrder()">読み込んだ出荷指示書をリセット</button><span class="hint">品目は選択した出荷指示書からのみ読み込みます。品目行の追加・削除には対応していません。</span></div>
<div class="table-wrap"><table class="ship-table" id="itemTable"><thead><tr><th>品目コード</th><th>品目名</th><th>規格</th><th>数量</th><th>備考</th></tr></thead><tbody></tbody><tfoot><tr><td colspan="3">合計</td><td id="qtyTotal">0</td><td></td></tr></tfoot></table></div>
<div class="footer-actions"><button class="btn" onclick="closeInputView()">◀</button><button class="btn primary" onclick="saveShipment()">保存(F8) ▲</button><button class="btn" onclick="location.href='${pageContext.request.contextPath}/sales/ship/inquiry'">一覧</button><span class="spacer"></span><button class="btn" onclick="closeInputView()">閉じる</button></div>
</div></div></main></div></div>
<div class="modal" id="partnerModal"><div class="modal-box"><div class="modal-head">取引先検索 <span class="spacer"></span><button class="modal-close" onclick="closeModal('partnerModal')">×</button></div><div class="modal-body"><div class="modal-tools"><input id="partnerKeyword" class="ship-input" placeholder="取引先コード / 取引先名 / 電話番号" onkeydown="if(event.key==='Enter')searchPartners()"><button class="btn primary" onclick="searchPartners()">Search</button><button class="btn" onclick="openPartnerNewModal()">取引先 新規</button></div><table class="modal-table"><thead><tr><th>コード</th><th>取引先名</th><th>電話</th><th>住所</th></tr></thead><tbody id="partnerBody"></tbody></table></div></div></div>
<div class="modal" id="partnerNewModal"><div class="modal-box quick-partner-box"><div class="modal-head">取引先新規登録 <span class="spacer"></span><button class="modal-close" onclick="closeModal('partnerNewModal')">×</button></div><div class="modal-body quick-partner-body"><div class="quick-partner-grid">
<div class="quick-field required"><label>取引先コード</label><div class="quick-inline"><input id="quickPartnerCode" class="ship-input" maxlength="100"><button class="btn small" onclick="checkQuickPartnerCode()">重複確認</button></div></div>
<div class="quick-field required"><label>商号（名称）</label><input id="quickPartnerName" class="ship-input" maxlength="100"></div>
<div class="quick-field"><label>代表者名</label><input id="quickPartnerRepresentative" class="ship-input" maxlength="100"></div>
<div class="quick-field"><label>電話</label><input id="quickPartnerPhone" class="ship-input"></div>
<div class="quick-field"><label>郵便番号</label><div class="quick-inline"><input id="quickPartnerZip" class="ship-input" readonly><button class="btn small" onclick="quickPartnerAddressSearch()">住所検索</button></div></div>
<div class="quick-field"><label>住所1</label><input id="quickPartnerAddress1" class="ship-input"></div>
<div class="quick-field full"><label>住所2</label><input id="quickPartnerAddress2" class="ship-input" placeholder="詳細住所"></div>
</div><div class="footer-actions"><span class="spacer"></span><button class="btn primary" type="button" onclick="saveQuickPartner()">登録</button><button class="btn" type="button" onclick="closeModal('partnerNewModal')">取消</button></div></div></div></div>
<div class="modal" id="sourceOrderModal"><div class="modal-box"><div class="modal-head">未出荷の出荷指示書を選択 <span class="spacer"></span><button class="modal-close" onclick="closeModal('sourceOrderModal')">×</button></div><div class="modal-body"><p class="hint" style="margin:0 0 10px">未出荷品目が残っている出荷指示書を1行ずつ表示します。出荷指示書を選択すると、その伝票に含まれる未出荷品目をすべて読み込みます。</p><div class="modal-tools"><input id="sourceOrderKeyword" class="ship-input" placeholder="出荷指示書番号／取引先／品目" onkeydown="if(event.key==='Enter')searchSourceOrders()"><button class="btn primary" onclick="searchSourceOrders()">Search</button></div><div class="table-wrap"><table class="modal-table"><thead><tr><th>選択</th><th>出荷指示書No.（PK）</th><th>日付</th><th>取引先</th><th>倉庫</th><th>品目概要</th><th>未出荷数量 合計</th></tr></thead><tbody id="sourceOrderBody"><tr><td colspan="7">照会中...</td></tr></tbody></table></div><div class="footer-actions"><span class="spacer"></span><button id="applySourceOrderButton" class="btn primary" type="button" onclick="applySourceOrders()">未出荷の指示書を選択</button><button class="btn" onclick="closeModal('sourceOrderModal')">閉じる</button></div></div></div></div>

<script>
const CTX='${pageContext.request.contextPath}';const EDIT_ID=Number('${editId}')||null;
const MODAL_MODE=new URLSearchParams(location.search).get('modal')==='1';const today=new Date();function iso(d){return new Date(d.getTime()-d.getTimezoneOffset()*60000).toISOString().slice(0,10)}function closeModal(id){document.getElementById(id).classList.remove('open')}function openPartnerModal(){document.getElementById('partnerModal').classList.add('open');searchPartners()}
let quickPartnerCodeChecked=false;
function openPartnerNewModal(){document.getElementById('partnerNewModal').classList.add('open');quickPartnerCodeChecked=false;['quickPartnerCode','quickPartnerName','quickPartnerRepresentative','quickPartnerPhone','quickPartnerZip','quickPartnerAddress1','quickPartnerAddress2'].forEach(id=>document.getElementById(id).value='');}
async function checkQuickPartnerCode(){const code=document.getElementById('quickPartnerCode').value.trim();if(!code){alert('取引先コードを入力してください。');return;}try{const dup=await getJson(CTX+'/base/account/check-code?businessPartnerCode='+encodeURIComponent(code));quickPartnerCodeChecked=!dup;alert(quickPartnerCodeChecked?'使用可能なコードです。':'この取引先コードは既に使用されています。');}catch(e){quickPartnerCodeChecked=false;alert(e.message||'取引先コードの重複確認中にエラーが発生しました。');}}
function quickPartnerAddressSearch(){if(window.daum&&daum.Postcode){new daum.Postcode({oncomplete:function(data){document.getElementById('quickPartnerZip').value=data.zonecode||'';document.getElementById('quickPartnerAddress1').value=data.roadAddress||data.jibunAddress||'';}}).open();}else{alert('住所検索サービスを読み込めませんでした。');}}
async function saveQuickPartner(){const code=document.getElementById('quickPartnerCode').value.trim(),name=document.getElementById('quickPartnerName').value.trim();if(!code||!name){alert('取引先コードと商号（名称）は必須項目です。');return;}if(!quickPartnerCodeChecked){alert('取引先コードの重複確認を行ってください。');return;}const fd=new URLSearchParams({businessPartnerCode:code,businessPartnerName:name,businessPartnerCodeType:'BUSINESS_NO',representativeName:document.getElementById('quickPartnerRepresentative').value,phoneNumber:document.getElementById('quickPartnerPhone').value,zipCode:document.getElementById('quickPartnerZip').value,address1:document.getElementById('quickPartnerAddress1').value,address2:document.getElementById('quickPartnerAddress2').value});try{const r=await fetch(CTX+'/base/account/quick-register',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},body:fd});const data=await r.json();if(!r.ok){throw new Error(data.message||'取引先の登録に失敗しました。');}document.getElementById('businessPartnerId').value=data.businessPartnerId;document.getElementById('partnerName').value=data.businessPartnerName||'';document.getElementById('contactNumber').value=data.phoneNumber||'';document.getElementById('address').value=[data.address1,data.address2].filter(Boolean).join(' ');closeModal('partnerNewModal');closeModal('partnerModal');alert('取引先が登録されました。');}catch(e){alert(e.message||'取引先登録中にエラーが発生しました。');}}
function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
async function getJson(url){const r=await fetch(url);if(!r.ok)throw new Error('照会中にエラーが発生しました。');return r.json()}
async function searchPartners(){const k=document.getElementById('partnerKeyword').value.trim();const list=await getJson(CTX+'/sales/common/partner-list?keyword='+encodeURIComponent(k));window._partners=list;document.getElementById('partnerBody').innerHTML=list.map(x=>'<tr class="selectable" onclick="selectPartner('+x.id+')"><td>'+esc(x.code)+'</td><td class="left">'+esc(x.name)+'</td><td>'+esc(x.phone)+'</td><td class="left">'+esc(x.address)+'</td></tr>').join('')||'<tr><td colspan="4">検索結果がありません。</td></tr>'}
function selectPartner(id){const x=(window._partners||[]).find(v=>String(v.id)===String(id));if(!x)return;document.getElementById('businessPartnerId').value=x.id;document.getElementById('partnerName').value=x.name||'';document.getElementById('contactNumber').value=x.phone||'';document.getElementById('address').value=x.address||'';closeModal('partnerModal')}
let sourceOrderRows=[];let currentSourceOrderId=null;let currentSourceVoucherNo='';let applyingSourceOrder=false;
async function addSourceItem(){
 if(applyingSourceOrder)return;
 document.getElementById('sourceOrderModal').classList.add('open');
 await searchSourceOrders();
}
async function searchSourceOrders(){
 const body=document.getElementById('sourceOrderBody');
 const applyButton=document.getElementById('applySourceOrderButton');
 body.innerHTML='<tr><td colspan="7">照会中...</td></tr>';
 applyButton.disabled=true;
 try{
  const k=document.getElementById('sourceOrderKeyword').value.trim();
  const url=CTX+'/sales/ship/unshipped-source?keyword='+encodeURIComponent(k);
  const rows=await getJson(url);
  if(!Array.isArray(rows))throw new Error('出荷指示書の検索結果の形式が正しくありません。');
  sourceOrderRows=rows;
  const grouped=new Map();
  sourceOrderRows.forEach(x=>{
   const id=String(x.sourceShippingOrderId||'');if(!id)return;
   if(!grouped.has(id))grouped.set(id,{id,voucherNo:x.sourceVoucherNo||'-',date:x.sourceDate||'-',partnerId:x.businessPartnerId,warehouseId:x.warehouseId,partner:x.sourcePartnerName||'-',warehouse:x.sourceWarehouseName||'-',items:[],total:0});
   const g=grouped.get(id);g.items.push(x);g.total+=Number(x.availableQuantity||0);
  });
  const orders=[...grouped.values()];
  body.innerHTML=orders.map(o=>'<tr><td><input type="radio" name="source-order-choice" class="source-order-check" value="'+esc(o.id)+'" '+(String(o.id)===String(currentSourceOrderId)?'checked':'')+'></td><td>'+esc(o.voucherNo)+'</td><td>'+esc(o.date)+'</td><td>'+esc(o.partner)+'</td><td>'+esc(o.warehouse)+'</td><td class="left" title="'+esc(o.items.map(x=>x.itemNameSnap||'').join(', '))+'">'+esc(o.items.map(x=>x.itemNameSnap||'').join(', '))+' ('+o.items.length+'件の品目)</td><td style="text-align:right">'+o.total.toLocaleString(undefined,{maximumFractionDigits:4})+'</td></tr>').join('')||'<tr><td colspan="7">未出荷の出荷指示書はありません。</td></tr>';
  applyButton.disabled=orders.length===0;
 }catch(e){
  sourceOrderRows=[];
  body.innerHTML='<tr><td colspan="7">未出荷の出荷指示書を照会できませんでした。</td></tr>';
  applyButton.disabled=true;
  alert(e.message||'出荷指示書の照会に失敗しました。現在の出荷入力内容は変更されていません。');
 }
}
function applySourceOrders(){
 if(applyingSourceOrder)return;
 const selected=document.querySelector('.source-order-check:checked');
 if(!selected){alert('変更する未出荷の出荷指示書を選択してください。');return;}
 const selectedId=String(selected.value);
 const selectedOrderRows=sourceOrderRows.filter(x=>String(x.sourceShippingOrderId||'')===selectedId);
 const first=selectedOrderRows[0];
 if(!first){alert('選択した出荷指示書に未出荷品目が見つかりません。一覧を再検索してください。');return;}
 if(selectedOrderRows.some(x=>!x.itemId||!x.sourceShippingOrderItemId||!(Number(x.availableQuantity)>0))){
  alert('選択した出荷指示書の品目または未出荷数量の情報が正しくありません。一覧を再検索してください。');return;
 }
 if(currentSourceOrderId!==null && String(currentSourceOrderId)===selectedId){
  alert('すでに読み込まれている出荷指示書です。別の出荷指示書を選択してください。');return;
 }
 const existingRows=[...document.querySelectorAll('#itemTable tbody tr')].filter(r=>r.dataset.itemId);
 const hasExistingOrder=currentSourceOrderId!==null||existingRows.length>0;
 if(hasExistingOrder){
  const oldVoucher=currentSourceVoucherNo?'('+currentSourceVoucherNo+')':'';
  const newVoucher=first.sourceVoucherNo?'('+first.sourceVoucherNo+')':'';
  const message=''+newVoucher+'」を選択しますか？\n現在の品目と、該当する出荷指示書から読み込んだ内容はすべて置き換えられます。';
  if(!window.confirm(message))return;
 }
 applyingSourceOrder=true;
 const applyButton=document.getElementById('applySourceOrderButton');
 const openButton=document.getElementById('openSourceOrderButton');
 applyButton.disabled=true;openButton.disabled=true;
 try{
  const tbody=document.querySelector('#itemTable tbody');
  const partnerId=String(first.businessPartnerId||'');
  const warehouseId=String(first.warehouseId||'');
  if(!partnerId||!warehouseId)throw new Error('選択した出荷指示書に取引先または倉庫の情報がありません。既存の内容は維持されます。');
  // 新しいデータ行を先に作成して検証してから画面を更新し、エラーが発生しても既存データが失われないようにする。
  const newRows=[];
  selectedOrderRows.forEach(x=>{
   const tr=document.createElement('tr');
   tr.innerHTML='<td><input class="item-code" readonly></td><td><input class="item-name" readonly></td><td><input class="item-spec" readonly></td><td><input class="qty" type="number" step="0.0001" min="0"></td><td><input class="remarks"></td>';
   tr.dataset.itemId='';tr.dataset.sourceShippingOrderItemId='';tr.dataset.available='';tr.dataset.sourceVoucherNo='';
   fillRow(tr,{itemId:x.itemId,itemCode:x.itemCodeSnap,itemName:x.itemNameSnap,spec:x.specSnap,unit:x.unitSnap,qty:x.availableQuantity,sourceShippingOrderItemId:x.sourceShippingOrderItemId,available:x.availableQuantity,sourceVoucherNo:x.sourceVoucherNo});
   tr.querySelector('.remarks').value='出荷指示書 '+(x.sourceVoucherNo||'');
   newRows.push(tr);
  });
  if(!newRows.length)throw new Error('読み込める未出荷品目がありません。既存の内容は維持されます。');
  const previousPartner=document.getElementById('businessPartnerId').value;
  tbody.replaceChildren(...newRows);
  if(previousPartner&&previousPartner!==partnerId){
   document.getElementById('contactNumber').value='';
   document.getElementById('postalCode').value='';
   document.getElementById('address').value='';
  }
  document.getElementById('businessPartnerId').value=partnerId;
  document.getElementById('partnerName').value=first.sourcePartnerName||'';
  document.getElementById('warehouseId').value=warehouseId;
  currentSourceOrderId=selectedId;
  currentSourceVoucherNo=first.sourceVoucherNo||'';
  updateTotal();
  closeModal('sourceOrderModal');
 }catch(e){alert(e.message||'出荷指示書の変更に失敗しました。既存の内容は維持されます。');}
 finally{applyingSourceOrder=false;applyButton.disabled=false;openButton.disabled=false;}
}
function resetSourceOrder(){
 if(applyingSourceOrder)return;
 const rows=[...document.querySelectorAll('#itemTable tbody tr')].filter(r=>r.dataset.itemId);
 if(currentSourceOrderId===null&&!rows.length){alert('リセットする出荷指示書の内容がありません。');return;}
 if(!window.confirm('読み込んだ出荷指示書と品目の内容をリセットしますか？'))return;
 document.querySelector('#itemTable tbody').replaceChildren();
 document.getElementById('businessPartnerId').value='';
 document.getElementById('partnerName').value='';
 document.getElementById('warehouseId').value='';
 document.getElementById('contactNumber').value='';
 document.getElementById('postalCode').value='';
 document.getElementById('address').value='';
 currentSourceOrderId=null;currentSourceVoucherNo='';
 updateTotal();
}
function addRow(){const tb=document.querySelector('#itemTable tbody'),tr=document.createElement('tr');tr.innerHTML='<td><input class="item-code" readonly></td><td><input class="item-name" readonly></td><td><input class="item-spec" readonly></td><td><input class="qty" type="number" step="0.0001" min="0"></td><td><input class="remarks"></td>';tr.dataset.itemId='';tr.dataset.sourceShippingOrderItemId='';tr.dataset.available='';tr.dataset.sourceVoucherNo='';tb.appendChild(tr);return tr}
function fillRow(tr,o){tr.dataset.itemId=o.itemId;tr.dataset.sourceShippingOrderItemId=o.sourceShippingOrderItemId||'';tr.dataset.available=o.available||'';tr.dataset.sourceVoucherNo=o.sourceVoucherNo||'';tr.dataset.unit=o.unit||'';tr.querySelector('.item-code').value=o.itemCode||'';tr.querySelector('.item-name').value=o.itemName||'';tr.querySelector('.item-spec').value=o.spec||'';tr.querySelector('.qty').value=o.qty||1;updateTotal()}
function updateTotal(){let total=0;document.querySelectorAll('#itemTable tbody tr').forEach(r=>total+=Number(r.querySelector('.qty')?.value||0));document.getElementById('qtyTotal').textContent=total.toLocaleString(undefined,{maximumFractionDigits:4})}
document.addEventListener('input',e=>{if(e.target.matches('.qty'))updateTotal()})
function validateRows(show){const rows=[...document.querySelectorAll('#itemTable tbody tr')].filter(r=>r.dataset.itemId);if(!document.getElementById('shipmentDate').value||!document.getElementById('businessPartnerId').value||!document.getElementById('warehouseId').value){if(show)alert('日付、取引先、出荷倉庫を入力してください。');return false}if(!rows.length){if(show)alert('品目を1件以上入力してください。');return false}for(const r of rows){const q=Number(r.querySelector('.qty').value);if(q<=0){if(show)alert('数量は0より大きい値を入力してください。');return false}if(r.dataset.available&&q>Number(r.dataset.available)){if(show)alert(r.querySelector('.item-name').value+'の未出荷数量を超えています。');return false}}return true}
function collect(){return {shipmentDate:document.getElementById('shipmentDate').value,businessPartnerId:Number(document.getElementById('businessPartnerId').value),managerId:Number(document.getElementById('managerId').value)||null,warehouseId:Number(document.getElementById('warehouseId').value),contactNumber:document.getElementById('contactNumber').value,postalCode:document.getElementById('postalCode').value,address:document.getElementById('address').value,remarks:document.getElementById('remarks').value,items:[...document.querySelectorAll('#itemTable tbody tr')].filter(r=>r.dataset.itemId).map(r=>({itemId:Number(r.dataset.itemId),itemCodeSnap:r.querySelector('.item-code').value,itemNameSnap:r.querySelector('.item-name').value,specSnap:r.querySelector('.item-spec').value,unitSnap:r.dataset.unit,quantity:Number(r.querySelector('.qty').value),remarks:r.querySelector('.remarks').value,sourceShippingOrderItemId:r.dataset.sourceShippingOrderItemId?Number(r.dataset.sourceShippingOrderItemId):null,availableQuantity:r.dataset.available?Number(r.dataset.available):null}))}}
async function saveShipment(){if(!validateRows(true))return;try{const url=EDIT_ID?CTX+'/sales/ship/update/'+EDIT_ID:CTX+'/sales/ship/register';const payload=collect();if(EDIT_ID)payload.shipmentId=EDIT_ID;const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});const t=await r.text();if(!r.ok){alert(t);return}if(MODAL_MODE&&window.parent!==window&&typeof window.parent.closeShipInputModal==='function'){window.parent.closeShipInputModal(true);return;}alert(EDIT_ID?'出荷伝票を編集しました。':'出荷を保存しました。伝票番号：'+t);location.href=CTX+'/sales/ship/inquiry'}catch(e){alert('出荷の保存中に通信エラーが発生しました。')}}
async function saveShipmentAndPrint(){await saveShipment()}
function postcodeSearch(){if(window.daum&&daum.Postcode){new daum.Postcode({oncomplete:function(data){document.getElementById('postalCode').value=data.zonecode||'';document.getElementById('address').value=data.roadAddress||data.jibunAddress||'';}}).open();}else{alert('住所検索サービスを読み込めませんでした。');}}
function closeInputView(){if(MODAL_MODE&&window.parent!==window&&typeof window.parent.closeShipInputModal==='function'){window.parent.closeShipInputModal(false);return;}history.back()}
async function loadEditData(){if(!EDIT_ID)return;try{const r=await fetch(CTX+'/sales/ship/get/'+EDIT_ID);if(!r.ok)throw new Error();const x=await r.json();document.getElementById('shipmentDate').value=x.shipmentDate||'';document.getElementById('businessPartnerId').value=x.businessPartnerId||'';document.getElementById('partnerName').value=x.partnerName||'';document.getElementById('managerId').value=x.managerId||'';document.getElementById('warehouseId').value=x.warehouseId||'';document.getElementById('contactNumber').value=x.contactNumber||'';document.getElementById('postalCode').value=x.postalCode||'';document.getElementById('address').value=x.address||'';document.getElementById('remarks').value=x.remarks||'';const rows=document.querySelectorAll('#itemTable tbody tr');const items=x.items||[];while(document.querySelectorAll('#itemTable tbody tr').length<items.length)addRow();items.forEach((i,idx)=>{const tr=document.querySelectorAll('#itemTable tbody tr')[idx];fillRow(tr,{itemId:i.itemId,itemCode:i.itemCodeSnap,itemName:i.itemNameSnap,spec:i.specSnap,unit:i.unitSnap,qty:i.quantity,sourceShippingOrderItemId:i.sourceShippingOrderItemId,sourceVoucherNo:i.sourceVoucherNo});tr.querySelector('.remarks').value=i.remarks||((i.sourceVoucherNo)?'出荷指示書 '+i.sourceVoucherNo:'');});updateTotal()}catch(e){alert('編集する出荷伝票を取得できませんでした。');if(MODAL_MODE&&window.parent!==window&&typeof window.parent.closeShipInputModal==='function'){window.parent.closeShipInputModal(false);}else{location.href=CTX+'/sales/ship/inquiry'}}}window.addEventListener('load',async()=>{if(!EDIT_ID)document.getElementById('shipmentDate').value=iso(today);await loadEditData()})
</script><script src="https://t1.daumcdn.net/mapjsapi/bundle/postcode/prod/postcode.v2.js"></script>
</body></html>
