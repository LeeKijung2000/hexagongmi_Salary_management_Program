<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt"%>
<%@ taglib prefix="my" tagdir="/WEB-INF/tags"%>
<jsp:useBean id="today" class="java.util.Date" />
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>販売入力2<%--판매입력2--%> - ヘキサゴン ERP<%--헥사곤 ERP--%></title>
<link href="https://cdn.jsdelivr.net/npm/@mdi/font@7.2.96/css/materialdesignicons.min.css" rel="stylesheet">
</head>
<body class="${embed == '1' ? 'sale-embed' : ''}">
	<div class="erp-wrapper">
		<my:sideMenu />
		<div class="erp-main">
			<main class="erp-content">
				<c:if test="${embed != '1'}">
					<div class="page-title">
						<i class="mdi mdi-cart-arrow-right"></i> 販売入力2<%--판매입력2--%>
					</div>
				</c:if>
				<form id="saleForm" onsubmit="return false;">
					<input type="hidden" name="header.saleId" value="${sale.header.saleId}">
					<input type="hidden" name="header.voucherStatus" id="voucherStatus"
						value="${empty sale.header.voucherStatus ? '正常' : sale.header.voucherStatus}">
					<input type="hidden" id="exchangeRate" value="${empty sale.header.exchangeRate ? 1 : sale.header.exchangeRate}">
					<input type="hidden" id="currencyName" value="${sale.header.currencyName}">
					<div class="list-wrap">
						<div class="sale-head">
							<div class="sale-field">
								<label>日付<%--일자--%></label>
								<input type="date" name="header.saleDt"
									value="<c:choose><c:when test="${not empty sale.header.saleDt}"><fmt:formatDate value="${sale.header.saleDt}" pattern="yyyy-MM-dd"/></c:when><c:otherwise><fmt:formatDate value="${today}" pattern="yyyy-MM-dd"/></c:otherwise></c:choose>">
							</div>
							<div class="sale-field">
								<label>取引先<%--거래처--%></label>
								<div class="sale-popup">
									<input type="hidden" name="header.businessPartnerId" id="businessPartnerId" value="${sale.header.businessPartnerId}">
									<input type="text" id="businessPartnerCode" class="header-code" value="${sale.header.businessPartnerCode}" placeholder="コード<%--코드--%>"
										oninput="clearPartnerId('code')"
										onkeydown="if(event.key==='Enter'){event.preventDefault();resolvePartner(event);}"
										onblur="resolvePartner(event)">
									<button type="button" class="popup-search-btn" onclick="openPartnerLookup()"><i class="mdi mdi-magnify"></i></button>
									<input type="text" id="businessPartnerName" value="${sale.header.businessPartnerName}" placeholder="取引先<%--거래처--%>"
										oninput="clearPartnerId('name')"
										onkeydown="if(event.key==='Enter'){event.preventDefault();resolvePartner(event);}"
										onblur="resolvePartner(event)">
								</div>
							</div>
							<div class="sale-field">
								<label>担当者<%--담당자--%></label>
								<div class="sale-popup">
									<input type="hidden" name="header.managerId" id="managerId" value="${sale.header.managerId}">
									<input type="text" id="employeeCode" class="header-code" value="${sale.header.employeeCode}" placeholder="コード<%--코드--%>"
										oninput="clearManagerId('code')"
										onkeydown="if(event.key==='Enter'){event.preventDefault();resolveManager(event);}"
										onblur="resolveManager(event)">
									<button type="button" class="popup-search-btn" onclick="openManagerLookup()"><i class="mdi mdi-magnify"></i></button>
									<input type="text" id="employeeName" value="${sale.header.employeeName}" placeholder="担当者<%--담당자--%>"
										oninput="clearManagerId('name')"
										onkeydown="if(event.key==='Enter'){event.preventDefault();resolveManager(event);}"
										onblur="resolveManager(event)">
								</div>
							</div>
							<div class="sale-field">
								<label>出荷倉庫<%--출하창고--%></label>
								<div class="sale-popup">
									<input type="hidden" name="header.warehousePk" id="warehousePk" value="${sale.header.warehousePk}">
									<input type="text" id="warehouseCode" class="header-code" value="${sale.header.warehouseCode}" placeholder="コード<%--코드--%>"
										oninput="clearWarehouseId('code')"
										onkeydown="if(event.key==='Enter'){event.preventDefault();resolveWarehouse(event);}"
										onblur="resolveWarehouse(event)">
									<button type="button" class="popup-search-btn" onclick="openWarehouseLookup()"><i class="mdi mdi-magnify"></i></button>
									<input type="text" id="warehouseName" value="${sale.header.warehouseName}" placeholder="出荷倉庫<%--출하창고--%>"
										oninput="clearWarehouseId('name')"
										onkeydown="if(event.key==='Enter'){event.preventDefault();resolveWarehouse(event);}"
										onblur="resolveWarehouse(event)">
								</div>
							</div>
							<div class="sale-field">
								<label>取引類型<%--거래유형--%></label>
								<select name="header.saleType" onchange="recalcAll()">
									<option value="付加税率適用" ${empty sale.header.saleType or sale.header.saleType == '付加税率適用' ? 'selected' : ''}>付加税率適用<%--부가세율 적용--%></option>
									<option value="付加税率不適用" ${sale.header.saleType == '付加税率不適用' ? 'selected' : ''}>付加税率不適用<%--부가세율 미적용--%></option>
								</select>
							</div>
						</div>

						<div class="sale-buttons">
							<input type="text" id="gridFindKeyword" class="grid-find-input" placeholder="表で探す内容<%--표에서 찾을 내용--%>" style="display: none;"
								onkeydown="if(event.key==='Enter'){event.preventDefault();findInGrid();}">
							<button type="button" class="btn-flat-sm" onclick="openGridFind()">検索<%--찾기--%></button>
							<button type="button" class="btn-flat-sm" onclick="sortGrid()">並べ替え<%--정렬--%></button>
							<button type="button" class="btn-flat-sm" onclick="openHoldModal()">保留<%--보류--%></button>
							<button type="button" class="btn-flat-sm" onclick="openDiscountModal()">割引<%--할인--%></button>
							<button type="button" class="btn-flat-sm" onclick="loadStock()">在庫読込<%--재고불러오기--%></button>
							<button type="button" class="btn-flat-sm" onclick="verifyLines()">検証<%--검증--%></button>
							<button type="button" class="btn-flat-sm" onclick="focusAdjustment()">調整<%--조정--%></button>
						</div>

						<div class="list-table-wrap">
							<table class="list-table" id="saleGrid">
								<thead>
									<tr>
										<th></th>
										<th>品目コード<%--품목코드--%></th>
										<th>品目名<%--품목명--%></th>
										<%-- 전체수량, 출하창고수량은 처음 표에 없다. 재고불러오기를 누르면 규격과 수량 사이에 칸과 값이 함께 붙는다. --%>
										<%-- 全体数量、出荷倉庫数量は最初の表にない。在庫読込を押すと規格と数量の間に列と値が一緒に付く。 --%>
										<th class="stock-anchor">規格<%--규격--%></th>
										<th class="col-num">数量<%--수량--%></th>
										<th class="col-num">単価<%--단가--%></th>
										<th class="col-num">供給価額<%--공급가액--%></th>
										<th class="col-num">付加税<%--부가세--%></th>
										<th class="col-num">合計<%--합계--%></th>
										<th>摘要<%--적요--%></th>
									</tr>
								</thead>
								<tbody>
									<c:choose>
										<c:when test="${empty sale.items}">
											<c:forEach begin="0" end="2">
												<tr>
													<td><input type="checkbox" class="line-check"></td>
													<td>
														<div class="line-code">
															<input type="hidden" class="line-item-pk">
															<input type="text" class="line-item-code" oninput="onCodeInput(this)"
																onkeydown="if(event.key==='Enter'){event.preventDefault();resolveItem(this);}"
																onblur="resolveItem(this, event)">
															<button type="button" class="popup-search-btn" onclick="openItemLookup(this)"><i class="mdi mdi-magnify"></i></button>
														</div>
													</td>
													<td><input type="text" class="line-item-name" oninput="ensureBlankRow()"></td>
													<td><input type="text" class="line-spec" oninput="ensureBlankRow()"></td>
													<td><input type="text" class="col-num line-qty" oninput="calcLine(this)"></td>
													<td><input type="text" class="col-num line-price" oninput="calcLine(this)"></td>
													<td><input type="text" class="col-num line-supply line-calc" readonly tabindex="-1"></td>
													<td><input type="text" class="col-num line-vat line-calc" readonly tabindex="-1"></td>
													<td><input type="text" class="col-num line-amt line-calc" readonly tabindex="-1">
														<input type="hidden" class="line-discount" value="0"></td>
													<td><input type="text" class="line-remark" maxlength="300"></td>
												</tr>
											</c:forEach>
										</c:when>
										<c:otherwise>
											<c:forEach var="line" items="${sale.items}">
												<tr>
													<td><input type="checkbox" class="line-check"></td>
													<td>
														<div class="line-code">
															<input type="hidden" class="line-item-pk" value="${line.itemPk}">
															<input type="text" class="line-item-code" value="${line.itemCode}" data-matched="${line.itemCode}"
																oninput="onCodeInput(this)"
																onkeydown="if(event.key==='Enter'){event.preventDefault();resolveItem(this);}"
																onblur="resolveItem(this, event)">
															<button type="button" class="popup-search-btn" onclick="openItemLookup(this)"><i class="mdi mdi-magnify"></i></button>
														</div>
													</td>
													<td><input type="text" class="line-item-name" value="${line.itemNm}" oninput="ensureBlankRow()"></td>
													<td><input type="text" class="line-spec" value="${line.spec}" oninput="ensureBlankRow()"></td>
													<td><input type="text" class="col-num line-qty" value="${line.saleQty}" oninput="calcLine(this)"></td>
													<td><input type="text" class="col-num line-price" value="${line.unitPrice}" oninput="calcLine(this)"></td>
													<td><input type="text" class="col-num line-supply line-calc" value="${line.supplyAmt}" readonly tabindex="-1"></td>
													<td><input type="text" class="col-num line-vat line-calc" value="${line.vatAmt}" readonly tabindex="-1"></td>
													<td><input type="text" class="col-num line-amt line-calc" value="${line.lineAmt}" readonly tabindex="-1">
														<input type="hidden" class="line-discount" value="${empty line.discountAmt ? 0 : line.discountAmt}"></td>
													<td><input type="text" class="line-remark" maxlength="300" value="${line.remark}"></td>
												</tr>
											</c:forEach>
										</c:otherwise>
									</c:choose>
								</tbody>
								<tfoot>
									<tr>
										<td id="footLead" colspan="4"></td>
										<td class="col-num" id="footQty">0</td>
										<td id="footGap"></td>
										<td class="col-num" id="footSupply">0</td>
										<td class="col-num" id="footVat">0</td>
										<td class="col-num" id="footTotal">0</td>
										<td></td>
									</tr>
								</tfoot>
							</table>
						</div>

						<%-- 품목이 등록되면 거래별 부가세 합계 한 줄을 보여 준다. 공급가액, 부가세, 합계는 위 품목표 계산값이고 직접 입력하지 않는다. --%>
						<%-- 品目が登録されると取引別付加税合計の1行を見せる。供給価額、付加税、合計は上の品目表の計算値であり、直接入力しない。 --%>
						<div class="list-table-wrap">
							<table class="list-table" id="adjustGrid">
								<colgroup>
									<col style="width: 20%;">
									<col style="width: 20%;">
									<col style="width: 20%;">
									<col style="width: 20%;">
									<col style="width: 20%;">
								</colgroup>
								<thead>
									<tr>
										<th>金額調整項目名<%--금액조정항목명--%></th>
										<th>増減区分<%--증감구분--%></th>
										<th>供給価額<%--공급가액--%></th>
										<th>付加税<%--부가세--%></th>
										<th>合計<%--합계--%></th>
									</tr>
								</thead>
								<tbody></tbody>
							</table>
						</div>

						<div class="sale-foot">
							<div class="save-split">
								<button type="button" class="btn-primary-sm save-main" onclick="return prepareSubmit('正常')">保存<%--저장--%></button>
								<button type="button" class="btn-primary-sm save-arrow" onclick="toggleSaveMenu(event)"><i class="mdi mdi-chevron-up"></i></button>
								<div id="saveMenu" class="save-menu">
									<button type="button" onclick="return prepareSubmit('正常')">保存<%--저장--%></button>
									<button type="button" onclick="return prepareSubmit('保留')">保留<%--보류--%></button>
								</div>
							</div>
							<button type="button" class="btn-flat-sm" onclick="rewriteSale()">再作成<%--다시 작성--%></button>
							<a class="btn-flat-sm" href="${pageContext.request.contextPath}/sales/sale/inquiry" onclick="return goInquiry(event)">リスト<%--리스트--%></a>
						</div>
						<div id="saleResult" class="sale-result"></div>
					</div>
				</form>
			</main>
		</div>
	</div>

	<my:lookupModal />

	<div class="modal-overlay" id="holdOverlay">
		<div class="lookup-card hold-card">
			<div class="lookup-head">
				<h3>保留照会<%--보류조회--%></h3>
				<button type="button" class="modal-close" onclick="closeHoldModal()"><i class="mdi mdi-close"></i></button>
			</div>
			<p class="hold-note">保留伝票は最大5件まで保存され、読み込んだ伝票を保存すると販売記録に残り、保留一覧から外れます。<%--보류전표는 최대 5개까지만 저장되며, 불러온 전표를 저장하면 보류 목록에서 빠집니다.--%></p>
			<div class="lookup-table-wrap">
				<table class="list-table">
					<thead>
						<tr>
							<th></th>
							<th>保留番号<%--보류번호--%></th>
							<th>取引先<%--거래처--%></th>
							<th>品目<%--품목--%></th>
							<th>金額<%--금액--%></th>
							<th>類型<%--유형--%></th>
							<th>倉庫<%--창고--%></th>
						</tr>
					</thead>
					<tbody id="holdBody"></tbody>
				</table>
			</div>
			<div class="lookup-foot">
				<button type="button" class="btn-primary-sm" onclick="deleteSelectedHolds()">選択削除<%--선택삭제--%></button>
				<button type="button" class="btn-flat-sm" onclick="closeHoldModal()">閉じる<%--닫기--%></button>
			</div>
		</div>
	</div>

	<div class="modal-overlay" id="discountOverlay">
		<div class="discount-card">
			<div class="discount-titlebar">
				<span>割引登録<%--할인 등록--%></span>
				<button type="button" class="discount-close" onclick="closeDiscountModal()"><i class="mdi mdi-close"></i></button>
			</div>
			<div class="discount-body">
				<h3>割引登録<%--할인 등록--%></h3>
				<div class="discount-head">
					<label>取引先<%--거래처--%></label>
					<input type="text" id="discountPartnerCode" readonly>
					<input type="text" id="discountPartnerName" readonly>
					<label>倉庫<%--창고--%></label>
					<input type="text" id="discountWarehouseCode" readonly>
					<input type="text" id="discountWarehouseName" readonly>
					<label>外貨<%--외화--%></label>
					<input type="text" id="discountCurrency" readonly>
					<label>取引類型<%--거래유형--%></label>
					<input type="text" id="discountSaleType" readonly>
				</div>
				<div class="discount-tools">
					<div class="discount-apply">
						<label><input type="radio" name="discountApply" value="batch" checked onchange="onDiscountApplyMode()"> 一括変更<%--일괄변경--%></label>
						<label><input type="radio" name="discountApply" value="slip" onchange="onDiscountApplyMode()"> 品目別<%--품목별--%></label>
					</div>
					<select id="discountPriceKind">
						<option value="price">割引単価<%--할인단가--%></option>
						<option value="vat">割引単価(VAT込)<%--할인단가(vat포함)--%></option>
					</select>
					<button type="button" class="discount-direct">直接入力<%--직접입력--%></button>
					<input type="text" id="discountValue" inputmode="decimal">
					<button type="button" class="btn-flat-sm" onclick="applyDiscountAmount()">適用<%--적용--%></button>
				</div>
				<div class="discount-table-wrap">
					<table class="list-table discount-table">
						<thead>
							<tr>
								<th><input type="checkbox" id="discountCheckAll" checked onclick="toggleDiscountChecks(this)"></th>
								<th></th>
								<th>品目コード<%--품목코드--%></th>
								<th>品目名<%--품목명--%></th>
								<th class="col-num">数量<%--수량--%></th>
								<th class="col-num">基準単価(VAT込)<%--기준단가(vat포함)--%></th>
								<th class="col-num">基準単価<%--기준단가--%></th>
								<th class="col-num">基準ウォン供給価額<%--기준원화공급가액--%></th>
								<th class="col-num">割引単価(VAT込)<%--할인단가(vat포함)--%></th>
								<th class="col-num">割引単価<%--할인단가--%></th>
								<th class="col-num">割引ウォン供給価額<%--할인원화공급가액--%></th>
								<th class="col-num">単価<%--단가--%></th>
								<th class="col-num">ウォン供給価額<%--원화공급가액--%></th>
							</tr>
						</thead>
						<tbody id="discountBody"></tbody>
						<tfoot>
							<tr>
								<td colspan="4"></td>
								<td class="col-num" id="discountFootQty"></td>
								<td></td>
								<td></td>
								<td class="col-num" id="discountFootBase"></td>
								<td></td>
								<td></td>
								<td class="col-num" id="discountFootOff"></td>
								<td></td>
								<td class="col-num" id="discountFootKrw"></td>
							</tr>
						</tfoot>
					</table>
				</div>
			</div>
			<div class="discount-foot">
				<button type="button" class="btn-primary-sm" onclick="applyDiscountToSale()">適用(F8)<%--적용(F8)--%></button>
				<button type="button" class="btn-flat-sm" onclick="closeDiscountModal()">閉じる<%--닫기--%></button>
			</div>
		</div>
	</div>

	<script>
		var ctx = '${pageContext.request.contextPath}';
		var embedMode = ${embed == '1'};

		// 코드나 이름을 고치면 조회 키를 지운다. 지금 치는 칸은 남기고, 반대 칸은 비워 코드와 이름이 어긋나지 않게 한다.
		// コードか名前を直すと照会キーを消す。今打っている欄は残し、反対の欄は空にしてコードと名前がずれないようにする。
		function clearPartnerId(from) {
			document.getElementById('businessPartnerId').value = '';
			document.getElementById('businessPartnerCode').dataset.matched = '';
			document.getElementById('businessPartnerName').dataset.matched = '';
			if (from !== 'code') document.getElementById('businessPartnerCode').value = '';
			if (from !== 'name') document.getElementById('businessPartnerName').value = '';
		}
		function clearManagerId(from) {
			document.getElementById('managerId').value = '';
			document.getElementById('employeeCode').dataset.matched = '';
			document.getElementById('employeeName').dataset.matched = '';
			if (from !== 'code') document.getElementById('employeeCode').value = '';
			if (from !== 'name') document.getElementById('employeeName').value = '';
		}
		function clearWarehouseId(from) {
			document.getElementById('warehousePk').value = '';
			document.getElementById('warehouseCode').dataset.matched = '';
			document.getElementById('warehouseName').dataset.matched = '';
			if (from !== 'code') document.getElementById('warehouseCode').value = '';
			if (from !== 'name') document.getElementById('warehouseName').value = '';
		}
		function sameText(value, keyword) {
			return String(value == null ? '' : value).trim() === keyword;
		}
		function skipLookupBlur(event) {
			return event && event.relatedTarget && event.relatedTarget.closest && event.relatedTarget.closest('.popup-search-btn');
		}
		function markMatched(input, text) {
			if (!input) return;
			input.dataset.matched = String(text || '').trim();
			input.dataset.resolving = '';
		}
		// 코드나 이름이 정확히 하나 같으면 그 항목을 넣는다. 없거나 여러 개면 그 글자로 조회 모달을 연다.
		// コードか名前が正確に一つ同じならその項目を入れる。ないか複数ならその文字で照会モーダルを開く。
		function resolveLookup(type, input, apply) {
			var text = String(input.value || '').trim();
			if (!text || input.dataset.matched === text || input.dataset.resolving === '1') return;
			input.dataset.resolving = '1';
			var path = type === 'partner' ? '/partners' : (type === 'manager' ? '/managers' : '/warehouses');
			fetch(ctx + path + '?keyword=' + encodeURIComponent(text), { headers: { 'Accept': 'application/json' } })
				.then(function(res) { return res.json(); })
				.then(function(list) {
					input.dataset.resolving = '';
					var exact = (list || []).filter(function(row) {
						if (type === 'partner')
							return sameText(row.businessPartnerCode, text) || sameText(row.businessPartnerName, text) || sameText(row.searchContent, text);
						if (type === 'manager')
							return sameText(row.employeeCode, text) || sameText(row.employeeName, text);
						return sameText(row.warehouseCode, text) || sameText(row.warehouseName, text);
					});
					if (exact.length === 1) {
						apply(exact[0]);
						markMatched(input, input.value);
					} else {
						CommonLookup.open(type, apply, text);
					}
				}).catch(function() { input.dataset.resolving = ''; });
		}
		function applyPartner(row) {
			document.getElementById('businessPartnerId').value = row.businessPartnerId || '';
			document.getElementById('businessPartnerCode').value = row.businessPartnerCode || '';
			document.getElementById('businessPartnerName').value = row.businessPartnerName || '';
			markMatched(document.getElementById('businessPartnerCode'), row.businessPartnerCode);
			markMatched(document.getElementById('businessPartnerName'), row.businessPartnerName);
		}
		function applyManager(row) {
			document.getElementById('managerId').value = row.managerId || '';
			document.getElementById('employeeCode').value = row.employeeCode || '';
			document.getElementById('employeeName').value = row.employeeName || '';
			markMatched(document.getElementById('employeeCode'), row.employeeCode);
			markMatched(document.getElementById('employeeName'), row.employeeName);
		}
		function applyWarehouse(row) {
			document.getElementById('warehousePk').value = row.warehousePk || '';
			document.getElementById('warehouseCode').value = row.warehouseCode || '';
			document.getElementById('warehouseName').value = row.warehouseName || '';
			markMatched(document.getElementById('warehouseCode'), row.warehouseCode);
			markMatched(document.getElementById('warehouseName'), row.warehouseName);
		}
		function resolvePartner(event) {
			if (skipLookupBlur(event)) return;
			resolveLookup('partner', event && event.target ? event.target : document.getElementById('businessPartnerName'), applyPartner);
		}
		function resolveManager(event) {
			if (skipLookupBlur(event)) return;
			resolveLookup('manager', event && event.target ? event.target : document.getElementById('employeeName'), applyManager);
		}
		function resolveWarehouse(event) {
			if (skipLookupBlur(event)) return;
			resolveLookup('warehouse', event && event.target ? event.target : document.getElementById('warehouseName'), applyWarehouse);
		}
		function headerLookupKeyword(codeId, nameId) {
			var code = document.getElementById(codeId).value.trim();
			return code || document.getElementById(nameId).value.trim();
		}
		function openPartnerLookup() { CommonLookup.open('partner', applyPartner, headerLookupKeyword('businessPartnerCode', 'businessPartnerName')); }
		function openManagerLookup() { CommonLookup.open('manager', applyManager, headerLookupKeyword('employeeCode', 'employeeName')); }
		function openWarehouseLookup() { CommonLookup.open('warehouse', applyWarehouse, headerLookupKeyword('warehouseCode', 'warehouseName')); }

		function num(value) {
			var n = Number(String(value == null ? '' : value).replace(/,/g, ''));
			return isNaN(n) ? 0 : n;
		}
		function money(value) { return Math.round(value).toLocaleString(); }
		function noVat() {
			return document.querySelector('[name="header.saleType"]').value === '付加税率不適用';
		}
		function lineRows() { return document.querySelectorAll('#saleGrid tbody tr'); }
		function adjRows() { return document.querySelectorAll('#adjustGrid tbody tr'); }
		function showResult(html) { document.getElementById('saleResult').innerHTML = html; }

		// 공급가액은 수량×단가에서 할인을 뺀다. 부가세율 미적용이면 부가세는 0이고, 합계는 둘을 더한 값이다.
		// 供給価額は数量×単価から割引を引く。付加税率不適用なら付加税は0であり、合計は二つを足した値である。
		function calcLine(el) {
			var tr = el.closest('tr');
			var qtyText = String(tr.querySelector('.line-qty').value || '').trim();
			var qty = num(qtyText);
			var price = num(tr.querySelector('.line-price').value);
			var discount = num(tr.querySelector('.line-discount').value);
			var supply = qty * price - discount;
			if (supply < 0) supply = 0;
			var vat = noVat() ? 0 : Math.round(supply * 0.1);
			var show = tr.querySelector('.line-item-pk').value && qtyText !== '';
			tr.querySelector('.line-supply').value = show ? money(supply) : '';
			tr.querySelector('.line-vat').value = show ? money(vat) : '';
			tr.querySelector('.line-amt').value = show ? money(supply + vat) : '';
			sumFooter();
			ensureBlankRow();
		}
		// 금액조정 부가세도 품목과 같이 공급가액의 10%다. 미적용이면 0이다.
		// 金額調整の付加税も品目と同じく供給価額の10%である。不適用なら0である。
		function calcAdj(el) {
			if (!el) return;
			var tr = el.closest('tr');
			var supply = num(tr.querySelector('.adj-supply').value);
			if (supply < 0) supply = 0;
			var vat = noVat() ? 0 : Math.round(supply * 0.1);
			tr.querySelector('.adj-vat').value = vat;
			tr.querySelector('.adj-total').value = supply + vat;
			tr.querySelector('.adj-vat-text').textContent = money(vat);
			tr.querySelector('.adj-total-text').textContent = money(supply + vat);
			sumFooter();
		}
		function recalcAll() {
			lineRows().forEach(function(tr) {
				if (tr.querySelector('.line-item-pk').value) calcLine(tr.querySelector('.line-qty'));
			});
			adjRows().forEach(function(tr) { calcAdj(tr.querySelector('.adj-supply')); });
		}
		function sumFooter() {
			var supply = 0, vat = 0, qty = 0;
			lineRows().forEach(function(tr) {
				if (!tr.querySelector('.line-item-pk').value) return;
				qty += num(tr.querySelector('.line-qty').value);
				supply += num(tr.querySelector('.line-supply').value);
				vat += num(tr.querySelector('.line-vat').value);
			});
			document.getElementById('footQty').textContent = money(qty);
			document.getElementById('footSupply').textContent = money(supply);
			document.getElementById('footVat').textContent = money(vat);
			document.getElementById('footTotal').textContent = money(supply + vat);
			syncVatAdjustment(supply, vat, qty > 0 || hasRegisteredItem());
		}
		function hasRegisteredItem() {
			var found = false;
			lineRows().forEach(function(tr) {
				if (tr.querySelector('.line-item-pk').value) found = true;
			});
			return found;
		}
		// 품목이 있으면 거래별 부가세 합계 한 줄을 보여 준다. 값은 품목표 합계이고 직접 입력하지 않는다.
		// 品目があれば取引別付加税合計の1行を見せる。値は品目表の合計であり、直接入力しない。
		function syncVatAdjustment(supply, vat, show) {
			var body = document.getElementById('adjustGrid').tBodies[0];
			if (!show) {
				body.innerHTML = '';
				return;
			}
			var tr = body.querySelector('tr.adj-summary');
			if (!tr) {
				body.innerHTML = '';
				tr = document.createElement('tr');
				tr.className = 'adj-summary';
				tr.innerHTML = '<td class="adj-name-text"></td><td></td>'
					+ '<td class="col-num adj-supply-text"></td>'
					+ '<td class="col-num adj-vat-text"></td>'
					+ '<td class="col-num adj-total-text"></td>';
				body.appendChild(tr);
			}
			tr.querySelector('.adj-name-text').textContent = '取引別付加税合計';
			tr.querySelector('.adj-supply-text').textContent = money(supply);
			tr.querySelector('.adj-vat-text').textContent = money(vat);
			tr.querySelector('.adj-total-text').textContent = money(supply + vat);
		}
		function blankRow() {
			var body = document.getElementById('saleGrid').tBodies[0];
			var row = body.querySelector('tr').cloneNode(true);
			row.querySelectorAll('input').forEach(function(input) {
				if (input.type === 'checkbox') input.checked = false;
				input.value = '';
				input.removeAttribute('name');
				delete input.dataset.matched;
				delete input.dataset.resolving;
			});
			row.querySelector('.line-discount').value = '0';
			delete row.dataset.basePrice;
			body.appendChild(row);
			return row;
		}
		function rowHasEntry(tr) {
			var classes = ['.line-item-pk', '.line-item-code', '.line-item-name', '.line-spec', '.line-qty', '.line-price', '.line-remark'];
			for (var i = 0; i < classes.length; i++) {
				var el = tr.querySelector(classes[i]);
				if (el && String(el.value || '').trim()) return true;
			}
			return false;
		}
		function ensureBlankRow() {
			var filled = true;
			lineRows().forEach(function(tr) { if (!rowHasEntry(tr)) filled = false; });
			if (filled) blankRow();
		}
		function padRows() {
			var body = document.getElementById('saleGrid').tBodies[0];
			while (body.querySelectorAll('tr').length < 3) blankRow();
		}
		function focusAdjustment() {
			document.getElementById('adjustGrid').scrollIntoView({ block: 'nearest' });
		}
		// 코드를 비우면 품목 키를 지운다. 글자만 고친 경우는 키를 유지해서 그 글자를 판매 스냅에 저장한다.
		// コードを空にすると品目キーを消す。文字だけ直したときはキーを維持し、その文字を販売スナップに保存する。
		function onCodeInput(input) {
			var tr = input.closest('tr');
			if (!String(input.value || '').trim()) {
				tr.querySelector('.line-item-pk').value = '';
				input.dataset.matched = '';
				calcLine(tr.querySelector('.line-qty'));
			}
			ensureBlankRow();
		}
		function applyItemRow(tr, row) {
			var code = tr.querySelector('.line-item-code');
			tr.querySelector('.line-item-pk').value = row.itemPk || '';
			code.value = row.itemCode || '';
			markMatched(code, row.itemCode);
			tr.querySelector('.line-item-name').value = row.itemName || row.itemNm || '';
			tr.querySelector('.line-spec').value = row.spec || '';
			if (row.unitPrice != null) tr.querySelector('.line-price').value = row.unitPrice;
			calcLine(tr.querySelector('.line-qty'));
		}
		function openItemLookup(el) {
			var preferred = el && el.closest ? el.closest('tr') : null;
			var typed = '';
			if (preferred) typed = preferred.querySelector('.line-item-code').value.trim();
			CommonLookup.open('item', function(selected) {
				var list = Array.isArray(selected) ? selected : [selected];
				list.forEach(function(row, index) {
					var target = index === 0 ? preferred : null;
					if (!target) {
						lineRows().forEach(function(tr) {
							if (!target && !tr.querySelector('.line-item-code').value) target = tr;
						});
					}
					if (!target) target = blankRow();
					applyItemRow(target, row);
				});
				ensureBlankRow();
			}, typed);
		}
		function resolveItem(input, event) {
			if (skipLookupBlur(event)) return;
			var text = String(input.value || '').trim();
			var tr = input.closest('tr');
			// 이미 고른 품목의 코드는 스냅 수정이다. 조회 결과로 코드, 품목명, 규격을 덮지 않는다.
			// 既に選んだ品目のコードはスナップ修正である。照会結果でコード、品目名、規格を上書きしない。
			if (tr.querySelector('.line-item-pk').value) return;
			if (!text) {
				tr.querySelector('.line-item-pk').value = '';
				ensureBlankRow();
				return;
			}
			if (input.dataset.matched === text || input.dataset.resolving === '1') return;
			input.dataset.resolving = '1';
			fetch(ctx + '/items?keyword=' + encodeURIComponent(text), { headers: { 'Accept': 'application/json' } })
				.then(function(res) { return res.json(); })
				.then(function(list) {
					input.dataset.resolving = '';
					var exact = (list || []).filter(function(row) {
						return sameText(row.itemCode, text) || sameText(row.itemName, text) || sameText(row.searchContent, text) || sameText(row.spec, text);
					});
					if (exact.length === 1) {
						applyItemRow(tr, exact[0]);
						ensureBlankRow();
					} else {
						tr.querySelector('.line-item-pk').value = '';
						CommonLookup.open('item', function(selected) {
							var rows = Array.isArray(selected) ? selected : [selected];
							if (rows[0]) applyItemRow(tr, rows[0]);
							rows.slice(1).forEach(function(row) {
								var target = null;
								lineRows().forEach(function(line) {
									if (!target && !line.querySelector('.line-item-code').value) target = line;
								});
								if (!target) target = blankRow();
								applyItemRow(target, row);
							});
							ensureBlankRow();
						}, text);
					}
				}).catch(function() { input.dataset.resolving = ''; });
		}
		function openGridFind() {
			var input = document.getElementById('gridFindKeyword');
			if (input.style.display === 'none') {
				input.style.display = '';
				input.focus();
				return;
			}
			findInGrid();
		}
		function findInGrid() {
			var keyword = document.getElementById('gridFindKeyword').value.trim();
			var first = null;
			document.querySelectorAll('#saleGrid tbody td').forEach(function(td) {
				td.classList.remove('cell-found');
				if (!keyword) return;
				var input = td.querySelector('input[type="text"]');
				var value = input ? input.value.trim() : td.textContent.trim();
				if (value && value.indexOf(keyword) >= 0) {
					td.classList.add('cell-found');
					if (!first) first = td;
				}
			});
			if (first) first.scrollIntoView({ block: 'nearest', inline: 'nearest' });
		}
		// 품목코드가 있는 줄을 위에서부터 정렬하고, 빈 줄은 아래에 둔다.
		// 品目コードがある行を上から並べ、空行は下に置く。
		function sortGrid() {
			var body = document.getElementById('saleGrid').tBodies[0];
			var rows = Array.prototype.slice.call(body.querySelectorAll('tr'));
			rows.sort(function(a, b) {
				var codeA = a.querySelector('.line-item-code').value.trim();
				var codeB = b.querySelector('.line-item-code').value.trim();
				if (!codeA && !codeB) return 0;
				if (!codeA) return 1;
				if (!codeB) return -1;
				return codeA.localeCompare(codeB);
			});
			rows.forEach(function(tr) { body.appendChild(tr); });
		}
		// 할인 창 헤더는 판매입력2의 거래처, 창고, 통화, 거래유형을 보여 주기만 한다. 품목 줄은 입력된 행만 가져온다.
		// 割引画面のヘッダは販売入力2の取引先、倉庫、通貨、取引類型を見せるだけである。品目行は入力された行だけ取る。
		function openDiscountModal() {
			var partnerName = document.getElementById('businessPartnerName');
			var warehouseName = document.getElementById('warehouseName');
			document.getElementById('discountPartnerCode').value = document.getElementById('businessPartnerCode').value || '';
			document.getElementById('discountPartnerName').value = partnerName.value || '';
			document.getElementById('discountWarehouseCode').value = document.getElementById('warehouseCode').value || '';
			document.getElementById('discountWarehouseName').value = warehouseName.value || '';
			document.getElementById('discountCurrency').value = discountCurrencyText(document.getElementById('currencyName').value);
			var saleType = document.querySelector('[name="header.saleType"]');
			var saleTypeLabel = saleType.options[saleType.selectedIndex];
			document.getElementById('discountSaleType').value = saleTypeLabel ? saleTypeLabel.textContent.replace(/\s+/g, ' ').trim() : '';
			if (!document.getElementById('currencyName').value) loadDomesticCurrency();
			fillDiscountCode('partner');
			fillDiscountCode('warehouse');
			var body = document.getElementById('discountBody');
			body.innerHTML = '';
			var no = 0;
			lineRows().forEach(function(tr) {
				if (!rowHasEntry(tr)) return;
				no++;
				body.appendChild(discountRow(tr, no));
			});
			document.getElementById('discountCheckAll').checked = true;
			document.getElementById('discountOverlay').classList.add('active');
			sumDiscountFooter();
		}
		function closeDiscountModal() {
			document.getElementById('discountOverlay').classList.remove('active');
		}
		function discountCurrencyText(name) {
			if (!name || name === '원화') return 'KR';
			return name;
		}
		function loadDomesticCurrency() {
			fetch(ctx + '/common/lookup/currencies', { headers: { 'Accept': 'application/json' } })
				.then(function(res) { return res.json(); })
				.then(function(list) {
					var found = (list || []).filter(function(row) { return row.currencyCode === 'KR'; })[0];
					if (!found) return;
					document.getElementById('currencyName').value = found.currencyName || '';
					document.getElementById('discountCurrency').value = found.currencyCode === 'KR' ? 'KR' : (found.currencyName || '');
					if (found.exchangeRate != null) document.getElementById('exchangeRate').value = found.exchangeRate;
				});
		}
		function fillDiscountCode(kind) {
			var codeInput = document.getElementById(kind === 'partner' ? 'discountPartnerCode' : 'discountWarehouseCode');
			var name = document.getElementById(kind === 'partner' ? 'discountPartnerName' : 'discountWarehouseName').value.trim();
			var id = document.getElementById(kind === 'partner' ? 'businessPartnerId' : 'warehousePk').value;
			if (codeInput.value || !name) return;
			fetch(ctx + (kind === 'partner' ? '/partners' : '/warehouses') + '?keyword=' + encodeURIComponent(name), {
				headers: { 'Accept': 'application/json' }
			}).then(function(res) { return res.json(); }).then(function(list) {
				var found = (list || []).filter(function(row) {
					if (kind === 'partner') return (!id || String(row.businessPartnerId) === String(id)) && sameText(row.businessPartnerName, name);
					return (!id || String(row.warehousePk) === String(id)) && sameText(row.warehouseName, name);
				})[0];
				if (found) codeInput.value = kind === 'partner' ? (found.businessPartnerCode || '') : (found.warehouseCode || '');
			});
		}
		function discountRow(source, no) {
			var tr = document.createElement('tr');
			var qtyText = String(source.querySelector('.line-qty').value || '').trim();
			var qty = num(qtyText);
			var cells = [
				'<input type="checkbox" class="discount-check" checked>',
				'<span class="discount-no">' + no + '</span>',
				source.querySelector('.line-item-code').value,
				source.querySelector('.line-item-name').value,
				qtyText === '' ? '' : money(qty)
			];
			cells.forEach(function(value, index) {
				var td = document.createElement('td');
				if (index < 2) td.innerHTML = value;
				else td.textContent = value;
				if (index === 4) td.className = 'col-num disc-qty';
				tr.appendChild(td);
			});
			['disc-base-vat', 'disc-base-price', 'disc-base-krw', 'disc-off-vat', 'disc-off-price', 'disc-off-krw', 'disc-price', 'disc-krw'].forEach(function(name) {
				var td = document.createElement('td');
				td.className = 'col-num ' + name;
				tr.appendChild(td);
			});
			tr.dataset.qty = qty;
			tr._saleRow = source;
			loadDiscountBase(tr, source, qty);
			return tr;
		}
		function loadDiscountBase(tr, source, qty) {
			var stored = source.dataset.basePrice;
			if (stored != null && stored !== '') {
				writeDiscountBase(tr, Number(stored), qty);
				return;
			}
			var itemPk = source.querySelector('.line-item-pk').value;
			var key = String(source.querySelector('.line-item-code').value || '').trim();
			if (!itemPk && !key) return;
			fetch(ctx + '/items?keyword=' + encodeURIComponent(key), { headers: { 'Accept': 'application/json' } })
				.then(function(res) { return res.json(); })
				.then(function(list) {
					var rows = list || [];
					var found = rows.filter(function(row) { return itemPk && String(row.itemPk) === String(itemPk); })[0];
					if (!found && key) {
						var exact = rows.filter(function(row) { return sameText(row.itemCode, key); });
						if (exact.length === 1) found = exact[0];
					}
					if (!found || found.unitPrice == null) return;
					source.dataset.basePrice = found.unitPrice;
					writeDiscountBase(tr, Number(found.unitPrice), qty);
				});
		}
		function writeDiscountBase(tr, base, qty) {
			if (isNaN(base)) return;
			var rateText = String(document.getElementById('exchangeRate').value || '').trim();
			var rate = rateText === '' ? 1 : num(rateText);
			tr.dataset.basePrice = base;
			tr.dataset.baseKrw = qty * rate * base;
			tr.querySelector('.disc-base-price').textContent = money(base);
			tr.querySelector('.disc-base-krw').textContent = money(tr.dataset.baseKrw);
			if (tr.dataset.offPrice != null && tr.dataset.offPrice !== '') writeDiscountPrice(tr, num(tr.dataset.offPrice));
			sumDiscountFooter();
		}
		// 일괄변경을 고르면 불러온 품목을 모두 체크한다. 품목별을 고르면 체크를 모두 해제한다.
		// 一括変更を選ぶと読み込んだ品目をすべてチェックする。品目別を選ぶとチェックをすべて外す。
		function onDiscountApplyMode() {
			var selected = document.querySelector('input[name="discountApply"]:checked');
			var batch = selected && selected.value === 'batch';
			document.getElementById('discountCheckAll').checked = !!batch;
			document.querySelectorAll('#discountBody .discount-check').forEach(function(input) { input.checked = !!batch; });
		}
		// 할인단가는 입력 금액을 그대로 쓴다. 할인단가(vat포함)는 입력 금액을 1.1로 나눈 값이다. 일괄변경은 모든 품목, 품목별은 체크한 품목만 적용한다.
		// 割引単価は入力金額をそのまま使う。割引単価(vat含む)は入力金額を1.1で割った値である。一括変更はすべての品目、品目別はチェックした品目だけ適用する。
		function applyDiscountAmount() {
			var kind = document.getElementById('discountPriceKind').value;
			var amount = num(document.getElementById('discountValue').value);
			var batch = document.querySelector('input[name="discountApply"]:checked').value === 'batch';
			if (batch) {
				document.getElementById('discountCheckAll').checked = true;
				document.querySelectorAll('#discountBody .discount-check').forEach(function(input) { input.checked = true; });
			}
			document.querySelectorAll('#discountBody tr').forEach(function(tr) {
				var box = tr.querySelector('.discount-check');
				if (!batch && (!box || !box.checked)) return;
				if (kind === 'vat') {
					tr.querySelector('.disc-off-vat').textContent = money(amount);
					writeDiscountPrice(tr, amount / 1.1);
					return;
				}
				tr.querySelector('.disc-off-vat').textContent = '';
				writeDiscountPrice(tr, amount);
			});
			sumDiscountFooter();
		}
		// 아래 적용은 계산된 단가와 공급가액을 판매입력2 품목 줄에만 넣는다. 부가세는 그 공급가액의 10%이고 품목 마스터는 바꾸지 않는다.
		// 下の適用は計算した単価と供給価額を販売入力2の品目行だけに入れる。付加税はその供給価額の10%であり、品目マスタは変えない。
		function applyDiscountToSale() {
			var selected = document.querySelector('input[name="discountApply"]:checked');
			var batch = selected && selected.value === 'batch';
			document.querySelectorAll('#discountBody tr').forEach(function(tr) {
				var box = tr.querySelector('.discount-check');
				if (!batch && (!box || !box.checked)) return;
				var priceText = tr.querySelector('.disc-price').textContent;
				var supplyText = tr.querySelector('.disc-krw').textContent;
				if (!priceText || !tr._saleRow) return;
				var saleRow = tr._saleRow;
				var supply = num(supplyText);
				var vat = noVat() ? 0 : Math.round(supply * 0.1);
				saleRow.querySelector('.line-price').value = priceText;
				saleRow.querySelector('.line-supply').value = supplyText;
				saleRow.querySelector('.line-vat').value = money(vat);
				saleRow.querySelector('.line-amt').value = money(supply + vat);
				saleRow.querySelector('.line-discount').value = '0';
			});
			sumFooter();
			closeDiscountModal();
		}
		function writeDiscountPrice(tr, amount) {
			var qty = num(tr.dataset.qty);
			var base = num(tr.dataset.basePrice);
			var baseKrw = num(tr.dataset.baseKrw);
			var offKrw = qty * amount;
			tr.dataset.offPrice = amount;
			tr.querySelector('.disc-off-price').textContent = money(amount);
			tr.querySelector('.disc-off-krw').textContent = money(offKrw);
			tr.querySelector('.disc-price').textContent = money(base - amount);
			tr.querySelector('.disc-krw').textContent = money(baseKrw - offKrw);
		}
		function sumDiscountFooter() {
			var rows = document.querySelectorAll('#discountBody tr');
			var qty = 0, base = 0, off = 0, krw = 0, hasOff = false, hasKrw = false;
			rows.forEach(function(tr) {
				qty += num(tr.querySelector('.disc-qty').textContent);
				base += num(tr.querySelector('.disc-base-krw').textContent);
				var offText = tr.querySelector('.disc-off-krw').textContent;
				var krwText = tr.querySelector('.disc-krw').textContent;
				if (offText) { hasOff = true; off += num(offText); }
				if (krwText) { hasKrw = true; krw += num(krwText); }
			});
			document.getElementById('discountFootQty').textContent = rows.length ? money(qty) : '';
			document.getElementById('discountFootBase').textContent = rows.length ? money(base) : '';
			document.getElementById('discountFootOff').textContent = hasOff ? money(off) : '';
			document.getElementById('discountFootKrw').textContent = hasKrw ? money(krw) : '';
		}
		function toggleDiscountChecks(box) {
			document.querySelectorAll('#discountBody .discount-check').forEach(function(input) { input.checked = box.checked; });
		}
		// 재고불러오기는 수량을 읽기만 한다. 칸은 그때 값과 함께 표에 붙는다. 출하창고 재고를 빼는 곳은 보류가 아닌 정상 저장이다.
		// 在庫読込は数量を読むだけである。列はそのとき値と一緒に表へ付く。出荷倉庫の在庫を引くのは保留ではない正常保存である。
		function loadStock() {
			var warehousePk = document.getElementById('warehousePk').value;
			if (!warehousePk) {
				showResult('出荷倉庫を先に選択してください。<%--출하창고를 먼저 선택하세요.--%>');
				return;
			}
			var targets = [];
			var jobs = [];
			lineRows().forEach(function(tr) {
				var itemPk = tr.querySelector('.line-item-pk').value;
				if (!itemPk) return;
				targets.push(tr);
				jobs.push(fetch(ctx + '/items/' + itemPk + '/stock?warehouseId=' + warehousePk).then(function(res) { return res.json(); }));
			});
			if (!jobs.length) {
				showResult('品目を先に入れてください。<%--품목을 먼저 넣으세요.--%>');
				return;
			}
			Promise.all(jobs).then(function(stocks) {
				showStockColumns();
				stocks.forEach(function(stock, index) {
					targets[index].querySelector('.line-tot').value = stock.totQty;
					targets[index].querySelector('.line-wh').value = stock.whQty;
				});
			});
		}
		function showStockColumns() {
			var table = document.getElementById('saleGrid');
			if (!table.classList.contains('stock-open')) {
				table.classList.add('stock-open');
				var anchor = table.querySelector('thead .stock-anchor');
				var totTh = document.createElement('th');
				totTh.className = 'col-num stock-col';
				totTh.textContent = '全体数量';
				var whTh = document.createElement('th');
				whTh.className = 'col-num stock-col';
				whTh.textContent = '出荷倉庫数量';
				anchor.parentNode.insertBefore(whTh, anchor.nextSibling);
				anchor.parentNode.insertBefore(totTh, whTh);
				document.getElementById('footLead').colSpan = 6;
			}
			lineRows().forEach(ensureStockCells);
		}
		function ensureStockCells(tr) {
			if (tr.querySelector('.line-tot')) return;
			var specTd = tr.querySelector('.line-spec').closest('td');
			var tot = stockCell('line-tot');
			var wh = stockCell('line-wh');
			specTd.parentNode.insertBefore(wh, specTd.nextSibling);
			specTd.parentNode.insertBefore(tot, wh);
		}
		function stockCell(cls) {
			var td = document.createElement('td');
			td.className = 'stock-col';
			var input = document.createElement('input');
			input.type = 'text';
			input.className = 'col-num ' + cls;
			td.appendChild(input);
			return td;
		}
		function hideStockColumns() {
			var table = document.getElementById('saleGrid');
			table.classList.remove('stock-open');
			table.querySelectorAll('.stock-col').forEach(function(el) { el.parentNode.removeChild(el); });
			var lead = document.getElementById('footLead');
			if (lead) lead.colSpan = 4;
		}
		function verifyLines() {
			var bad = 0;
			lineRows().forEach(function(tr) {
				if (!tr.querySelector('.line-item-pk').value) return;
				var supply = Math.max(0, num(tr.querySelector('.line-qty').value) * num(tr.querySelector('.line-price').value) - num(tr.querySelector('.line-discount').value));
				var vat = noVat() ? 0 : Math.round(supply * 0.1);
				var ok = num(tr.querySelector('.line-supply').value) === Math.round(supply) && num(tr.querySelector('.line-vat').value) === vat;
				tr.querySelector('.line-supply').closest('td').classList.toggle('cell-found', !ok);
				if (!ok) bad++;
				calcLine(tr.querySelector('.line-qty'));
			});
			adjRows().forEach(function(tr) { calcAdj(tr.querySelector('.adj-supply')); });
			showResult(bad ? '金額が合わない行 ' + bad + '件を再計算しました。<%--금액이 맞지 않는 줄 건을 다시 계산했습니다.--%>' : '数量、単価、金額は合っています。<%--수량, 단가, 금액이 맞습니다.--%>');
		}
		function toggleSaveMenu(event) {
			event.preventDefault();
			event.stopPropagation();
			document.getElementById('saveMenu').classList.toggle('open');
		}
		document.addEventListener('click', function() {
			var menu = document.getElementById('saveMenu');
			if (menu) menu.classList.remove('open');
		});
		// 저장과 보류 전에 막는다. 거래처, 출하창고, 담당자, 품목이 없거나 수량이 0 이하면 보내지 않는다. 금액만 있는 조정은 항목명이 있어야 한다.
		// 保存と保留の前に止める。取引先、出荷倉庫、担当者、品目がないか数量が0以下なら送らない。金額だけの調整は項目名が必要である。
		function validateBeforeSave() {
			if (!document.getElementById('businessPartnerId').value) {
				showResult('取引先を選択してください。<%--거래처를 선택하세요.--%>');
				return false;
			}
			if (!document.getElementById('warehousePk').value) {
				showResult('出荷倉庫を選択してください。<%--출하창고를 선택하세요.--%>');
				return false;
			}
			if (!document.getElementById('managerId').value) {
				showResult('担当者を選択してください。<%--담당자를 선택하세요.--%>');
				return false;
			}
			var hasItem = false, zeroQty = false;
			lineRows().forEach(function(tr) {
				var qtyCell = tr.querySelector('.line-qty').closest('td');
				qtyCell.classList.remove('cell-bad');
				if (!tr.querySelector('.line-item-pk').value) return;
				hasItem = true;
				var qtyText = String(tr.querySelector('.line-qty').value || '').replace(/,/g, '').trim();
				if (qtyText === '' || num(qtyText) <= 0) {
					zeroQty = true;
					qtyCell.classList.add('cell-bad');
				}
			});
			if (!hasItem) {
				showResult('品目を入力してください。<%--품목을 입력하세요.--%>');
				return false;
			}
			if (zeroQty) {
				showResult('数量は0より大きい必要があります。<%--수량은 0보다 커야 합니다.--%>');
				return false;
			}
			var missingName = false;
			adjRows().forEach(function(tr) {
				if (tr.classList.contains('adj-summary')) return;
				var nameInput = tr.querySelector('.adj-name');
				if (!nameInput) return;
				var named = String(nameInput.value || '').trim();
				var supply = String(tr.querySelector('.adj-supply').value || '').replace(/,/g, '').trim();
				if (!named && supply !== '' && num(supply) !== 0) missingName = true;
			});
			if (missingName) {
				showResult('調整項目名を入力してください。<%--조정항목명을 입력하세요.--%>');
				return false;
			}
			return true;
		}
		function plain(input) {
			if (input) input.value = String(input.value || '').replace(/,/g, '');
		}
		// 품목이 있는 줄과 이름이 있는 조정만 서버로 보낸다. 신규는 POST, 수정은 PUT /sales/input2 이다.
		// 品目がある行と名前がある調整だけサーバへ送る。新規は POST、修正は PUT /sales/input2 である。
		function prepareSubmit(status) {
			if (!validateBeforeSave()) return false;
			document.getElementById('voucherStatus').value = status;
			var index = 0;
			lineRows().forEach(function(tr) {
				if (!tr.querySelector('.line-item-pk').value) return;
				['line-qty', 'line-price', 'line-discount', 'line-supply', 'line-vat', 'line-amt', 'line-tot', 'line-wh'].forEach(function(cls) {
					plain(tr.querySelector('.' + cls));
				});
				[['line-item-pk', 'itemPk'], ['line-item-code', 'itemCode'], ['line-item-name', 'itemNm'],
					['line-spec', 'spec'], ['line-qty', 'saleQty'], ['line-price', 'unitPrice'],
					['line-discount', 'discountAmt'],
					['line-supply', 'supplyAmt'], ['line-vat', 'vatAmt'], ['line-amt', 'lineAmt'],
					['line-tot', 'totQty'], ['line-wh', 'whQty'], ['line-remark', 'remark']].forEach(function(pair) {
					var field = tr.querySelector('.' + pair[0]);
					if (field) field.name = 'items[' + index + '].' + pair[1];
				});
				index++;
			});
			var adjIndex = 0;
			adjRows().forEach(function(tr) {
				if (tr.classList.contains('adj-summary') || !tr.querySelector('.adj-name')) return;
				if (!String(tr.querySelector('.adj-name').value || '').trim()) return;
				plain(tr.querySelector('.adj-supply'));
				plain(tr.querySelector('.adj-vat'));
				plain(tr.querySelector('.adj-total'));
				tr.querySelector('.adj-name').name = 'adjustments[' + adjIndex + '].adjustmentName';
				tr.querySelector('.adj-sign').name = 'adjustments[' + adjIndex + '].increaseDecrease';
				tr.querySelector('.adj-supply').name = 'adjustments[' + adjIndex + '].supplyAmt';
				tr.querySelector('.adj-vat').name = 'adjustments[' + adjIndex + '].vatAmt';
				tr.querySelector('.adj-total').name = 'adjustments[' + adjIndex + '].totalAmt';
				adjIndex++;
			});
			var form = document.getElementById('saleForm');
			var saleId = (form.querySelector('[name="header.saleId"]').value || '').trim();
			fetch(ctx + (saleId ? '/sales/input2/' + saleId : '/sales/input2'), {
				method: saleId ? 'PUT' : 'POST',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Accept': 'application/json' },
				body: new URLSearchParams(new FormData(form)).toString()
			}).then(function(res) {
				return res.json().then(function(body) { return { ok: res.ok, body: body || {} }; }, function() { return { ok: res.ok, body: {} }; });
			}).then(function(result) {
				if (!result.ok) {
					showResult(result.body.message || '保存できませんでした。<%--저장하지 못했습니다.--%>');
					return;
				}
				if (embedMode && window.parent && window.parent !== window)
					window.parent.postMessage({ type: 'sale-saved', saleId: result.body.saleId }, '*');
				else
					location.href = ctx + '/sales/sale/input2';
			}).catch(function() {
				showResult('保存できませんでした。<%--저장하지 못했습니다.--%>');
			});
			return false;
		}
		// 다시 작성은 빈 판매입력2다. 모달 안이면 제목을 판매입력2로 되돌리고 embed를 유지한다.
		// 再作成は空の販売入力2である。モーダル内なら題名を販売入力2へ戻し、embedを維持する。
		function rewriteSale() {
			if (embedMode && window.parent && window.parent !== window)
				window.parent.postMessage({ type: 'sale-title', mode: 'new', inputType: 'POS' }, '*');
			location.href = ctx + '/sales/sale/input2' + (embedMode ? '?embed=1' : '');
		}
		// 리스트는 판매조회로 간다. 모달 안이면 프레임을 옮기지 않고 부모 모달을 닫게 한다.
		// リストは販売照会へ行く。モーダル内ならフレームを移さず、親モーダルを閉じさせる。
		function goInquiry(event) {
			if (embedMode && window.parent && window.parent !== window) {
				event.preventDefault();
				window.parent.postMessage({ type: 'sale-close' }, '*');
				return false;
			}
			return true;
		}
		function openHoldModal() {
			document.getElementById('holdOverlay').classList.add('active');
			fetch(ctx + '/sales/input2?status=hold').then(function(res) { return res.json(); }).then(renderHolds);
		}
		function closeHoldModal() { document.getElementById('holdOverlay').classList.remove('active'); }
		function renderHolds(list) {
			var body = document.getElementById('holdBody');
			if (!list.length) {
				body.innerHTML = '<tr><td colspan="7">保留伝票がありません。<%--보류 전표가 없습니다.--%></td></tr>';
				return;
			}
			body.innerHTML = list.map(function(row) {
				return '<tr><td><input type="checkbox" class="hold-check" value="' + row.saleId + '"></td>'
					+ '<td><button type="button" class="hold-no" onclick="loadHold(' + row.saleId + ')">' + (row.holdNo || row.saleId) + '</button></td>'
					+ '<td>' + (row.businessPartnerName || '') + '</td>'
					+ '<td>' + (row.itemSummary || '') + '</td>'
					+ '<td class="col-num">' + money(row.currAmt) + '</td>'
					+ '<td>' + (row.saleType || '') + '</td>'
					+ '<td>' + (row.warehouseName || '') + '</td></tr>';
			}).join('');
		}
		function toDateInput(value) {
			var d = typeof value === 'number' ? new Date(value) : new Date(value);
			if (isNaN(d.getTime())) return String(value).substring(0, 10);
			var m = ('0' + (d.getMonth() + 1)).slice(-2);
			var day = ('0' + d.getDate()).slice(-2);
			return d.getFullYear() + '-' + m + '-' + day;
		}
		function resetGrid() {
			hideStockColumns();
			var body = document.getElementById('saleGrid').tBodies[0];
			var rows = body.querySelectorAll('tr');
			for (var i = rows.length - 1; i >= 3; i--) body.removeChild(rows[i]);
			body.querySelectorAll('tr').forEach(function(tr) {
				tr.querySelectorAll('input').forEach(function(input) {
					if (input.type === 'checkbox') input.checked = false;
					input.value = '';
					input.removeAttribute('name');
					delete input.dataset.matched;
				});
			});
		}
		function resetAdj() {
			document.getElementById('adjustGrid').tBodies[0].innerHTML = '';
		}
		function fillItem(item) {
			var target = null;
			lineRows().forEach(function(tr) {
				if (!target && !tr.querySelector('.line-item-code').value) target = tr;
			});
			if (!target) target = blankRow();
			target.querySelector('.line-item-pk').value = item.itemPk || '';
			target.querySelector('.line-item-code').value = item.itemCode || '';
			markMatched(target.querySelector('.line-item-code'), item.itemCode);
			target.querySelector('.line-item-name').value = item.itemNm || '';
			target.querySelector('.line-spec').value = item.spec || '';
			target.querySelector('.line-qty').value = item.saleQty != null ? item.saleQty : '';
			target.querySelector('.line-price').value = item.unitPrice != null ? item.unitPrice : '';
			target.querySelector('.line-discount').value = item.discountAmt != null ? item.discountAmt : 0;
			target.querySelector('.line-remark').value = item.remark || '';
			calcLine(target.querySelector('.line-qty'));
		}
		// 보류 목록에서 고른 전표를 입력란에 채운다. 이 시점에는 삭제하지 않고, 나중에 정상으로 저장하면 보류 목록에서 빠진다.
		// 保留一覧で選んだ伝票を入力欄に入れる。この時点では削除せず、後で正常に保存すると保留一覧から外れる。
		function loadHold(saleId) {
			fetch(ctx + '/sales/input2/' + saleId).then(function(res) { return res.json(); }).then(function(sale) {
				var header = sale.header || {};
				document.querySelector('[name="header.saleId"]').value = header.saleId || '';
				document.getElementById('voucherStatus').value = '保留';
				document.getElementById('businessPartnerId').value = header.businessPartnerId || '';
				document.getElementById('businessPartnerCode').value = header.businessPartnerCode || '';
				document.getElementById('businessPartnerName').value = header.businessPartnerName || '';
				document.getElementById('managerId').value = header.managerId || '';
				document.getElementById('employeeCode').value = header.employeeCode || '';
				document.getElementById('employeeName').value = header.employeeName || '';
				document.getElementById('warehousePk').value = header.warehousePk || '';
				document.getElementById('warehouseCode').value = header.warehouseCode || '';
				document.getElementById('warehouseName').value = header.warehouseName || '';
				markMatched(document.getElementById('businessPartnerCode'), header.businessPartnerCode);
				markMatched(document.getElementById('businessPartnerName'), header.businessPartnerName);
				markMatched(document.getElementById('employeeCode'), header.employeeCode);
				markMatched(document.getElementById('employeeName'), header.employeeName);
				markMatched(document.getElementById('warehouseCode'), header.warehouseCode);
				markMatched(document.getElementById('warehouseName'), header.warehouseName);
				if (header.saleType) document.querySelector('[name="header.saleType"]').value = header.saleType;
				if (header.exchangeRate != null) document.getElementById('exchangeRate').value = header.exchangeRate;
				document.getElementById('currencyName').value = header.currencyName || '';
				if (header.saleDt) document.querySelector('[name="header.saleDt"]').value = toDateInput(header.saleDt);
				resetGrid();
				resetAdj();
				(sale.items || []).forEach(fillItem);
				ensureBlankRow();
				closeHoldModal();
				showResult('保留伝票を読み込みました。保存すると販売記録に残り、保留一覧から外れます。<%--보류전표를 불러왔습니다. 저장하면 판매 기록으로 남고 보류 목록에서 빠집니다.--%>');
			});
		}
		function deleteSelectedHolds() {
			var ids = [];
			document.querySelectorAll('.hold-check:checked').forEach(function(box) { ids.push(box.value); });
			if (!ids.length) return;
			var chain = Promise.resolve();
			ids.forEach(function(id) {
				chain = chain.then(function() { return fetch(ctx + '/sales/input2/' + id, { method: 'DELETE' }); });
			});
			chain.then(function() { return fetch(ctx + '/sales/input2?status=hold'); })
				.then(function(res) { return res.json(); })
				.then(renderHolds);
		}
		if (document.getElementById('businessPartnerId').value) {
			markMatched(document.getElementById('businessPartnerCode'), document.getElementById('businessPartnerCode').value);
			markMatched(document.getElementById('businessPartnerName'), document.getElementById('businessPartnerName').value);
		}
		if (document.getElementById('managerId').value) {
			markMatched(document.getElementById('employeeCode'), document.getElementById('employeeCode').value);
			markMatched(document.getElementById('employeeName'), document.getElementById('employeeName').value);
		}
		if (document.getElementById('warehousePk').value) {
			markMatched(document.getElementById('warehouseCode'), document.getElementById('warehouseCode').value);
			markMatched(document.getElementById('warehouseName'), document.getElementById('warehouseName').value);
		}
		document.addEventListener('keydown', function(event) {
			if (event.key !== 'F8') return;
			if (!document.getElementById('discountOverlay').classList.contains('active')) return;
			event.preventDefault();
			applyDiscountToSale();
		});
		sumFooter();
		padRows();
		ensureBlankRow();
	</script>
	<style>
		body.sale-embed { margin: 0; overflow: auto; height: auto; }
		body.sale-embed .erp-sidebar { display: none !important; }
		body.sale-embed .erp-wrapper, body.sale-embed .erp-main { height: auto; overflow: visible; }
		.page-title { font-size: 1.25rem; font-weight: 700; color: var(--text-main, #0B1026); margin-bottom: 20px; display: flex; align-items: center; gap: 10px; }
		.page-title i { color: var(--color-blue, #4B88FF); font-size: 24px; }
		.list-wrap { background: #fff; border-radius: 14px; border: 1px solid var(--border-color, #e2e8f0); box-shadow: 0 10px 25px -5px rgba(75, 136, 255, .08); overflow: hidden; }
		.sale-head { display: grid; grid-template-columns: 1fr 1fr; gap: 12px 28px; padding: 22px 22px 8px; }
		.sale-field { display: grid; grid-template-columns: 88px 1fr; align-items: center; gap: 10px; }
		.sale-field label { font-weight: 700; color: #0B1026; font-size: 13px; }
		.sale-popup, .line-code { display: flex; align-items: center; gap: 6px; }
		.sale-popup input, .line-code input { flex: 1; }
		.sale-popup .header-code { flex: 0 0 110px; width: 110px; }
		.popup-search-btn { width: 34px; height: 34px; flex: none; border: 1px solid #cbd5e1; border-radius: 8px; background: #f8fafc; color: #1f3c88; cursor: pointer; }
		.sale-field input, .sale-field select { width: 100%; border: 1px solid #e2e8f0; border-radius: 8px; padding: 9px 12px; font-size: 13px; outline: none; background: #fff; color: #0B1026; }
		.sale-buttons, .sale-foot { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; }
		.sale-buttons { padding: 8px 22px 16px; }
		.sale-foot { padding: 16px 22px 22px; }
		.grid-find-input { border: 1px solid #e2e8f0; border-radius: 8px; padding: 8px 12px; font-size: 13px; width: 180px; }
		.list-table-wrap { width: 100%; overflow-x: auto; }
		.list-table { width: 100%; border-collapse: collapse; table-layout: fixed; }
		#saleGrid th, #saleGrid td, #adjustGrid th, #adjustGrid td { border: 1px solid #94a3b8; padding: 8px 10px; font-size: 13px; }
		.list-table th { background: #f8fafc; font-weight: 700; color: #64748b; }
		.list-table .col-num, .list-table th.col-num { text-align: right; }
		.list-table input { width: 100%; border: none; background: transparent; font-size: 13px; outline: none; }
		.list-table input.line-calc { color: #334155; cursor: default; }
		.list-table input.line-check { width: auto; }
		.list-table tfoot td { font-weight: 700; }
		.list-table td.cell-found, .list-table td.cell-found input { background: #fff3bf; }
		.list-table td.cell-bad { background: #fee2e2; }
		#adjustGrid { width: 100%; }
		#adjustGrid th { text-align: center; }
		.save-split { position: relative; display: inline-flex; }
		.save-main { border-radius: 8px 0 0 8px; }
		.save-arrow { border-radius: 0 8px 8px 0; border-left: 1px solid rgba(255,255,255,.35); padding: 8px; }
		.save-menu { display: none; position: absolute; left: 0; bottom: 42px; min-width: 120px; background: #fff; border: 1px solid #e2e8f0; border-radius: 8px; box-shadow: 0 8px 20px rgba(11,16,38,.12); z-index: 20; }
		.save-menu.open { display: block; }
		.save-menu button { display: block; width: 100%; text-align: left; background: #fff; border: none; padding: 10px 14px; font-weight: 700; cursor: pointer; }
		.hold-card { width: min(860px, 96vw); }
		.hold-note { padding: 12px 18px 0; color: #64748b; font-size: 13px; }
		.hold-no { border: none; background: transparent; color: #1F3C88; font-weight: 700; cursor: pointer; }
		.sale-result { padding: 0 22px 18px; color: #0B1026; font-size: 13px; }
		#saleGrid th:nth-child(1), #saleGrid td:nth-child(1) { width: 36px; }
		#discountOverlay { z-index: 1300; align-items: flex-start; padding: 4vh 16px; }
		.discount-card { width: min(1280px, 98vw); background: #fff; border-radius: 8px; overflow: hidden; box-shadow: 0 24px 60px rgba(11, 16, 38, .28); }
		.discount-titlebar { height: 36px; background: #2f6bff; color: #fff; display: flex; align-items: center; justify-content: space-between; padding: 0 8px 0 14px; font-size: 13px; font-weight: 700; }
		.discount-close { border: 0; background: transparent; color: #fff; font-size: 18px; cursor: pointer; }
		.discount-body { padding: 16px 18px 8px; }
		.discount-body h3 { margin: 0 0 14px; font-size: 18px; color: #0B1026; }
		.discount-head { display: grid; grid-template-columns: 72px 110px minmax(140px, 1fr) 72px 110px minmax(140px, 1fr); gap: 8px; align-items: center; margin-bottom: 12px; }
		.discount-head label { font-size: 13px; font-weight: 700; color: #334155; }
		.discount-head input { height: 32px; border: 1px solid #dbe3ee; border-radius: 4px; padding: 0 8px; background: #f8fafc; color: #0B1026; }
		#discountCurrency { grid-column: 2 / 4; }
		#discountSaleType { grid-column: 5 / 7; }
		.discount-tools { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; padding: 8px 0 12px; font-size: 13px; color: #334155; }
		.discount-tools select, .discount-tools input[type="text"] { height: 32px; border: 1px solid #dbe3ee; border-radius: 4px; padding: 0 8px; }
		.discount-tools input[type="text"] { width: 90px; }
		.discount-direct { height: 32px; border: 1px solid #2f6bff; border-radius: 4px; background: #eef4ff; color: #1d4ed8; font-weight: 700; padding: 0 10px; }
		.discount-apply { display: flex; align-items: center; gap: 12px; margin-right: 8px; }
		.discount-table-wrap { overflow: auto; max-height: 360px; border-top: 1px solid #e2e8f0; }
		.discount-table { width: 100%; min-width: 1100px; }
		.discount-table input { width: auto; }
		.discount-table th, .discount-table td { padding: 6px 4px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
		.discount-table thead th { background: #2f6bff; color: #fff; font-size: 11px; text-align: center; }
		.discount-no { display: inline-flex; width: 22px; height: 22px; border-radius: 50%; background: #2f6bff; color: #fff; align-items: center; justify-content: center; font-size: 12px; font-weight: 700; }
		.discount-foot { display: flex; gap: 8px; padding: 12px 18px 16px; }
	</style>
</body>
</html>
