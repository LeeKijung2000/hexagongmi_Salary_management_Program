<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ taglib prefix="my" tagdir="/WEB-INF/tags"%>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>販売単価一括変更<%--판매단가일괄변경--%> - ヘキサゴン ERP<%--헥사곤 ERP--%></title>
<link href="https://cdn.jsdelivr.net/npm/@mdi/font@7.2.96/css/materialdesignicons.min.css" rel="stylesheet">
</head>
<body>
	<div class="erp-wrapper">
		<my:sideMenu />
		<div class="erp-main">
			<main class="erp-content">
				<%-- 프로젝트, 거래구분, 하단의 판매단가일괄변경 목록 버튼, 종료일, 설정은 두지 않는다. --%>
				<%-- プロジェクト、取引区分、下段の販売単価一括変更一覧ボタン、終了日、設定は置かない。 --%>
				<div class="list-wrap" id="searchPane">
					<div class="price-form">
						<div class="form-row mode-row">
							<label>区分<%--구분--%></label>
							<div class="checks" id="modeChecks">
								<label><input type="radio" name="changeMode" value="PRICE" checked> 単価変更<%--단가변경--%></label>
								<label><input type="radio" name="changeMode" value="RATE"> 為替変更<%--환율변경--%></label>
							</div>
						</div>
						<div class="form-row">
							<label>基準日付<%--기준일자--%></label>
							<div class="date-line">
								<select id="datePreset" onchange="applyPreset()"></select>
								<select id="fromYear" onchange="onDatePart('from')"></select><span>/</span>
								<select id="fromMonth" onchange="onDatePart('from')"></select><span>/</span>
								<select id="fromDay" onchange="onDatePart('from')"></select>
								<span class="tilde">~</span>
								<select id="toYear" onchange="onDatePart('to')"></select><span>/</span>
								<select id="toMonth" onchange="onDatePart('to')"></select><span>/</span>
								<select id="toDay" onchange="onDatePart('to')"></select>
								<button type="button" class="cal-btn" onclick="openCalendar()" title="カレンダー<%--달력--%>"><i class="mdi mdi-calendar-month-outline"></i></button>
								<input type="date" id="calendarPick" class="cal-native">
							</div>
						</div>
						<div class="form-row">
							<label>取引類型<%--거래유형--%></label>
							<div class="search-field">
								<button type="button" onclick="openTransaction()"><i class="mdi mdi-magnify"></i></button>
								<input type="text" id="transactionName" readonly placeholder="取引類型<%--거래유형--%>">
								<button type="button" class="clear-btn" onclick="clearTransaction()"><i class="mdi mdi-close"></i></button>
							</div>
						</div>
						<div class="form-row">
							<label>内.外貨区分<%--내.외자구분--%></label>
							<div class="checks" id="currencyChecks">
								<label><input type="radio" name="currencyScope" value="DOMESTIC" checked> 内貨<%--내자--%></label>
								<label><input type="radio" name="currencyScope" value="FOREIGN"> 外貨<%--외자--%></label>
							</div>
						</div>
						<div class="form-row">
							<label class="link-label" onclick="openWarehouse()">出荷倉庫<%--출하창고--%> <i class="mdi mdi-menu-down"></i></label>
							<div class="search-field">
								<button type="button" onclick="openWarehouse()"><i class="mdi mdi-magnify"></i></button>
								<input type="text" id="warehouseName" placeholder="出荷倉庫<%--출하창고--%>" oninput="warehouseId = null">
								<button type="button" class="clear-btn" onclick="clearWarehouse()"><i class="mdi mdi-close"></i></button>
							</div>
						</div>
						<div class="form-row">
							<label class="link-label" onclick="openPartner()">取引先<%--거래처--%> <i class="mdi mdi-menu-down"></i></label>
							<div class="search-field">
								<button type="button" onclick="openPartner()"><i class="mdi mdi-magnify"></i></button>
								<input type="text" id="partnerName" placeholder="取引先<%--거래처--%>" oninput="partnerId = null">
								<button type="button" class="clear-btn" onclick="clearPartner()"><i class="mdi mdi-close"></i></button>
							</div>
						</div>
						<div class="form-row">
							<label class="link-label" onclick="openItem()">品目コード<%--품목코드--%> <i class="mdi mdi-menu-down"></i></label>
							<div class="search-field">
								<button type="button" onclick="openItem()"><i class="mdi mdi-magnify"></i></button>
								<input type="text" id="itemCode" placeholder="品目コード<%--품목코드--%>" oninput="itemId = null">
								<button type="button" class="clear-btn" onclick="clearItem()"><i class="mdi mdi-close"></i></button>
							</div>
						</div>
						<div class="form-row">
							<label>進行状態<%--진행상태--%></label>
							<div class="checks">
								<label><input type="checkbox" id="progressAll" checked> 全体<%--전체--%></label>
								<span class="check-split"></span>
								<label><input type="checkbox" id="progressUnconfirmed" value="UNCONFIRMED" checked> 未確認<%--미확인--%></label>
								<label><input type="checkbox" id="progressConfirmed" value="CONFIRMED" checked> 確認<%--확인--%></label>
							</div>
						</div>
					</div>
					<div class="sale-foot">
						<button type="button" class="btn-search" onclick="search()">検索(F8)<%--검색(F8)--%></button>
						<button type="button" class="foot-link" onclick="setToday()">今日<%--금일--%></button>
						<button type="button" class="foot-link" onclick="setYesterday()">前日<%--전일--%></button>
						<button type="button" class="foot-link" onclick="setThisWeek()">今週(~今日)<%--금주(~오늘)--%></button>
						<button type="button" class="foot-link" onclick="setLastWeek()">先週<%--전주--%></button>
						<button type="button" class="foot-link" onclick="setThisMonth()">今月(~今日)<%--금월(~오늘)--%></button>
						<button type="button" class="foot-link" onclick="setLastMonth()">前月<%--전월--%></button>
						<button type="button" class="foot-link" onclick="resetConditions()">再作成<%--다시 작성--%></button>
					</div>
					<p id="changeMessage" class="inq-message"></p>
				</div>
				<%-- 검색하면 조건 화면 대신 이 목록으로 넘어간다. 머리글은 세로 스크롤에 고정하고, 표는 가로로 넘긴다. --%>
				<%-- 検索すると条件画面の代わりにこの一覧へ移る。見出しは縦スクロールに固定し、表は横へ送る。 --%>
				<div id="resultPane" class="result-pane" hidden>
					<div class="result-top">
						<button type="button" class="result-back" onclick="closeResult()" title="照会条件<%--조회조건--%>"><i class="mdi mdi-arrow-left"></i></button>
						<h2>販売単価一括変更<%--판매단가일괄변경--%></h2>
						<span id="resultPeriod"></span>
					</div>
					<p id="resultMessage" class="result-message"></p>
					<div class="result-scroll" id="resultScroll">
						<table class="result-table">
							<thead>
								<tr>
									<th class="col-check"><input type="checkbox" id="checkAll" onclick="toggleAll(this)"></th>
									<th class="col-no"></th>
									<th>日付-No.<%--일자-No.--%></th>
									<th>取引先名<%--거래처명--%></th>
									<th>担当者名<%--담당자명--%></th>
									<th>出荷倉庫名<%--출하창고명--%></th>
									<th>取引類型名<%--거래유형명--%></th>
									<th class="num">為替レート<%--환율--%></th>
									<th>通貨<%--통화--%></th>
									<th>品目コード<%--품목코드--%></th>
									<th>品目名<%--품목명--%></th>
									<th>規格<%--규격--%></th>
									<th class="num">数量<%--수량--%></th>
									<th>単位<%--단위--%></th>
									<th class="num">単価<%--단가--%></th>
									<th class="num">供給価額<%--공급가액--%></th>
									<th class="num">付加税<%--부가세--%></th>
									<th>初回作成日<%--최초작성일자--%></th>
									<th>最終修正日<%--최종수정일자--%></th>
								</tr>
							</thead>
							<tbody id="resultBody"></tbody>
						</table>
					</div>
					<div class="result-foot">
						<button type="button" class="btn-search" id="savePrice" onclick="savePrices()">保存(F8)<%--저장(F8)--%></button>
					</div>
				</div>
			</main>
		</div>
	</div>

	<my:lookupModal />

	<div class="modal-overlay" id="choiceOverlay">
		<div class="lookup-card choice-card">
			<div class="lookup-head">
				<h3 id="choiceTitle"></h3>
				<button type="button" class="modal-close" onclick="closeChoice()"><i class="mdi mdi-close"></i></button>
			</div>
			<div id="choiceBody" class="choice-body"></div>
		</div>
	</div>

	<script>
		<%-- 조회는 /change-price/lines, 고친 단가 저장은 /change-price/prices, 환율변경은 /change-price/rate를 부른다. --%>
		<%-- 照会は /change-price/lines、直した単価の保存は /change-price/prices、為替変更は /change-price/rate を呼ぶ。 --%>
		var ctx = '${pageContext.request.contextPath}';
		var defaultFrom = '${fromDate}';
		var defaultTo = '${toDate}';
		var warehouseId = null;
		var partnerId = null;
		var itemId = null;
		var transactionType = '';
		var lines = [];
		var PRESETS = [
			{ code : 'THIS_MONTH', name : '今月(~今日)' }, // 금월(~오늘)
			{ code : 'TODAY', name : '今日' }, // 금일
			{ code : 'YESTERDAY', name : '前日' }, // 전일
			{ code : 'THIS_WEEK', name : '今週(~今日)' }, // 금주(~오늘)
			{ code : 'LAST_WEEK', name : '先週' }, // 전주
			{ code : 'LAST_MONTH', name : '前月' } // 전월
		];

		document.getElementById('modeChecks').addEventListener('change', applyCurrencyLock);

		document.getElementById('progressAll').addEventListener('change', function() {
			document.getElementById('progressUnconfirmed').checked = this.checked;
			document.getElementById('progressConfirmed').checked = this.checked;
		});
		document.getElementById('progressUnconfirmed').addEventListener('change', onProgressDetail);
		document.getElementById('progressConfirmed').addEventListener('change', onProgressDetail);
		<%-- 조건 화면의 F8은 검색, 목록 화면의 F8은 단가 저장이다. --%>
		<%-- 条件画面の F8 は検索、一覧画面の F8 は単価保存である。 --%>
		document.addEventListener('keydown', function(event) {
			if (event.key !== 'F8')
				return;
			event.preventDefault();
			if (document.getElementById('resultPane').hidden)
				search();
			else
				savePrices();
		});

		<%-- 환율변경이면 외자로 고정하고 내외자 라디오를 잠근다. 단가변경으로 돌아오면 푼다. --%>
		<%-- 為替変更なら外貨に固定し内外貨ラジオを鎖す。単価変更へ戻ると外す。 --%>
		function applyCurrencyLock() {
			var rate = document.querySelector('input[name="changeMode"][value="RATE"]').checked;
			var box = document.getElementById('currencyChecks');
			if (rate)
				document.querySelector('input[name="currencyScope"][value="FOREIGN"]').checked = true;
			box.classList.toggle('locked', rate);
			var radios = box.querySelectorAll('input');
			for (var i = 0; i < radios.length; i++)
				radios[i].disabled = rate;
		}

		function onProgressDetail() {
			var unconfirmed = document.getElementById('progressUnconfirmed').checked;
			var confirmed = document.getElementById('progressConfirmed').checked;
			document.getElementById('progressAll').checked = unconfirmed && confirmed;
		}

		function search() {
			return searchLines();
		}

		function searchLines() {
			var fromDate = readIso('from');
			var toDate = readIso('to');
			if (!fromDate || !toDate) {
				showMessage('基準日付を入力してください。'); // 기준일자를 입력하세요.
				closeResult();
				return;
			}
			if (fromDate > toDate) {
				showMessage('開始日が終了日より後です。'); // 시작일이 종료일보다 뒤입니다.
				clearGrid();
				closeResult();
				return;
			}
			if (!progressReady()) {
				showMessage('進行状態を選択してください。'); // 진행상태를 선택하세요.
				closeResult();
				return;
			}
			return fetch(ctx + '/sales/sale/change-price/lines?' + queryString(), { headers : { 'Accept' : 'application/json' } })
					.then(function(res) {
						return res.json().then(function(body) {
							return { ok : res.ok, body : body || {} };
						});
					}).then(function(result) {
						if (!result.ok) {
							showMessage(result.body.message || '照会できませんでした。'); // 조회하지 못했습니다.
							clearGrid();
							closeResult();
							return false;
						}
						lines = result.body.lines || [];
						showMessage('');
						showResult(lines, result.body.truncated);
						return true;
					}).catch(function() {
						showMessage('照会できませんでした。'); // 조회하지 못했습니다.
						closeResult();
						return false;
					});
		}

		function queryString() {
			var parts = [
				'fromDate=' + encodeURIComponent(readIso('from')),
				'toDate=' + encodeURIComponent(readIso('to')),
				'currencyScope=' + encodeURIComponent(checkedValue('currencyScope'))
			];
			if (transactionType)
				parts.push('transactionType=' + encodeURIComponent(transactionType));
			if (warehouseId)
				parts.push('warehouseId=' + encodeURIComponent(warehouseId));
			if (partnerId)
				parts.push('partnerId=' + encodeURIComponent(partnerId));
			if (itemId)
				parts.push('itemId=' + encodeURIComponent(itemId));
			progressValues().forEach(function(status) {
				parts.push('progressStatuses=' + encodeURIComponent(status));
			});
			return parts.join('&');
		}

		function progressReady() {
			return document.getElementById('progressAll').checked
					|| document.getElementById('progressUnconfirmed').checked
					|| document.getElementById('progressConfirmed').checked;
		}

		function progressValues() {
			if (document.getElementById('progressAll').checked)
				return [];
			var values = [];
			if (document.getElementById('progressUnconfirmed').checked)
				values.push('UNCONFIRMED');
			if (document.getElementById('progressConfirmed').checked)
				values.push('CONFIRMED');
			return values.length >= 2 ? [] : values;
		}

		function clearGrid() {
			lines = [];
			var body = document.getElementById('resultBody');
			if (body)
				body.innerHTML = '';
		}

		<%-- 조건 화면을 숨기고 판매 목록으로 넘어간다. --%>
		<%-- 条件画面を隠し販売一覧へ移る。 --%>
		function showResult(rows, truncated) {
			document.getElementById('resultPeriod').textContent = slashDate(readIso('from')) + ' ~ ' + slashDate(readIso('to'));
			var note = '';
			if (truncated)
				note = '1,000件を超えるため先頭1,000件だけ表示します。'; // 1,000건을 넘으면 앞 1,000건만 표시합니다.
			else if (!rows || !rows.length)
				note = '照会された販売がありません。'; // 조회된 판매가 없습니다.
			showResultNote(note, !!note);
			document.getElementById('checkAll').checked = false;
			document.getElementById('resultBody').innerHTML = buildRows(rows || []);
			document.getElementById('searchPane').hidden = true;
			document.getElementById('resultPane').hidden = false;
			var scroller = document.getElementById('resultScroll');
			scroller.scrollTop = 0;
			scroller.scrollLeft = 0;
		}

		function closeResult() {
			document.getElementById('resultPane').hidden = true;
			document.getElementById('searchPane').hidden = false;
		}

		<%-- 체크한 행만 단가를 고친다. 선택을 풀면 입력값을 원래 단가로 되돌리고 잠근다. --%>
		<%-- チェックした行だけ単価を直す。選択を外すと入力値を元の単価へ戻し鎖す。 --%>
		function toggleAll(box) {
			var checks = document.querySelectorAll('#resultBody .row-check');
			for (var i = 0; i < checks.length; i++) {
				checks[i].checked = box.checked;
				syncPriceLock(checks[i].closest('tr'));
			}
		}

		function syncPriceLock(row) {
			if (!row)
				return;
			var check = row.querySelector('.row-check');
			var input = row.querySelector('.price-input');
			if (!check || !input)
				return;
			input.disabled = !check.checked;
			if (!check.checked)
				input.value = input.getAttribute('data-origin') || '';
		}

		document.getElementById('resultBody').addEventListener('change', function(event) {
			var check = event.target.closest ? event.target.closest('.row-check') : null;
			if (!check)
				return;
			syncPriceLock(check.closest('tr'));
			var checks = document.querySelectorAll('#resultBody .row-check');
			var all = checks.length > 0;
			for (var i = 0; i < checks.length; i++) {
				if (!checks[i].checked)
					all = false;
			}
			document.getElementById('checkAll').checked = all;
		});

		function slashDate(value) {
			return value ? String(value).replace(/-/g, '/') : '';
		}

		function buildRows(rows) {
			var sorted = rows.slice().sort(function(a, b) {
				return String(a.saleDate || '').localeCompare(String(b.saleDate || ''))
						|| (Number(a.saleId) - Number(b.saleId))
						|| (Number(a.lineNo) - Number(b.lineNo));
			});
			if (!sorted.length)
				return '<tr><td colspan="19" class="result-empty">照会された販売がありません。<%--조회된 판매가 없습니다.--%></td></tr>';
			return sorted.map(function(line, index) {
				return '<tr>'
						+ '<td class="col-check"><input type="checkbox" class="row-check" value="' + esc(line.saleItemId) + '"></td>'
						+ '<td class="col-no"><span class="row-badge">' + (index + 1) + '</span></td>'
						+ dateNoCell(line)
						+ textCell(line.partnerName)
						+ textCell(line.managerName)
						+ textCell(line.warehouseName)
						+ textCell(line.transactionName)
						+ numCell(line.exchangeRate)
						+ textCell(line.currencyScopeName)
						+ textCell(line.itemCode)
						+ textCell(line.itemName)
						+ textCell(line.spec)
						+ numCell(line.quantity)
						+ textCell(line.unitName)
						+ priceCell(line)
						+ numCell(line.supplyAmount)
						+ numCell(line.vatAmount)
						+ textCell(line.createdDate)
						+ textCell(line.updatedDate)
						+ '</tr>';
			}).join('');
		}

		function dateNoCell(line) {
			var text = String(line.dateNo || '');
			var cut = text.lastIndexOf('-');
			var datePart = cut < 0 ? text : text.slice(0, cut);
			var seq = cut < 0 ? '' : text.slice(cut + 1);
			var week = weekName(line.saleDate);
			return '<td class="date-cell">' + esc(datePart)
					+ (week ? '<br>(' + esc(week) + ')' : '')
					+ (seq ? '<br>-' + esc(seq) : '') + '</td>';
		}

		function weekName(iso) {
			if (!iso)
				return '';
			var parts = String(iso).split('-');
			if (parts.length < 3)
				return '';
			var date = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
			if (isNaN(date.getTime()))
				return '';
			return ['日', '月', '火', '水', '木', '金', '土'][date.getDay()]; // 일 월 화 수 목 금 토
		}

		<%-- 표에서 고칠 수 있는 칸은 단가뿐이다. 행을 체크하기 전에는 잠겨 있다. --%>
		<%-- 表で直せる枠は単価だけである。行をチェックする前は鎖してある。 --%>
		function priceCell(line) {
			var value = priceText(line.unitPrice);
			return '<td class="num"><input type="text" class="price-input" inputmode="decimal" disabled data-id="'
					+ esc(line.saleItemId) + '" data-origin="' + esc(value) + '" value="' + esc(value) + '"></td>';
		}

		function priceText(value) {
			if (value === null || value === undefined || value === '')
				return '';
			var number = Number(value);
			return isNaN(number) ? '' : String(number);
		}

		<%-- 고친 단가만 저장한다. 공급가액과 부가세는 서버가 수량과 거래유형으로 다시 계산한다. --%>
		<%-- 直した単価だけ保存する。供給価額と付加税はサーバーが数量と取引類型で計算し直す。 --%>
		function savePrices() {
			var button = document.getElementById('savePrice');
			if (button.disabled)
				return;
			var rows = changedPrices();
			if (!rows)
				return;
			if (!rows.length) {
				showResultNote('変更された単価がありません。', true); // 변경된 단가가 없습니다.
				return;
			}
			button.disabled = true;
			var body = rows.map(function(row) {
				return 'saleItemIds=' + encodeURIComponent(row.id) + '&unitPrices=' + encodeURIComponent(row.price);
			}).join('&');
			fetch(ctx + '/sales/sale/change-price/prices', {
				method : 'POST',
				headers : {
					'Content-Type' : 'application/x-www-form-urlencoded;charset=UTF-8',
					'Accept' : 'application/json'
				},
				body : body
			}).then(function(res) {
				return res.json().then(function(payload) {
					return { ok : res.ok, body : payload || {} };
				});
			}).then(function(result) {
				button.disabled = false;
				if (!result.ok) {
					showResultNote(result.body.message || '単価を保存できませんでした。', true); // 단가를 저장하지 못했습니다.
					return;
				}
				var saved = result.body;
				var note = '単価を保存しました。伝票 ' + (saved.changedSlips || 0) + '件、明細 ' + (saved.changedLines || 0) + '件。'; // 단가를 저장했습니다.
				if (saved.failedSlips)
					note += '失敗 ' + saved.failedSlips + '件。'; // 실패
				return searchLines().then(function(refreshed) {
					if (refreshed)
						showResultNote(note, false);
				});
			}).catch(function() {
				button.disabled = false;
				showResultNote('単価を保存できませんでした。', true); // 단가를 저장하지 못했습니다.
			});
		}

		function changedPrices() {
			var inputs = document.querySelectorAll('#resultBody .price-input');
			var rows = [];
			var selected = 0;
			for (var i = 0; i < inputs.length; i++) {
				var input = inputs[i];
				if (input.disabled)
					continue;
				selected++;
				var text = String(input.value || '').replace(/,/g, '').trim();
				var number = Number(text);
				if (!text || isNaN(number) || number < 0) {
					showResultNote('単価が正しくありません。', true); // 단가가 올바르지 않습니다.
					input.focus();
					return null;
				}
				var origin = Number(input.getAttribute('data-origin'));
				if (number !== origin)
					rows.push({ id : input.getAttribute('data-id'), price : text });
			}
			if (!selected) {
				showResultNote('変更する行を選択してください。', true); // 수정할 행을 선택하세요.
				return null;
			}
			return rows;
		}

		function showResultNote(text, error) {
			var note = document.getElementById('resultMessage');
			note.textContent = text || '';
			note.classList.toggle('is-error', !!error);
		}

		function textCell(value) {
			return '<td>' + esc(value || '') + '</td>';
		}

		function numCell(value) {
			return '<td class="num">' + money(value) + '</td>';
		}

		function money(value) {
			if (value === null || value === undefined || value === '')
				return '';
			var number = Number(value);
			if (isNaN(number))
				return '';
			return number.toLocaleString('ko-KR', { maximumFractionDigits : 4 });
		}

		function esc(value) {
			return String(value == null ? '' : value).replace(/[&<>"']/g, function(ch) {
				return { '&' : '&amp;', '<' : '&lt;', '>' : '&gt;', '"' : '&quot;', "'" : '&#39;' }[ch];
			});
		}

		function checkedValue(name) {
			var input = document.querySelector('input[name="' + name + '"]:checked');
			return input ? input.value : '';
		}

		function openPartner() {
			CommonLookup.open('partner', function(row) {
				partnerId = row.businessPartnerId;
				document.getElementById('partnerName').value = row.businessPartnerName || '';
			});
		}
		function openWarehouse() {
			CommonLookup.open('warehouse', function(row) {
				warehouseId = row.warehousePk;
				document.getElementById('warehouseName').value = row.warehouseName || '';
			});
		}
		function openItem() {
			CommonLookup.open('item', function(rows) {
				var row = rows && rows.length ? rows[0] : null;
				if (!row)
					return;
				itemId = row.itemPk;
				document.getElementById('itemCode').value = row.itemCode || '';
			});
		}
		function clearPartner() { partnerId = null; document.getElementById('partnerName').value = ''; }
		function clearWarehouse() { warehouseId = null; document.getElementById('warehouseName').value = ''; }
		function clearItem() { itemId = null; document.getElementById('itemCode').value = ''; }

		function openTransaction() {
			openChoice('取引類型', [ // 거래유형
				{ code : '', name : '全体' }, // 전체
				{ code : 'VAT', name : '付加税率適用' }, // 부가세율 적용
				{ code : 'NO_VAT', name : '付加税率不適用' } // 부가세율 미적용
			], function(choice) {
				transactionType = choice.code;
				document.getElementById('transactionName').value = choice.code ? choice.name : '';
			});
		}
		function clearTransaction() {
			transactionType = '';
			document.getElementById('transactionName').value = '';
		}

		function setProgress(code) {
			var all = code === 'ALL';
			document.getElementById('progressAll').checked = all;
			document.getElementById('progressUnconfirmed').checked = all || code === 'UNCONFIRMED';
			document.getElementById('progressConfirmed').checked = all || code === 'CONFIRMED';
		}

		function openChoice(title, choices, onSelect) {
			document.getElementById('choiceTitle').textContent = title;
			document.getElementById('choiceBody').innerHTML = choices.map(function(choice, index) {
				return '<button type="button" data-index="' + index + '">' + choice.name + '</button>';
			}).join('');
			document.getElementById('choiceBody').onclick = function(event) {
				var button = event.target.closest('button');
				if (!button)
					return;
				onSelect(choices[Number(button.getAttribute('data-index'))]);
				closeChoice();
			};
			document.getElementById('choiceOverlay').classList.add('active');
		}
		function closeChoice() {
			document.getElementById('choiceOverlay').classList.remove('active');
		}

		function buildDateSelects() {
			var preset = document.getElementById('datePreset');
			preset.innerHTML = '<option value=""></option>' + PRESETS.map(function(item) {
				return '<option value="' + item.code + '">' + item.name + '</option>';
			}).join('');
			var yearNow = today().getFullYear();
			['from', 'to'].forEach(function(prefix) {
				fillNumberSelect(prefix + 'Year', yearNow - 5, yearNow + 1);
				fillNumberSelect(prefix + 'Month', 1, 12);
				fillNumberSelect(prefix + 'Day', 1, 31);
			});
		}

		function fillNumberSelect(id, from, to) {
			var html = '';
			for (var n = from; n <= to; n++)
				html += '<option value="' + n + '">' + pad2(n) + '</option>';
			document.getElementById(id).innerHTML = html;
		}

		function applyPreset() {
			var code = document.getElementById('datePreset').value;
			if (!code)
				return;
			if (code === 'TODAY')
				setToday();
			else if (code === 'YESTERDAY')
				setYesterday();
			else if (code === 'THIS_WEEK')
				setThisWeek();
			else if (code === 'LAST_WEEK')
				setLastWeek();
			else if (code === 'LAST_MONTH')
				setLastMonth();
			else
				setThisMonth();
		}

		<%-- 금일, 전일, 금주, 전주, 금월, 전월은 기간을 넣은 뒤 바로 검색한다. 화면을 열 때와 다시 작성은 조회하지 않는다. --%>
		<%-- 今日、前日、今週、先週、今月、前月は期間を入れたあとすぐ検索する。画面を開くときと再作成は照会しない。 --%>
		function setToday() { var day = today(); setRange(day, day, 'TODAY'); search(); }
		function setYesterday() {
			var day = today();
			day.setDate(day.getDate() - 1);
			setRange(day, day, 'YESTERDAY');
			search();
		}
		function setThisWeek() {
			var end = today();
			setRange(mondayOf(end), end, 'THIS_WEEK');
			search();
		}
		function setLastWeek() {
			var start = mondayOf(today());
			start.setDate(start.getDate() - 7);
			var end = new Date(start.getTime());
			end.setDate(end.getDate() + 6);
			setRange(start, end, 'LAST_WEEK');
			search();
		}
		function setThisMonth() {
			var end = today();
			setRange(new Date(end.getFullYear(), end.getMonth(), 1), end, 'THIS_MONTH');
			search();
		}
		function setLastMonth() {
			var now = today();
			setRange(new Date(now.getFullYear(), now.getMonth() - 1, 1), new Date(now.getFullYear(), now.getMonth(), 0), 'LAST_MONTH');
			search();
		}

		function mondayOf(date) {
			var day = new Date(date.getTime());
			var offset = day.getDay() === 0 ? 6 : day.getDay() - 1;
			day.setDate(day.getDate() - offset);
			return day;
		}
		function today() {
			var now = new Date();
			return new Date(now.getFullYear(), now.getMonth(), now.getDate());
		}
		function setRange(from, to, preset) {
			writeDate('from', from);
			writeDate('to', to);
			if (preset)
				document.getElementById('datePreset').value = preset;
		}
		function writeDate(prefix, date) {
			document.getElementById(prefix + 'Year').value = String(date.getFullYear());
			document.getElementById(prefix + 'Month').value = String(date.getMonth() + 1);
			clampDays(prefix);
			document.getElementById(prefix + 'Day').value = String(date.getDate());
		}
		function onDatePart(prefix) {
			clampDays(prefix);
			document.getElementById('datePreset').value = '';
		}
		function clampDays(prefix) {
			var year = Number(document.getElementById(prefix + 'Year').value);
			var month = Number(document.getElementById(prefix + 'Month').value);
			var dayBox = document.getElementById(prefix + 'Day');
			var kept = Number(dayBox.value);
			var last = new Date(year, month, 0).getDate();
			fillNumberSelect(prefix + 'Day', 1, last);
			dayBox.value = String(Math.min(kept || 1, last));
		}
		function readIso(prefix) {
			var year = document.getElementById(prefix + 'Year').value;
			var month = document.getElementById(prefix + 'Month').value;
			var day = document.getElementById(prefix + 'Day').value;
			if (!year || !month || !day)
				return '';
			return year + '-' + pad2(month) + '-' + pad2(day);
		}
		function openCalendar() {
			var picker = document.getElementById('calendarPick');
			picker.value = readIso('to');
			if (picker.showPicker)
				picker.showPicker();
			else
				picker.focus();
		}
		document.getElementById('calendarPick').addEventListener('change', function() {
			if (!this.value)
				return;
			var parts = this.value.split('-');
			writeDate('to', new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2])));
			document.getElementById('datePreset').value = '';
		});

		<%-- 다시 작성은 조건을 처음 값으로 되돌리고 목록을 닫는다. 조회하지 않는다. --%>
		<%-- 再作成は条件を初期値へ戻し一覧を閉じる。照会しない。 --%>
		function resetConditions() {
			document.querySelector('input[name="changeMode"][value="PRICE"]').checked = true;
			document.querySelector('input[name="currencyScope"][value="DOMESTIC"]').checked = true;
			applyCurrencyLock();
			setProgress('ALL');
			clearTransaction();
			clearWarehouse();
			clearPartner();
			clearItem();
			var end = today();
			setRange(new Date(end.getFullYear(), end.getMonth(), 1), end, 'THIS_MONTH');
			clearGrid();
			closeResult();
			showMessage('');
		}

		function pad2(value) {
			return ('0' + value).slice(-2);
		}
		function showMessage(text) {
			document.getElementById('changeMessage').textContent = text || '';
		}

		applyCurrencyLock();
		buildDateSelects();
		var openDay = today();
		setRange(new Date(openDay.getFullYear(), openDay.getMonth(), 1), openDay, 'THIS_MONTH');
		if (defaultFrom && defaultTo) {
			var fromParts = defaultFrom.split('-');
			var toParts = defaultTo.split('-');
			writeDate('from', new Date(Number(fromParts[0]), Number(fromParts[1]) - 1, Number(fromParts[2])));
			writeDate('to', new Date(Number(toParts[0]), Number(toParts[1]) - 1, Number(toParts[2])));
			document.getElementById('datePreset').value = 'THIS_MONTH';
		}
	</script>
	<style>
		.list-wrap { background: #fff; border: 1px solid #e6ebf2; border-radius: 8px; overflow: hidden; }
		.price-form { display: flex; flex-direction: column; }
		.form-row { display: grid; grid-template-columns: 120px minmax(0, 1fr); align-items: center; gap: 12px; padding: 9px 18px; border-bottom: 1px solid #eef2f6; }
		.form-row > label { font-size: 13px; font-weight: 700; color: #3e5470; }
		.mode-row { background: #f4f7ff; }
		.link-label { color: #2f6bff; cursor: pointer; display: inline-flex; align-items: center; }
		.link-label i { font-size: 16px; }
		.checks { display: flex; flex-wrap: wrap; align-items: center; gap: 8px 18px; font-size: 13px; color: #334155; }
		.checks label { display: inline-flex; align-items: center; gap: 6px; }
		.checks.locked { color: #94a3b8; }
		.checks.locked input { cursor: not-allowed; }
		.check-split { width: 1px; height: 14px; background: #d5deea; }
		.date-line { display: flex; flex-wrap: wrap; align-items: center; gap: 4px; }
		.date-line select, .search-field input {
			border: 1px solid #d7dee8; border-radius: 4px; background: #fff; color: #334155;
			height: 32px; padding: 0 8px; font-size: 13px; outline: none;
		}
		.date-line select:focus, .search-field input:focus { border-color: #2f6bff; }
		#datePreset { min-width: 118px; margin-right: 6px; }
		.tilde { color: #64748b; padding: 0 4px; }
		.cal-btn { border: 1px solid #d7dee8; background: #fff; color: #2f6bff; width: 32px; height: 32px; border-radius: 4px; cursor: pointer; }
		.cal-native { position: absolute; width: 1px; height: 1px; opacity: 0; pointer-events: none; }
		.search-field { display: flex; align-items: center; gap: 4px; width: min(640px, 100%); }
		.search-field input { flex: 1; min-width: 0; }
		.search-field button, .clear-btn {
			border: none; background: transparent; color: #94a3b8; width: 28px; height: 32px; cursor: pointer; flex: 0 0 auto;
		}
		.search-field button:hover, .clear-btn:hover { color: #2f6bff; }
		.sale-foot { display: flex; flex-wrap: wrap; align-items: center; gap: 4px 8px; padding: 12px 16px; border-top: 1px solid #eef2f6; }
		.btn-search { background: #2f6bff; color: #fff; border: none; border-radius: 6px; font-weight: 700; font-size: 13px; padding: 7px 14px; cursor: pointer; }
		.btn-search:hover { background: #1d4ed8; }
		.foot-link { border: none; background: transparent; color: #5b6b82; font-size: 13px; padding: 6px 4px; cursor: pointer; }
		.foot-link:hover { color: #2f6bff; }
		.inq-message { min-height: 20px; margin: 0 18px 8px; color: #b91c1c; font-size: 13px; }
		.result-pane { display: flex; flex-direction: column; background: #fff; border: 1px solid #e6ebf2; border-radius: 8px; min-height: calc(100vh - 120px); }
		.result-pane[hidden] { display: none !important; }
		.result-top { display: flex; align-items: center; gap: 10px; padding: 14px 16px 4px; }
		.result-top h2 { margin: 0; font-size: 18px; font-weight: 800; color: #0B1026; }
		.result-back { border: none; background: transparent; color: #334155; width: 32px; height: 32px; cursor: pointer; font-size: 20px; }
		#resultPeriod { margin-left: auto; font-size: 13px; color: #334155; }
		.result-message { min-height: 18px; margin: 0 16px 8px; color: #334155; font-size: 13px; }
		.result-message.is-error { color: #b91c1c; }
		.result-foot { padding: 12px 16px; border-top: 1px solid #e6ebf2; }
		.price-input {
			width: 110px; height: 28px; border: 1px solid #d7dee8; border-radius: 4px; background: #fff;
			text-align: right; padding: 0 8px; font-size: 12px; color: #0B1026;
		}
		.price-input:focus { border-color: #2f6bff; outline: none; }
		.price-input:disabled { background: #f8fafc; }
		.result-scroll { overflow: auto; max-height: calc(100vh - 190px); border-top: 1px solid #e6ebf2; }
		.result-table { border-collapse: separate; border-spacing: 0; width: max-content; min-width: 1760px; }
		.result-table th, .result-table td {
			border-bottom: 1px solid #e6ebf2; border-right: 1px solid #f1f5f9; padding: 8px 12px;
			font-size: 12px; white-space: nowrap; background: #fff; text-align: center; vertical-align: middle;
		}
		.result-table th { position: sticky; top: 0; z-index: 2; background: #f4f7fb; font-weight: 700; color: #334155; }
		.result-table tbody tr:nth-child(even) td { background: #f7f8fb; }
		.result-table td.num, .result-table th.num { text-align: right; font-variant-numeric: tabular-nums; }
		.result-table .col-check, .result-table .col-no { text-align: center; }
		.date-cell { line-height: 1.35; }
		.row-badge {
			display: inline-flex; align-items: center; justify-content: center;
			width: 22px; height: 22px; border: 1px solid #cbd5e1; border-radius: 50%; font-size: 11px; color: #334155;
		}
		.result-empty { text-align: center; color: #64748b; padding: 28px; }
		.modal-overlay { display: none; position: fixed; inset: 0; background: rgba(11, 16, 38, .45); align-items: flex-start; justify-content: center; padding: 6vh 16px; z-index: 1300; overflow: auto; }
		.modal-overlay.active { display: flex; }
		.choice-card { width: min(420px, 96vw); }
		.choice-body { display: flex; flex-direction: column; padding: 8px; }
		.choice-body button { text-align: left; background: #fff; border: none; border-bottom: 1px solid #e2e8f0; padding: 12px 14px; font-weight: 700; cursor: pointer; }
		.choice-body button:hover { background: #f7faff; }
		.lookup-head { display: flex; align-items: center; gap: 12px; padding: 14px 16px; border-bottom: 1px solid #e2e8f0; }
		.lookup-head h3 { font-size: 1.05rem; font-weight: 800; color: #0B1026; margin-right: auto; }
		.modal-close { border: none; background: #f1f5f9; color: #64748b; width: 32px; height: 32px; border-radius: 50%; cursor: pointer; }
		@media (max-width: 900px) {
			.form-row { grid-template-columns: 96px minmax(0, 1fr); }
		}
	</style>
</body>
</html>
