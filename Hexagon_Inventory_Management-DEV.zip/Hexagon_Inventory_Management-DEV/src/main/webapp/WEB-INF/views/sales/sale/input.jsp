<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt"%>
<%@ taglib prefix="my" tagdir="/WEB-INF/tags"%>
<jsp:useBean id="today" class="java.util.Date" />
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>販売入力<%--판매입력--%> - ヘキサゴン ERP<%--헥사곤 ERP--%></title>
<link
	href="https://cdn.jsdelivr.net/npm/@mdi/font@7.2.96/css/materialdesignicons.min.css"
	rel="stylesheet">
</head>
<%-- embed=1은 판매조회가 이 화면을 모달에 넣을 때다. 사이드바와 제목은 조회 쪽 모달이 대신한다. --%>
<%-- embed=1は販売照会がこの画面をモーダルに入れるときである。サイドバーと題名は照会側のモーダルが代わりに出す。 --%>
<body class="${embed == '1' ? 'sale-embed' : ''}">
	<div class="erp-wrapper">
		<my:sideMenu />

		<div class="erp-main">
			<main class="erp-content">
				<c:if test="${embed != '1'}">
				<div class="page-title">
					<i class="mdi mdi-cart-plus"></i> 販売入力<%--판매입력--%>
				</div>
				</c:if>

				<form id="saleForm" onsubmit="return false;">
					<input type="hidden" name="header.saleId"
						value="${sale.header.saleId}"> <input type="hidden"
						name="header.voucherStatus" id="voucherStatus"
						value="${empty sale.header.voucherStatus ? '正常' : sale.header.voucherStatus}">
					<input type="hidden" name="after" id="afterSave" value="">

					<div class="list-wrap">
						<div class="sale-head">
							<div class="sale-field">
								<label>日付<%--일자--%></label> <input type="date" name="header.saleDt"
									value="<c:choose><c:when test="${not empty sale.header.saleDt}"><fmt:formatDate value="${sale.header.saleDt}" pattern="yyyy-MM-dd"/></c:when><c:otherwise><fmt:formatDate value="${today}" pattern="yyyy-MM-dd"/></c:otherwise></c:choose>">
							</div>
							<%-- 거래처, 담당자, 출하창고는 코드, 돋보기, 이름 순이다. 코드와 이름은 조회 결과만 채우고, 저장되는 값은 숨은 키다. --%>
							<%-- 取引先、担当者、出荷倉庫はコード、虫眼鏡、名前の順である。コードと名前は照会結果だけ入れ、保存される値は隠したキーである。 --%>
							<div class="sale-field">
								<label>取引先<%--거래처--%></label>
								<div class="sale-popup">
									<input type="hidden" name="header.businessPartnerId"
										id="businessPartnerId"
										value="${sale.header.businessPartnerId}">
									<input type="text" id="businessPartnerCode" class="header-code"
										value="${sale.header.businessPartnerCode}" placeholder="コード<%--코드--%>"
										oninput="clearPartnerId('code')"
										onkeydown="if(event.key==='Enter'){event.preventDefault();resolvePartner(event);}"
										onblur="resolvePartner(event)">
									<button type="button" class="popup-search-btn"
										onclick="openPartnerLookup()">
										<i class="mdi mdi-magnify"></i>
									</button>
									<input type="text" name="header.businessPartnerName"
										id="businessPartnerName"
										value="${sale.header.businessPartnerName}" placeholder="取引先<%--거래처--%>"
										oninput="clearPartnerId('name')"
										onkeydown="if(event.key==='Enter'){event.preventDefault();resolvePartner(event);}"
										onblur="resolvePartner(event)">
								</div>
							</div>
							<div class="sale-field">
								<label>担当者<%--담당자--%></label>
								<div class="sale-popup">
									<input type="hidden" name="header.managerId" id="managerId"
										value="${sale.header.managerId}">
									<input type="text" id="employeeCode" class="header-code"
										value="${sale.header.employeeCode}" placeholder="コード<%--코드--%>"
										oninput="clearManagerId('code')"
										onkeydown="if(event.key==='Enter'){event.preventDefault();resolveManager(event);}"
										onblur="resolveManager(event)">
									<button type="button" class="popup-search-btn"
										onclick="openManagerLookup()">
										<i class="mdi mdi-magnify"></i>
									</button>
									<input type="text" name="header.employeeName" id="employeeName"
										value="${sale.header.employeeName}" placeholder="担当者<%--담당자--%>"
										oninput="clearManagerId('name')"
										onkeydown="if(event.key==='Enter'){event.preventDefault();resolveManager(event);}"
										onblur="resolveManager(event)">
								</div>
							</div>
							<div class="sale-field">
								<label>出荷倉庫<%--출하창고--%></label>
								<div class="sale-popup">
									<input type="hidden" name="header.warehousePk" id="warehousePk"
										value="${sale.header.warehousePk}">
									<input type="text" id="warehouseCode" class="header-code"
										value="${sale.header.warehouseCode}" placeholder="コード<%--코드--%>"
										oninput="clearWarehouseId('code')"
										onkeydown="if(event.key==='Enter'){event.preventDefault();resolveWarehouse(event);}"
										onblur="resolveWarehouse(event)">
									<button type="button" class="popup-search-btn"
										onclick="openWarehouseLookup()">
										<i class="mdi mdi-magnify"></i>
									</button>
									<input type="text" name="header.warehouseName" id="warehouseName"
										value="${sale.header.warehouseName}" placeholder="出荷倉庫<%--출하창고--%>"
										oninput="clearWarehouseId('name')"
										onkeydown="if(event.key==='Enter'){event.preventDefault();resolveWarehouse(event);}"
										onblur="resolveWarehouse(event)">
								</div>
							</div>
							<div class="sale-field">
								<label>取引類型<%--거래유형--%></label> <select name="header.saleType">
									<option value="付加税率適用"
										${empty sale.header.saleType or sale.header.saleType == '付加税率適用' ? 'selected' : ''}>付加税率適用<%--부가세율 적용--%></option>
									<option value="付加税率不適用"
										${sale.header.saleType == '付加税率不適用' ? 'selected' : ''}>付加税率不適用<%--부가세율 미적용--%></option>
								</select>
							</div>
							<div class="sale-field">
								<label>通貨<%--통화--%></label>
								<div class="currency-pair">
									<select name="header.currencyId" id="currencySelect"
										onchange="onCurrencyChange(this)">
										<c:choose>
											<c:when test="${empty currencies}">
												<option value="" data-code="KR" data-rate="1">KR</option>
											</c:when>
											<c:otherwise>
												<c:forEach var="currency" items="${currencies}">
													<option value="${currency.currencyId}"
														data-code="${currency.currencyCode }"
														data-rate="${empty currency.exchangeRate ? 1 : currency.exchangeRate }"
														${sale.header.currencyId == currency.currencyId or (empty sale.header.currencyId and currency.currencyCode == 'KR') ? 'selected' : ''}>
														${currency.currencyCode == 'KR' ? 'KR' : currency.currencyName}</option>
												</c:forEach>
											</c:otherwise>
										</c:choose>
										<%-- 추가를 고르면 통화코드, 통화명, 환율을 등록하고 그 통화를 선택한다. 追加を選ぶと通貨コード、通貨名、為替レートを登録しその通貨を選択する。 --%>
										<option value="add">追加<%--추가--%></option>
									</select> <input type="text" name="header.exchangeRate"
										id="exchangeRate" inputmode="decimal"
										value="${empty sale.header.exchangeRate ? 1 : sale.header.exchangeRate }">
								</div>
							</div>
						</div>

						<div class="sale-buttons">
							<input type="text" id="gridFindKeyword" class="grid-find-input"
								placeholder="表で探す内容<%--표에서 찾을 내용--%>" style="display: none;"
								onkeydown="if(event.key==='Enter'){event.preventDefault();findInGrid();}">
							<button type="button" class="btn-flat-sm"
								onclick="openGridFind()">検索<%--찾기--%></button>
							<button type="button" class="btn-flat-sm" onclick="sortGrid()">並べ替え<%--정렬--%></button>
							<div class="save-split history-split">
								<button type="button" class="btn-flat-sm save-main"
									onclick="openHistory('sale')">取引履歴<%--거래내역보기--%></button>
								<button type="button" class="btn-flat-sm save-arrow"
									onclick="toggleHistoryMenu(event)">
									<i class="mdi mdi-chevron-down"></i>
								</button>
								<div id="historyMenu" class="save-menu history-menu">
									<button type="button" onclick="openHistory('order')">注文<%--주문--%></button>
									<button type="button" onclick="openHistory('quote')">見積<%--견적--%></button>
								</div>
							</div>
							<%-- 주문 버튼은 미판매 주문 품목을 바로 아래 표에 넣는다. 전표불러오기와 달리 조회 화면을 열지 않는다. --%>
							<%-- 注文ボタンは未販売の注文品目をすぐ下の表に入れる。伝票読込とは違い照会画面は開かない。 --%>
							<button type="button" class="btn-flat-sm" onclick="loadOrders()">注文<%--주문--%></button>
							<button type="button" class="btn-flat-sm"
								onclick="openHoldModal()">保留<%--보류--%></button>
							<button type="button" class="btn-flat-sm"
								onclick="openDiscountModal()">割引<%--할인--%></button>
							<button type="button" class="btn-flat-sm" onclick="loadStock()">在庫読込<%--재고불러오기--%></button>
							<button type="button" class="btn-flat-sm" onclick="verifyLines()">検証<%--검증--%></button>
							<button type="button" class="btn-flat-sm" onclick="showProfit()">利益計算<%--이익계산--%></button>
							<%-- type="button"이라 판매 폼을 저장하지 않는다. 누르면 종류 선택 모달만 연다. --%>
							<%-- type="button"なので販売フォームは保存しない。押すと種類選択モーダルだけ開く。 --%>
							<button type="button" class="btn-flat-sm" onclick="openSlipLoadChooser()">伝票読込<%--전표불러오기--%></button>
							<button type="button" class="btn-flat-sm" onclick="calcVat()">取引別付加税計算<%--거래별부가세계산--%></button>
						</div>

						<div class="list-table-wrap">
							<table class="list-table" id="saleGrid">
								<colgroup>
									<col style="width: 46px;">
									<col style="width: 14%;">
									<col style="width: 15%;">
									<col id="saleColSpec" style="width: 12%;">
									<col style="width: 9%;">
									<col style="width: 9%;">
									<col style="width: 11%;">
									<col style="width: 9%;">
									<col style="width: 10%;">
								</colgroup>
								<thead>
									<%-- 첫 칸은 행 선택 체크박스다. 품목 칸은 모두 입력할 수 있고, 고친 값은 판매 기록에만 저장한다. 先頭は行選択チェックボックスである。品目の欄はすべて入力でき、直した値は販売記録だけに保存する。 --%>
									<tr>
										<th></th>
										<th>品目コード<%--품목코드--%></th>
										<th>品目名<%--품목명--%></th>
										<%-- 전체수량, 출하창고수량은 처음 표에 없다. 재고불러오기를 누르면 규격과 수량 사이에 칸과 값이 함께 붙는다. 재고를 빼는 곳은 정상 저장이며 보류는 빼지 않는다. --%>
										<%-- 全体数量、出荷倉庫数量は最初の表にない。在庫読込を押すと規格と数量の間に列と値が一緒に付く。在庫を引くのは正常保存であり、保留は引かない。 --%>
										<th class="stock-anchor">規格<%--규격--%></th>
										<th class="col-num">数量<%--수량--%></th>
										<th class="col-num">単価<%--단가--%></th>
										<th class="col-num">供給価額<%--공급가액--%></th>
										<th class="col-num">付加税<%--부가세--%></th>
										<th class="col-num">合計<%--합계--%></th>
									</tr>
								</thead>
								<tbody>
									<c:choose>
										<c:when test="${empty sale.items}">
											<c:forEach begin="0" end="2" var="i">
												<tr>
													<td><input type="checkbox" class="line-check"></td>
													<td>
														<div class="line-code">
															<input type="hidden" class="line-item-pk"> <input
																type="text" class="line-item-code"
																oninput="clearItemPk(this)"
																onkeydown="if(event.key==='Enter'){event.preventDefault();resolveItem(this);}"
																onblur="resolveItem(this, event)">
															<button type="button" class="popup-search-btn"
																onclick="openItemLookup(this)">
																<i class="mdi mdi-magnify"></i>
															</button>
														</div>
													</td>
													<td><input type="text" class="line-item-name"
														oninput="ensureBlankRow()"></td>
													<td><input type="text" class="line-spec"
														oninput="ensureBlankRow()"></td>
													<td><input type="text" class="col-num line-qty"
														oninput="calcLine(this)"></td>
													<td><input type="text" class="col-num line-price"
														oninput="calcLine(this)"></td>
													<td><input type="text" class="col-num line-supply"
														oninput="sumFooter()"></td>
													<td><input type="text" class="col-num line-vat"
														oninput="sumFooter()"></td>
													<td><input type="text" class="col-num line-amt"
														oninput="sumFooter()"> <input type="hidden"
														class="line-discount" value="0"> <input
														type="hidden" class="line-src-type"> <input
														type="hidden" class="line-src-id"></td>
												</tr>
											</c:forEach>
										</c:when>
										<c:otherwise>
											<c:forEach var="line" items="${sale.items}" varStatus="st">
												<tr>
													<td><input type="checkbox" class="line-check"></td>
													<td>
														<div class="line-code">
															<input type="hidden" class="line-item-pk"
																value="${line.itemPk}"> <input type="text"
																class="line-item-code" value="${line.itemCode}"
																data-matched="${line.itemCode}"
																oninput="clearItemPk(this)"
																onkeydown="if(event.key==='Enter'){event.preventDefault();resolveItem(this);}"
																onblur="resolveItem(this, event)">
															<button type="button" class="popup-search-btn"
																onclick="openItemLookup(this)">
																<i class="mdi mdi-magnify"></i>
															</button>
														</div>
													</td>
													<td><input type="text" class="line-item-name"
														value="${line.itemNm}" oninput="ensureBlankRow()"></td>
													<td><input type="text" class="line-spec"
														value="${line.spec}" oninput="ensureBlankRow()"></td>
													<td><input type="text" class="col-num line-qty"
														value="${line.saleQty}" oninput="calcLine(this)"></td>
													<td><input type="text" class="col-num line-price"
														value="${line.unitPrice}" oninput="calcLine(this)"></td>
													<td><input type="text" class="col-num line-supply"
														value="${line.supplyAmt}" oninput="sumFooter()"></td>
													<td><input type="text" class="col-num line-vat"
														value="${line.vatAmt}" oninput="sumFooter()"></td>
													<td><input type="text" class="col-num line-amt"
														value="${line.lineAmt}" oninput="sumFooter()"> <input
														type="hidden" class="line-discount"
														value="${empty line.discountAmt ? 0 : line.discountAmt}">
														<input type="hidden" class="line-src-type"
														value="${line.slipLink.srcType}"> <input
														type="hidden" class="line-src-id"
														value="${line.slipLink.srcItemId}"></td>
												</tr>
											</c:forEach>
										</c:otherwise>
									</c:choose>
								</tbody>
								<tfoot>
									<tr>
										<td id="footLead" colspan="4"></td>
										<%-- 수량은 품목 키가 있는 행의 수량 합계다. 数量は品目キーがある行の数量合計である。 --%>
										<td class="col-num" id="footQty">0</td>
										<td id="footGap"></td>
										<td class="col-num" id="footSupply">0</td>
										<td class="col-num" id="footVat">0</td>
										<td class="col-num" id="footTotal">0</td>
									</tr>
								</tfoot>
							</table>
						</div>

						<div class="sale-foot">
							<div class="save-split">
								<button type="submit" class="btn-primary-sm save-main"
									onclick="return prepareSubmit('正常', '')">保存<%--저장--%></button>
								<button type="button" class="btn-primary-sm save-arrow"
									onclick="toggleSaveMenu(event)">
									<i class="mdi mdi-chevron-up"></i>
								</button>
								<div id="saveMenu" class="save-menu">
									<button type="submit" onclick="return prepareSubmit('正常', '')">保存<%--저장--%></button>
									<button type="submit" onclick="return prepareSubmit('保留', '')">保留<%--보류--%></button>
								</div>
							</div>
							<button type="submit" class="btn-flat-sm"
								onclick="return prepareSubmit('正常', 'statement')">保存/伝票<%--저장/전표--%></button>
							<button type="button" class="btn-flat-sm" onclick="rewriteSale()">再作成<%--다시 작성--%></button>
							<a class="btn-flat-sm"
								href="${pageContext.request.contextPath}/sales/sale/inquiry"
								onclick="return goInquiry(event)">リスト<%--리스트--%></a>
						</div>
						<div id="saleResult" class="sale-result"></div>
					</div>
				</form>
			</main>
		</div>
	</div>

	<c:if test="${not empty message}">
		<div class="sale-result hold-message">${message}</div>
	</c:if>
	<my:lookupModal />

	<%-- 할인 등록 모달. 헤더는 판매입력 값을 읽기만 하고 고칠 수 없다. 가운데 적용은 이 표만 계산한다. 아래 적용은 판매 품목의 단가·공급가액·부가세에만 넣으며 품목 마스터는 수정하지 않는다. 수량과 금액은 정수로 표시한다. --%>
	<%-- 割引登録モーダル。ヘッダは販売入力の値を読むだけで直せない。中央の適用はこの表だけ計算する。下の適用は販売品目の単価・供給価額・付加税だけに入れ、品目マスタは修正しない。数量と金額は整数で表示する。 --%>
	<div class="modal-overlay" id="discountOverlay">
		<div class="discount-card">
			<div class="discount-titlebar">
				<span>割引登録<%--할인 등록--%></span>
				<button type="button" class="discount-close" onclick="closeDiscountModal()">
					<i class="mdi mdi-close"></i>
				</button>
			</div>
			<div class="discount-body">
				<h3>割引登録<%--할인 등록--%></h3>
				<%-- 헤더 칸은 readonly다. 판매입력에서 복사만 하고, 돋보기와 Fn은 두지 않는다. --%>
				<%-- ヘッダ欄はreadonlyである。販売入力から写すだけで、虫眼鏡とFnは置かない。 --%>
				<div class="discount-head">
					<label>取引先<%--거래처--%></label>
					<input type="text" id="discountPartnerCode" readonly>
					<input type="text" id="discountPartnerName" readonly>
					<label>倉庫<%--창고--%></label>
					<input type="text" id="discountWarehouseCode" readonly>
					<input type="text" id="discountWarehouseName" readonly>
					<label>外貨<%--외화--%></label>
					<input type="text" id="discountCurrency" readonly>
					<label>取引類型<%--거래유형--%></label>
					<input type="text" id="discountSaleType" readonly>
				</div>
				<div class="discount-tools">
					<div class="discount-apply">
						<label><input type="radio" name="discountApply" value="batch" checked onchange="onDiscountApplyMode()"> 一括変更<%--일괄변경--%></label>
						<label><input type="radio" name="discountApply" value="slip" onchange="onDiscountApplyMode()"> 品目別<%--품목별--%></label>
					</div>
					<select id="discountPriceKind">
						<option value="price">割引単価<%--할인단가--%></option>
						<option value="vat">割引単価(VAT込)<%--할인단가(vat포함)--%></option>
					</select>
					<button type="button" class="discount-direct">直接入力<%--직접입력--%></button>
					<input type="text" id="discountValue" inputmode="decimal">
					<button type="button" class="btn-flat-sm" onclick="applyDiscountAmount()">適用<%--적용--%></button>
				</div>
				<div class="discount-table-wrap">
					<table class="list-table discount-table">
						<colgroup>
							<col style="width: 3%">
							<col style="width: 3.5%">
							<col style="width: 8%">
							<col style="width: 13%">
							<col style="width: 6%">
							<col style="width: 8%">
							<col style="width: 8%">
							<col style="width: 9%">
							<col style="width: 8%">
							<col style="width: 7%">
							<col style="width: 9%">
							<col style="width: 8%">
							<col style="width: 9.5%">
						</colgroup>
						<thead>
							<tr>
								<th><input type="checkbox" id="discountCheckAll" checked onclick="toggleDiscountChecks(this)"></th>
								<th></th>
								<th>品目コード<%--품목코드--%></th>
								<th>品目名<%--품목명--%></th>
								<th class="col-num">数量<%--수량--%></th>
								<th class="col-num">基準単価(VAT込)<%--기준단가(vat포함)--%></th>
								<th class="col-num">基準単価<%--기준단가--%></th>
								<th class="col-num">基準ウォン供給価額<%--기준원화공급가액--%></th>
								<th class="col-num">割引単価(VAT込)<%--할인단가(vat포함)--%></th>
								<th class="col-num">割引単価<%--할인단가--%></th>
								<th class="col-num">割引ウォン供給価額<%--할인원화공급가액--%></th>
								<th class="col-num">単価<%--단가--%></th>
								<th class="col-num">ウォン供給価額<%--원화공급가액--%></th>
							</tr>
						</thead>
						<tbody id="discountBody"></tbody>
						<tfoot>
							<tr>
								<td colspan="4"></td>
								<td class="col-num" id="discountFootQty"></td>
								<td></td>
								<td></td>
								<td class="col-num" id="discountFootBase"></td>
								<td></td>
								<td></td>
								<td class="col-num" id="discountFootOff"></td>
								<td></td>
								<td class="col-num" id="discountFootKrw"></td>
							</tr>
						</tfoot>
					</table>
				</div>
			</div>
			<div class="discount-foot">
				<button type="button" class="btn-primary-sm" onclick="applyDiscountToSale()">適用(F8)<%--적용(F8)--%></button>
				<button type="button" class="btn-flat-sm" onclick="closeDiscountModal()">閉じる<%--닫기--%></button>
			</div>
		</div>
	</div>

	<div class="modal-overlay" id="currencyOverlay">
		<div class="lookup-card currency-card">
			<div class="lookup-head">
				<h3>通貨追加<%--통화 추가--%></h3>
				<button type="button" class="modal-close"
					onclick="closeCurrencyModal()">
					<i class="mdi mdi-close"></i>
				</button>
			</div>
			<div class="currency-form">
				<label>通貨コード<%--통화코드--%></label> <input type="text" id="newCurrencyCode"
					maxlength="10"> <label>通貨名<%--통화명--%></label> <input type="text"
					id="newCurrencyName" maxlength="50"> <label>為替レート<%--환율--%></label> <input
					type="text" id="newCurrencyRate" inputmode="decimal">
				<p id="currencyError" class="currency-error"></p>
			</div>
			<div class="lookup-foot">
				<button type="button" class="btn-primary-sm"
					onclick="saveCurrency()">保存<%--저장--%></button>
				<button type="button" class="btn-flat-sm"
					onclick="closeCurrencyModal()">閉じる<%--닫기--%></button>
			</div>
		</div>
	</div>

	<div class="modal-overlay" id="holdOverlay">
		<div class="lookup-card hold-card">
			<div class="lookup-head">
				<h3>保留照会<%--보류조회--%></h3>
				<button type="button" class="modal-close" onclick="closeHoldModal()">
					<i class="mdi mdi-close"></i>
				</button>
			</div>
			<p class="hold-note">保留伝票は最大5件まで保存され、読み込んだ伝票を保存すると販売記録に残り、保留一覧から外れます。<%--보류전표는 최대 5개까지만 저장되며, 불러온 전표를 저장으로 판매 기록에 남기면 보류 목록에서 빠집니다.--%></p>
			<div class="lookup-table-wrap">
				<table class="list-table">
					<thead>
						<tr>
							<th></th>
							<th>保留番号<%--보류번호--%></th>
							<th>取引先<%--거래처--%></th>
							<th>品目<%--품목--%></th>
							<th>金額<%--금액--%></th>
							<th>類型<%--유형--%></th>
							<th>倉庫<%--창고--%></th>
						</tr>
					</thead>
					<tbody id="holdBody"></tbody>
				</table>
			</div>
			<div class="lookup-foot">
				<button type="button" class="btn-primary-sm"
					onclick="deleteSelectedHolds()">選択削除<%--선택삭제--%></button>
				<button type="button" class="btn-flat-sm" onclick="closeHoldModal()">閉じる<%--닫기--%></button>
			</div>
		</div>
	</div>

	<div class="modal-overlay" id="slipListOverlay">
		<div class="lookup-card hold-card">
			<div class="lookup-head">
				<h3 id="slipListTitle">販売書<%--판매서--%></h3>
				<button type="button" class="modal-close" onclick="closeSlipList()">
					<i class="mdi mdi-close"></i>
				</button>
			</div>
			<p class="hold-note" id="slipListNote"></p>
			<div class="lookup-table-wrap">
				<table class="list-table">
					<thead>
						<tr>
							<th>日付<%--일자--%></th>
							<th>伝票<%--전표--%></th>
							<th>取引先<%--거래처--%></th>
							<th class="col-num">供給価額<%--공급가액--%></th>
							<th class="col-num">付加税<%--부가세--%></th>
							<th>状態<%--상태--%></th>
						</tr>
					</thead>
					<tbody id="slipListBody"></tbody>
				</table>
			</div>
			<div class="lookup-foot">
				<button type="button" class="btn-flat-sm"
					onclick="openSlipInquiry()">リスト<%--리스트--%></button>
				<button type="button" class="btn-flat-sm" onclick="closeSlipList()">閉じる<%--닫기--%></button>
			</div>
		</div>
	</div>

	<%-- 1단계. 평소엔 숨겨 두고, active 클래스가 붙으면 화면 가운데에 보인다. 버튼의 인자는 아래 주소표의 키다. --%>
	<%-- 1段目。普段は隠し、activeクラスが付くと画面の中央に見える。ボタンの引数は下のアドレステーブルのキーである。 --%>
	<div class="modal-overlay" id="slipLoadChooserOverlay">
		<div class="lookup-card slip-load-chooser">
			<div class="lookup-head">
				<h3>伝票読込<%--전표불러오기--%></h3>
				<button type="button" class="modal-close" onclick="closeSlipLoadChooser()">
					<i class="mdi mdi-close"></i>
				</button>
			</div>
			<div class="slip-load-choices">
				<button type="button" onclick="openSlipLoadInquiry('quote')">見積<%--견적--%></button>
				<button type="button" onclick="openSlipLoadInquiry('order')">注文<%--주문--%></button>
				<button type="button" onclick="openSlipLoadInquiry('shipOrder')">出荷指示書<%--출하지시서--%></button>
				<button type="button" onclick="openSlipLoadInquiry('ship')">出荷<%--출하--%></button>
			</div>
		</div>
	</div>

	<%-- 2단계. iframe은 이 페이지 안에 다른 주소를 그려 주는 창이다. src에 조회 주소를 넣으면 그 JSP가 여기 들어온다. --%>
	<%-- 2段目。iframeはこのページの中に別アドレスを描く窓である。srcに照会アドレスを入れるとそのJSPがここに入る。 --%>
	<div class="modal-overlay slip-inquiry-overlay" id="slipLoadOverlay">
		<div class="lookup-card slip-load-view">
			<div class="lookup-head">
				<h3 id="slipLoadTitle">見積書照会<%--견적서 조회--%></h3>
				<button type="button" class="modal-close" onclick="closeSlipLoadInquiry()">
					<i class="mdi mdi-close"></i>
				</button>
			</div>
			<iframe id="slipLoadFrame" class="slip-load-frame" title="伝票照会<%--전표 조회--%>"></iframe>
		</div>
	</div>

	<div class="modal-overlay slip-inquiry-overlay" id="slipInquiryOverlay">
		<div class="lookup-card hold-card">
			<div class="lookup-head">
				<h3 id="slipInquiryTitle">販売書照会<%--판매서 조회--%></h3>
				<button type="button" class="modal-close"
					onclick="closeSlipInquiry()">
					<i class="mdi mdi-close"></i>
				</button>
			</div>
			<div class="lookup-table-wrap">
				<table class="list-table">
					<thead>
						<tr>
							<th>日付<%--일자--%></th>
							<th>伝票<%--전표--%></th>
							<th>取引先<%--거래처--%></th>
							<th class="col-num">供給価額<%--공급가액--%></th>
							<th class="col-num">付加税<%--부가세--%></th>
							<th>状態<%--상태--%></th>
						</tr>
					</thead>
					<tbody id="slipInquiryBody"></tbody>
				</table>
			</div>
			<div class="lookup-foot">
				<button type="button" class="btn-flat-sm"
					onclick="closeSlipInquiry()">閉じる<%--닫기--%></button>
			</div>
		</div>
	</div>

	<script>
		// 코드나 이름을 고치면 조회 키를 지운다. 지금 치는 칸은 남기고, 반대 칸은 비워 코드와 이름이 어긋나지 않게 한다.
		// コードか名前を直すと照会キーを消す。今打っている欄は残し、反対の欄は空にしてコードと名前がずれないようにする。
		function clearPartnerId(from) {
			document.getElementById('businessPartnerId').value = '';
			document.getElementById('businessPartnerCode').dataset.matched = '';
			document.getElementById('businessPartnerName').dataset.matched = '';
			document.getElementById('businessPartnerName').dataset.code = '';
			if (from !== 'code')
				document.getElementById('businessPartnerCode').value = '';
			if (from !== 'name')
				document.getElementById('businessPartnerName').value = '';
		}
		function clearManagerId(from) {
			document.getElementById('managerId').value = '';
			document.getElementById('employeeCode').dataset.matched = '';
			document.getElementById('employeeName').dataset.matched = '';
			if (from !== 'code')
				document.getElementById('employeeCode').value = '';
			if (from !== 'name')
				document.getElementById('employeeName').value = '';
		}
		function clearWarehouseId(from) {
			document.getElementById('warehousePk').value = '';
			document.getElementById('warehouseCode').dataset.matched = '';
			document.getElementById('warehouseName').dataset.matched = '';
			document.getElementById('warehouseName').dataset.code = '';
			if (from !== 'code')
				document.getElementById('warehouseCode').value = '';
			if (from !== 'name')
				document.getElementById('warehouseName').value = '';
		}
		function sameText(value, keyword) {
			return String(value == null ? '' : value).trim() === keyword;
		}
		function skipLookupBlur(event) {
			return event && event.relatedTarget && event.relatedTarget.closest
					&& event.relatedTarget.closest('.popup-search-btn');
		}
		function markMatched(input, text) {
			input.dataset.matched = String(text || '').trim();
			input.dataset.resolving = '';
		}
		// 코드 칸이나 이름 칸에 글자를 넣고 Enter를 치거나 칸에서 빠지면, 코드·이름·검색창내용이 정확히 하나 같은 항목을 넣는다. 없거나 여러 개면 그 글자로 조회 모달을 연다. 돋보기를 누를 때는 자동으로 넣지 않는다.
		// コード欄か名前欄に文字を入れてEnterを押すか欄から外れると、コード・名前・検索窓内容が正確に一つ同じ項目を入れる。ないか複数ならその文字で照会モーダルを開く。虫眼鏡を押すときは自動では入れない。
		function resolveLookup(type, input, apply) {
			var text = String(input.value || '').trim();
			if (!text || input.dataset.matched === text || input.dataset.resolving === '1')
				return;
			input.dataset.resolving = '1';
			var path = type === 'partner' ? '/partners' : (type === 'manager' ? '/managers' : '/warehouses');
			fetch(ctx + path + '?keyword=' + encodeURIComponent(text), {
				headers : { 'Accept' : 'application/json' }
			}).then(function(res) {
				return res.json();
			}).then(function(list) {
				input.dataset.resolving = '';
				var exact = (list || []).filter(function(row) {
					if (type === 'partner')
						return sameText(row.businessPartnerCode, text)
								|| sameText(row.businessPartnerName, text)
								|| sameText(row.searchContent, text);
					if (type === 'manager')
						return sameText(row.employeeCode, text) || sameText(row.employeeName, text);
					return sameText(row.warehouseCode, text) || sameText(row.warehouseName, text);
				});
				if (exact.length === 1) {
					apply(exact[0]);
					markMatched(input, input.value);
				} else {
					CommonLookup.open(type, apply, text);
				}
			}).catch(function() {
				input.dataset.resolving = '';
			});
		}
		// 조회 결과는 코드, 이름, 숨은 키를 같이 넣는다. 코드 칸과 이름 칸 둘 다 조회된 값으로 표시한다.
		// 照会結果はコード、名前、隠したキーを一緒に入れる。コード欄と名前欄の両方を照会した値で表示する。
		function applyPartner(row) {
			var code = row.businessPartnerCode || '';
			var name = row.businessPartnerName || '';
			document.getElementById('businessPartnerId').value = row.businessPartnerId || '';
			document.getElementById('businessPartnerCode').value = code;
			document.getElementById('businessPartnerName').value = name;
			document.getElementById('businessPartnerName').dataset.code = code;
			markMatched(document.getElementById('businessPartnerCode'), code);
			markMatched(document.getElementById('businessPartnerName'), name);
		}
		function applyManager(row) {
			var code = row.employeeCode || '';
			var name = row.employeeName || '';
			document.getElementById('managerId').value = row.managerId || '';
			document.getElementById('employeeCode').value = code;
			document.getElementById('employeeName').value = name;
			markMatched(document.getElementById('employeeCode'), code);
			markMatched(document.getElementById('employeeName'), name);
		}
		function applyWarehouse(row) {
			var code = row.warehouseCode || '';
			var name = row.warehouseName || '';
			document.getElementById('warehousePk').value = row.warehousePk || '';
			document.getElementById('warehouseCode').value = code;
			document.getElementById('warehouseName').value = name;
			document.getElementById('warehouseName').dataset.code = code;
			markMatched(document.getElementById('warehouseCode'), code);
			markMatched(document.getElementById('warehouseName'), name);
		}
		function resolvePartner(event) {
			if (skipLookupBlur(event))
				return;
			resolveLookup('partner', event && event.target ? event.target : document.getElementById('businessPartnerName'), applyPartner);
		}
		function resolveManager(event) {
			if (skipLookupBlur(event))
				return;
			resolveLookup('manager', event && event.target ? event.target : document.getElementById('employeeName'), applyManager);
		}
		function resolveWarehouse(event) {
			if (skipLookupBlur(event))
				return;
			resolveLookup('warehouse', event && event.target ? event.target : document.getElementById('warehouseName'), applyWarehouse);
		}
		function openPartnerLookup() {
			CommonLookup.open('partner', applyPartner, headerLookupKeyword('businessPartnerCode', 'businessPartnerName'));
		}
		function openGridFind() {
			var input = document.getElementById('gridFindKeyword');
			if (input.style.display === 'none') {
				input.style.display = '';
				input.focus();
				return;
			}
			findInGrid();
		}
		// 찾기 칸은 찾기 버튼을 눌러야 나타난다. 입력한 글자가 품목 표 칸에 포함되면 그 칸을 표시하고, 값이 완전히 같지 않아도 찾는다.
		// 検索欄は検索ボタンを押すと表示される。入力した文字が品目表のセルに含まれればそのセルを表示し、値が完全に同じでなくても探す。
		function findInGrid() {
			var keyword = document.getElementById('gridFindKeyword').value
					.trim();
			var cells = document.querySelectorAll('.list-table tbody td');
			var first = null;
			cells.forEach(function(td) {
				td.classList.remove('cell-found');
				if (!keyword)
					return;
				var input = td.querySelector('input[type="text"]');
				var value = input ? input.value.trim() : td.textContent.trim();
				if (value && value.indexOf(keyword) >= 0) {
					td.classList.add('cell-found');
					if (!first)
						first = td;
				}
			});
			if (first)
				first.scrollIntoView({
					block : 'nearest',
					inline : 'nearest'
				});
		}
		// 돋보기는 코드에 글자가 있으면 그 글자로, 없으면 이름으로 조회 창을 연다. 자동으로 칸을 채우지는 않는다.
		// 虫眼鏡はコードに文字があればその文字で、なければ名前で照会画面を開く。自動では欄を埋めない。
		function headerLookupKeyword(codeId, nameId) {
			var code = document.getElementById(codeId).value.trim();
			return code || document.getElementById(nameId).value.trim();
		}
		function openManagerLookup() {
			CommonLookup.open('manager', applyManager, headerLookupKeyword('employeeCode', 'employeeName'));
		}
		function openWarehouseLookup() {
			CommonLookup.open('warehouse', applyWarehouse, headerLookupKeyword('warehouseCode', 'warehouseName'));
		}
		// 품목 찾기는 버튼을 누른 줄에 첫 항목을 넣고, 나머지 선택 항목은 빈 줄에 이어서 넣는다. 그 칸에 입력한 글자를 모달 검색어로 넣는다.
		// 品目検索はボタンを押した行に最初の項目を入れ、残りの選択項目は空行に続けて入れる。その欄に入力した文字をモーダルの検索語に入れる。
		function openItemLookup(el) {
			var preferred = el && el.closest ? el.closest('tr') : null;
			var typed = '';
			if (preferred) {
				var codeInput = preferred.querySelector('.line-item-code');
				typed = codeInput ? codeInput.value.trim() : '';
			}
			CommonLookup.open('item', function(selected) {
				var list = Array.isArray(selected) ? selected : [ selected ];
				list.forEach(function(row, index) {
					var target = null;
					if (index === 0 && preferred)
						target = preferred;
					if (!target) {
						lineRows().forEach(function(tr) {
							if (!target && !tr.querySelector('.line-item-code').value)
								target = tr;
						});
					}
					if (!target)
						target = blankRow();
					applyItemRow(target, row);
				});
				ensureBlankRow();
			}, typed);
		}
		var ctx = '${pageContext.request.contextPath}';
		// 판매조회 모달에서 열었으면 저장 뒤 부모 창에 알리고, 이 프레임은 조회 목록으로 나가지 않는다.
		// 販売照会のモーダルで開いたなら保存後に親画面へ知らせ、このフレームは照会一覧へ出て行かない。
		var embedMode = ${embed == '1'};
		function num(value) {
			var n = Number(String(value == null ? '' : value).replace(/,/g, ''));
			return isNaN(n) ? 0 : n;
		}
		function money(value) {
			return Math.round(value).toLocaleString();
		}
		// 합계는 판매 품목 표만 더한다. 조회 창 표까지 읽으면 품목 칸이 없어 계산이 멈추고 아래 합계가 0으로 남는다. 수량은 품목 키가 있는 행의 수량 합계다.
		// 合計は販売品目表だけ足す。照会画面の表まで読むと品目欄がなく計算が止まり、下の合計が0のまま残る。数量は品目キーがある行の数量合計である。
		function lineRows() {
			return document.querySelectorAll('#saleGrid tbody tr');
		}
		// 공급가액은 수량×단가에서 할인을 뺀 금액이다. 부가세율 적용이면 그 금액의 10%가 부가세이고, 합계는 둘을 더한 값이다.
		// 供給価額は数量×単価から割引を引いた金額である。付加税率適用ならその金額の10%が付加税であり、合計は二つを足した値である。
		function calcLine(el) {
			var tr = el.closest('tr');
			var qtyText = String(tr.querySelector('.line-qty').value || '')
					.trim();
			var qty = num(qtyText);
			var price = num(tr.querySelector('.line-price').value);
			var discount = num(tr.querySelector('.line-discount').value);
			var supply = qty * price - discount;
			if (supply < 0)
				supply = 0;
			var vat = document.querySelector('[name="header.saleType"]').value === '付加税率不適用' ? 0
					: Math.round(supply * 0.1);
			var show = tr.querySelector('.line-item-pk').value
					&& qtyText !== '';
			tr.querySelector('.line-supply').value = show ? money(supply) : '';
			tr.querySelector('.line-vat').value = show ? money(vat) : '';
			tr.querySelector('.line-amt').value = show ? money(supply + vat)
					: '';
			sumFooter();
			ensureBlankRow();
		}
		function sumFooter() {
			var supply = 0, vat = 0, qty = 0;
			lineRows().forEach(function(tr) {
				var itemPk = tr.querySelector('.line-item-pk');
				if (!itemPk || !itemPk.value)
					return;
				qty += num(tr.querySelector('.line-qty').value);
				supply += num(tr.querySelector('.line-supply').value);
				vat += num(tr.querySelector('.line-vat').value);
			});
			document.getElementById('footQty').textContent = money(qty);
			document.getElementById('footSupply').textContent = money(supply);
			document.getElementById('footVat').textContent = money(vat);
			document.getElementById('footTotal').textContent = money(supply
					+ vat);
		}
		function blankRow() {
			var body = document.getElementById('saleGrid').tBodies[0];
			var row = body.querySelector('tr').cloneNode(true);
			row.querySelectorAll('input').forEach(function(input) {
				input.value = '';
				input.removeAttribute('name');
				delete input.dataset.matched;
				delete input.dataset.resolving;
			});
			row.querySelector('.line-discount').value = '0';
			delete row.dataset.basePrice;
			var check = row.querySelector('.line-check');
			if (check)
				check.checked = false;
			body.appendChild(row);
			return row;
		}
		// 품목 행은 3개로 시작한다. 코드, 품목명, 규격, 수량, 단가 중 값이 있는 행이 모든 행이면 아래에 빈 행을 하나 붙인다.
		// 品目行は3行で始める。コード、品目名、規格、数量、単価に値がある行がすべての行なら、下に空行を一つ付ける。
		function ensureBlankRow() {
			var filled = true;
			lineRows().forEach(function(tr) {
				if (!rowHasEntry(tr))
					filled = false;
			});
			if (filled)
				blankRow();
		}
		function rowHasEntry(tr) {
			var classes = [ '.line-item-pk', '.line-item-code', '.line-item-name',
					'.line-spec', '.line-qty', '.line-price' ];
			for (var i = 0; i < classes.length; i++) {
				var el = tr.querySelector(classes[i]);
				if (el && String(el.value || '').trim())
					return true;
			}
			return false;
		}
		function padRows() {
			var body = document.getElementById('saleGrid').tBodies[0];
			while (body.querySelectorAll('tr').length < 3)
				blankRow();
		}
		// 품목코드가 코드, 품목명, 검색창내용, 규격과 정확히 하나 같으면 그 줄에 넣는다. 아니면 그 글자로 품목 모달을 연다. 고친 품목명, 규격, 금액은 이 판매 줄에만 남고 품목 마스터는 바꾸지 않는다.
		// 品目コードがコード、品目名、検索窓内容、規格と正確に一つ同じならその行に入れる。違えばその文字で品目モーダルを開く。直した品目名、規格、金額はこの販売行だけに残り、品目マスタは変えない。
		function clearItemPk(input) {
			var tr = input.closest('tr');
			tr.querySelector('.line-item-pk').value = '';
			input.dataset.matched = '';
			delete tr.dataset.basePrice;
			ensureBlankRow();
		}
		function applyItemRow(tr, row) {
			var code = tr.querySelector('.line-item-code');
			tr.querySelector('.line-item-pk').value = row.itemPk || '';
			code.value = row.itemCode || '';
			markMatched(code, row.itemCode);
			tr.querySelector('.line-item-name').value = row.itemName || '';
			tr.querySelector('.line-spec').value = row.spec || '';
			tr.dataset.basePrice = row.unitPrice != null ? row.unitPrice : '';
			if (row.unitPrice != null)
				tr.querySelector('.line-price').value = row.unitPrice;
			calcLine(tr.querySelector('.line-qty'));
		}
		function fillItemToNextRow(row) {
			var target = null;
			lineRows().forEach(function(tr) {
				if (!target && !tr.querySelector('.line-item-code').value)
					target = tr;
			});
			if (!target)
				target = blankRow();
			applyItemRow(target, row);
		}
		function resolveItem(input, event) {
			if (skipLookupBlur(event))
				return;
			var text = String(input.value || '').trim();
			var tr = input.closest('tr');
			if (!text) {
				tr.querySelector('.line-item-pk').value = '';
				input.dataset.resolving = '';
				ensureBlankRow();
				return;
			}
			if (input.dataset.matched === text || input.dataset.resolving === '1')
				return;
			input.dataset.resolving = '1';
			fetch(ctx + '/items?keyword=' + encodeURIComponent(text), {
				headers : { 'Accept' : 'application/json' }
			}).then(function(res) {
				return res.json();
			}).then(function(list) {
				input.dataset.resolving = '';
				var exact = (list || []).filter(function(row) {
					return sameText(row.itemCode, text) || sameText(row.itemName, text)
							|| sameText(row.searchContent, text) || sameText(row.spec, text);
				});
				if (exact.length === 1) {
					applyItemRow(tr, exact[0]);
					ensureBlankRow();
				} else {
					tr.querySelector('.line-item-pk').value = '';
					CommonLookup.open('item', function(selected) {
						var rows = Array.isArray(selected) ? selected : [ selected ];
						if (rows[0])
							applyItemRow(tr, rows[0]);
						rows.slice(1).forEach(fillItemToNextRow);
						ensureBlankRow();
					}, text);
				}
			}).catch(function() {
				input.dataset.resolving = '';
			});
		}
		function fillSource(row) {
			var target = null;
			lineRows().forEach(function(tr) {
				if (!target && !tr.querySelector('.line-item-code').value)
					target = tr;
			});
			if (!target)
				target = blankRow();
			target.querySelector('.line-item-pk').value = row.itemPk || '';
			target.querySelector('.line-item-code').value = row.itemCode || '';
			target.querySelector('.line-item-name').value = row.itemNm || '';
			target.querySelector('.line-spec').value = row.spec || '';
			target.querySelector('.line-qty').value = row.remainQty != null ? row.remainQty
					: '';
			target.querySelector('.line-price').value = row.unitPrice != null ? row.unitPrice
					: '';
			target.querySelector('.line-src-type').value = row.srcType || '';
			target.querySelector('.line-src-id').value = row.srcItemId || '';
			calcLine(target.querySelector('.line-qty'));
			ensureBlankRow();
		}
		// 품목코드가 있는 줄을 위에서부터 정렬하고, 빈 줄은 아래에 둔다.
		// 品目コードがある行を上から並べ、空行は下に置く。
		function sortGrid() {
			var body = document.getElementById('saleGrid').tBodies[0];
			var rows = Array.prototype.slice.call(body.querySelectorAll('tr'));
			rows.sort(function(a, b) {
				var codeA = a.querySelector('.line-item-code').value.trim();
				var codeB = b.querySelector('.line-item-code').value.trim();
				if (!codeA && !codeB)
					return 0;
				if (!codeA)
					return 1;
				if (!codeB)
					return -1;
				return codeA.localeCompare(codeB);
			});
			rows.forEach(function(tr) {
				body.appendChild(tr);
			});
		}
		function showResult(html) {
			document.getElementById('saleResult').innerHTML = html;
		}
		// 서버가 돌려주는 상태 이름이다. 화면과 저장이 같은 일본어를 쓴다. 한글은 정상, 보류, 부가세율 적용이다.
		// サーバが返す状態名である。画面と保存は同じ日本語を使う。韓国語は正常、保留、付加税率適用である。
		function showLabel(text) {
			var labels = {
				'保留' : '保留',
				'正常' : '正常',
				'取消' : '取消',
				'返品' : '返品',
				'確認' : '確認',
				'未確認' : '未確認',
				'付加税率適用' : '付加税率適用',
				'付加税率不適用' : '付加税率不適用'
			};
			return labels[text] || text || '';
		}
		var slipKind = 'sale';
		var slipKindName = {
			sale : '販売書<%--판매서--%>',
			order : '注文書<%--주문서--%>',
			quote : '見積書<%--견적서--%>'
		};
		var slipInquiryName = {
			sale : '販売書照会<%--판매서 조회--%>',
			order : '注文書照会<%--주문서 조회--%>',
			quote : '見積書照会<%--견적서 조회--%>'
		};
		function formatYmd(date) {
			var month = date.getMonth() + 1;
			var day = date.getDate();
			return date.getFullYear() + '-' + (month < 10 ? '0' : '') + month
					+ '-' + (day < 10 ? '0' : '') + day;
		}
		function historyRange() {
			var raw = document.querySelector('[name="header.saleDt"]').value;
			var day = raw ? new Date(raw + 'T00:00:00') : new Date();
			if (isNaN(day.getTime()))
				day = new Date();
			return {
				from : formatYmd(new Date(day.getFullYear(), day.getMonth(), 1)),
				to : formatYmd(day)
			};
		}
		function toggleHistoryMenu(event) {
			event.preventDefault();
			event.stopPropagation();
			document.getElementById('saveMenu').classList.remove('open');
			document.getElementById('historyMenu').classList.toggle('open');
		}
		function openHistory(kind) {
			slipKind = kind;
			document.getElementById('historyMenu').classList.remove('open');
			var range = historyRange();
			openSlipList(slipKindName[kind] + ' ' + range.from + ' ~ '
					+ range.to, '画面の日付が属する月の1日からその日までの履歴です。<%--화면 일자가 속한 달의 1일부터 그날까지의 내역입니다.--%>', kind,
					range.from, range.to);
		}
		function openSlipInquiry() {
			var kind = slipKind;
			document.getElementById('slipInquiryTitle').textContent = slipInquiryName[kind];
			document.getElementById('slipInquiryBody').innerHTML = '<tr><td colspan="6">照会中です。<%--조회 중입니다.--%></td></tr>';
			document.getElementById('slipInquiryOverlay').classList
					.add('active');
			fetch(
					ctx + '/sales/sale/input/slips?kind='
							+ encodeURIComponent(kind)).then(function(res) {
				return res.json();
			}).then(function(list) {
				renderSlipRows('slipInquiryBody', list, kind);
			});
		}
		function closeSlipInquiry() {
			document.getElementById('slipInquiryOverlay').classList
					.remove('active');
		}
		function closeSlipList() {
			closeSlipInquiry();
			document.getElementById('slipListOverlay').classList
					.remove('active');
		}
		function openSlipList(title, note, kind, fromDate, toDate) {
			document.getElementById('slipListTitle').textContent = title;
			document.getElementById('slipListNote').textContent = note;
			document.getElementById('slipListBody').innerHTML = '<tr><td colspan="6">照会中です。<%--조회 중입니다.--%></td></tr>';
			document.getElementById('slipListOverlay').classList.add('active');
			var url = ctx + '/sales/sale/input/slips?kind='
					+ encodeURIComponent(kind);
			if (fromDate)
				url += '&fromDate=' + encodeURIComponent(fromDate);
			if (toDate)
				url += '&toDate=' + encodeURIComponent(toDate);
			fetch(url).then(function(res) {
				return res.json();
			}).then(function(list) {
				renderSlipRows('slipListBody', list, kind);
			});
		}
		function renderSlipRows(bodyId, list, kind) {
			var body = document.getElementById(bodyId);
			if (!list.length) {
				body.innerHTML = '<tr><td colspan="6">照会された伝票がありません。<%--조회된 전표가 없습니다.--%></td></tr>';
				return;
			}
			body.innerHTML = list.map(
					function(row) {
						var no = row.slipNo || row.slipId || '';
						var slipCell = kind === 'sale' ? '<a href="' + ctx
								+ '/sales/sale/input?saleId=' + row.slipId
								+ '">' + no + '</a>' : no;
						return '<tr><td>' + (row.slipDate || '') + '</td><td>'
								+ slipCell + '</td><td>'
								+ (row.businessPartnerName || '')
								+ '</td><td class="col-num">'
								+ money(row.supplyAmt)
								+ '</td><td class="col-num">'
								+ money(row.vatAmt) + '</td><td>'
								+ showLabel(row.voucherStatus) + '</td></tr>';
					}).join('');
		}
		function loadOrders() {
			var id = document.getElementById('businessPartnerId').value;
			var url = ctx + '/sales/sale/input/unsold-orders'
					+ (id ? '?businessPartnerId=' + id : '');
			fetch(url).then(function(res) {
				return res.json();
			}).then(function(list) {
				if (!list.length) {
					showResult('未販売の注文がありません。<%--미판매 주문이 없습니다.--%>');
					return;
				}
				list.forEach(fillSource);
				showResult('未販売の注文 ' + list.length + '件を入れました。<%--미판매 주문 건을 넣었습니다.--%>');
			});
		}
		// 버튼이 넘긴 키로 모달 제목과 조회 주소를 같이 찾는다. 키 이름이 두 표에서 같아야 한다.
		// ボタンが渡したキーでモーダルの題名と照会アドレスを一緒に探す。キー名は二つの表で同じでなければならない。
		var slipLoadTitle = {
			quote : '見積書照会<%--견적서 조회--%>',
			order : '注文書照会<%--주문서 조회--%>',
			shipOrder : '出荷指示書照会<%--출하지시서 조회--%>',
			ship : '出荷照会<%--출하 조회--%>'
		};
		// 종류별 조회 JSP 주소. quote는 sales/estimate/inquiry.jsp, order는 sales/order/inquiry.jsp, shipOrder는 sales/ship-order/inquiry.jsp, ship은 sales/ship/inquiry.jsp 이다.
		// 種類ごとの照会JSPアドレス。quoteはsales/estimate/inquiry.jsp、orderはsales/order/inquiry.jsp、shipOrderはsales/ship-order/inquiry.jsp、shipはsales/ship/inquiry.jspである。
		var slipLoadPage = {
			quote : '/sales/estimate/inquiry',
			order : '/sales/order/inquiry',
			shipOrder : '/sales/ship-order/inquiry',
			ship : '/sales/ship/inquiry'
		};
		// active를 붙이면 CSS가 이 모달을 보여 준다. 판매 입력 값은 아직 건드리지 않는다.
		// activeを付けるとCSSがこのモーダルを見せる。販売入力の値はまだ触らない。
		function openSlipLoadChooser() {
			document.getElementById('slipLoadChooserOverlay').classList.add('active');
		}
		function closeSlipLoadChooser() {
			document.getElementById('slipLoadChooserOverlay').classList.remove('active');
		}
		// 선택 창을 닫고, 제목을 바꾼 뒤 iframe 주소에 조회 JSP를 넣는다. ctx는 앱 주소 앞부분이다.
		// 選択画面を閉じ、題名を変えたあとiframeのアドレスに照会JSPを入れる。ctxはアプリのアドレスの先頭である。
		function openSlipLoadInquiry(kind) {
			closeSlipLoadChooser();
			document.getElementById('slipLoadTitle').textContent = slipLoadTitle[kind] || '伝票照会<%--전표 조회--%>';
			document.getElementById('slipLoadFrame').src = ctx + (slipLoadPage[kind] || '') + '?embed=1';
			document.getElementById('slipLoadOverlay').classList.add('active');
		}
		// 모달을 숨기고 iframe 주소를 빈 페이지로 바꾼다. 조회 JSP가 뒤에서 계속 남지 않게 한다.
		// モーダルを隠し、iframeのアドレスを空のページに変える。照会JSPが後ろで残り続けないようにする。
		function closeSlipLoadInquiry() {
			document.getElementById('slipLoadOverlay').classList.remove('active');
			document.getElementById('slipLoadFrame').src = 'about:blank';
		}
		// 할인 창 헤더는 판매입력의 거래처, 창고, 통화, 거래유형을 복사해 보여 주기만 한다. 거래유형도 화면과 저장이 같은 일본어다. 기준단가는 품목 마스터의 출고단가이고, 기준원화공급가액은 수량×환율×기준단가다. 수량과 금액은 반올림한 정수만 표시한다.
		// 割引画面のヘッダは販売入力の取引先、倉庫、通貨、取引類型を写して見せるだけである。取引類型も画面と保存は同じ日本語である。基準単価は品目マスタの出庫単価であり、基準ウォン供給価額は数量×為替レート×基準単価である。数量と金額は丸めた整数だけ表示する。
		function openDiscountModal() {
			var partnerName = document.getElementById('businessPartnerName');
			var warehouseName = document.getElementById('warehouseName');
			document.getElementById('discountPartnerCode').value = document.getElementById('businessPartnerCode').value || partnerName.dataset.code || '';
			document.getElementById('discountPartnerName').value = partnerName.value || '';
			document.getElementById('discountWarehouseCode').value = document.getElementById('warehouseCode').value || warehouseName.dataset.code || '';
			document.getElementById('discountWarehouseName').value = warehouseName.value || '';
			var currency = document.getElementById('currencySelect');
			var currencyOption = currency.options[currency.selectedIndex];
			document.getElementById('discountCurrency').value = currencyOption
					&& currencyOption.value !== 'add' ? currencyOption.textContent.trim() : '';
			var saleType = document.querySelector('[name="header.saleType"]');
			var saleTypeLabel = saleType.options[saleType.selectedIndex];
			document.getElementById('discountSaleType').value = saleTypeLabel
					? saleTypeLabel.textContent.replace(/\s+/g, ' ').trim() : '';
			fillDiscountCode('partner');
			fillDiscountCode('warehouse');
			var body = document.getElementById('discountBody');
			body.innerHTML = '';
			var no = 0;
			lineRows().forEach(function(tr) {
				if (!rowHasEntry(tr))
					return;
				no++;
				body.appendChild(discountRow(tr, no));
			});
			document.getElementById('discountCheckAll').checked = true;
			document.getElementById('discountOverlay').classList.add('active');
			sumDiscountFooter();
		}
		function closeDiscountModal() {
			document.getElementById('discountOverlay').classList.remove('active');
		}
		function fillDiscountCode(kind) {
			var codeInput = document.getElementById(kind === 'partner' ? 'discountPartnerCode' : 'discountWarehouseCode');
			var name = document.getElementById(kind === 'partner' ? 'discountPartnerName' : 'discountWarehouseName').value.trim();
			var id = document.getElementById(kind === 'partner' ? 'businessPartnerId' : 'warehousePk').value;
			if (codeInput.value || !name)
				return;
			fetch(ctx + (kind === 'partner' ? '/partners' : '/warehouses') + '?keyword=' + encodeURIComponent(name), {
				headers : { 'Accept' : 'application/json' }
			}).then(function(res) {
				return res.json();
			}).then(function(list) {
				var found = (list || []).filter(function(row) {
					if (kind === 'partner')
						return (!id || String(row.businessPartnerId) === String(id))
								&& sameText(row.businessPartnerName, name);
					return (!id || String(row.warehousePk) === String(id))
							&& sameText(row.warehouseName, name);
				})[0];
				if (found)
					codeInput.value = kind === 'partner' ? (found.businessPartnerCode || '') : (found.warehouseCode || '');
			});
		}
		function discountRow(source, no) {
			var tr = document.createElement('tr');
			var qtyText = String(source.querySelector('.line-qty').value || '').trim();
			var qty = num(qtyText);
			var cells = [
				'<input type="checkbox" class="discount-check" checked>',
				'<span class="discount-no">' + no + '</span>',
				source.querySelector('.line-item-code').value,
				source.querySelector('.line-item-name').value,
				qtyText === '' ? '' : money(qty)
			];
			cells.forEach(function(value, index) {
				var td = document.createElement('td');
				if (index < 2)
					td.innerHTML = value;
				else
					td.textContent = value;
				if (index === 4)
					td.className = 'col-num disc-qty';
				tr.appendChild(td);
			});
			[ 'disc-base-vat', 'disc-base-price', 'disc-base-krw', 'disc-off-vat', 'disc-off-price', 'disc-off-krw', 'disc-price', 'disc-krw' ]
					.forEach(function(name) {
						var td = document.createElement('td');
						td.className = 'col-num ' + name;
						tr.appendChild(td);
					});
			tr.dataset.qty = qty;
			tr._saleRow = source;
			loadDiscountBase(tr, source, qty);
			return tr;
		}
		function loadDiscountBase(tr, source, qty) {
			var stored = source.dataset.basePrice;
			if (stored != null && stored !== '') {
				writeDiscountBase(tr, Number(stored), qty);
				return;
			}
			var itemPk = source.querySelector('.line-item-pk').value;
			var key = String(source.querySelector('.line-item-code').value || '').trim();
			if (!itemPk && !key)
				return;
			fetch(ctx + '/items?keyword=' + encodeURIComponent(key), {
				headers : { 'Accept' : 'application/json' }
			}).then(function(res) {
				return res.json();
			}).then(function(list) {
				var rows = list || [];
				var found = rows.filter(function(row) {
					return itemPk && String(row.itemPk) === String(itemPk);
				})[0];
				if (!found && key) {
					var exact = rows.filter(function(row) {
						return sameText(row.itemCode, key);
					});
					if (exact.length === 1)
						found = exact[0];
				}
				if (!found || found.unitPrice == null)
					return;
				source.dataset.basePrice = found.unitPrice;
				writeDiscountBase(tr, Number(found.unitPrice), qty);
			});
		}
		// 기준단가와 기준원화공급가액을 정수로 넣는다. 이미 할인단가를 적용한 행이면 단가와 원화공급가액을 다시 계산한다.
		// 基準単価と基準ウォン供給価額を整数で入れる。すでに割引単価を適用した行なら単価とウォン供給価額を計算し直す。
		function writeDiscountBase(tr, base, qty) {
			if (isNaN(base))
				return;
			var rateText = String(document.getElementById('exchangeRate').value || '').trim();
			var rate = rateText === '' ? 1 : num(rateText);
			tr.dataset.basePrice = base;
			tr.dataset.baseKrw = qty * rate * base;
			tr.querySelector('.disc-base-price').textContent = money(base);
			tr.querySelector('.disc-base-krw').textContent = money(tr.dataset.baseKrw);
			if (tr.dataset.offPrice != null && tr.dataset.offPrice !== '')
				writeDiscountPrice(tr, num(tr.dataset.offPrice));
			sumDiscountFooter();
		}
		// 일괄변경을 고르면 불러온 품목을 모두 체크한다. 품목별을 고르면 체크를 모두 해제한다.
		// 一括変更を選ぶと読み込んだ品目をすべてチェックする。品目別を選ぶとチェックをすべて外す。
		function onDiscountApplyMode() {
			var selected = document.querySelector('input[name="discountApply"]:checked');
			var batch = selected && selected.value === 'batch';
			document.getElementById('discountCheckAll').checked = !!batch;
			document.querySelectorAll('#discountBody .discount-check').forEach(function(input) {
				input.checked = !!batch;
			});
		}
		// 할인단가는 입력 금액을 그대로 쓴다. 할인단가(vat포함)는 그 칸에 입력 금액을 넣고, 할인단가는 입력 금액을 1.1로 나눈 값이다.
		// 할인원화공급가액은 수량×할인단가다. 단가는 기준단가-할인단가, 원화공급가액은 기준원화공급가액-할인원화공급가액이다.
		// 일괄변경은 불러온 품목을 모두 선택해 적용하고, 품목별은 체크한 품목만 적용한다.
		// 割引単価は入力金額をそのまま使う。割引単価(vat含む)はその欄に入力金額を入れ、割引単価は入力金額を1.1で割った値である。
		// 割引ウォン供給価額は数量×割引単価である。単価は基準単価-割引単価、ウォン供給価額は基準ウォン供給価額-割引ウォン供給価額である。
		// 一括変更は読み込んだ品目をすべて選んで適用し、品目別はチェックした品目だけ適用する。
		function applyDiscountAmount() {
			var kind = document.getElementById('discountPriceKind').value;
			var amount = num(document.getElementById('discountValue').value);
			var batch = document.querySelector('input[name="discountApply"]:checked').value === 'batch';
			if (batch) {
				document.getElementById('discountCheckAll').checked = true;
				document.querySelectorAll('#discountBody .discount-check').forEach(function(input) {
					input.checked = true;
				});
			}
			document.querySelectorAll('#discountBody tr').forEach(function(tr) {
				var box = tr.querySelector('.discount-check');
				if (!batch && (!box || !box.checked))
					return;
				if (kind === 'vat') {
					tr.querySelector('.disc-off-vat').textContent = money(amount);
					writeDiscountPrice(tr, amount / 1.1);
					return;
				}
				tr.querySelector('.disc-off-vat').textContent = '';
				writeDiscountPrice(tr, amount);
			});
			sumDiscountFooter();
		}
		// 아래 적용은 모달에서 계산된 최종 단가와 원화공급가액을 판매입력 품목 줄에만 넣는다. 부가세는 그 공급가액의 10%다. 품목 마스터는 바꾸지 않는다.
		// 下の適用はモーダルで計算した最終単価とウォン供給価額を販売入力の品目行だけに入れる。付加税はその供給価額の10%である。品目マスタは変えない。
		function applyDiscountToSale() {
			var selected = document.querySelector('input[name="discountApply"]:checked');
			var batch = selected && selected.value === 'batch';
			document.querySelectorAll('#discountBody tr').forEach(function(tr) {
				var box = tr.querySelector('.discount-check');
				if (!batch && (!box || !box.checked))
					return;
				var priceText = tr.querySelector('.disc-price').textContent;
				var supplyText = tr.querySelector('.disc-krw').textContent;
				if (!priceText || !tr._saleRow)
					return;
				var saleRow = tr._saleRow;
				var supply = num(supplyText);
				var vat = Math.round(supply * 0.1);
				saleRow.querySelector('.line-price').value = priceText;
				saleRow.querySelector('.line-supply').value = supplyText;
				saleRow.querySelector('.line-vat').value = money(vat);
				saleRow.querySelector('.line-amt').value = money(supply + vat);
				saleRow.querySelector('.line-discount').value = '0';
			});
			sumFooter();
			closeDiscountModal();
		}
		// 할인단가와 수량으로 할인원화공급가액을 만들고, 단가와 원화공급가액은 기준 금액에서 뺀다. 화면에는 반올림한 정수만 쓴다.
		// 割引単価と数量で割引ウォン供給価額を作り、単価とウォン供給価額は基準金額から引く。画面には丸めた整数だけ書く。
		function writeDiscountPrice(tr, amount) {
			var qty = num(tr.dataset.qty);
			var base = num(tr.dataset.basePrice);
			var baseKrw = num(tr.dataset.baseKrw);
			var offKrw = qty * amount;
			tr.dataset.offPrice = amount;
			tr.querySelector('.disc-off-price').textContent = money(amount);
			tr.querySelector('.disc-off-krw').textContent = money(offKrw);
			tr.querySelector('.disc-price').textContent = money(base - amount);
			tr.querySelector('.disc-krw').textContent = money(baseKrw - offKrw);
		}
		function sumDiscountFooter() {
			var rows = document.querySelectorAll('#discountBody tr');
			var qty = 0, base = 0, off = 0, krw = 0, hasOff = false, hasKrw = false;
			rows.forEach(function(tr) {
				qty += num(tr.querySelector('.disc-qty').textContent);
				base += num(tr.querySelector('.disc-base-krw').textContent);
				var offText = tr.querySelector('.disc-off-krw').textContent;
				var krwText = tr.querySelector('.disc-krw').textContent;
				if (offText) {
					hasOff = true;
					off += num(offText);
				}
				if (krwText) {
					hasKrw = true;
					krw += num(krwText);
				}
			});
			document.getElementById('discountFootQty').textContent = rows.length ? money(qty) : '';
			document.getElementById('discountFootBase').textContent = rows.length ? money(base) : '';
			document.getElementById('discountFootOff').textContent = hasOff ? money(off) : '';
			document.getElementById('discountFootKrw').textContent = hasKrw ? money(krw) : '';
		}
		function toggleDiscountChecks(box) {
			document.querySelectorAll('#discountBody .discount-check').forEach(function(input) {
				input.checked = box.checked;
			});
		}
		document.addEventListener('keydown', function(event) {
			if (event.key !== 'F8')
				return;
			if (!document.getElementById('discountOverlay').classList.contains('active'))
				return;
			event.preventDefault();
			applyDiscountToSale();
		});
		// 재고불러오기는 입력한 품목의 재고수량과 출하창고를 읽어 전체수량, 출하창고수량 칸에만 넣는다. 이 버튼은 재고를 줄이지 않는다. 출하창고 재고를 빼는 시점은 보류가 아닌 저장이다.
		// 在庫読込は入力した品目の在庫数量と出荷倉庫を読み、全体数量、出荷倉庫数量の列だけに入れる。このボタンは在庫を減らさない。出荷倉庫の在庫を引く時点は保留ではない保存である。
		function loadStock() {
			var warehousePk = document.getElementById('warehousePk').value;
			if (!warehousePk) {
				showResult('出荷倉庫を先に選択してください。<%--출하창고를 먼저 선택하세요.--%>');
				return;
			}
			var targets = [];
			var jobs = [];
			lineRows().forEach(function(tr) {
				var itemPk = tr.querySelector('.line-item-pk').value;
				if (!itemPk)
					return;
				targets.push(tr);
				jobs.push(fetch(ctx + '/items/' + itemPk + '/stock?warehouseId=' + warehousePk).then(function(res) {
					return res.json();
				}));
			});
			if (!jobs.length) {
				showResult('品目を先に入れてください。<%--품목을 먼저 넣으세요.--%>');
				return;
			}
			Promise.all(jobs).then(function(stocks) {
				showStockColumns();
				stocks.forEach(function(stock, index) {
					targets[index].querySelector('.line-tot').value = stock.totQty;
					targets[index].querySelector('.line-wh').value = stock.whQty;
				});
			});
		}
		function showStockColumns() {
			var table = document.getElementById('saleGrid');
			if (!table.classList.contains('stock-open')) {
				table.classList.add('stock-open');
				var anchor = table.querySelector('thead .stock-anchor');
				var totTh = document.createElement('th');
				totTh.className = 'col-num stock-col';
				totTh.textContent = '全体数量';
				var whTh = document.createElement('th');
				whTh.className = 'col-num stock-col';
				whTh.textContent = '出荷倉庫数量';
				anchor.parentNode.insertBefore(whTh, anchor.nextSibling);
				anchor.parentNode.insertBefore(totTh, whTh);
				var specCol = document.getElementById('saleColSpec');
				if (specCol) {
					var colWh = document.createElement('col');
					colWh.className = 'stock-col';
					colWh.style.width = '11%';
					var colTot = document.createElement('col');
					colTot.className = 'stock-col';
					colTot.style.width = '9%';
					specCol.parentNode.insertBefore(colWh, specCol.nextSibling);
					specCol.parentNode.insertBefore(colTot, colWh);
				}
				document.getElementById('footLead').colSpan = 6;
			}
			lineRows().forEach(ensureStockCells);
		}
		function ensureStockCells(tr) {
			if (tr.querySelector('.line-tot'))
				return;
			var specTd = tr.querySelector('.line-spec').closest('td');
			var tot = stockCell('line-tot');
			var wh = stockCell('line-wh');
			specTd.parentNode.insertBefore(wh, specTd.nextSibling);
			specTd.parentNode.insertBefore(tot, wh);
		}
		function stockCell(cls) {
			var td = document.createElement('td');
			td.className = 'stock-col';
			var input = document.createElement('input');
			input.type = 'text';
			input.className = 'col-num ' + cls;
			td.appendChild(input);
			return td;
		}
		function hideStockColumns() {
			var table = document.getElementById('saleGrid');
			table.classList.remove('stock-open');
			table.querySelectorAll('.stock-col').forEach(function(el) {
				el.parentNode.removeChild(el);
			});
			var lead = document.getElementById('footLead');
			if (lead)
				lead.colSpan = 4;
		}
		function verifyLines() {
			var bad = 0;
			lineRows()
					.forEach(
							function(tr) {
								if (!tr.querySelector('.line-item-pk').value)
									return;
								var qty = num(tr.querySelector('.line-qty').value);
								var price = num(tr.querySelector('.line-price').value);
								var discount = num(tr
										.querySelector('.line-discount').value);
								var supply = Math
										.max(0, qty * price - discount);
								var vat = document
										.querySelector('[name="header.saleType"]').value === '付加税率不適用' ? 0
										: Math.round(supply * 0.1);
								var supplyCell = tr.querySelector(
										'.line-supply').closest('td');
								var ok = num(tr.querySelector('.line-supply').value) === Math
										.round(supply)
										&& num(tr.querySelector('.line-vat').value) === vat;
								supplyCell.classList.toggle('cell-found', !ok);
								if (!ok)
									bad++;
								calcLine(tr.querySelector('.line-qty'));
							});
			showResult(bad ? '金額が合わない行 ' + bad + '件を再計算しました。<%--금액이 맞지 않는 줄 건을 다시 계산했습니다.--%>'
					: '数量、単価、金額は合っています。<%--수량, 단가, 금액이 맞습니다.--%>');
		}
		function showProfit() {
			var jobs = [];
			lineRows()
					.forEach(
							function(tr) {
								var itemPk = tr.querySelector('.line-item-pk').value;
								if (!itemPk)
									return;
								var salePrice = num(tr
										.querySelector('.line-price').value);
								jobs
										.push(fetch(
												ctx
														+ '/sales/sale/input/profit?itemPk='
														+ itemPk)
												.then(function(res) {
													return res.json();
												})
												.then(
														function(item) {
															var std = num(item.stdCostMaterial)
																	+ num(item.stdCostExpense)
																	+ num(item.stdCostLabor)
																	+ num(item.stdCostOutsourcing);
															return item.itemCode
																	+ ' 仕入<%--매입--%> '
																	+ money(item.purchasePrice)
																	+ ' / 標準原価<%--표준원가--%> '
																	+ money(std)
																	+ ' / 販売単価<%--판매단가--%> '
																	+ money(salePrice);
														}));
							});
			Promise.all(jobs).then(function(lines) {
				showResult(lines.length ? lines.join('<br>') : '品目を先に入れてください。<%--품목을 먼저 넣으세요.--%>');
			});
		}
		function calcVat() {
			lineRows().forEach(function(tr) {
				if (tr.querySelector('.line-item-pk').value)
					calcLine(tr.querySelector('.line-qty'));
			});
			var saleTypeBox = document.querySelector('[name="header.saleType"]');
			var saleTypeText = saleTypeBox.options[saleTypeBox.selectedIndex].textContent.replace(/\s+/g, ' ').trim();
			showResult(saleTypeText + 'を基準に付加税を再計算しました。<%--기준으로 부가세를 다시 계산했습니다.--%>');
		}
		function toggleSaveMenu(event) {
			event.preventDefault();
			event.stopPropagation();
			document.getElementById('historyMenu').classList.remove('open');
			document.getElementById('saveMenu').classList.toggle('open');
		}
		document.addEventListener('click', function() {
			var menu = document.getElementById('saveMenu');
			var history = document.getElementById('historyMenu');
			if (menu)
				menu.classList.remove('open');
			if (history)
				history.classList.remove('open');
		});
		function openHoldModal() {
			document.getElementById('holdOverlay').classList.add('active');
			fetch(ctx + '/sales?status=hold').then(function(res) {
				return res.json();
			}).then(renderHolds);
		}
		function closeHoldModal() {
			document.getElementById('holdOverlay').classList.remove('active');
		}
		function renderHolds(list) {
			var body = document.getElementById('holdBody');
			if (!list.length) {
				body.innerHTML = '<tr><td colspan="7">保留伝票がありません。<%--보류 전표가 없습니다.--%></td></tr>';
				return;
			}
			body.innerHTML = list
					.map(
							function(row) {
								return '<tr><td><input type="checkbox" class="hold-check" value="' + row.saleId + '"></td>'
										+ '<td><button type="button" class="hold-no" onclick="loadHold('
										+ row.saleId
										+ ')">'
										+ (row.holdNo || row.saleId)
										+ '</button></td>'
										+ '<td>'
										+ (row.businessPartnerName || '')
										+ '</td>'
										+ '<td>'
										+ (row.itemSummary || '')
										+ '</td>'
										+ '<td class="col-num">'
										+ money(row.currAmt)
										+ '</td>'
										+ '<td>'
										+ showLabel(row.saleType)
										+ '</td>'
										+ '<td>'
										+ (row.warehouseName || '')
										+ '</td></tr>';
							}).join('');
		}
		// 보류 목록에서 고른 전표를 입력란에 채운다. 이 시점에는 삭제하지 않고, 나중에 정상으로 저장하면 보류 목록에서 빠진다.
		// 保留一覧で選んだ伝票を入力欄に入れる。この時点では削除せず、後で正常に保存すると保留一覧から外れる。
		function loadHold(saleId) {
			fetch(ctx + '/sales/' + saleId)
					.then(function(res) {
						return res.json();
					})
					.then(
							function(sale) {
								var header = sale.header || {};
								document
										.querySelector('[name="header.saleId"]').value = header.saleId
										|| '';
								document.getElementById('voucherStatus').value = '保留';
								document.getElementById('businessPartnerId').value = header.businessPartnerId
										|| '';
								document.getElementById('businessPartnerCode').value = header.businessPartnerCode
										|| '';
								document.getElementById('businessPartnerName').value = header.businessPartnerName
										|| '';
								document.getElementById('businessPartnerName').dataset.code = header.businessPartnerCode
										|| '';
								document.getElementById('managerId').value = header.managerId
										|| '';
								document.getElementById('employeeCode').value = header.employeeCode
										|| '';
								document.getElementById('employeeName').value = header.employeeName
										|| '';
								document.getElementById('warehousePk').value = header.warehousePk
										|| '';
								document.getElementById('warehouseCode').value = header.warehouseCode
										|| '';
								document.getElementById('warehouseName').value = header.warehouseName
										|| '';
								document.getElementById('warehouseName').dataset.code = header.warehouseCode
										|| '';
								markMatched(document.getElementById('businessPartnerCode'), header.businessPartnerCode);
								markMatched(document.getElementById('businessPartnerName'), header.businessPartnerName);
								markMatched(document.getElementById('employeeCode'), header.employeeCode);
								markMatched(document.getElementById('employeeName'), header.employeeName);
								markMatched(document.getElementById('warehouseCode'), header.warehouseCode);
								markMatched(document.getElementById('warehouseName'), header.warehouseName);
								if (header.saleType)
									document
											.querySelector('[name="header.saleType"]').value = header.saleType;
								if (header.currencyId)
									document
											.querySelector('[name="header.currencyId"]').value = header.currencyId;
								if (header.exchangeRate != null)
									document.getElementById('exchangeRate').value = header.exchangeRate;
								if (header.saleDt)
									document
											.querySelector('[name="header.saleDt"]').value = toDateInput(header.saleDt);
								resetGrid();
								(sale.items || [])
										.forEach(function(item) {
											fillSource({
												itemPk : item.itemPk,
												itemCode : item.itemCode,
												itemNm : item.itemNm,
												spec : item.spec,
												remainQty : item.saleQty,
												unitPrice : item.unitPrice,
												srcType : item.slipLink ? item.slipLink.srcType
														: '',
												srcItemId : item.slipLink ? item.slipLink.srcItemId
														: ''
											});
											var rows = lineRows();
											var tr = rows[rows.length - 1];
											lineRows()
													.forEach(
															function(row) {
																if (row
																		.querySelector('.line-item-pk').value == item.itemPk
																		&& row
																				.querySelector('.line-qty').value == item.saleQty)
																	tr = row;
															});
											tr.querySelector('.line-discount').value = item.discountAmt || 0;
											calcLine(tr
													.querySelector('.line-qty'));
										});
								closeHoldModal();
								showResult('保留伝票を読み込みました。保存すると販売記録に残り、保留一覧から外れます。<%--보류전표를 불러왔습니다. 저장하면 판매 기록으로 남고 보류 목록에서 빠집니다.--%>');
							});
		}
		function toDateInput(value) {
			var d = typeof value === 'number' ? new Date(value) : new Date(
					value);
			if (isNaN(d.getTime()))
				return String(value).substring(0, 10);
			var m = ('0' + (d.getMonth() + 1)).slice(-2);
			var day = ('0' + d.getDate()).slice(-2);
			return d.getFullYear() + '-' + m + '-' + day;
		}
		function resetGrid() {
			hideStockColumns();
			var body = document.getElementById('saleGrid').tBodies[0];
			var rows = body.querySelectorAll('tr');
			for (var i = rows.length - 1; i >= 3; i--)
				body.removeChild(rows[i]);
			body.querySelectorAll('tr').forEach(function(tr) {
				tr.querySelectorAll('input').forEach(function(input) {
					input.value = '';
				});
				if (tr.querySelector('.line-discount'))
					tr.querySelector('.line-discount').value = '0';
			});
		}
		function deleteSelectedHolds() {
			var ids = Array.prototype.map.call(document
					.querySelectorAll('.hold-check:checked'), function(box) {
				return box.value;
			});
			if (!ids.length)
				return;
			var chain = Promise.resolve();
			ids.forEach(function(id) {
				chain = chain.then(function() {
					return fetch(ctx + '/sales/' + id, {
						method : 'DELETE'
					});
				});
			});
			chain.then(function() {
				return fetch(ctx + '/sales?status=hold');
			}).then(function(res) {
				return res.json();
			}).then(renderHolds);
		}
		var currencyBeforeAdd = '';
		function showCurrencyRate() {
			var sel = document.getElementById('currencySelect');
			var opt = sel.options[sel.selectedIndex];
			if (!opt || opt.value === 'add')
				return;
			document.getElementById('exchangeRate').value = opt
					.getAttribute('data-rate')
					|| '1';
		}
		// 통화 콤보에서 추가를 고르면 통화코드, 통화명, 환율을 입력하는 창을 연다. 닫으면 추가를 고르기 전 통화로 되돌린다.
		// 通貨コンボで追加を選ぶと通貨コード、通貨名、為替レートを入力する画面を開く。閉じると追加を選ぶ前の通貨に戻す。
		function onCurrencyChange(sel) {
			if (sel.value !== 'add') {
				currencyBeforeAdd = sel.value;
				showCurrencyRate();
				return;
			}
			document.getElementById('newCurrencyCode').value = '';
			document.getElementById('newCurrencyName').value = '';
			document.getElementById('newCurrencyRate').value = '';
			document.getElementById('currencyError').textContent = '';
			document.getElementById('currencyOverlay').classList.add('active');
			document.getElementById('newCurrencyName').focus();
		}
		function closeCurrencyModal() {
			document.getElementById('currencyOverlay').classList
					.remove('active');
			var sel = document.getElementById('currencySelect');
			if (sel.value === 'add')
				sel.value = currencyBeforeAdd;
		}
		function saveCurrency() {
			var name = document.getElementById('newCurrencyName').value.trim();
			var code = document.getElementById('newCurrencyCode').value.trim();
			var rate = document.getElementById('newCurrencyRate').value.trim();
			var error = document.getElementById('currencyError');
			if (!name) {
				error.textContent = '通貨名を入力してください。<%--통화명을 입력하세요.--%>';
				return;
			}
			if (code.toUpperCase() === 'KR') {
				error.textContent = 'KRは基本ウォンです。<%--KR은 기본 원화--%>';
				return;
			}
			if (!rate || isNaN(Number(rate.replace(/,/g, '')))) {
				error.textContent = '為替レートを入力してください。<%--환율을 입력하세요.--%>';
				return;
			}
			var body = 'currencyCode=' + encodeURIComponent(code)
					+ '&currencyName=' + encodeURIComponent(name)
					+ '&exchangeRate='
					+ encodeURIComponent(rate.replace(/,/g, ''));
			fetch(ctx + '/common/lookup/currencies', {
				method : 'POST',
				headers : {
					'Content-Type' : 'application/x-www-form-urlencoded'
				},
				body : body
			})
					.then(function(res) {
						return res.json().then(function(data) {
							return {
								ok : res.ok,
								data : data
							};
						});
					})
					.then(
							function(result) {
								if (!result.ok) {
									error.textContent = result.data.message
											|| '通貨を追加できませんでした。<%--통화를 추가하지 못했습니다.--%>';
									return;
								}
								var sel = document
										.getElementById('currencySelect');
								var opt = document.createElement('option');
								opt.value = result.data.currencyId;
								opt.textContent = result.data.currencyName;
								opt.setAttribute('data-code',
										result.data.currencyCode || '');
								opt.setAttribute('data-rate',
										result.data.exchangeRate);
								sel.insertBefore(opt, sel
										.querySelector('option[value="add"]'));
								sel.value = result.data.currencyId;
								currencyBeforeAdd = sel.value;
								showCurrencyRate();
								document.getElementById('currencyOverlay').classList
										.remove('active');
							});
		}
		// 저장, 보류, 저장/전표 전에 막는다. 거래처, 출하창고, 담당자 키가 없거나 품목이 없고, 품목 수량이 비었거나 0 이하면 전송하지 않는다.
		// 保存、保留、保存/伝票の前に止める。取引先、出荷倉庫、担当者キーがないか品目がなく、品目数量が空か0以下なら送信しない。
		function validateBeforeSave() {
			if (document.getElementById('currencySelect').value === 'add') {
				showResult('通貨を選択してください。<%--통화를 선택하세요.--%>');
				return false;
			}
			if (!document.getElementById('businessPartnerId').value) {
				showResult('取引先を選択してください。<%--거래처를 선택하세요.--%>');
				return false;
			}
			if (!document.getElementById('warehousePk').value) {
				showResult('出荷倉庫を選択してください。<%--출하창고를 선택하세요.--%>');
				return false;
			}
			if (!document.getElementById('managerId').value) {
				showResult('担当者を選択してください。<%--담당자를 선택하세요.--%>');
				return false;
			}
			var hasItem = false;
			var zeroQty = false;
			lineRows().forEach(
					function(tr) {
						var qtyCell = tr.querySelector('.line-qty').closest(
								'td');
						qtyCell.classList.remove('cell-bad');
						var itemPk = tr.querySelector('.line-item-pk').value;
						if (!itemPk)
							return;
						hasItem = true;
						var qtyText = String(
								tr.querySelector('.line-qty').value || '')
								.replace(/,/g, '').trim();
						if (qtyText === '' || num(qtyText) <= 0) {
							zeroQty = true;
							qtyCell.classList.add('cell-bad');
						}
					});
			if (!hasItem) {
				showResult('品目を入力してください。<%--품목을 입력하세요.--%>');
				return false;
			}
			if (zeroQty) {
				showResult('数量は0より大きい必要があります。<%--수량은 0보다 커야 합니다.--%>');
				return false;
			}
			return true;
		}
		// 저장, 화살표의 보류, 저장/전표가 같은 검사를 통과한 뒤에만 품목 줄을 서버로 보낸다. 품목이 없는 줄은 빼 둔다.
		// 保存、矢印の保留、保存/伝票は同じ検査を通った後だけ品目行をサーバへ送る。品目のない行は除いておく。
		// 신규는 POST /sales, 수정은 PUT /sales/{saleId} 로 저장하고 saleId를 받는다. 거래명세서는 저장/전표일 때만 연다.
		// 新規は POST /sales、修正は PUT /sales/{saleId} で保存して saleId を受け取る。取引明細書は保存/伝票のときだけ開く。
		// 다시 작성은 빈 판매입력이다. 모달 안이면 제목을 판매입력으로 되돌리고 embed를 유지한다.
		// 再作成は空の販売入力である。モーダル内なら題名を販売入力へ戻し、embedを維持する。
		function rewriteSale() {
			if (embedMode && window.parent && window.parent !== window)
				window.parent.postMessage({ type : 'sale-title', mode : 'new' }, '*');
			location.href = ctx + '/sales/sale/input' + (embedMode ? '?embed=1' : '');
		}
		// 리스트는 판매조회로 간다. 모달 안이면 프레임을 옮기지 않고 부모 모달을 닫게 한다.
		// リストは販売照会へ行く。モーダル内ならフレームを移さず、親モーダルを閉じさせる。
		function goInquiry(event) {
			if (embedMode && window.parent && window.parent !== window) {
				event.preventDefault();
				window.parent.postMessage({ type : 'sale-close' }, '*');
				return false;
			}
			return true;
		}
		function prepareSubmit(status, after) {
			if (!validateBeforeSave())
				return false;
			document.getElementById('voucherStatus').value = status;
			document.getElementById('afterSave').value = after;
			var index = 0;
			lineRows()
					.forEach(
							function(tr) {
								if (!tr.querySelector('.line-item-pk').value)
									return;
								[ 'line-qty', 'line-price', 'line-discount',
										'line-supply', 'line-vat', 'line-amt',
										'line-tot', 'line-wh' ]
										.forEach(function(cls) {
											var input = tr.querySelector('.'
													+ cls);
											if (input)
												input.value = String(
														input.value || '')
														.replace(/,/g, '');
										});
								[ [ 'line-item-pk', 'itemPk' ],
										// 화면에서 고친 품목코드, 품목명, 규격은 판매 품목에만 보낸다. 품목 마스터는 수정하지 않는다.
										// 画面で直した品目コード、品目名、規格は販売品目だけに送る。品目マスタは修正しない。
										[ 'line-item-code', 'itemCode' ],
										[ 'line-item-name', 'itemNm' ],
										[ 'line-spec', 'spec' ],
										[ 'line-qty', 'saleQty' ],
										[ 'line-price', 'unitPrice' ],
										[ 'line-discount', 'discountAmt' ],
										[ 'line-supply', 'supplyAmt' ],
										[ 'line-vat', 'vatAmt' ],
										[ 'line-amt', 'lineAmt' ],
										[ 'line-tot', 'totQty' ],
										[ 'line-wh', 'whQty' ] ]
										.forEach(function(pair) {
											var field = tr.querySelector('.' + pair[0]);
											if (field)
												field.name = 'items[' + index + '].' + pair[1];
										});
								var srcType = tr
										.querySelector('.line-src-type').value;
								tr.querySelectorAll('input[data-applied-qty]')
										.forEach(function(old) {
											old.parentNode.removeChild(old);
										});
								if (srcType) {
									tr.querySelector('.line-src-type').name = 'items['
											+ index + '].slipLink.srcType';
									tr.querySelector('.line-src-id').name = 'items['
											+ index + '].slipLink.srcItemId';
									var applied = document
											.createElement('input');
									applied.type = 'hidden';
									applied.setAttribute('data-applied-qty', '1');
									applied.name = 'items[' + index
											+ '].slipLink.appliedQty';
									applied.value = tr
											.querySelector('.line-qty').value;
									tr.appendChild(applied);
								}
								index++;
							});
			var form = document.getElementById('saleForm');
			var saleId = (form.querySelector('[name="header.saleId"]').value || '').trim();
			fetch(ctx + (saleId ? '/sales/' + saleId : '/sales'), {
				method : saleId ? 'PUT' : 'POST',
				headers : {
					'Content-Type' : 'application/x-www-form-urlencoded',
					'Accept' : 'application/json'
				},
				body : new URLSearchParams(new FormData(form)).toString()
			}).then(function(res) {
				return res.json().then(function(body) {
					return { ok : res.ok, body : body || {} };
				}, function() {
					return { ok : res.ok, body : {} };
				});
			}).then(function(result) {
				if (!result.ok) {
					showResult(result.body.message || '保存できませんでした。<%--저장하지 못했습니다.--%>');
					return;
				}
				if (after === 'statement')
					location.href = ctx + '/sales/sale/input/statement?saleId=' + result.body.saleId
							+ (embedMode ? '&embed=1' : '');
				else if (embedMode && window.parent && window.parent !== window)
					window.parent.postMessage({ type : 'sale-saved', saleId : result.body.saleId }, '*');
				else
					location.href = ctx + '/sales/sale/input';
			}).catch(function() {
				showResult('保存できませんでした。<%--저장하지 못했습니다.--%>');
			});
			return false;
		}
		currencyBeforeAdd = document.getElementById('currencySelect').value;
		if (document.getElementById('businessPartnerId').value) {
			document.getElementById('businessPartnerCode').dataset.matched = document
					.getElementById('businessPartnerCode').value.trim();
			document.getElementById('businessPartnerName').dataset.matched = document
					.getElementById('businessPartnerName').value.trim();
			document.getElementById('businessPartnerName').dataset.code = document
					.getElementById('businessPartnerCode').value.trim();
		}
		if (document.getElementById('managerId').value) {
			document.getElementById('employeeCode').dataset.matched = document
					.getElementById('employeeCode').value.trim();
			document.getElementById('employeeName').dataset.matched = document
					.getElementById('employeeName').value.trim();
		}
		if (document.getElementById('warehousePk').value) {
			document.getElementById('warehouseCode').dataset.matched = document
					.getElementById('warehouseCode').value.trim();
			document.getElementById('warehouseName').dataset.matched = document
					.getElementById('warehouseName').value.trim();
			document.getElementById('warehouseName').dataset.code = document
					.getElementById('warehouseCode').value.trim();
		}
		sumFooter();
		padRows();
		ensureBlankRow();
	</script>

	<style>
body.sale-embed {
	margin: 0;
	overflow: auto;
	height: auto
}

body.sale-embed .erp-sidebar {
	display: none !important
}

body.sale-embed .erp-wrapper,
body.sale-embed .erp-main {
	height: auto;
	overflow: visible
}

.page-title {
	font-size: 1.25rem;
	font-weight: 700;
	color: var(- -text-main, #0B1026);
	margin-bottom: 20px;
	display: flex;
	align-items: center;
	gap: 10px
}

.page-title i {
	color: var(- -color-blue, #4B88FF);
	font-size: 24px
}

.erp-main, .erp-content {
	min-width: 0
}

.list-wrap {
	background: #fff;
	border-radius: 14px;
	border: 1px solid var(- -border-color, #e2e8f0);
	box-shadow: var(- -shadow-soft, 0 10px 25px -5px rgba(75, 136, 255, .08));
	overflow: hidden;
	min-width: 0;
	width: 100%
}

.btn-primary-sm, .btn-flat-sm {
	display: inline-flex;
	align-items: center;
	justify-content: center;
	gap: 4px;
	cursor: pointer;
	border-radius: 8px;
	font-weight: 700;
	text-decoration: none
}

.btn-primary-sm {
	background: var(- -color-blue, #4B88FF);
	color: #fff;
	border: none;
	font-size: 13px;
	padding: 8px 14px
}

.btn-primary-sm:hover {
	background: var(- -color-navy, #1F3C88)
}

.btn-flat-sm {
	background: #f8fafc;
	border: 1px solid var(- -border-color, #e2e8f0);
	color: var(- -text-sub, #64748b);
	font-size: 13px;
	padding: 8px 14px
}

.btn-flat-sm:hover {
	background: #eef2f7
}

.sale-head {
	display: grid;
	grid-template-columns: 1fr 1fr;
	gap: 12px 28px;
	padding: 22px 22px 8px
}

.sale-field {
	display: grid;
	grid-template-columns: 88px 1fr;
	align-items: center;
	gap: 10px
}

.sale-field label {
	font-weight: 700;
	color: var(- -text-main, #0B1026);
	font-size: 13px
}

.sale-popup, .line-code {
	display: flex;
	align-items: center;
	gap: 6px
}

.sale-popup input, .line-code input {
	flex: 1
}

.sale-popup .header-code {
	flex: 0 0 110px;
	width: 110px
}

.popup-search-btn {
	width: 34px;
	height: 34px;
	flex: none;
	border: 1px solid #cbd5e1;
	border-radius: 8px;
	background: #f8fafc;
	color: #1f3c88;
	cursor: pointer
}

.sale-field input, .sale-field select {
	width: 100%;
	border: 1px solid var(- -border-color, #e2e8f0);
	border-radius: 8px;
	padding: 9px 12px;
	font-size: 13px;
	outline: none;
	background: #fff;
	color: var(- -text-main, #0B1026)
}

.sale-field input:focus, .sale-field select:focus {
	border-color: var(- -color-blue, #4B88FF)
}

.sale-buttons {
	display: flex;
	flex-wrap: wrap;
	gap: 8px;
	align-items: center;
	padding: 8px 22px 16px
}

.grid-find-input {
	border: 1px solid var(- -border-color, #e2e8f0);
	border-radius: 8px;
	padding: 8px 12px;
	font-size: 13px;
	width: 180px;
	outline: none
}

.grid-find-input:focus {
	border-color: var(- -color-blue, #4B88FF)
}

.list-table td.cell-found {
	background: #fff3bf
}

.list-table td.cell-found input {
	background: #fff3bf
}

.list-table-wrap {
	width: 100%;
	overflow-x: auto
}

.list-table {
	width: 100%;
	border-collapse: collapse;
	table-layout: fixed
}

.list-table th, .list-table td {
	border-top: 1px solid var(- -border-color, #e2e8f0);
	border-bottom: 1px solid var(- -border-color, #e2e8f0);
	padding: 8px 10px;
	font-size: 13px;
	text-align: left
}

#saleGrid th, #saleGrid td {
	border: 1px solid #94a3b8
}

.list-table th {
	background: #f8fafc;
	font-weight: 700;
	color: var(- -text-sub, #64748b)
}

.list-table .col-num, .list-table th.col-num {
	text-align: right
}

.list-table input {
	width: 100%;
	border: none;
	background: transparent;
	font-size: 13px;
	outline: none;
	color: var(--text-main, #0B1026)
}

.list-table input.line-check {
	width: auto
}

.list-table tfoot td {
	font-weight: 700;
	background: #fff
}

.sale-foot {
	display: flex;
	flex-wrap: wrap;
	gap: 8px;
	align-items: center;
	padding: 16px 22px 22px
}

.save-split {
	position: relative;
	display: inline-flex
}

.save-main {
	border-radius: 8px 0 0 8px
}

.save-arrow {
	border-radius: 0 8px 8px 0;
	border-left: 1px solid rgba(255, 255, 255, .35);
	padding: 8px 8px
}

.save-menu {
	display: none;
	position: absolute;
	left: 0;
	bottom: 42px;
	min-width: 120px;
	background: #fff;
	border: 1px solid #e2e8f0;
	border-radius: 8px;
	box-shadow: 0 8px 20px rgba(11, 16, 38, .12);
	overflow: hidden;
	z-index: 20
}

.save-menu.open {
	display: block
}

.history-menu {
	top: calc(100% + 4px);
	bottom: auto
}

.history-split .save-main {
	border-right: none
}

.history-split .save-arrow {
	border-left: 1px solid #e2e8f0;
	color: #64748b
}

.slip-inquiry-overlay {
	z-index: 1300
}

.slip-load-chooser {
	width: min(360px, 96vw)
}

.slip-load-choices {
	display: grid;
	grid-template-columns: 1fr 1fr;
	gap: 10px;
	padding: 18px
}

.slip-load-choices button {
	height: 44px;
	border: 1px solid #d7e0ec;
	border-radius: 8px;
	background: #fff;
	font-weight: 700;
	cursor: pointer
}

.slip-load-choices button:hover {
	background: #f7faff
}

/* 카드 높이를 정해 두고 iframe이 남은 칸을 채운다. 높이가 없으면 iframe이 납작해진다. */
/* カードの高さを決め、iframeが残りの欄を埋める。高さがないとiframeが潰れる。 */
.slip-load-view {
	width: min(1100px, 96vw);
	height: min(82vh, 900px);
	display: flex;
	flex-direction: column;
	overflow: hidden
}

.slip-load-frame {
	flex: 1;
	width: 100%;
	border: 0;
	background: #fff
}

.save-menu button {
	display: block;
	width: 100%;
	text-align: left;
	background: #fff;
	border: none;
	padding: 10px 14px;
	font-weight: 700;
	cursor: pointer
}

.save-menu button:hover {
	background: #f7faff
}

.hold-card {
	width: min(860px, 96vw)
}

.currency-pair {
	display: flex;
	gap: 8px;
	min-width: 0
}

.currency-pair select, .currency-pair input {
	flex: 1;
	min-width: 0
}

.currency-card {
	width: min(420px, 96vw)
}

.currency-form {
	display: grid;
	grid-template-columns: 88px 1fr;
	gap: 12px 10px;
	align-items: center;
	padding: 18px
}

.currency-form label {
	font-weight: 700;
	font-size: 13px;
	color: #0B1026
}

.currency-form input {
	border: 1px solid #e2e8f0;
	border-radius: 8px;
	padding: 9px 12px;
	font-size: 13px;
	outline: none
}

.currency-form input:focus {
	border-color: #4B88FF
}

.currency-error {
	grid-column: 1/-1;
	margin: 0;
	color: #b91c1c;
	font-size: 13px;
	min-height: 18px
}

.hold-note {
	padding: 12px 18px 0;
	color: #64748b;
	font-size: 13px
}

.hold-no {
	border: none;
	background: transparent;
	color: #1F3C88;
	font-weight: 700;
	cursor: pointer
}

.hold-message {
	padding: 0 0 12px
}

.sale-result {
	padding: 0 22px 18px;
	color: #0B1026;
	font-size: 13px
}

.sale-result table {
	width: 100%;
	border-collapse: collapse
}

.sale-result th, .sale-result td {
	border-bottom: 1px solid #e2e8f0;
	padding: 8px;
	text-align: left
}

.list-table td.cell-bad {
	background: #fee2e2
}

#discountOverlay {
	z-index: 1300;
	align-items: flex-start;
	padding: 4vh 16px
}

.discount-card {
	width: min(1280px, 98vw);
	background: #fff;
	border-radius: 8px;
	overflow: hidden;
	box-shadow: 0 24px 60px rgba(11, 16, 38, .28)
}

.discount-titlebar {
	height: 36px;
	background: #2f6bff;
	color: #fff;
	display: flex;
	align-items: center;
	justify-content: space-between;
	padding: 0 8px 0 14px;
	font-size: 13px;
	font-weight: 700
}

.discount-close {
	border: 0;
	background: transparent;
	color: #fff;
	font-size: 18px;
	cursor: pointer
}

.discount-body {
	padding: 16px 18px 8px
}

.discount-body h3 {
	margin: 0 0 14px;
	font-size: 18px;
	color: #0B1026
}

.discount-head {
	display: grid;
	grid-template-columns: 72px 110px minmax(140px, 1fr) 72px 110px minmax(140px, 1fr);
	gap: 8px 8px;
	align-items: center;
	margin-bottom: 12px
}

.discount-head label {
	font-size: 13px;
	font-weight: 700;
	color: #334155
}

.discount-head input {
	height: 32px;
	border: 1px solid #dbe3ee;
	border-radius: 4px;
	padding: 0 8px;
	background: #f8fafc;
	color: #0B1026
}

#discountCurrency {
	grid-column: 2/4
}

#discountSaleType {
	grid-column: 5/7
}

.discount-tools {
	display: flex;
	align-items: center;
	gap: 8px;
	flex-wrap: wrap;
	padding: 8px 0 12px;
	font-size: 13px;
	color: #334155
}

.discount-tools select, .discount-tools input[type="text"] {
	height: 32px;
	border: 1px solid #dbe3ee;
	border-radius: 4px;
	padding: 0 8px
}

.discount-tools input[type="text"] {
	width: 90px
}

.discount-direct {
	height: 32px;
	border: 1px solid #2f6bff;
	border-radius: 4px;
	background: #eef4ff;
	color: #1d4ed8;
	font-weight: 700;
	padding: 0 10px
}

.discount-apply {
	display: flex;
	align-items: center;
	gap: 12px;
	margin-right: 8px
}

.discount-table-wrap {
	overflow: auto;
	max-height: 360px;
	border-top: 1px solid #e2e8f0
}

.discount-table input {
	width: auto
}

.discount-table {
	width: 100%;
	min-width: 0;
	table-layout: fixed
}

.discount-table th, .discount-table td {
	padding: 6px 4px;
	overflow: hidden;
	text-overflow: ellipsis;
	border: 1px solid #94a3b8
}

.discount-table thead th {
	background: #2f6bff;
	color: #fff;
	font-size: 11px;
	font-weight: 700;
	line-height: 1.25;
	text-align: center;
	white-space: normal;
	vertical-align: middle;
	border-color: rgba(255, 255, 255, .55)
}

.discount-table tbody td {
	background: #f3f8ff;
	font-size: 12px;
	white-space: nowrap
}

.discount-table th:nth-child(1), .discount-table td:nth-child(1),
.discount-table th:nth-child(2), .discount-table td:nth-child(2) {
	text-align: center;
	padding-left: 0;
	padding-right: 0
}

.discount-table th:nth-child(3), .discount-table td:nth-child(3),
.discount-table th:nth-child(4), .discount-table td:nth-child(4) {
	text-align: left
}

.discount-no {
	display: inline-flex;
	width: 22px;
	height: 22px;
	border-radius: 50%;
	background: #2f6bff;
	color: #fff;
	align-items: center;
	justify-content: center;
	font-size: 12px;
	font-weight: 700
}

.discount-foot {
	display: flex;
	gap: 8px;
	padding: 12px 18px 16px
}
</style>
</body>
</html>
