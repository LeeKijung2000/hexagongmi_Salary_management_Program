package org.sales.sale.dto;

import java.util.Date;

import lombok.Data;

/**
 * 판매 이력조회 조건. 판매입력1은 NORMAL, 판매입력2는 POS다. saleId가 있으면 그 전표만 본다.
 * 販売履歴照会の条件。販売入力1は NORMAL、販売入力2は POS である。saleIdがあればその伝票だけ見る。
 */
@Data
public class SaleHistorySearchDTO {

	private Date fromDate;
	private Date toDate;
	/** NORMAL 또는 POS. 비어 있으면 입력 구분을 가리지 않는다. 空なら入力区分を問わない。 */
	private String inputType;
	private Long saleId;
	private String keyword;
}
