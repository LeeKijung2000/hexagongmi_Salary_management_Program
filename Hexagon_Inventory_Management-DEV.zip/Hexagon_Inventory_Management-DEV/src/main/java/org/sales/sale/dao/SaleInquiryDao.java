package org.sales.sale.dao;

import java.math.BigDecimal;
import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.sales.sale.dto.LoadedSlipDTO;
import org.sales.sale.dto.SaleHistorySearchDTO;
import org.sales.sale.dto.SaleHistorySnapDTO;
import org.sales.sale.dto.SaleSlipHistorySourceDTO;
import org.sales.sale.dto.SaleInquiryHeaderDTO;
import org.sales.sale.dto.SaleInquiryRowDTO;
import org.sales.sale.dto.SaleInquirySearchDTO;
import org.sales.sale.dto.SaleStockLineDTO;
import org.sales.sale.dto.VoucherHistoryDTO;

/**
 * 판매조회 Dao. 목록은 TB_SALE이고, 확정은 진행상태와 수불, 이력을 남긴다. 선택삭제는 전표와 품목, 연결을 지우고 취소 이력만 추가한다.
 * 販売照会 Dao。一覧は TB_SALE であり、確定は進行状態と受払、履歴を残す。選択削除は伝票と品目、接続を消し、取消履歴だけ追加する。
 */
public interface SaleInquiryDao {

	/** 검색 조건에 맞는 판매 건수. 보류, 취소, 반품은 세지 않는다.
	 *  検索条件に合う販売件数。保留、取消、返品は数えない。 */
	int countSales(SaleInquirySearchDTO search);

	/** 한 페이지의 판매 목록. 판매일자, 판매번호 내림차순이다.
	 *  1ページの販売一覧。販売日付、販売番号の降順である。 */
	List<SaleInquiryRowDTO> selectSales(SaleInquirySearchDTO search);

	/** 확정이나 삭제 전에 헤더를 잠근다. 없으면 null.
	 *  確定や削除の前にヘッダをロックする。なければ null。 */
	SaleInquiryHeaderDTO lockSale(@Param("saleId") Long saleId);

	/** 그 판매의 품목 수량과 재고관리여부. 수불과 재고 복원에 쓴다.
	 *  その販売の品目数量と在庫管理可否。受払と在庫復元に使う。 */
	List<SaleStockLineDTO> selectStockLines(@Param("saleId") Long saleId);

	/** 진행상태를 바꾼다. 기대하던 상태일 때만 1을 반환한다.
	 *  進行状態を変える。期待していた状態のときだけ 1 を返す。 */
	int updateProgress(@Param("saleId") Long saleId, @Param("progressStatus") String progressStatus,
			@Param("expectedStatus") String expectedStatus);

	/** 이 판매에 남긴 수불 건수. movementType은 SALE 또는 SALE_CANCEL이다.
	 *  この販売に残した受払件数。movementTypeは SALE または SALE_CANCEL である。 */
	int countMovements(@Param("saleId") Long saleId, @Param("movementType") String movementType);

	/** 수불 한 줄. 수량 증감이 0이면 넣지 않는다.
	 *  受払1行。数量増減が 0 なら入れない。 */
	int insertMovement(@Param("warehouseId") Long warehouseId, @Param("itemId") Long itemId,
			@Param("movementType") String movementType, @Param("quantityChange") BigDecimal quantityChange,
			@Param("saleId") Long saleId);

	/** 출하창고 재고에 delta를 더한다. 선택삭제는 양수로 판매입력1이 뺀 수량을 되돌린다.
	 *  出荷倉庫の在庫に delta を足す。選択削除は正数で販売入力1が引いた数量を戻す。 */
	int adjustInventory(@Param("warehouseId") Long warehouseId, @Param("itemId") Long itemId,
			@Param("delta") BigDecimal delta);

	/** 연결과 품목, 조정, 결제, 헤더를 지운다. 기존 이력은 지우지 않는다.
	 *  接続と品目、調整、決済、ヘッダを消す。既存の履歴は消さない。 */
	int deleteSaleGraph(@Param("saleId") Long saleId);

	/** 이력 한 줄. 작업자는 로그인 사용자가 없어 비워 두고, 진행상태만 같이 남긴다.
	 *  履歴1行。作業者はログインユーザーがいないので空にし、進行状態だけ一緒に残す。 */
	int insertHistory(@Param("saleId") Long saleId, @Param("actionType") String actionType,
			@Param("afterStatus") String afterStatus, @Param("description") String description);

	/** 삭제 전에 거래처, 품목, 담당자, 진행상태를 읽는다. 削除の前に取引先、品目、担当者、進行状態を読む。 */
	SaleHistorySnapDTO selectSnapshot(@Param("saleId") Long saleId);

	/** 이미 있는 이력에 전표 모습을 붙인다. 전표를 지운 뒤에도 신규, 수정 행이 내용을 갖게 한다.
	 *  既にある履歴に伝票の姿を付ける。伝票を消したあとも新規、修正の行が内容を持つようにする。 */
	int attachSnapshot(@Param("saleId") Long saleId, @Param("snapshot") String snapshot);

	/** 신규, 수정, 삭제 이력. 판매입력 구분과 기간, 한 전표로 좁힌다.
	 *  新規、修正、削除の履歴。販売入力の区分と期間、1伝票で絞る。 */
	List<VoucherHistoryDTO> selectHistory(SaleHistorySearchDTO search);

	/** 한 전표의 이력 줄. 작업일시 오름차순이고 확인, 미확인 변경도 포함한다.
	 *  1伝票の履歴行。作業日時の昇順であり、確認、未確認の変更も含む。 */
	List<SaleSlipHistorySourceDTO> selectSlipHistory(@Param("saleId") Long saleId);

	/** 주문, 견적, 원판매 연결. 연결이 없으면 빈 목록이다.
	 *  注文、見積、元販売の接続。接続がなければ空の一覧である。 */
	List<LoadedSlipDTO> selectSources(@Param("saleId") Long saleId);
}
