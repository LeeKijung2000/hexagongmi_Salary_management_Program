package org.sales.sale.controller;

import java.util.HashMap;
import java.util.Map;

import org.sales.sale.dto.PaymentInquiryDetailDTO;
import org.sales.sale.dto.PaymentInquiryResultDTO;
import org.sales.sale.dto.PaymentInquirySaveDTO;
import org.sales.sale.dto.PaymentInquirySearchDTO;
import org.sales.sale.service.PaymentInquiryService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/sales/sale")
@AllArgsConstructor
/**
 * 결제내역조회 화면. 목록, 상세, 신규, 재결제는 이 주소에서 처리한다.
 * 決済履歴照会画面。一覧、詳細、新規、再決済はこのアドレスで処理する。
 */
public class PaymentInquiryController {

	private PaymentInquiryService service;

	/** 결제내역조회 화면. 전체 탭이 처음 선택이고, 목록은 화면이 열리며 조회한다.
	 *  決済履歴照会画面。全体タブが最初の選択であり、一覧は画面が開くと照会する。 */
	@GetMapping("/payment-inquiry")
	public String paymentInquiry() {
		return "sales/sale/payment-inquiry";
	}

	/** 전체 목록. 검색어가 길면 400과 메시지를 돌려준다.
	 *  全体一覧。検索語が長ければ 400 とメッセージを返す。 */
	@GetMapping("/payment-inquiry/list")
	@ResponseBody
	public ResponseEntity<?> list(PaymentInquirySearchDTO search) {
		log.info("payment-inquiry list " + search);
		try {
			PaymentInquiryResultDTO body = service.search(search);
			return new ResponseEntity<PaymentInquiryResultDTO>(body, HttpStatus.OK);
		} catch (IllegalArgumentException e) {
			return error(e.getMessage());
		}
	}

	/** 내역. 선택 결제 한 건이다.
	 *  内訳。選択した決済1件である。 */
	@GetMapping("/payment-inquiry/detail")
	@ResponseBody
	public ResponseEntity<?> detail(@RequestParam("paymentId") Long paymentId) {
		log.info("payment-inquiry detail " + paymentId);
		try {
			PaymentInquiryDetailDTO body = service.detail(paymentId);
			return new ResponseEntity<PaymentInquiryDetailDTO>(body, HttpStatus.OK);
		} catch (IllegalArgumentException e) {
			return error(e.getMessage());
		}
	}

	/** 신규 등록. TB_PAYMENT 한 건을 넣고 판매입력으로 보내지 않는다.
	 *  新規登録。TB_PAYMENT を1件入れ、販売入力へ送らない。 */
	@PostMapping("/payment-inquiry")
	@ResponseBody
	public ResponseEntity<?> create(@RequestBody PaymentInquirySaveDTO save) {
		log.info("payment-inquiry create " + save);
		try {
			PaymentInquiryDetailDTO body = service.create(save);
			return new ResponseEntity<PaymentInquiryDetailDTO>(body, HttpStatus.OK);
		} catch (IllegalArgumentException e) {
			return error(e.getMessage());
		}
	}

	/** 재결제. 승인실패와 취소만 새 결제로 넣는다.
	 *  再決済。承認失敗と取消だけ新しい決済として入れる。 */
	@PostMapping("/payment-inquiry/repay")
	@ResponseBody
	public ResponseEntity<?> repay(@RequestParam("paymentId") Long paymentId) {
		log.info("payment-inquiry repay " + paymentId);
		try {
			PaymentInquiryDetailDTO body = service.repay(paymentId);
			return new ResponseEntity<PaymentInquiryDetailDTO>(body, HttpStatus.OK);
		} catch (IllegalArgumentException e) {
			return error(e.getMessage());
		}
	}

	/** 검증에서 막힌 일본어 메시지를 400으로 돌려 화면 문구에 그대로 보여 준다.
	 *  検証で止めた日本語メッセージを 400 で返し、画面の文言にそのまま出す。 */
	private ResponseEntity<Map<String, Object>> error(String message) {
		Map<String, Object> body = new HashMap<String, Object>();
		body.put("message", message);
		return new ResponseEntity<Map<String, Object>>(body, HttpStatus.BAD_REQUEST);
	}
}
