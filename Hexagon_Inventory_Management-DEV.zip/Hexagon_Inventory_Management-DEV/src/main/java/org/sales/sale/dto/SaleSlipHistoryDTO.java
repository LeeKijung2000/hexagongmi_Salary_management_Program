package org.sales.sale.dto;

import java.util.List;

import lombok.Data;

/**
 * 이력 H를 눌렀을 때의 전표 이력. 제목은 일자-No이고 줄은 시간순이다.
 * 履歴 H を押したときの伝票履歴。題名は日付-Noであり、行は時刻順である。
 */
@Data
public class SaleSlipHistoryDTO {

	/** yyyy/MM/dd-당일순번. 年/月/日-当日の伝票番号。 */
	private String dateNo;
	private List<SaleSlipHistoryLineDTO> rows;
}
