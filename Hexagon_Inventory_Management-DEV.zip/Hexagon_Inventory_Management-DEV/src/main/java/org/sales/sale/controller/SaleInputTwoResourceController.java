package org.sales.sale.controller;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.sales.sale.dto.HoldSlipDTO;
import org.sales.sale.dto.SaleInputTwoDTO;
import org.sales.sale.service.SaleInputTwoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/sales/input2")
@AllArgsConstructor
/**
 * 판매입력2 전표 자원. 신규는 POST /sales/input2, 수정은 PUT /sales/input2/{saleId} 이다.
 * 판매입력1의 /sales 와 주소를 나누어 같은 저장 주소가 겹치지 않게 한다.
 * 販売入力2の伝票資源。新規は POST /sales/input2、修正は PUT /sales/input2/{saleId} である。
 * 販売入力1の /sales とアドレスを分け、同じ保存アドレスが重ならないようにする。
 */
public class SaleInputTwoResourceController {

	private SaleInputTwoService service;

	/** 보류 목록. status=hold 일 때만 POS 보류 전표를 돌려준다.
	 *  保留一覧。status=hold のときだけ POS の保留伝票を返す。 */
	@GetMapping(params = "status=hold")
	@ResponseBody
	public List<HoldSlipDTO> holds() {
		return service.getHolds();
	}

	/** 보류전표 한 건을 입력란에 채운다. 이 조회는 행을 지우지 않는다.
	 *  保留伝票1件を入力欄に入れる。この照会は行を消さない。 */
	@GetMapping("/{saleId}")
	@ResponseBody
	public SaleInputTwoDTO get(@PathVariable("saleId") Long saleId) {
		return service.takeHold(saleId);
	}

	/** 신규 저장. 201과 saleId를 돌려주고 화면 이동은 브라우저가 한다.
	 *  新規保存。201 と saleId を返し、画面移動はブラウザが行う。 */
	@PostMapping
	@ResponseBody
	public ResponseEntity<Map<String, Object>> create(SaleInputTwoDTO sale) {
		log.info("create sale input2: " + sale);
		return save(sale, false);
	}

	/** 기존 전표 수정. 경로의 saleId를 헤더에 넣고 같은 검사로 저장한다.
	 *  既存伝票の修正。パスの saleId をヘッダに入れて同じ検査で保存する。 */
	@PutMapping("/{saleId}")
	@ResponseBody
	public ResponseEntity<Map<String, Object>> update(@PathVariable("saleId") Long saleId, SaleInputTwoDTO sale) {
		log.info("update sale input2: " + saleId);
		if (sale.getHeader() == null) {
			return error("保存する内容がありません。"); // 저장할 내용이 없습니다.
		}
		sale.getHeader().setSaleId(saleId);
		return save(sale, true);
	}

	/** 보류 전표 한 건 삭제. 금액조정, 품목, 이력, 헤더 순서로 지운다.
	 *  保留伝票1件の削除。金額調整、品目、履歴、ヘッダの順に消す。 */
	@DeleteMapping("/{saleId}")
	@ResponseBody
	public ResponseEntity<Void> delete(@PathVariable("saleId") Long saleId) {
		service.deleteHolds(Collections.singletonList(saleId));
		return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
	}

	private ResponseEntity<Map<String, Object>> save(SaleInputTwoDTO sale, boolean modify) {
		if (sale.getHeader() == null) {
			return error("保存する内容がありません。"); // 저장할 내용이 없습니다.
		}
		boolean hold = "保留".equals(sale.getHeader().getVoucherStatus()); // 보류
		boolean isNew = !modify && sale.getHeader().getSaleId() == null;
		// 보류 상태 전표가 이미 5개이면 새 보류 저장만 막는다. 이미 있는 보류전표를 다시 보류로 저장하는 경우는 개수에 넣지 않는다.
		// 保留状態の伝票が既に5件なら新しい保留保存だけ止める。既にある保留伝票を再び保留で保存する場合は件数に入れない。
		if (hold && isNew && service.countHolds() >= 5) {
			return error("保留伝票は最大5件まで保存されます。"); // 보류전표는 최대 5개까지만 저장됩니다.
		}
		try {
			if (modify) {
				if (!service.modify(sale)) {
					return error("保存できませんでした。"); // 저장하지 못했습니다.
				}
			} else {
				service.register(sale);
			}
		} catch (IllegalArgumentException e) {
			return error(e.getMessage());
		}
		Map<String, Object> body = new HashMap<String, Object>();
		body.put("saleId", sale.getHeader().getSaleId());
		HttpStatus status = modify ? HttpStatus.OK : HttpStatus.CREATED;
		return new ResponseEntity<Map<String, Object>>(body, status);
	}

	private ResponseEntity<Map<String, Object>> error(String message) {
		Map<String, Object> body = new HashMap<String, Object>();
		body.put("message", message);
		return new ResponseEntity<Map<String, Object>>(body, HttpStatus.BAD_REQUEST);
	}
}
