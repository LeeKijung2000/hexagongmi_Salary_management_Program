package org.sales.sale.service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.sales.sale.dao.SaleInquiryDao;
import org.sales.sale.dto.LoadedSlipDTO;
import org.sales.sale.dto.SaleHistorySearchDTO;
import org.sales.sale.dto.SaleHistorySnapDTO;
import org.sales.sale.dto.SaleSlipHistoryDTO;
import org.sales.sale.dto.SaleSlipHistoryLineDTO;
import org.sales.sale.dto.SaleSlipHistorySourceDTO;
import org.sales.sale.dto.SaleInquiryHeaderDTO;
import org.sales.sale.dto.SaleInquiryPageDTO;
import org.sales.sale.dto.SaleInquiryRowDTO;
import org.sales.sale.dto.SaleInquirySearchDTO;
import org.sales.sale.dto.SaleStockLineDTO;
import org.sales.sale.dto.VoucherHistoryDTO;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
@AllArgsConstructor
/**
 * 판매조회 처리. 조회는 읽기 전용이고, 확정과 선택삭제는 진행상태, 수불, 재고, 이력을 한 트랜잭션으로 맞춘다.
 * 販売照会の処理。照会は読取専用であり、確定と選択削除は進行状態、受払、在庫、履歴を一つのトランザクションで合わせる。
 */
public class SaleInquiryServiceImpl implements SaleInquiryService {

	private SaleInquiryDao mapper;

	@Override
	@Transactional(readOnly = true)
	public SaleInquiryPageDTO search(Date fromDate, Date toDate, String tab, String keyword, int page) {
		log.info("search......" + fromDate + " " + toDate + " " + tab + " " + keyword + " page " + page);
		checkPeriod(fromDate, toDate);
		SaleInquirySearchDTO search = new SaleInquirySearchDTO();
		search.setFromDate(fromDate);
		search.setToDate(toDate);
		search.setProgressStatus(progressCode(tab));
		search.setKeyword(blankToNull(keyword));
		int total = mapper.countSales(search);
		int pages = total == 0 ? 1 : (total + PAGE_SIZE - 1) / PAGE_SIZE;
		if (page < 1) {
			page = 1;
		}
		if (page > pages) {
			page = pages;
		}
		search.setStartRow((page - 1) * PAGE_SIZE + 1);
		search.setEndRow(page * PAGE_SIZE);
		SaleInquiryPageDTO result = new SaleInquiryPageDTO();
		result.setPage(page);
		result.setPageSize(PAGE_SIZE);
		result.setTotalCount(total);
		result.setTotalPages(pages);
		List<SaleInquiryRowDTO> rows = total == 0 ? new ArrayList<SaleInquiryRowDTO>() : mapper.selectSales(search);
		result.setRows(rows);
		return result;
	}

	@Override
	@Transactional
	public void changeProgress(List<Long> saleIds, String progressStatus) {
		log.info("changeProgress......" + saleIds + " " + progressStatus);
		List<Long> ids = requireIds(saleIds);
		boolean confirm = "CONFIRMED".equals(progressStatus);
		boolean unconfirm = "UNCONFIRMED".equals(progressStatus);
		if (!confirm && !unconfirm) {
			throw new IllegalArgumentException("進行状態が正しくありません。"); // 진행상태가 올바르지 않습니다.
		}
		int changed = 0;
		for (Long saleId : ids) {
			if (confirm && confirmOne(saleId)) {
				changed++;
			}
			if (unconfirm && unconfirmOne(saleId)) {
				changed++;
			}
		}
		if (changed == 0) {
			throw new IllegalArgumentException("変更する販売がありません。"); // 변경할 판매가 없습니다.
		}
	}

	@Override
	@Transactional
	public void deleteSelected(List<Long> saleIds) {
		log.info("deleteSelected......" + saleIds);
		for (Long saleId : requireIds(saleIds)) {
			deleteOne(saleId);
		}
	}

	@Override
	@Transactional(readOnly = true)
	public List<VoucherHistoryDTO> searchHistory(Date fromDate, Date toDate, String inputType, Long saleId,
			String keyword) {
		log.info("searchHistory......" + inputType + " " + saleId + " " + keyword);
		String type = historyInputType(inputType);
		if (saleId == null && type == null) {
			throw new IllegalArgumentException("販売を選択してください。"); // 판매를 선택하세요.
		}
		SaleHistorySearchDTO search = new SaleHistorySearchDTO();
		// 한 전표를 고르면 그 전표의 신규, 수정, 삭제를 기간과 상관없이 본다.
		// 1伝票を選ぶとその伝票の新規、修正、削除を期間に関係なく見る。
		if (saleId == null) {
			search.setFromDate(fromDate);
			search.setToDate(toDate);
			search.setInputType(type);
		}
		search.setSaleId(saleId);
		search.setKeyword(blankToNull(keyword));
		List<VoucherHistoryDTO> rows = mapper.selectHistory(search);
		for (VoucherHistoryDTO row : rows) {
			fillDeletedSnapshot(row);
			row.setActionName(actionName(row.getActionType()));
			if (row.getWorkerName() == null) {
				row.setWorkerName("GUEST");
			}
			row.setDescription(null);
		}
		return rows;
	}

	@Override
	@Transactional(readOnly = true)
	public SaleSlipHistoryDTO slipHistory(Long saleId) {
		log.info("slipHistory......" + saleId);
		if (saleId == null) {
			throw new IllegalArgumentException("販売を選択してください。"); // 판매를 선택하세요.
		}
		List<SaleSlipHistorySourceDTO> sources = mapper.selectSlipHistory(saleId);
		SaleSlipHistoryDTO page = new SaleSlipHistoryDTO();
		page.setDateNo(slipDateNo(sources));
		List<SaleSlipHistoryLineDTO> rows = new ArrayList<SaleSlipHistoryLineDTO>();
		// 이 창에 남기는 이력은 작업일시, 진행상태, 상태뿐이다. 작업자는 로그인 사용자가 없어 GUEST다.
		// この窓に残す履歴は作業日時、進行状態、状態だけである。作業者はログインユーザーがいないので GUEST である。
		for (SaleSlipHistorySourceDTO source : sources) {
			String progress = slipProgress(source);
			SaleSlipHistoryLineDTO line = new SaleSlipHistoryLineDTO();
			line.setWorkerName("GUEST");
			line.setWorkedAt(formatWorkedAt(source.getWorkedAt()));
			line.setSlipStatusName(progress);
			line.setProgressName(progress);
			line.setActionName(slipActionName(source));
			rows.add(line);
		}
		page.setRows(rows);
		return page;
	}

	@Override
	@Transactional(readOnly = true)
	public List<LoadedSlipDTO> getSources(Long saleId) {
		if (saleId == null) {
			throw new IllegalArgumentException("販売を選択してください。"); // 판매를 선택하세요.
		}
		return mapper.selectSources(saleId);
	}

	/**
	 * 미확인을 확인으로 바꾼다. 재고 수량은 판매입력1의 정상 저장이 이미 뺐으므로 여기서 다시 빼지 않고, 재고관리 품목의 판매 수불만 남긴다.
	 * 未確認を確認へ変える。在庫数量は販売入力1の正常保存がすでに引いているので、ここでは再び引かず、在庫管理品目の販売受払だけ残す。
	 */
	private boolean confirmOne(Long saleId) {
		SaleInquiryHeaderDTO header = requireActive(saleId);
		if (!"UNCONFIRMED".equals(header.getProgressStatus())) {
			return false;
		}
		if (mapper.updateProgress(saleId, "CONFIRMED", "UNCONFIRMED") != 1) {
			return false;
		}
		// 같은 판매의 판매 수불이 이미 있으면 확정을 반복해도 수불을 더하지 않는다.
		// 同じ販売の販売受払がすでにあれば、確定を繰り返しても受払を足さない。
		if (mapper.countMovements(saleId, "SALE") == 0) {
			writeMovements(header, mapper.selectStockLines(saleId), "SALE", true);
		}
		mapper.insertHistory(saleId, "STATUS", "CONFIRMED", "판매확정");
		return true;
	}

	/**
	 * 확인을 미확인으로 되돌린다. 재고와 수불은 그대로 둔다. 재고를 되돌리는 곳은 선택삭제뿐이다.
	 * 確認を未確認へ戻す。在庫と受払はそのまま残す。在庫を戻すのは選択削除だけである。
	 */
	private boolean unconfirmOne(Long saleId) {
		SaleInquiryHeaderDTO header = requireActive(saleId);
		if (!"CONFIRMED".equals(header.getProgressStatus())) {
			return false;
		}
		if (mapper.updateProgress(saleId, "UNCONFIRMED", "CONFIRMED") != 1) {
			return false;
		}
		mapper.insertHistory(saleId, "STATUS", "UNCONFIRMED", "미확인변경");
		return true;
	}

	/**
	 * 판매 한 건을 지운다. 정상 저장 때 빠진 수량을 먼저 되돌리고, 판매 수불이 있으면 취소 수불로 상계한 뒤 전표를 지운다.
	 * 販売1件を消す。正常保存で引いた数量を先に戻し、販売受払があれば取消受払で相殺したあと伝票を消す。
	 */
	private void deleteOne(Long saleId) {
		SaleInquiryHeaderDTO header = requireActive(saleId);
		List<SaleStockLineDTO> lines = mapper.selectStockLines(saleId);
		// 판매입력1은 진행상태가 미확인이어도 정상 저장에서 재고를 뺀다. 그래서 미확인 삭제에서도 그 수량은 되돌린다.
		// 販売入力1は進行状態が未確認でも正常保存で在庫を引く。そのため未確認の削除でもその数量は戻す。
		restoreSavedQuantity(header, lines);
		if (mapper.countMovements(saleId, "SALE") > mapper.countMovements(saleId, "SALE_CANCEL")) {
			writeMovements(header, lines, "SALE_CANCEL", false);
		}
		// 전표를 지우기 전에 거래처와 품목을 신규, 수정 이력에 붙여 둔다.
		// 伝票を消す前に取引先と品目を新規、修正の履歴へ付けておく。
		String snapshot = snapshotJson(mapper.selectSnapshot(saleId));
		if (snapshot != null) {
			mapper.attachSnapshot(saleId, snapshot);
		}
		mapper.deleteSaleGraph(saleId);
		// 기존 이력 행은 지우지 않는다. 삭제 직후 취소 이력만 추가한다.
		// 既存の履歴行は消さない。削除の直後に取消履歴だけ追加する。
		mapper.insertHistory(saleId, "CANCEL", header.getProgressStatus(),
				snapshot == null ? "선택삭제" : "선택삭제\n" + snapshot);
	}

	/** 잠근 헤더가 정상이 아니면 확정과 삭제를 하지 않는다. ロックしたヘッダが正常でなければ確定と削除をしない。 */
	private SaleInquiryHeaderDTO requireActive(Long saleId) {
		SaleInquiryHeaderDTO header = mapper.lockSale(saleId);
		if (header == null) {
			throw new IllegalArgumentException("販売伝票がありません。"); // 판매전표가 없습니다.
		}
		if (!"ACTIVE".equals(header.getVoucherStatus())) {
			throw new IllegalArgumentException("正常の販売だけ処理できます。"); // 정상 판매만 처리할 수 있습니다.
		}
		return header;
	}

	/** 판매입력1이 정상 저장 때 뺀 수량을 창고 재고에 다시 더한다. 재고관리여부와 상관없이 저장 때 빠진 줄은 모두 되돌린다.
	 *  販売入力1が正常保存で引いた数量を倉庫在庫へ再び足す。在庫管理可否にかかわらず、保存で引いた行はすべて戻す。 */
	private void restoreSavedQuantity(SaleInquiryHeaderDTO header, List<SaleStockLineDTO> lines) {
		if (header.getWarehouseId() == null || lines == null) {
			return;
		}
		for (SaleStockLineDTO line : lines) {
			if (!hasQuantity(line)) {
				continue;
			}
			mapper.adjustInventory(header.getWarehouseId(), line.getItemId(), line.getQuantity());
		}
	}

	/** 재고관리여부가 Y인 줄만 수불을 남긴다. negative면 판매 차감, 아니면 취소 복원이다. 수량이 0이면 넣지 않는다.
	 *  在庫管理可否が Y の行だけ受払を残す。negativeなら販売減算、そうでなければ取消復元である。数量が 0 なら入れない。 */
	private void writeMovements(SaleInquiryHeaderDTO header, List<SaleStockLineDTO> lines, String movementType,
			boolean negative) {
		if (header.getWarehouseId() == null || lines == null) {
			return;
		}
		for (SaleStockLineDTO line : lines) {
			if (!hasQuantity(line) || line.getInventoryControlYn() == null
					|| !"Y".equals(line.getInventoryControlYn().trim())) {
				continue;
			}
			BigDecimal change = negative ? line.getQuantity().negate() : line.getQuantity();
			mapper.insertMovement(header.getWarehouseId(), line.getItemId(), movementType, change, header.getSaleId());
		}
	}

	private boolean hasQuantity(SaleStockLineDTO line) {
		return line != null && line.getItemId() != null && line.getQuantity() != null
				&& line.getQuantity().signum() > 0;
	}

	private List<Long> requireIds(List<Long> saleIds) {
		if (saleIds == null || saleIds.isEmpty()) {
			throw new IllegalArgumentException("販売を選択してください。"); // 판매를 선택하세요.
		}
		return saleIds;
	}

	/** 시작일과 종료일이 있고, 시작일이 종료일보다 늦지 않아야 조회한다.
	 *  開始日と終了日があり、開始日が終了日より遅くなければ照会する。 */
	private void checkPeriod(Date fromDate, Date toDate) {
		if (fromDate == null || toDate == null) {
			throw new IllegalArgumentException("照会期間を入力してください。"); // 조회기간을 입력하세요.
		}
		SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
		if (format.format(fromDate).compareTo(format.format(toDate)) > 0) {
			throw new IllegalArgumentException("開始日が終了日より後です。"); // 시작일이 종료일보다 뒤입니다.
		}
	}

	/** 화면 탭을 진행상태 코드로 바꾼다. 전체는 조건을 비운다.
	 *  画面タブを進行状態コードへ変える。全体は条件を空にする。 */
	private String progressCode(String tab) {
		if (tab == null || tab.trim().isEmpty() || "ALL".equals(tab) || "全体".equals(tab)) {
			return null;
		}
		if ("UNCONFIRMED".equals(tab) || "未確認".equals(tab)) {
			return "UNCONFIRMED";
		}
		if ("CONFIRMED".equals(tab) || "確認".equals(tab)) {
			return "CONFIRMED";
		}
		throw new IllegalArgumentException("状態タブが正しくありません。"); // 상태 탭이 올바르지 않습니다.
	}

	private String blankToNull(String keyword) {
		if (keyword == null) {
			return null;
		}
		String trimmed = keyword.trim();
		return trimmed.isEmpty() ? null : trimmed;
	}

	/** 이력 코드의 화면 이름. 신규, 수정, 삭제만 이력 모달에 나온다. 이력コードの画面名。新規、修正、削除だけ履歴モーダルに出る。 */
	private String actionName(String actionType) {
		if ("CREATE".equals(actionType)) {
			return "新規"; // 신규
		}
		if ("UPDATE".equals(actionType)) {
			return "修正"; // 수정
		}
		if ("CANCEL".equals(actionType)) {
			return "削除"; // 삭제
		}
		if ("STATUS".equals(actionType)) {
			return "状態変更"; // 상태변경
		}
		return actionType;
	}

	/** 판매입력1은 NORMAL, 판매입력2는 POS. 비어 있으면 한 전표 조회다.
	 *  販売入力1は NORMAL、販売入力2は POS。空なら1伝票の照会である。 */
	private String historyInputType(String inputType) {
		if (inputType == null || inputType.trim().isEmpty()) {
			return null;
		}
		if ("NORMAL".equals(inputType) || "INPUT1".equals(inputType)) {
			return "NORMAL";
		}
		if ("POS".equals(inputType) || "INPUT2".equals(inputType)) {
			return "POS";
		}
		throw new IllegalArgumentException("販売入力の区分が正しくありません。"); // 판매입력 구분이 올바르지 않습니다.
	}

	/** 지운 전표는 조인이 비므로 삭제 전에 저장한 모습으로 칸을 채운다.
	 *  消した伝票は結合が空なので、削除の前に保存した姿で欄を埋める。 */
	private void fillDeletedSnapshot(VoucherHistoryDTO row) {
		if (row.getPartnerName() != null || row.getDescription() == null) {
			return;
		}
		int start = row.getDescription().indexOf("{\"it\":");
		if (start < 0) {
			return;
		}
		String json = row.getDescription().substring(start);
		if (row.getDateNo() == null) {
			row.setDateNo(jsonValue(json, "dn"));
		}
		row.setPartnerCode(jsonValue(json, "pc"));
		row.setPartnerName(jsonValue(json, "pn"));
		row.setItemName(jsonValue(json, "in"));
		row.setManagerCode(jsonValue(json, "mc"));
		row.setManagerName(jsonValue(json, "mn"));
		if (row.getProgressName() == null) {
			row.setProgressName(progressLabel(jsonValue(json, "ps")));
		}
	}

	private String snapshotJson(SaleHistorySnapDTO snap) {
		if (snap == null) {
			return null;
		}
		String inputType = snap.getInputType() == null ? "NORMAL" : snap.getInputType();
		return "{\"it\":\"" + jsonEscape(inputType) + "\",\"dn\":\"" + jsonEscape(snap.getDateNo()) + "\",\"pc\":\""
				+ jsonEscape(snap.getPartnerCode()) + "\",\"pn\":\"" + jsonEscape(snap.getPartnerName())
				+ "\",\"in\":\"" + jsonEscape(snap.getItemName()) + "\",\"mc\":\"" + jsonEscape(snap.getManagerCode())
				+ "\",\"mn\":\"" + jsonEscape(snap.getManagerName()) + "\",\"ps\":\""
				+ jsonEscape(snap.getProgressName()) + "\"}";
	}

	private String jsonEscape(String value) {
		if (value == null) {
			return "";
		}
		String trimmed = value.replace('\n', ' ').replace('\r', ' ').replace("\\", "\\\\").replace("\"", "\\\"");
		return trimmed.length() > 80 ? trimmed.substring(0, 80) : trimmed;
	}

	private String jsonValue(String json, String key) {
		String mark = "\"" + key + "\":\"";
		int start = json.indexOf(mark);
		if (start < 0) {
			return null;
		}
		start += mark.length();
		StringBuilder value = new StringBuilder();
		for (int i = start; i < json.length(); i++) {
			char ch = json.charAt(i);
			if (ch == '\\' && i + 1 < json.length()) {
				value.append(json.charAt(++i));
				continue;
			}
			if (ch == '"') {
				break;
			}
			value.append(ch);
		}
		return value.length() == 0 ? null : value.toString();
	}

	/** 전표 이력 창의 제목. 지운 전표는 저장해 둔 일자-No를 쓴다.
	 *  伝票履歴の窓の題名。消した伝票は保存しておいた日付-Noを使う。 */
	private String slipDateNo(List<SaleSlipHistorySourceDTO> sources) {
		if (sources == null) {
			return null;
		}
		for (SaleSlipHistorySourceDTO source : sources) {
			if (source.getDateNo() != null) {
				return source.getDateNo();
			}
		}
		for (SaleSlipHistorySourceDTO source : sources) {
			String dateNo = snapshotValue(source.getDescription(), "dn");
			if (dateNo != null) {
				return dateNo;
			}
		}
		return null;
	}

	/** 그 작업 시점의 진행상태. 확인 또는 미확인만 남긴다.
	 *  その作業時点の進行状態。確認または未確認だけ残す。 */
	private String slipProgress(SaleSlipHistorySourceDTO source) {
		if ("STATUS".equals(source.getActionType())) {
			if (source.getDescription() != null && source.getDescription().startsWith("판매확정")) {
				return "確認"; // 확인
			}
			if (source.getDescription() != null && source.getDescription().startsWith("미확인변경")) {
				return "未確認"; // 미확인
			}
		}
		String after = progressLabel(source.getAfterStatus());
		if (after != null) {
			return after;
		}
		String saved = progressLabel(snapshotValue(source.getDescription(), "ps"));
		if (saved != null) {
			return saved;
		}
		if (source.getProgressName() != null) {
			return source.getProgressName();
		}
		return "未確認"; // 미확인
	}

	/** 상태 칸. 신규, 수정, 삭제와 진행상태 변경만 적는다.
	 *  状態欄。新規、修正、削除と進行状態の変更だけ書く。 */
	private String slipActionName(SaleSlipHistorySourceDTO source) {
		if ("CREATE".equals(source.getActionType())) {
			return "新規"; // 신규
		}
		if ("UPDATE".equals(source.getActionType())) {
			return "修正"; // 수정
		}
		if ("CANCEL".equals(source.getActionType())) {
			return "削除"; // 삭제
		}
		if ("STATUS".equals(source.getActionType())) {
			return slipProgress(source);
		}
		return source.getActionType();
	}

	private String progressLabel(String status) {
		if (status == null) {
			return null;
		}
		if ("CONFIRMED".equals(status) || "確認".equals(status) || "확인".equals(status)) {
			return "確認"; // 확인
		}
		if ("UNCONFIRMED".equals(status) || "未確認".equals(status) || "미확인".equals(status)) {
			return "未確認"; // 미확인
		}
		return null;
	}

	private String snapshotValue(String description, String key) {
		if (description == null) {
			return null;
		}
		int start = description.indexOf("{\"it\":");
		if (start < 0) {
			return null;
		}
		return jsonValue(description.substring(start), key);
	}

	/** 2026/10/01 오후 1:29:13 형식. 2026/10/01 午後 1:29:13 の形式。 */
	private String formatWorkedAt(Date workedAt) {
		if (workedAt == null) {
			return "";
		}
		return new SimpleDateFormat("yyyy/MM/dd a h:mm:ss", Locale.KOREAN).format(workedAt);
	}
}
