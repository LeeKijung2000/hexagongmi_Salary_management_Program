package org.sales.sale.controller;

import java.util.Date;
import java.util.List;

import org.sales.sale.service.CommonLookupService;
import org.sales.sale.dto.ItemProfitDTO;
import org.sales.sale.dto.SlipListDTO;
import org.sales.sale.dto.SlipSourceLineDTO;
import org.sales.sale.service.SaleInputOneService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/sales/sale")
@AllArgsConstructor
/**
 * 판매입력1 화면. 화면 주소는 GET /sales/sale/input 이고, 저장과 보류 조회는 /sales 자원을 쓴다.
 * 저장/전표만 거래명세서로 가고, 그 외 저장 뒤 이동은 브라우저가 빈 입력 화면으로 한다.
 * 販売入力1画面。画面アドレスは GET /sales/sale/input であり、保存と保留照会は /sales 資源を使う。
 * 保存/伝票だけ取引明細書へ行き、それ以外の保存後の移動はブラウザが空の入力画面へ行う。
 */
public class SaleInputOneController {

	private SaleInputOneService service;

	private CommonLookupService commonLookup;

	/** 빈 판매입력 화면. saleId가 있으면 그 전표의 헤더와 품목을 채워 수정처럼 연다. embed=1이면 판매조회 모달 안에 연다.
	 *  空の販売入力画面。saleIdがあればその伝票のヘッダと品目を入れて修正のように開く。embed=1なら販売照会のモーダル内に開く。 */
	@GetMapping("/input")
	public String input(@RequestParam(value = "saleId", required = false) Long saleId,
			@RequestParam(value = "embed", required = false) String embed, Model model) {
		log.info("input saleId: " + saleId);
		if (saleId != null) {
			model.addAttribute("sale", service.get(saleId));
		}
		model.addAttribute("currencies", commonLookup.getCurrencies());
		model.addAttribute("embed", embed);
		return "sales/sale/input";
	}

	/** 저장/전표로 연 거래명세서. embed=1이면 판매조회 모달 안에서 사이드바 없이 연다.
	 *  保存/伝票で開く取引明細書。embed=1なら販売照会のモーダル内でサイドバーなしに開く。 */
	@GetMapping("/input/statement")
	public String statement(@RequestParam("saleId") Long saleId,
			@RequestParam(value = "embed", required = false) String embed, Model model) {
		model.addAttribute("sale", service.get(saleId));
		model.addAttribute("embed", embed);
		return "sales/sale/statement";
	}

	/** 거래내역보기와 리스트 조회. kind는 sale, order, quote이다. 날짜가 있으면 그날까지, 없으면 전체다. 보류 판매는 빼 둔다.
	 *  取引履歴とリスト照会。kindはsale、order、quoteである。日付があればその日まで、なければ全体である。保留の販売は除いておく。 */
	@GetMapping("/input/slips")
	@ResponseBody
	public List<SlipListDTO> slips(@RequestParam(value = "kind", defaultValue = "sale") String kind,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Date toDate) {
		return service.getSlips(kind, fromDate, toDate);
	}

	/** 주문 버튼. 아직 판매로 넘기지 않은 주문 라인을 돌려준다. 거래처가 있으면 그 거래처만 좁힌다.
	 *  注文ボタン。まだ販売へ渡していない注文行を返す。取引先があればその取引先だけに絞る。 */
	@GetMapping("/input/unsold-orders")
	@ResponseBody
	public List<SlipSourceLineDTO> unsoldOrders(@RequestParam(value = "businessPartnerId", required = false) Long businessPartnerId) {
		return service.getUnsoldOrders(businessPartnerId);
	}

	/** 남은 수량이 있는 견적 라인. 전표불러오기 버튼은 견적서 조회 JSP를 모달에 열고 이 주소는 호출하지 않는다.
	 *  残数量がある見積行。伝票読込ボタンは見積書照会JSPをモーダルに開き、このアドレスは呼ばない。 */
	@GetMapping("/input/quote-lines")
	@ResponseBody
	public List<SlipSourceLineDTO> quoteLines(@RequestParam(value = "businessPartnerId", required = false) Long businessPartnerId) {
		return service.getQuoteLines(businessPartnerId);
	}

	/** 아직 다른 판매로 넘기지 않은 판매 품목. 전표불러오기 버튼은 조회 JSP를 모달에 열고 이 주소는 호출하지 않는다.
	 *  まだ他の販売へ渡していない販売品目。伝票読込ボタンは照会JSPをモーダルに開き、このアドレスは呼ばない。 */
	@GetMapping("/input/sale-lines")
	@ResponseBody
	public List<SlipSourceLineDTO> saleLines(@RequestParam(value = "businessPartnerId", required = false) Long businessPartnerId) {
		return service.getSaleLines(businessPartnerId);
	}

	/** 이익계산. 매입단가와 표준원가를 읽어 화면에만 보여 주고 전표 라인에는 저장하지 않는다.
	 *  利益計算。仕入単価と標準原価を読んで画面に見せるだけであり、伝票行には保存しない。 */
	@GetMapping("/input/profit")
	@ResponseBody
	public ItemProfitDTO profit(@RequestParam("itemPk") Long itemPk) {
		return service.getItemProfit(itemPk);
	}

}
