package org.sales.sale.controller;

import org.sales.sale.service.SaleInputTwoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/sales/sale")
@AllArgsConstructor
/**
 * 판매입력2 화면. 주소는 GET /sales/sale/input2 이다. 저장과 보류는 /sales/input2 를 쓴다.
 * 販売入力2画面。アドレスは GET /sales/sale/input2 である。保存と保留は /sales/input2 を使う。
 */
public class SaleInputTwoController {

	private SaleInputTwoService service;

	/** 빈 판매입력2. saleId가 있으면 그 전표를 채워 수정처럼 연다.
	 *  空の販売入力2。saleIdがあればその伝票を入れて修正のように開く。 */
	@GetMapping("/input2")
	public String input(@RequestParam(value = "saleId", required = false) Long saleId,
			@RequestParam(value = "embed", required = false) String embed, Model model) {
		log.info("input2 saleId: " + saleId);
		if (saleId != null) {
			model.addAttribute("sale", service.get(saleId));
		}
		model.addAttribute("embed", embed);
		return "sales/sale/input2";
	}
}
