package org.sales.sale.dto;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

/**
 * 주문 버튼과 견적·판매 잔량 조회 라인. 전표불러오기는 조회 JSP를 모달에 열고 이 값을 판매 표에 넣지 않는다.
 * 미판매수량 = ORDER_ITEM.QUANTITY - SUM(APPLIED_QTY, SRC_TYPE=ORDER).
 * 注文ボタンと見積・販売の残数量照会の行。伝票読込は照会JSPをモーダルに開き、この値を販売表に入れない。
 * 未販売数量 = ORDER_ITEM.QUANTITY - SUM(APPLIED_QTY, SRC_TYPE=ORDER)。
 */
@Data
public class SlipSourceLineDTO {

    private String srcType;
    private Long srcId;
    private Long srcItemId;
    private Date slipDate;
    private Long businessPartnerId;
    private String businessPartnerName;
    private Long itemPk;
    private String itemCode;
    private String itemNm;
    private String spec;
    private BigDecimal quantity;
    private BigDecimal appliedQty;
    private BigDecimal remainQty;
    private BigDecimal unitPrice;
    private BigDecimal supplyAmt;
    private BigDecimal vatAmt;
}
