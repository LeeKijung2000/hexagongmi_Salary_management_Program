package org.sales.sale.dto;

import java.math.BigDecimal;

import lombok.Data;

/** 이익계산용 품목 원가. 매입단가, 판매단가, 재료·경비·노무·외주 표준원가를 읽어 화면에만 보여 주고 라인에는 저장하지 않는다.
 *  利益計算用の品目原価。仕入単価、販売単価、材料・経費・労務・外注の標準原価を読んで画面に見せるだけであり、行には保存しない。 */
@Data
public class ItemProfitDTO {

    private Long itemPk;
    private String itemCode;
    private BigDecimal purchasePrice;
    private BigDecimal salesPrice;
    private BigDecimal stdCostMaterial;
    private BigDecimal stdCostExpense;
    private BigDecimal stdCostLabor;
    private BigDecimal stdCostOutsourcing;
}
