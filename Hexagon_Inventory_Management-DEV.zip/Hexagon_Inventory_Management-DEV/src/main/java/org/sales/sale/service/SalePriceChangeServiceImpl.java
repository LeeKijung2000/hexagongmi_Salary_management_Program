package org.sales.sale.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.sales.sale.dao.SalePriceChangeDao;
import org.sales.sale.dto.SalePriceChangeApplyResultDTO;
import org.sales.sale.dto.SalePriceChangeItemDTO;
import org.sales.sale.dto.SalePriceChangeKeyDTO;
import org.sales.sale.dto.SalePriceChangeLineDTO;
import org.sales.sale.dto.SalePriceChangeResultDTO;
import org.sales.sale.dto.SalePriceChangeSearchDTO;
import org.sales.sale.dto.SalePriceChangeSlipDTO;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
@AllArgsConstructor
/**
 * 판매단가일괄변경. 한 전표의 품목과 헤더는 같은 트랜잭션이고, 전표가 실패하면 그 전표만 롤백한다.
 * 販売単価一括変更。1伝票の品目とヘッダは同じトランザクションであり、伝票が失敗すればその伝票だけロールバックする。
 */
public class SalePriceChangeServiceImpl implements SalePriceChangeService {

	static final int MAX_ROWS = 1000;
	private static final BigDecimal VAT_RATE = new BigDecimal("0.1");
	private static final int PRICE_SCALE = 4;
	private static final int CHANGED = 1;
	private static final int SKIPPED = 2;
	private static final Set<String> CURRENCIES = new HashSet<String>(Arrays.asList("DOMESTIC", "FOREIGN"));
	private static final Set<String> INPUTS = new HashSet<String>(Arrays.asList("ALL", "NORMAL", "RETURN"));
	private static final Set<String> PROGRESS = new HashSet<String>(Arrays.asList("UNCONFIRMED", "CONFIRMED"));

	private SalePriceChangeDao mapper;
	private PlatformTransactionManager transactionManager;

	/** 품목 줄을 판매일자, 판매번호 순으로 돌려준다. 화면을 열 때는 조회하지 않는다.
	 *  品目行を販売日付、販売番号順で返す。画面を開いたときは照会しない。 */
	@Override
	@Transactional(readOnly = true)
	public SalePriceChangeResultDTO search(SalePriceChangeSearchDTO search) {
		log.info("search......" + search);
		prepare(search);
		int count = mapper.countLines(search);
		List<SalePriceChangeLineDTO> lines = count == 0 ? new ArrayList<SalePriceChangeLineDTO>()
				: mapper.selectLines(search);
		SalePriceChangeResultDTO result = new SalePriceChangeResultDTO();
		result.setLines(lines);
		result.setTotalCount(count);
		result.setTruncated(count > MAX_ROWS);
		return result;
	}

	/** 고른 줄만 화면 단가로 바꾼다. 같은 전표의 나머지 줄은 두고, 헤더만 전 줄 합계로 다시 쓴다.
	 *  選んだ行だけ画面単価へ変える。同じ伝票の残りの行は置き、ヘッダだけ全行合計で書き直す。 */
	@Override
	public SalePriceChangeApplyResultDTO changePrice(List<Long> saleItemIds, BigDecimal unitPrice) {
		log.info("changePrice......" + saleItemIds + " " + unitPrice);
		if (unitPrice == null || unitPrice.signum() < 0) {
			throw new IllegalArgumentException("変更単価が正しくありません。"); // 변경단가가 올바르지 않습니다.
		}
		List<Long> ids = requireIds(saleItemIds);
		Map<Long, BigDecimal> prices = new LinkedHashMap<Long, BigDecimal>();
		for (Long id : ids) {
			prices.put(id, unitPrice);
		}
		return apply(ids, false, prices);
	}

	/** 화면에서 고친 단가만 줄마다 저장한다. 순서가 같은 판매품목번호와 단가를 짝으로 받는다.
	 *  画面で直した単価だけ行ごとに保存する。順が同じ販売品目番号と単価を組で受ける。 */
	@Override
	public SalePriceChangeApplyResultDTO changePrices(List<Long> saleItemIds, List<BigDecimal> unitPrices) {
		log.info("changePrices......" + saleItemIds);
		if (saleItemIds == null || unitPrices == null || saleItemIds.isEmpty()
				|| saleItemIds.size() != unitPrices.size()) {
			throw new IllegalArgumentException("変更単価が正しくありません。"); // 변경단가가 올바르지 않습니다.
		}
		Map<Long, BigDecimal> prices = new LinkedHashMap<Long, BigDecimal>();
		for (int i = 0; i < saleItemIds.size(); i++) {
			Long id = saleItemIds.get(i);
			BigDecimal price = unitPrices.get(i);
			if (id == null || price == null || price.signum() < 0) {
				throw new IllegalArgumentException("変更単価が正しくありません。"); // 변경단가가 올바르지 않습니다.
			}
			prices.put(id, price);
		}
		if (prices.size() > MAX_ROWS) {
			throw new IllegalArgumentException("一度に変更できる明細は1,000件までです。"); // 한 번에 변경할 수 있는 내역은 1,000건까지입니다.
		}
		return apply(new ArrayList<Long>(prices.keySet()), false, prices);
	}

	/** 고른 줄이 들어 있는 외자 전표 전체를 통화 마스터 환율로 다시 계산한다. 내자 전표는 뺀다.
	 *  選んだ行が入っている外貨伝票全体を通貨マスタの為替で計算し直す。内貨伝票は除く。 */
	@Override
	public SalePriceChangeApplyResultDTO changeRate(List<Long> saleItemIds) {
		log.info("changeRate......" + saleItemIds);
		return apply(saleItemIds, true, null);
	}

	/** 전표마다 새 트랜잭션으로 고친다. 한 전표가 실패해도 이미 커밋한 전표는 남긴다.
	 *  伝票ごとに新しいトランザクションで直す。1伝票が失敗しても、すでにコミットした伝票は残す。 */
	private SalePriceChangeApplyResultDTO apply(List<Long> saleItemIds, boolean rateMode, Map<Long, BigDecimal> prices) {
		List<Long> ids = requireIds(saleItemIds);
		List<SalePriceChangeKeyDTO> keys = mapper.selectTargets(ids);
		if (keys == null || keys.isEmpty()) {
			throw new IllegalArgumentException("変更できる明細がありません。"); // 변경할 수 있는 내역이 없습니다.
		}
		Map<Long, Set<Long>> selected = group(keys);
		TransactionTemplate tx = new TransactionTemplate(transactionManager);
		tx.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
		int changedSlips = 0;
		int changedLines = 0;
		int skipped = 0;
		int failed = 0;
		List<Long> failedIds = new ArrayList<Long>();
		for (Map.Entry<Long, Set<Long>> entry : selected.entrySet()) {
			final Long saleId = entry.getKey();
			final Set<Long> itemIds = entry.getValue();
			try {
				int[] counts = tx.execute(status -> {
					int outcome = rateMode ? applyRate(saleId) : applyPrice(saleId, itemIds, prices);
					int lines = outcome == CHANGED ? (rateMode ? countLines(saleId) : itemIds.size()) : 0;
					return new int[] { outcome, lines };
				});
				if (counts[0] == SKIPPED) {
					skipped++;
				} else {
					changedSlips++;
					changedLines += counts[1];
				}
			} catch (RuntimeException e) {
				log.warn("sale price change failed " + saleId, e);
				failed++;
				failedIds.add(saleId);
			}
		}
		SalePriceChangeApplyResultDTO result = new SalePriceChangeApplyResultDTO();
		result.setChangedSlips(changedSlips);
		result.setChangedLines(changedLines);
		result.setSkippedDomestic(skipped);
		result.setFailedSlips(failed);
		result.setMessage(message(rateMode, changedSlips, changedLines, skipped, failed, failedIds));
		return result;
	}

	/** 대상 줄의 단가를 바꾸고 공급가액, 부가세, 합계를 다시 계산한 뒤 헤더를 그 전표 합계로 맞춘다.
	 *  対象行の単価を変え、供給価額、付加税、合計を計算し直したあとヘッダをその伝票合計へ合わせる。 */
	private int applyPrice(Long saleId, Set<Long> itemIds, Map<Long, BigDecimal> prices) {
		SalePriceChangeSlipDTO slip = requireSlip(saleId);
		List<SalePriceChangeItemDTO> items = itemsOf(saleId);
		boolean vat = vatApplied(slip.getTransactionType());
		BigDecimal supplySum = BigDecimal.ZERO;
		BigDecimal vatSum = BigDecimal.ZERO;
		boolean changed = false;
		for (SalePriceChangeItemDTO item : items) {
			if (itemIds.contains(item.getSaleItemId())) {
				BigDecimal nextPrice = prices == null ? null : prices.get(item.getSaleItemId());
				if (nextPrice == null || nextPrice.signum() < 0) {
					throw new IllegalArgumentException("変更単価が正しくありません。"); // 변경단가가 올바르지 않습니다.
				}
				item.setUnitPrice(nextPrice);
				fillAmounts(item, vat);
				mapper.updateItem(item);
				changed = true;
			}
			supplySum = supplySum.add(nvl(item.getSupplyAmount()));
			vatSum = vatSum.add(nvl(item.getVatAmount()));
		}
		if (!changed) {
			throw new IllegalArgumentException("変更できる明細がありません。"); // 변경할 수 있는 내역이 없습니다.
		}
		writeHeaderAmounts(slip, supplySum, vatSum);
		mapper.updateHeaderAmounts(slip);
		return CHANGED;
	}

	/** 내자가 아니면 전표 환율을 통화 마스터 환율로 바꾸고, 단가는 이전 환율 대비로 다시 계산한다.
	 *  内貨でなければ伝票為替を通貨マスタの為替へ変え、単価は前の為替との比で計算し直す。 */
	private int applyRate(Long saleId) {
		SalePriceChangeSlipDTO slip = requireSlip(saleId);
		if (domestic(slip.getCurrencyCode())) {
			return SKIPPED;
		}
		if (slip.getCurrencyRate() == null) {
			throw new IllegalArgumentException("為替レートが登録されていません。"); // 환율이 등록되어 있지 않습니다.
		}
		BigDecimal oldRate = nvl(slip.getExchangeRate());
		if (oldRate.signum() == 0) {
			oldRate = BigDecimal.ONE;
		}
		BigDecimal newRate = slip.getCurrencyRate();
		List<SalePriceChangeItemDTO> items = itemsOf(saleId);
		boolean vat = vatApplied(slip.getTransactionType());
		BigDecimal supplySum = BigDecimal.ZERO;
		BigDecimal vatSum = BigDecimal.ZERO;
		for (SalePriceChangeItemDTO item : items) {
			BigDecimal nextPrice = nvl(item.getUnitPrice()).multiply(newRate).divide(oldRate, PRICE_SCALE,
					RoundingMode.HALF_UP);
			item.setUnitPrice(nextPrice);
			fillAmounts(item, vat);
			mapper.updateItem(item);
			supplySum = supplySum.add(item.getSupplyAmount());
			vatSum = vatSum.add(item.getVatAmount());
		}
		slip.setExchangeRate(newRate);
		writeHeaderAmounts(slip, supplySum, vatSum);
		mapper.updateHeaderRate(slip);
		return CHANGED;
	}

	/** 공급가액은 수량×단가이다. 부가세율 적용이면 그 금액의 10%이고, 합계는 둘을 더한 값이다.
	 *  供給価額は数量×単価である。付加税率適用ならその金額の10%であり、合計は二つを足した値である。 */
	private void fillAmounts(SalePriceChangeItemDTO item, boolean vat) {
		BigDecimal supply = nvl(item.getQuantity()).multiply(nvl(item.getUnitPrice())).setScale(0, RoundingMode.HALF_UP);
		BigDecimal vatAmount = vat ? supply.multiply(VAT_RATE).setScale(0, RoundingMode.HALF_UP) : BigDecimal.ZERO;
		item.setSupplyAmount(supply);
		item.setVatAmount(vatAmount);
		item.setTotalAmount(supply.add(vatAmount));
	}

	/** 헤더 합계는 품목 합계에 기존 조정금액을 더한다. 진행상태와 전표상태는 바꾸지 않는다.
	 *  ヘッダ合計は品目合計に既存の調整金額を足す。進行状態と伝票状態は変えない。 */
	private void writeHeaderAmounts(SalePriceChangeSlipDTO slip, BigDecimal supplySum, BigDecimal vatSum) {
		slip.setSupplyAmount(supplySum);
		slip.setVatAmount(vatSum);
		slip.setTotalAmount(supplySum.add(vatSum).add(nvl(slip.getAdjustmentAmount())));
	}

	/** 환율변경 건수에 쓰는 그 전표의 품목 수. 단가변경 건수에는 쓰지 않는다.
	 *  為替変更の件数に使うその伝票の品目数。単価変更の件数には使わない。 */
	private int countLines(Long saleId) {
		return itemsOf(saleId).size();
	}

	/** 헤더 합계용으로 그 전표의 품목을 모두 읽는다. 없으면 빈 목록이다.
	 *  ヘッダ合計のためその伝票の品目をすべて読む。なければ空の一覧である。 */
	private List<SalePriceChangeItemDTO> itemsOf(Long saleId) {
		List<SalePriceChangeItemDTO> items = mapper.selectItems(saleId);
		return items == null ? new ArrayList<SalePriceChangeItemDTO>() : items;
	}

	/** 정상, 반품 전표만 받는다. 없거나 취소, 보류면 그 전표를 실패로 돌린다.
	 *  正常、返品伝票だけ受ける。ないか取消、保留ならその伝票を失敗へ回す。 */
	private SalePriceChangeSlipDTO requireSlip(Long saleId) {
		SalePriceChangeSlipDTO slip = mapper.selectSlip(saleId);
		if (slip == null) {
			throw new IllegalArgumentException("伝票が見つかりません。"); // 전표를 찾을 수 없습니다.
		}
		return slip;
	}

	/** 통화가 없거나 KR이면 내자이다. 환율변경 대상에서 뺀다.
	 *  通貨がないか KR なら内貨である。為替変更の対象から除く。 */
	private boolean domestic(String currencyCode) {
		return currencyCode == null || currencyCode.trim().isEmpty() || "KR".equals(currencyCode);
	}

	/** 부가세율 미적용만 부가세가 0이다. 비어 있으면 적용으로 본다.
	 *  付加税率不適用だけ付加税が0である。空なら適用と見る。 */
	private boolean vatApplied(String transactionType) {
		return !"NO_VAT".equals(transactionType);
	}

	/** 고른 품목을 전표별로 묶는다. 같은 전표는 한 트랜잭션에서 고친다.
	 *  選んだ品目を伝票別に束ねる。同じ伝票は1トランザクションで直す。 */
	private Map<Long, Set<Long>> group(List<SalePriceChangeKeyDTO> keys) {
		Map<Long, Set<Long>> selected = new LinkedHashMap<Long, Set<Long>>();
		for (SalePriceChangeKeyDTO key : keys) {
			if (key.getSaleId() == null || key.getSaleItemId() == null) {
				continue;
			}
			Set<Long> itemIds = selected.get(key.getSaleId());
			if (itemIds == null) {
				itemIds = new LinkedHashSet<Long>();
				selected.put(key.getSaleId(), itemIds);
			}
			itemIds.add(key.getSaleItemId());
		}
		if (selected.isEmpty()) {
			throw new IllegalArgumentException("変更できる明細がありません。"); // 변경할 수 있는 내역이 없습니다.
		}
		return selected;
	}

	/** 빈 선택과 1,000건 초과를 막는다. 같은 품목번호는 한 번만 남긴다.
	 *  空の選択と1,000件超えを止める。同じ品目番号は一度だけ残す。 */
	private List<Long> requireIds(List<Long> saleItemIds) {
		if (saleItemIds == null || saleItemIds.isEmpty()) {
			throw new IllegalArgumentException("変更する行を選択してください。"); // 변경할 행을 선택하세요.
		}
		List<Long> ids = new ArrayList<Long>();
		for (Long id : saleItemIds) {
			if (id != null && !ids.contains(id)) {
				ids.add(id);
			}
		}
		if (ids.isEmpty()) {
			throw new IllegalArgumentException("変更する行を選択してください。"); // 변경할 행을 선택하세요.
		}
		if (ids.size() > MAX_ROWS) {
			throw new IllegalArgumentException("一度に変更できる明細は1,000件までです。"); // 한 번에 변경할 수 있는 내역은 1,000건까지입니다.
		}
		return ids;
	}

	/** 화면으로 돌려 줄 일본어 결과 문장. 실패 전표 번호를 뒤에 붙인다.
	 *  画面へ返す日本語の結果文。失敗した伝票番号を後ろへ付ける。 */
	private String message(boolean rateMode, int slips, int lines, int skipped, int failed, List<Long> failedIds) {
		if (rateMode && slips == 0 && failed == 0 && skipped > 0) {
			return "内貨伝票は為替変更の対象外です。"; // 내자 전표는 환율변경 대상이 아닙니다.
		}
		StringBuilder text = new StringBuilder();
		if (rateMode) {
			text.append("為替を変更しました。伝票 ").append(slips).append("件。"); // 환율을 변경했습니다.
			if (skipped > 0) {
				text.append("内貨 ").append(skipped).append("件は対象外です。"); // 내자 건은 대상에서 뺐습니다.
			}
		} else {
			text.append("単価を変更しました。伝票 ").append(slips).append("件、明細 ").append(lines).append("件。"); // 단가를 변경했습니다.
		}
		if (failed > 0) {
			text.append("失敗 ").append(failed).append("件"); // 실패 건.
			if (failedIds != null && !failedIds.isEmpty()) {
				text.append(' ').append(failedIds);
			}
			text.append('。');
		}
		return text.toString();
	}

	/** 빈 값은 화면 기본값으로 채운 뒤 허용 목록에 있는지 본다.
	 *  空の値は画面の初期値で埋めたあと、許す一覧にあるか見る。 */
	private void prepare(SalePriceChangeSearchDTO search) {
		if (search == null || search.getFromDate() == null || search.getToDate() == null) {
			throw new IllegalArgumentException("基準日を入力してください。"); // 기준일자를 입력하세요.
		}
		if (toLocal(search.getFromDate()).isAfter(toLocal(search.getToDate()))) {
			throw new IllegalArgumentException("開始日が終了日より後です。"); // 시작일이 종료일보다 뒤입니다.
		}
		search.setCurrencyScope(code(search.getCurrencyScope(), "DOMESTIC"));
		search.setInputScope(code(search.getInputScope(), "ALL"));
		search.setTransactionType(blankToNull(search.getTransactionType()));
		if (!CURRENCIES.contains(search.getCurrencyScope())) {
			throw new IllegalArgumentException("内外貨区分が正しくありません。"); // 내외자구분이 올바르지 않습니다.
		}
		if (!INPUTS.contains(search.getInputScope())) {
			throw new IllegalArgumentException("取引区分が正しくありません。"); // 거래구분이 올바르지 않습니다.
		}
		List<String> progress = new ArrayList<String>();
		if (search.getProgressStatuses() != null) {
			for (String status : search.getProgressStatuses()) {
				String value = blankToNull(status);
				if (value == null || progress.contains(value)) {
					continue;
				}
				if (!PROGRESS.contains(value)) {
					throw new IllegalArgumentException("進行状態が正しくありません。"); // 진행상태가 올바르지 않습니다.
				}
				progress.add(value);
			}
		}
		search.setProgressStatuses(progress.size() >= PROGRESS.size() ? null : progress);
		search.setLimit(MAX_ROWS);
	}

	private LocalDate toLocal(Date date) {
		if (date instanceof java.sql.Date) {
			return ((java.sql.Date) date).toLocalDate();
		}
		return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
	}

	private String code(String value, String fallback) {
		String text = blankToNull(value);
		return text == null ? fallback : text;
	}

	private String blankToNull(String value) {
		if (value == null) {
			return null;
		}
		String text = value.trim();
		return text.isEmpty() ? null : text;
	}

	private BigDecimal nvl(BigDecimal value) {
		return value == null ? BigDecimal.ZERO : value;
	}
}
