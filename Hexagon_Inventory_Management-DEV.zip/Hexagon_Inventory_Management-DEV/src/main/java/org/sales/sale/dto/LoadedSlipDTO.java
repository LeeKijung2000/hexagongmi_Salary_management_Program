package org.sales.sale.dto;

import lombok.Data;

/**
 * 판매에 연결된 원본 전표. srcType은 ORDER, QUOTE, SALE이다. documentId는 그 전표의 헤더 키다.
 * 販売に接続した元伝票。srcTypeは ORDER、QUOTE、SALE である。documentIdはその伝票のヘッダキーである。
 */
@Data
public class LoadedSlipDTO {

	private String srcType;
	private Long documentId;
	private String dateNo;
	private String voucherNo;
	private String partnerName;
	private String itemName;
}
