package org.sales.sale.dto;

import java.math.BigDecimal;

import lombok.Data;

/**
 * 판매 라인과 원천 전표 연결. SALE_SLIP_LINK.
 * SRC_TYPE은 ORDER, QUOTE, SALE이다. 주문·견적·판매 불러오기로 만든 줄만 값이 있고, 직접 고른 품목은 null이다.
 * 販売行と元伝票の接続。SALE_SLIP_LINK。
 * SRC_TYPEはORDER、QUOTE、SALEである。注文・見積・販売の読込で作った行だけ値があり、直接選んだ品目はnullである。
 */
@Data
public class SaleSlipLinkDTO {

    private Long linkId;
    private Long saleItemId;
    private String srcType;
    private Long srcItemId;
    private BigDecimal appliedQty;
}
