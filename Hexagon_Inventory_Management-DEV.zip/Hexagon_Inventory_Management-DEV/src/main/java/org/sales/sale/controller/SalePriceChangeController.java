package org.sales.sale.controller;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.sales.sale.dto.SalePriceChangeApplyResultDTO;
import org.sales.sale.dto.SalePriceChangeResultDTO;
import org.sales.sale.dto.SalePriceChangeSearchDTO;
import org.sales.sale.service.SalePriceChangeService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/sales/sale")
@AllArgsConstructor
/**
 * 판매단가일괄변경 화면. 조회, 단가변경, 환율변경은 이 주소에서 처리한다.
 * 販売単価一括変更画面。照会、単価変更、為替変更はこのアドレスで処理する。
 */
public class SalePriceChangeController {

	private SalePriceChangeService service;

	/** 판매단가일괄변경 화면. 기준일자 기본값은 이번 달 1일부터 오늘까지다.
	 *  販売単価一括変更画面。基準日の初期値は今月1日から今日までである。 */
	@GetMapping("/change-price")
	public String changePrice(Model model) {
		LocalDate today = LocalDate.now();
		model.addAttribute("fromDate", today.withDayOfMonth(1).toString());
		model.addAttribute("toDate", today.toString());
		return "sales/sale/change-price";
	}

	/** 조건에 맞는 판매 품목. 시작일이 종료일보다 늦으면 400과 메시지를 돌려준다.
	 *  条件に合う販売品目。開始日が終了日より遅ければ 400 とメッセージを返す。 */
	@GetMapping("/change-price/lines")
	@ResponseBody
	public ResponseEntity<?> lines(SalePriceChangeSearchDTO search) {
		log.info("change-price lines " + search);
		try {
			SalePriceChangeResultDTO body = service.search(search);
			return new ResponseEntity<SalePriceChangeResultDTO>(body, HttpStatus.OK);
		} catch (IllegalArgumentException e) {
			return error(e.getMessage());
		}
	}

	/** 단가변경. 고른 줄의 단가를 화면 단가로 바꾸고 헤더 금액을 다시 더한다.
	 *  単価変更。選んだ行の単価を画面単価へ変え、ヘッダ金額を足し直す。 */
	@PostMapping("/change-price/price")
	@ResponseBody
	public ResponseEntity<?> price(@RequestParam("saleItemIds") List<Long> saleItemIds,
			@RequestParam("unitPrice") BigDecimal unitPrice) {
		log.info("change-price price " + unitPrice + " " + saleItemIds);
		try {
			SalePriceChangeApplyResultDTO body = service.changePrice(saleItemIds, unitPrice);
			return new ResponseEntity<SalePriceChangeApplyResultDTO>(body, HttpStatus.OK);
		} catch (IllegalArgumentException e) {
			return error(e.getMessage());
		}
	}

	/** 줄마다 다른 단가 저장. 판매품목번호와 단가는 같은 순서로 받는다.
	 *  行ごとに違う単価の保存。販売品目番号と単価は同じ順で受ける。 */
	@PostMapping("/change-price/prices")
	@ResponseBody
	public ResponseEntity<?> prices(@RequestParam("saleItemIds") List<Long> saleItemIds,
			@RequestParam("unitPrices") List<BigDecimal> unitPrices) {
		log.info("change-price prices " + saleItemIds);
		try {
			SalePriceChangeApplyResultDTO body = service.changePrices(saleItemIds, unitPrices);
			return new ResponseEntity<SalePriceChangeApplyResultDTO>(body, HttpStatus.OK);
		} catch (IllegalArgumentException e) {
			return error(e.getMessage());
		}
	}

	/** 환율변경. 외자 전표만 통화 마스터 환율로 금액을 다시 계산한다.
	 *  為替変更。外貨伝票だけ通貨マスタの為替で金額を計算し直す。 */
	@PostMapping("/change-price/rate")
	@ResponseBody
	public ResponseEntity<?> rate(@RequestParam("saleItemIds") List<Long> saleItemIds) {
		log.info("change-price rate " + saleItemIds);
		try {
			SalePriceChangeApplyResultDTO body = service.changeRate(saleItemIds);
			return new ResponseEntity<SalePriceChangeApplyResultDTO>(body, HttpStatus.OK);
		} catch (IllegalArgumentException e) {
			return error(e.getMessage());
		}
	}

	/** 검증에서 막힌 일본어 메시지를 400으로 돌려 화면 문구에 그대로 보여 준다.
	 *  検証で止めた日本語メッセージを 400 で返し、画面の文言にそのまま出す。 */
	private ResponseEntity<Map<String, Object>> error(String message) {
		Map<String, Object> body = new HashMap<String, Object>();
		body.put("message", message);
		return new ResponseEntity<Map<String, Object>>(body, HttpStatus.BAD_REQUEST);
	}
}
