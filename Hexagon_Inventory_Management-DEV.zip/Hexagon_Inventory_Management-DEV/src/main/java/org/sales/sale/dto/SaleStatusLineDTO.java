package org.sales.sale.dto;

import java.math.BigDecimal;

import lombok.Data;

/**
 * 판매현황 한 줄. 라인별은 TB_SALE_ITEM 1행이고, 전표별은 그 판매의 합계다.
 * 수량, 단가, 공급가액, 부가세, 합계는 저장된 값이다.
 * 販売状況の1行。ライン別は TB_SALE_ITEM の1行であり、伝票別はその販売の合計である。
 * 数量、単価、供給価額、付加税、合計は保存された値である。
 */
@Data
public class SaleStatusLineDTO {

	private Long saleId;
	private Long saleItemId;
	private Integer lineNo;
	private String saleDate;
	private String dateNo;
	private String voucherNo;
	private Long partnerId;
	private String partnerName;
	private Long itemId;
	private String itemCode;
	private String itemName;
	private String spec;
	private String managerName;
	private Long warehouseId;
	private String warehouseName;
	private BigDecimal quantity;
	private BigDecimal unitPrice;
	private BigDecimal supplyAmount;
	private BigDecimal vatAmount;
	private BigDecimal totalAmount;
	private String transactionName;
	private String currencyName;
	private String inputTypeName;
	private String saleInputType;
	/** 비교기간 수량. 같은 조건으로 따로 조회한 값이고, 차이는 화면에서 계산한다. 比較期間数量。同じ条件で別に照会した値であり、差は画面で計算する。 */
	private BigDecimal compareQuantity;
}
