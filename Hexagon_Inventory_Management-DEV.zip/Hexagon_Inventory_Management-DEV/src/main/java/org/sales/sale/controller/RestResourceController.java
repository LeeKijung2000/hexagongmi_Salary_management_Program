package org.sales.sale.controller;

import java.util.List;

import org.sales.sale.dto.ItemLookupDTO;
import org.sales.sale.dto.ManagerLookupDTO;
import org.sales.sale.dto.PartnerLookupDTO;
import org.sales.sale.dto.WarehouseLookupDTO;
import org.sales.sale.service.CommonLookupService;
import org.sales.sale.dto.ItemStockDTO;
import org.sales.sale.service.SaleInputOneService;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.zerock.controller.BusinessPartnerController;
import org.zerock.controller.ItemController;
import org.zerock.controller.WarehouseController;
import org.zerock.domain.BusinessPartnerManagerVO;
import org.zerock.domain.BusinessPartnerVO;
import org.zerock.domain.ItemVO;
import org.zerock.domain.WarehouseVO;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@AllArgsConstructor
/**
 * 판매입력이 쓰는 조회와 신규 등록. 목록은 GET, 등록은 POST 이고 기존 기준정보 화면의 등록 주소는 그대로 둔다.
 * 販売入力が使う照会と新規登録。一覧は GET、登録は POST であり、既存の基準情報画面の登録アドレスはそのまま残す。
 */
public class RestResourceController {

	private CommonLookupService lookup;

	private SaleInputOneService saleService;

	private BusinessPartnerController partnerController;

	private WarehouseController warehouseController;

	private ItemController itemController;

	/** 거래처 목록. 코드, 이름, 검색창내용이 키워드와 맞는 사용 중 거래처를 돌려준다.
	 *  取引先一覧。コード、名前、検索窓内容がキーワードに合う使用中の取引先を返す。 */
	@GetMapping("/partners")
	@ResponseBody
	public List<PartnerLookupDTO> partners(@RequestParam(value = "keyword", required = false) String keyword,
			@RequestParam(value = "includeUnused", defaultValue = "false") boolean includeUnused) {
		return lookup.getPartners(keyword, includeUnused);
	}

	/** 거래처 등록. 기준정보 등록과 같은 처리를 쓰고, 성공하면 success 를 돌려준다.
	 *  取引先登録。基準情報の登録と同じ処理を使い、成功すれば success を返す。 */
	@PostMapping(value = "/partners", produces = MediaType.TEXT_PLAIN_VALUE + ";charset=UTF-8")
	@ResponseBody
	public ResponseEntity<String> createPartner(BusinessPartnerVO partner) {
		return partnerController.register(partner);
	}

	/** 창고 목록. 구분, 창고코드, 창고명을 돌려준다.
	 *  倉庫一覧。区分、倉庫コード、倉庫名を返す。 */
	@GetMapping("/warehouses")
	@ResponseBody
	public List<WarehouseLookupDTO> warehouses(@RequestParam(value = "keyword", required = false) String keyword,
			@RequestParam(value = "includeUnused", defaultValue = "false") boolean includeUnused) {
		return lookup.getWarehouses(keyword, includeUnused);
	}

	/** 창고 등록. 기준정보 등록과 같은 처리를 쓴다.
	 *  倉庫登録。基準情報の登録と同じ処理を使う。 */
	@PostMapping(value = "/warehouses", produces = MediaType.TEXT_PLAIN_VALUE + ";charset=UTF-8")
	@ResponseBody
	public ResponseEntity<String> createWarehouse(WarehouseVO warehouse) {
		return warehouseController.register(warehouse);
	}

	/** 사원 목록. 사원코드와 사원명을 돌려준다.
	 *  社員一覧。社員コードと社員名を返す。 */
	@GetMapping("/managers")
	@ResponseBody
	public List<ManagerLookupDTO> managers(@RequestParam(value = "keyword", required = false) String keyword) {
		return lookup.getManagers(keyword);
	}

	/** 사원 등록. 기준정보 등록과 같은 처리를 쓴다.
	 *  社員登録。基準情報の登録と同じ処理を使う。 */
	@PostMapping(value = "/managers", produces = MediaType.TEXT_PLAIN_VALUE + ";charset=UTF-8")
	@ResponseBody
	public ResponseEntity<String> createManager(BusinessPartnerManagerVO manager) {
		return partnerController.managerRegister(manager);
	}

	/** 품목 목록. 품목코드, 품목명, 검색창내용, 규격, 전체재고, 출고단가를 돌려준다.
	 *  品目一覧。品目コード、品目名、検索窓内容、規格、全体在庫、出庫単価を返す。 */
	@GetMapping("/items")
	@ResponseBody
	public List<ItemLookupDTO> items(@RequestParam(value = "keyword", required = false) String keyword) {
		return lookup.getItems(keyword);
	}

	/** 품목 등록. 기준정보 등록과 같은 검사를 쓰고, 품목 마스터에만 insert 한다.
	 *  品目登録。基準情報の登録と同じ検査を使い、品目マスタだけに insert する。 */
	@PostMapping(value = "/items", produces = MediaType.TEXT_PLAIN_VALUE + ";charset=UTF-8")
	@ResponseBody
	public ResponseEntity<String> createItem(ItemVO item) {
		return itemController.register(item, null);
	}

	/** 품목 재고. 전체 재고와 출하창고 재고를 읽어 화면에만 준다. 재고 수량은 바꾸지 않는다.
	 *  品目在庫。全体在庫と出荷倉庫の在庫を読んで画面に渡すだけである。在庫数量は変えない。 */
	@GetMapping("/items/{itemId}/stock")
	@ResponseBody
	public ItemStockDTO stock(@PathVariable("itemId") Long itemId,
			@RequestParam("warehouseId") Long warehouseId) {
		log.info("item stock itemId: " + itemId + ", warehouseId: " + warehouseId);
		return saleService.getItemStock(itemId, warehouseId);
	}
}
