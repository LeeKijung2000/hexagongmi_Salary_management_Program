package org.sales.sale.dto;

import java.math.BigDecimal;

import lombok.Data;

/**
 * 조회 조건 전체의 합계. 화면에 자른 목록과 별도로 전 건을 더한다.
 * 照会条件全体の合計。画面で切った一覧とは別に全件を足す。
 */
@Data
public class SaleStatusTotalDTO {

	private BigDecimal quantity;
	private BigDecimal supplyAmount;
	private BigDecimal vatAmount;
	private BigDecimal totalAmount;
}
