package org.sales.sale.dto;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

/**
 * 결제 등록. 화면이 결제금액에서 나눈 공급가액과 부가세를 그대로 저장하고, 판매 전표 금액은 다시 계산하지 않는다.
 * 決済登録。画面が決済金額から分けた供給価額と付加税をそのまま保存し、販売伝票の金額は計算し直さない。
 */
@Data
public class PaymentInquirySaveDTO {

	private Long paymentId;
	/** 화면 일시. 비어 있으면 지금이다. 画面の日時。空なら今である。 */
	private String requestedAtText;
	private Date requestedAt;
	private Long requesterId;
	private Long businessPartnerId;
	private Long saleId;
	private Long warehouseId;
	private String companyCode;
	private String vanCode;
	private String paymentMethod;
	private Integer installmentMonths;
	private String receiptType;
	private String easyPaymentNo;
	private String receiptPrintYn;
	private BigDecimal supplyAmount;
	private BigDecimal vatRate;
	private BigDecimal vatAmount;
	private BigDecimal paymentAmount;
	private String paymentStatus;
	private String approvalNumber;
	private String failureReason;
	private String inventoryVoucherNo;
	private String accountingVoucherNo;
	private String forcedYn;
	private Date cancelledAt;
}
