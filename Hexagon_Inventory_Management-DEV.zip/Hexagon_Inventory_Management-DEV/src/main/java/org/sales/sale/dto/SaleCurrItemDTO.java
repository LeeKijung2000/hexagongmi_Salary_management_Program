package org.sales.sale.dto;

import java.math.BigDecimal;

import lombok.Data;

/**
 * 판매입력1 품목 라인. SALE_CURR_ITEM.
 * 공급가액 = 수량 * 단가 - 할인. 합계 = 공급가액 + 부가세.
 * 販売入力1品目行。SALE_CURR_ITEM。
 * 供給価額 = 数量 * 単価 - 割引。合計 = 供給価額 + 付加税。
 */
@Data
public class SaleCurrItemDTO {

    private Long itemId;
    private Long saleId;
    private Long itemPk;
    /** 화면에서 고친 품목코드. 판매 품목의 ITEM_CODE_SNAP에만 저장하고 TB_ITEM은 수정하지 않는다. 값이 있으면 마스터 코드보다 이 값을 넣는다.
     *  画面で直した品目コード。販売品目のITEM_CODE_SNAPだけに保存しTB_ITEMは修正しない。値があればマスタコードよりこの値を入れる。 */
    private String itemCode;
    private String itemNm;
    private String spec;
    /** 재고불러오기가 넣는 전체수량. 모든 창고 재고 합이며 표시용이다. 차감은 이 값이 아니라 판매수량으로 한다.
     *  在庫読込が入る全体数量。全倉庫の在庫合計であり表示用である。減算はこの値ではなく販売数量で行う。 */
    private BigDecimal totQty;
    /** 선택한 출하창고의 재고 합. 재고불러오기가 넣는 표시값이다. 정상 저장은 이 칸이 아니라 판매수량을 출하창고 재고에서 뺀다.
     *  選んだ出荷倉庫の在庫合計。在庫読込が入る表示値である。正常保存はこの欄ではなく販売数量を出荷倉庫の在庫から引く。 */
    private BigDecimal whQty;
    private BigDecimal saleQty;
    private BigDecimal unitPrice;
    private BigDecimal discountAmt;
    private BigDecimal supplyAmt;
    private BigDecimal vatAmt;
    private BigDecimal lineAmt;
    private String remark;

    /** 주문 버튼으로 불러온 원천 연결. 전표불러오기 모달은 조회 JSP만 열고 이 연결을 넣지 않는다. 없으면 null.
     *  注文ボタンで読み込んだ元伝票の接続。伝票読込モーダルは照会JSPだけ開き、この接続は入れない。なければ null。 */
    private SaleSlipLinkDTO slipLink;
}
