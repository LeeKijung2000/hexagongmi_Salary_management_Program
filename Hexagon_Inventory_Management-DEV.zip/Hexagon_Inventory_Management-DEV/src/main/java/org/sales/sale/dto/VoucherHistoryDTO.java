package org.sales.sale.dto;

import lombok.Data;

/**
 * 판매 전표 이력 한 줄. 전표를 지운 뒤에도 DOCUMENT_ID로 취소 이력이 남는다.
 * 販売伝票履歴の1行。伝票を消したあとも DOCUMENT_ID で取消履歴が残る。
 */
@Data
public class VoucherHistoryDTO {

	private Long historyId;
	private Long documentId;
	private String actionType;
	/** 화면 표시용 작업명. 画面表示用の作業名。 */
	private String actionName;
	private String description;
	/** yyyy/MM/dd. 작업일자. 作業日付。 */
	private String workedAt;
	/** yyyy/MM/dd-당일순번. 年/月/日-当日の伝票番号。 */
	private String dateNo;
	private String partnerCode;
	private String partnerName;
	private String itemName;
	private String managerCode;
	private String managerName;
	/** 로그인 사용자가 없으면 GUEST. ログインユーザーがなければ GUEST。 */
	private String workerName;
	/** 확인 또는 미확인. 確認または未確認。 */
	private String progressName;
}
