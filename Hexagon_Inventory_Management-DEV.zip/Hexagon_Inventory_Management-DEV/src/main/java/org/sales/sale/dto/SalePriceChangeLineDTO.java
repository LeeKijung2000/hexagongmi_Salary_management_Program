package org.sales.sale.dto;

import java.math.BigDecimal;

import lombok.Data;

/**
 * 판매단가일괄변경 조회 한 줄. TB_SALE_ITEM 1행이고, 금액은 저장된 값이다.
 * 販売単価一括変更の照会1行。TB_SALE_ITEM の1行であり、金額は保存された値である。
 */
@Data
public class SalePriceChangeLineDTO {

	private Long saleId;
	private Long saleItemId;
	private Integer lineNo;
	private String saleDate;
	private String dateNo;
	private String partnerName;
	private String managerName;
	private String warehouseName;
	private String itemCode;
	private String itemName;
	private String spec;
	private String unitName;
	private BigDecimal quantity;
	private BigDecimal unitPrice;
	private BigDecimal supplyAmount;
	private BigDecimal vatAmount;
	private BigDecimal totalAmount;
	private BigDecimal exchangeRate;
	private String currencyCode;
	private String currencyName;
	/** 화면 통화 칸. 내자 또는 외자. 画面の通貨枠。内貨または外貨。 */
	private String currencyScopeName;
	private String progressName;
	private String transactionName;
	private String inputTypeName;
	/** 전표 최초작성일. TB_SALE.CREATED_AT. 伝票の初回作成日。TB_SALE.CREATED_AT。 */
	private String createdDate;
	/** 품목 행의 최종수정일. 品目行の最終修正日。 */
	private String updatedDate;
}
