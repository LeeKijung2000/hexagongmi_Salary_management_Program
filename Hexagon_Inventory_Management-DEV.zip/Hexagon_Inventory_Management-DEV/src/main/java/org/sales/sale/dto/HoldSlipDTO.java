package org.sales.sale.dto;

import java.math.BigDecimal;

import lombok.Data;

/** 가운데 보류 버튼의 목록 한 줄. 보류번호, 거래처, 품목 요약, 금액, 유형, 창고만 보여 주고 상세는 번호를 눌렀을 때 입력란에 채운다.
 *  中央の保留ボタンの一覧1行。保留番号、取引先、品目の要約、金額、類型、倉庫だけ見せ、詳細は番号を押したとき入力欄に入れる。 */
@Data
public class HoldSlipDTO {

	private Long saleId;
	private String holdNo;
	private String businessPartnerName;
	private String itemSummary;
	private BigDecimal currAmt;
	private String saleType;
	private String warehouseName;
}
