package org.sales.sale.controller;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import org.sales.sale.dto.SaleStatusResultDTO;
import org.sales.sale.dto.SaleStatusSearchDTO;
import org.sales.sale.service.SaleStatusService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/sales/sale")
@AllArgsConstructor
/**
 * 판매현황 화면. 현황과 집계는 이 주소에서 조회만 한다.
 * 販売状況画面。現状と集計はこのアドレスで照会だけする。
 */
public class SaleStatusController {

	private SaleStatusService service;

	/** 판매현황 화면. 기준일자 기본값은 이번 달 1일부터 오늘까지다.
	 *  販売状況画面。基準日付の初期値は今月1日から今日までである。 */
	@GetMapping("/status")
	public String status(Model model) {
		LocalDate today = LocalDate.now();
		model.addAttribute("fromDate", today.withDayOfMonth(1).toString());
		model.addAttribute("toDate", today.toString());
		return "sales/sale/status";
	}

	/** 현황 탭. 시작일이 종료일보다 늦으면 400과 메시지를 돌려준다.
	 *  現状タブ。開始日が終了日より遅ければ 400 とメッセージを返す。 */
	@GetMapping("/status/lines")
	@ResponseBody
	public ResponseEntity<?> lines(SaleStatusSearchDTO search) {
		log.info("status lines " + search);
		try {
			SaleStatusResultDTO body = service.searchLines(search);
			return new ResponseEntity<SaleStatusResultDTO>(body, HttpStatus.OK);
		} catch (IllegalArgumentException e) {
			return error(e.getMessage());
		}
	}

	/** 집계 탭. 집계조건이 없으면 400과 안내 메시지를 돌려준다.
	 *  集計タブ。集計条件がなければ 400 と案内メッセージを返す。 */
	@GetMapping("/status/summary")
	@ResponseBody
	public ResponseEntity<?> summary(SaleStatusSearchDTO search) {
		log.info("status summary " + search);
		try {
			SaleStatusResultDTO body = service.searchSummary(search);
			return new ResponseEntity<SaleStatusResultDTO>(body, HttpStatus.OK);
		} catch (IllegalArgumentException e) {
			return error(e.getMessage());
		}
	}

	/** 검증에서 막힌 일본어 메시지를 400으로 돌려 화면 문구에 그대로 보여 준다.
	 *  検証で止めた日本語メッセージを 400 で返し、画面の文言にそのまま出す。 */
	private ResponseEntity<Map<String, Object>> error(String message) {
		Map<String, Object> body = new HashMap<String, Object>();
		body.put("message", message);
		return new ResponseEntity<Map<String, Object>>(body, HttpStatus.BAD_REQUEST);
	}
}
