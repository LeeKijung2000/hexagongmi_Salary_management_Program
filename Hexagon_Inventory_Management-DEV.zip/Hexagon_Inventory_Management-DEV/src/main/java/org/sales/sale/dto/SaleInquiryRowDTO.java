package org.sales.sale.dto;

import java.math.BigDecimal;

import lombok.Data;

/**
 * 판매조회 목록의 한 줄. 일자-No는 판매일자와 판매번호이고, 품목명은 첫 줄만 보이며 더 있으면 외 n건을 붙인다.
 * 販売照会一覧の1行。日付-Noは販売日付と販売番号であり、品目名は先頭行だけ見せ、さらにあれば外 n件を付ける。
 */
@Data
public class SaleInquiryRowDTO {

	private int rowNo;
	private Long saleId;
	/** yyyy-MM-dd - 판매번호. yyyy-MM-dd - 販売番号。 */
	private String dateNo;
	private String partnerName;
	private String itemName;
	/** 공급가액 합계. TB_SALE.SUPPLY_AMOUNT. 供給価額合計。 */
	private BigDecimal supplyAmount;
	private String transactionName;
	private String warehouseName;
	/** 확인 또는 미확인. 画面は 確認 または 未確認。 */
	private String progressName;
	/** 불러온 전표 연결이 1건이라도 있으면 1. 読込伝票の接続が1件でもあれば 1。 */
	private Integer hasSource;
	/** 판매입력1은 NORMAL, 판매입력2는 POS다. 販売入力1は NORMAL、販売入力2は POS である。 */
	private String saleInputType;
}
