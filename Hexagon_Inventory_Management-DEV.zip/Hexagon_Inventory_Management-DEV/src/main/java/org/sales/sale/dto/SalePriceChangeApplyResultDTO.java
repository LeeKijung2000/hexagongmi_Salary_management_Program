package org.sales.sale.dto;

import lombok.Data;

/**
 * 단가변경 또는 환율변경 결과. 전표마다 커밋하고, 실패한 전표만 롤백한 건수를 담는다.
 * 単価変更または為替変更の結果。伝票ごとにコミットし、失敗した伝票だけロールバックした件数を入れる。
 */
@Data
public class SalePriceChangeApplyResultDTO {

	private int changedSlips;
	private int changedLines;
	private int skippedDomestic;
	private int failedSlips;
	private String message;
}
