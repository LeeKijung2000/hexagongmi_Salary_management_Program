package org.sales.sale.dto;

import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

/**
 * 판매단가일괄변경 조회 조건. 값이 있는 항목만 SQL 조건이 된다.
 * 販売単価一括変更の照会条件。値がある項目だけ SQL 条件になる。
 */
@Data
public class SalePriceChangeSearchDTO {

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date fromDate;

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date toDate;

	/** TB_SALE.TRANSACTION_TYPE. 비어 있으면 전체. 空なら全体。 */
	private String transactionType;

	/** DOMESTIC, FOREIGN. 내자는 통화가 없거나 KR, 외자는 KR이 아닌 통화만 남긴다.
	 *  内貨は通貨がないか KR、外貨は KR でない通貨だけ残す。 */
	private String currencyScope;

	private Long warehouseId;

	private Long partnerId;

	private Long itemId;

	/** ALL, NORMAL, RETURN. 반품은 전표상태가 RETURN이거나 입력구분이 RETURN인 줄만 남긴다.
	 *  返品は伝票状態が RETURN か、入力区分が RETURN の行だけ残す。 */
	private String inputScope;

	/** 전체면 비운다. 미확인은 UNCONFIRMED, 확인은 CONFIRMED. 全体なら空ける。未確認は UNCONFIRMED、確認は CONFIRMED。 */
	private List<String> progressStatuses;

	/** 한 번에 읽는 줄 수. 서비스가 1,000으로 고정한다. 一度に読む行数。サービスが 1,000 に固定する。 */
	private Integer limit;
}
