package org.sales.sale.service;

import java.util.List;

import org.sales.sale.dto.HoldSlipDTO;
import org.sales.sale.dto.ItemStockDTO;
import org.sales.sale.dto.SaleInputTwoDTO;

/**
 * 판매입력2 서비스. 판매입력1과 같은 저장, 보류, 재고 차감에 금액조정과 적요를 더한다.
 * 정상 저장만 출하창고 재고에서 판매수량을 뺀다. 보류는 재고를 건드리지 않는다. 판매입력구분은 POS다.
 * 販売入力2サービス。販売入力1と同じ保存、保留、在庫減算に金額調整と摘要を足す。
 * 正常保存だけ出荷倉庫の在庫から販売数量を引く。保留は在庫を変えない。販売入力区分はPOSである。
 */
public interface SaleInputTwoService {

	/** 새 전표를 저장한다. 판매입력구분은 POS다. 정상이면 출하창고 수량이 0보다 큰 품목만 저장하고 재고를 뺀다.
	 *  新しい伝票を保存する。販売入力区分はPOSである。正常なら出荷倉庫数量が0より大きい品目だけ保存し、在庫を引く。 */
	void register(SaleInputTwoDTO sale);

	/** 전표 한 건. 헤더, 품목, 금액조정을 읽는다. 伝票1件。ヘッダ、品目、金額調整を読む。 */
	SaleInputTwoDTO get(Long saleId);

	/** 이미 있는 전표를 고친다. 이전에 정상으로 빠진 재고는 되돌리고, 다시 정상이면 새 수량으로 뺀다.
	 *  既にある伝票を直す。以前正常で引いた在庫は戻し、再び正常なら新しい数量で引く。 */
	boolean modify(SaleInputTwoDTO sale);

	/** 재고불러오기. 전체 창고 합과 출하창고 수량만 읽고 재고는 줄이지 않는다.
	 *  在庫読込。全倉庫の合計と出荷倉庫数量だけ読み、在庫は減らさない。 */
	ItemStockDTO getItemStock(Long itemPk, Long warehousePk);

	/** 판매입력2 보류 전표 수. 새 보류가 5건을 넘는지 볼 때 쓴다.
	 *  販売入力2の保留伝票数。新しい保留が5件を超えるか見るときに使う。 */
	int countHolds();

	/** 판매입력2 보류 목록. POS 보류만 가져온다. 販売入力2の保留一覧。POSの保留だけ取る。 */
	List<HoldSlipDTO> getHolds();

	/** 보류전표를 입력란에 채우기만 한다. 행은 지우지 않는다.
	 *  保留伝票を入力欄に入れるだけである。行は消さない。 */
	SaleInputTwoDTO takeHold(Long saleId);

	/** 고른 보류전표를 지운다. 금액조정, 품목, 이력, 헤더 순서로 지운다.
	 *  選んだ保留伝票を消す。金額調整、品目、履歴、ヘッダの順に消す。 */
	void deleteHolds(List<Long> saleIds);
}
