package org.sales.sale.dto;

import java.math.BigDecimal;

import lombok.Data;

/** 재고불러오기 결과. TOT_QTY는 그 품목의 창고 재고 합이고, WH_QTY는 선택한 출하창고의 재고 합이다. 이 조회는 재고를 줄이지 않는다. 차감은 정상 저장에서 판매수량으로 한다.
 *  在庫読込の結果。TOT_QTYはその品目の倉庫在庫合計で、WH_QTYは選んだ出荷倉庫の在庫合計である。この照会は在庫を減らさない。減算は正常保存で販売数量により行う。 */
@Data
public class ItemStockDTO {

    private Long itemPk;
    private BigDecimal totQty;
    private BigDecimal whQty;
}
