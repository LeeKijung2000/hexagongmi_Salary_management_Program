package org.sales.sale.dto;

import lombok.Data;

/**
 * 이력을 남길 때 같이 적는 전표 모습. 전표를 지운 뒤에도 거래처와 품목을 이력에서 볼 수 있게 한다.
 * 履歴を残すときに一緒に書く伝票の姿。伝票を消したあとも取引先と品目を履歴で見られるようにする。
 */
@Data
public class SaleHistorySnapDTO {

	/** NORMAL은 판매입력1, POS는 판매입력2. NORMALは販売入力1、POSは販売入力2。 */
	private String inputType;
	private String dateNo;
	private String partnerCode;
	private String partnerName;
	private String itemName;
	private String managerCode;
	private String managerName;
	private String progressName;
}
