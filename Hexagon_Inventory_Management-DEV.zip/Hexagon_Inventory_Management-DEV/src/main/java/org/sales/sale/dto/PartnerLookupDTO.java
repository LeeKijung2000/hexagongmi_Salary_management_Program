package org.sales.sale.dto;

import lombok.Data;

/** 거래처검색. 코드, 거래처명, 검색창내용. 상세내역은 화면 문구만 표시한다.
 *  取引先検索。コード、取引先名、検索窓内容。詳細は画面文言だけ表示する。 */
@Data
public class PartnerLookupDTO {

	private Long businessPartnerId;
	private String businessPartnerCode;
	private String businessPartnerName;
	private String searchContent;
}
