package org.sales.sale.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/sales/sale")
/**
 * 결제내역데이터비교. 프로젝트 기간 안에 구현하지 못해 화면 주소만 열어 둔다.
 * 決済履歴データ比較。プロジェクト期間内に実装できず、画面のアドレスだけ開いておく。
 */
public class SaleController {

    @GetMapping("/payment-compare")
    public String paymentCompare() {
        return "sales/sale/payment-compare";
    }
}
