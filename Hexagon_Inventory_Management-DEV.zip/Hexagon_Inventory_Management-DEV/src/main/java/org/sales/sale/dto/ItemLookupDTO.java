package org.sales.sale.dto;

import java.math.BigDecimal;

import lombok.Data;

/** 품목검색. 품목코드, 품목명, 검색창내용, 규격, 전체재고, 출고단가.
 *  品目検索。品目コード、品目名、検索窓内容、規格、全体在庫、出庫単価。 */
@Data
public class ItemLookupDTO {

	private Long itemPk;
	private String itemCode;
	private String itemName;
	private String searchContent;
	private String spec;
	private BigDecimal qty;
	/** 출고단가. TB_ITEM_PRICE의 SALES. 판매 품목 단가로 넣는다.
	 *  出庫単価。TB_ITEM_PRICEのSALES。販売品目の単価に入れる。 */
	private BigDecimal unitPrice;
}
