package org.sales.sale.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.sales.sale.dto.CurrencyDTO;
import org.sales.sale.dto.ItemLookupDTO;
import org.sales.sale.dto.ManagerLookupDTO;
import org.sales.sale.dto.PartnerLookupDTO;
import org.sales.sale.dto.WarehouseLookupDTO;

/**
 * 공통 조회 Dao. 사용중단포함은 거래처와 창고 조회에만 적용한다. 품목에는 USE_YN이 없고, 담당자 조회에는 사용중단 조건을 두지
 * 않는다. 共通照会 Dao。使用中止含むは取引先と倉庫の照会だけに適用する。 品目にはUSE_YNがなく、担当者照会には使用中止の条件を置かない。
 */
public interface CommonLookupDao {

	/** 거래처검색. 코드, 거래처명, 검색창내용. includeUnused가 아니면 사용 중만 본다.
	 *  取引先検索。コード、取引先名、検索窓内容。includeUnusedでなければ使用中だけ見る。 */
	List<PartnerLookupDTO> selectPartners(@Param("keyword") String keyword,
			@Param("includeUnused") boolean includeUnused);

	/** 창고검색. 구분, 창고코드, 창고명. 사용중단 창고는 includeUnused일 때만 포함한다.
	 *  倉庫検索。区分、倉庫コード、倉庫名。使用中止の倉庫はincludeUnusedのときだけ含める。 */
	List<WarehouseLookupDTO> selectWarehouses(@Param("keyword") String keyword,
			@Param("includeUnused") boolean includeUnused);

	/** 사원검색. 사용 중인 사원코드와 사원명만 돌려준다.
	 *  社員検索。使用中の社員コードと社員名だけ返す。 */
	List<ManagerLookupDTO> selectManagers(@Param("keyword") String keyword);

	/** 품목검색. 코드, 품목명, 검색창내용, 규격, 전체재고, 출고단가. 사용 중인 품목만 본다.
	 *  品目検索。コード、品目名、検索窓内容、規格、全体在庫、出庫単価。使用中の品目だけ見る。 */
	List<ItemLookupDTO> selectItems(@Param("keyword") String keyword);

	/**
	 * 사용 중인 통화 목록. TB_CURRENCY. 使用中の通貨一覧。TB_CURRENCY。
	 */
	List<CurrencyDTO> selectCurrencies();

	/**
	 * 통화명으로 한 건. 기본 통화와 이름 중복 확인에 쓴다. 通貨名で1件。既定通貨と名前の重複確認に使う。
	 */
	CurrencyDTO selectCurrencyByName(@Param("currencyName") String currencyName);

	/**
	 * 통화코드로 한 건. 기본 원화는 KR이다. 通貨コードで1件。既定の韓国ウォンはKRである。
	 */
	CurrencyDTO selectCurrencyByCode(@Param("currencyCode") String currencyCode);

	/**
	 * 다음 통화 번호. 次の通貨番号。
	 */
	Long nextCurrencyId();

	/**
	 * 통화 한 건 추가. 코드가 없으면 C와 번호로 만든다. 通貨1件を追加する。コードがなければCと番号で作る。
	 */
	void insertCurrency(CurrencyDTO currency);
}
