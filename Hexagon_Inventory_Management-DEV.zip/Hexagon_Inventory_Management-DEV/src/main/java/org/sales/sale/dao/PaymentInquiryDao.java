package org.sales.sale.dao;

import java.util.List;

import org.sales.sale.dto.PaymentInquiryDetailDTO;
import org.sales.sale.dto.PaymentInquiryRowDTO;
import org.sales.sale.dto.PaymentInquirySaveDTO;
import org.sales.sale.dto.PaymentInquirySearchDTO;

/**
 * 결제내역 Dao. 목록과 상세는 읽고, 등록은 TB_PAYMENT 한 건만 넣는다.
 * 決済履歴 Dao。一覧と詳細は読み、登録は TB_PAYMENT を1件だけ入れる。
 */
public interface PaymentInquiryDao {

	/** 검색에 걸리는 결제 건수. 1,000건 제한은 적용하지 않는다.
	 *  検索に掛かる決済件数。1,000件制限は掛けない。 */
	int countList(PaymentInquirySearchDTO search);

	/** 결제 목록. 결제일시, 결제ID 내림차순이고 1,000건에서 자른다.
	 *  決済一覧。決済日時、決済IDの降順であり、1,000件で切る。 */
	List<PaymentInquiryRowDTO> selectList(PaymentInquirySearchDTO search);

	/** 결제 한 건. 없으면 null이다.
	 *  決済1件。なければ null である。 */
	PaymentInquiryDetailDTO selectDetail(Long paymentId);

	/** 거래처가 있는지. 取引先があるか。 */
	int countPartner(Long businessPartnerId);

	/** 요청자가 있는지. 依頼者がいるか。 */
	int countManager(Long managerId);

	/** 창고가 있는지. 倉庫があるか。 */
	int countWarehouse(Long warehouseId);

	/** TB_PAYMENT 한 건. PAYMENT_ID는 TB_PAYMENT_SEQ.NEXTVAL이다.
	 *  TB_PAYMENT 1件。PAYMENT_ID は TB_PAYMENT_SEQ.NEXTVAL である。 */
	int insertPayment(PaymentInquirySaveDTO save);
}
