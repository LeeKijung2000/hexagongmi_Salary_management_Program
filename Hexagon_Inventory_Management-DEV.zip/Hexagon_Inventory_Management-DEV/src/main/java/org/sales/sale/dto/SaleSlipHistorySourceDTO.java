package org.sales.sale.dto;

import java.util.Date;

import lombok.Data;

/**
 * 전표 이력 창을 만들기 전 조회 한 줄. 작업 시각, 진행상태, 행위만 화면으로 넘긴다.
 * 伝票履歴の窓を作る前の照会1行。作業時刻、進行状態、行為だけ画面へ渡す。
 */
@Data
public class SaleSlipHistorySourceDTO {

	private Date workedAt;
	private String actionType;
	private String description;
	private String afterStatus;
	private String dateNo;
	/** 전표가 남아 있을 때의 진행상태. 伝票が残っているときの進行状態。 */
	private String progressName;
}
