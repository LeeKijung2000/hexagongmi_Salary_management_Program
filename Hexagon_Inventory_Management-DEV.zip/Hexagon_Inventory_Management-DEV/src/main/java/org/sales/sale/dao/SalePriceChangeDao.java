package org.sales.sale.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.sales.sale.dto.SalePriceChangeItemDTO;
import org.sales.sale.dto.SalePriceChangeKeyDTO;
import org.sales.sale.dto.SalePriceChangeLineDTO;
import org.sales.sale.dto.SalePriceChangeSearchDTO;
import org.sales.sale.dto.SalePriceChangeSlipDTO;

/**
 * 판매단가일괄변경 Dao. 조회는 TB_SALE, TB_SALE_ITEM을 읽고, 변경은 단가와 금액만 고친다.
 * 販売単価一括変更 Dao。照会は TB_SALE、TB_SALE_ITEM を読み、変更は単価と金額だけ直す。
 */
public interface SalePriceChangeDao {

	/** 조건에 맞는 품목 줄 수. 1,000건 제한은 적용하지 않는다.
	 *  条件に合う品目行数。1,000件制限は掛けない。 */
	int countLines(SalePriceChangeSearchDTO search);

	/** 조건에 맞는 품목 줄. 판매일자, 판매번호, 줄번호 오름차순이고 1,000건에서 자른다.
	 *  条件に合う品目行。販売日付、販売番号、行番号の昇順であり、1,000件で切る。 */
	List<SalePriceChangeLineDTO> selectLines(SalePriceChangeSearchDTO search);

	/** 고른 품목이 속한 정상, 반품 전표. 판매일자, 판매번호 순이다.
	 *  選んだ品目が属する正常、返品伝票。販売日付、販売番号順である。 */
	List<SalePriceChangeKeyDTO> selectTargets(@Param("saleItemIds") List<Long> saleItemIds);

	/** 전표 헤더와 통화 마스터 환율. 없거나 취소, 보류면 null이다.
	 *  伝票ヘッダと通貨マスタの為替。ないか取消、保留なら null である。 */
	SalePriceChangeSlipDTO selectSlip(@Param("saleId") Long saleId);

	/** 그 전표의 모든 품목. 헤더 합계는 고르지 않은 줄까지 더한다.
	 *  その伝票のすべての品目。ヘッダ合計は選んでいない行まで足す。 */
	List<SalePriceChangeItemDTO> selectItems(@Param("saleId") Long saleId);

	/** 판매 품목 스냅의 단가, 공급가액, 부가세, 합계. 품목 마스터, 진행상태, 재고는 건드리지 않는다.
	 *  販売品目スナップの単価、供給価額、付加税、合計。品目マスタ、進行状態、在庫は触らない。 */
	int updateItem(SalePriceChangeItemDTO item);

	/** 헤더 공급가액, 부가세, 합계. 환율은 그대로 둔다.
	 *  ヘッダの供給価額、付加税、合計。為替はそのままにする。 */
	int updateHeaderAmounts(SalePriceChangeSlipDTO slip);

	/** 헤더 환율과 금액. 환율변경에서만 쓴다.
	 *  ヘッダの為替と金額。為替変更でだけ使う。 */
	int updateHeaderRate(SalePriceChangeSlipDTO slip);
}
