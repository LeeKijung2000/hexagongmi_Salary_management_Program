package org.sales.sale.dto;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;

/**
 * 판매입력2 한 전표. 헤더, 품목, 금액조정이다.
 * 빈 품목 줄과 이름이 없는 조정 줄은 저장하지 않는다.
 * 販売入力2の伝票1件。ヘッダ、品目、金額調整である。
 * 空の品目行と名前のない調整行は保存しない。
 */
@Data
public class SaleInputTwoDTO {

	private SaleHeaderDTO header;
	private List<SaleLineDTO> items = new ArrayList<SaleLineDTO>();
	private List<SaleAdjustmentDTO> adjustments = new ArrayList<SaleAdjustmentDTO>();
}
