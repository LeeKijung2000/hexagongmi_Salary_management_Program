package org.sales.sale.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;
import java.util.List;

import org.sales.sale.dto.CurrencyDTO;
import org.sales.sale.service.CommonLookupService;
import org.sales.sale.dao.SaleInputTwoDao;
import org.sales.sale.dto.HoldSlipDTO;
import org.sales.sale.dto.ItemStockDTO;
import org.sales.sale.dto.SaleAdjustmentDTO;
import org.sales.sale.dto.SaleHeaderDTO;
import org.sales.sale.dto.SaleHistoryDTO;
import org.sales.sale.dto.SaleInputTwoDTO;
import org.sales.sale.dto.SaleLineDTO;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
@AllArgsConstructor
/**
 * 판매입력2 저장. 헤더, 품목, 금액조정, 이력을 한 트랜잭션에 넣는다.
 * 공급가액은 수량×단가에서 할인을 뺀다. 판매입력구분은 POS다. 정상 저장만 출하창고 재고를 뺀다. 보류는 빼지 않는다.
 * 販売入力2の保存。ヘッダ、品目、金額調整、履歴を一つのトランザクションに入れる。
 * 供給価額は数量×単価から割引を引く。販売入力区分はPOSである。正常保存だけ出荷倉庫の在庫を引く。保留は引かない。
 */
public class SaleInputTwoServiceImpl implements SaleInputTwoService {

	private SaleInputTwoDao mapper;

	private CommonLookupService commonLookup;

	/** 헤더, 품목, 금액조정, 이력을 한 번에 넣는다. 정상이면 재고를 검사한 뒤 판매수량을 뺀다.
	 *  ヘッダ、品目、金額調整、履歴を一度に入れる。正常なら在庫を検査したあと販売数量を引く。 */
	@Override
	@Transactional
	public void register(SaleInputTwoDTO sale) {
		log.info("register......" + sale);
		validate(sale);
		prepareHeader(sale.getHeader(), false);
		// 정상 저장은 출하창고 재고가 0인 품목을 넣지 않는다. 차감 전에 검사해서 전표가 생기지 않게 한다.
		// 正常保存は出荷倉庫の在庫が0の品目を入れない。減算の前に検査し、伝票ができないようにする。
		assertWarehouseStock(sale);
		mapper.insertSale(sale.getHeader());
		saveLines(sale, "등록");
		// 정상 저장만 출하창고 재고에서 판매수량을 뺀다. 보류는 전표만 남긴다.
		// 正常保存だけ出荷倉庫の在庫から販売数量を引く。保留は伝票だけ残す。
		if (countsAsSale(sale.getHeader())) {
			adjustInventory(sale.getHeader(), sale.getItems(), true);
		}
	}

	/** 헤더와 품목, 금액조정을 읽어 화면에 채운다. 재고는 건드리지 않는다.
	 *  ヘッダと品目、金額調整を読んで画面に入れる。在庫は触らない。 */
	@Override
	@Transactional(readOnly = true)
	public SaleInputTwoDTO get(Long saleId) {
		log.info("get......" + saleId);
		SaleInputTwoDTO sale = new SaleInputTwoDTO();
		sale.setHeader(mapper.selectSale(saleId));
		sale.setItems(mapper.selectItems(saleId));
		sale.setAdjustments(mapper.selectAdjustments(saleId));
		return sale;
	}

	/** 헤더를 고친 뒤 품목과 금액조정을 지우고 다시 넣는다. 이전 정상 수량은 되돌린 다음 새 수량으로 뺀다.
	 *  ヘッダを直したあと品目と金額調整を消して入れ直す。前の正常数量は戻してから新しい数量で引く。 */
	@Override
	@Transactional
	public boolean modify(SaleInputTwoDTO sale) {
		log.info("modify......" + sale);
		validate(sale);
		Long saleId = sale.getHeader().getSaleId();
		SaleHeaderDTO previousHeader = mapper.selectSale(saleId);
		List<SaleLineDTO> previousItems = mapper.selectItems(saleId);
		if (previousHeader == null) {
			return false;
		}
		if (sale.getHeader().getProgressStatus() == null) {
			sale.getHeader().setProgressStatus(previousHeader.getProgressStatus());
		}
		prepareHeader(sale.getHeader(), true);
		if (mapper.updateSale(sale.getHeader()) != 1) {
			return false;
		}
		// 이미 정상으로 빠져 있던 수량은 먼저 되돌린다. 그다음 이번 저장이 정상이면 새 판매수량으로 다시 뺀다.
		// 既に正常で引いてあった数量は先に戻す。その後今回の保存が正常なら新しい販売数量で再び引く。
		if (countsAsSale(previousHeader)) {
			adjustInventory(previousHeader, previousItems, false);
		}
		// 이미 빠져 있던 수량을 되돌린 뒤의 출하창고 수량으로 검사한다. 0이면 이번 수정도 롤백된다.
		// 既に引いてあった数量を戻したあとの出荷倉庫数量で検査する。0なら今回の修正もロールバックされる。
		assertWarehouseStock(sale);
		mapper.deleteAdjustmentsBySaleId(saleId);
		mapper.deleteItemsBySaleId(saleId);
		saveLines(sale, "수정");
		if (countsAsSale(sale.getHeader())) {
			adjustInventory(sale.getHeader(), sale.getItems(), true);
		}
		return true;
	}

	/** 저장 전에 검사한다. 거래처, 출하창고, 담당자 키가 없고 품목이 없거나 수량이 0 이하면 저장하지 않는다.
	 *  금액이 있는 조정 줄은 항목명이 있어야 하고, 증감구분은 증가와 감소만 받는다.
	 *  保存前に検査する。取引先、出荷倉庫、担当者キーがなく品目がないか数量が0以下なら保存しない。
	 *  金額がある調整行は項目名が必要で、増減区分は増加と減少だけ受ける。 */
	private void validate(SaleInputTwoDTO sale) {
		SaleHeaderDTO header = sale.getHeader();
		if (header == null || header.getBusinessPartnerId() == null) {
			throw new IllegalArgumentException("取引先を選択してください。"); // 거래처를 선택하세요.
		}
		if (header.getWarehousePk() == null) {
			throw new IllegalArgumentException("出荷倉庫を選択してください。"); // 출하창고를 선택하세요.
		}
		if (header.getManagerId() == null) {
			throw new IllegalArgumentException("担当者を選択してください。"); // 담당자를 선택하세요.
		}
		boolean hasItem = false;
		if (sale.getItems() != null) {
			for (SaleLineDTO item : sale.getItems()) {
				if (item.getItemPk() == null) {
					continue;
				}
				hasItem = true;
				if (item.getSaleQty() == null || item.getSaleQty().compareTo(BigDecimal.ZERO) <= 0) {
					throw new IllegalArgumentException("数量は0より大きい必要があります。"); // 수량은 0보다 커야 합니다.
				}
			}
		}
		if (!hasItem) {
			throw new IllegalArgumentException("品目を入力してください。"); // 품목을 입력하세요.
		}
		if (sale.getAdjustments() != null) {
			for (SaleAdjustmentDTO adjustment : sale.getAdjustments()) {
				boolean named = adjustment.getAdjustmentName() != null && !adjustment.getAdjustmentName().trim().isEmpty();
				boolean hasAmount = adjustment.getSupplyAmt() != null && adjustment.getSupplyAmt().signum() != 0;
				if (!named) {
					if (hasAmount) {
						throw new IllegalArgumentException("調整項目名を入力してください。"); // 조정항목명을 입력하세요.
					}
					continue;
				}
				String sign = adjustment.getIncreaseDecrease();
				if (sign != null && !sign.isEmpty() && !"INCREASE".equals(sign) && !"DECREASE".equals(sign)) {
					throw new IllegalArgumentException("調整区分が正しくありません。"); // 조정구분이 올바르지 않습니다.
				}
			}
		}
	}

	/** 신규는 판매번호와 진행상태 미확인을 채운다. 비어 있으면 일반, 정상, 부가세율 적용, 통화 KR이다.
	 *  新規は販売番号と進行状態の未確認を埋める。空なら一般、正常、付加税率適用、通貨KRである。 */
	private void prepareHeader(SaleHeaderDTO header, boolean keepId) {
		if (!keepId) {
			header.setSaleId(mapper.nextSaleId());
			header.setProgressStatus("未確認"); // 미확인
		}
		if (header.getSaleDiv() == null) {
			header.setSaleDiv("一般"); // 일반
		}
		if (keepId && header.getProgressStatus() == null) {
			header.setProgressStatus("未確認"); // 미확인
		}
		if (header.getVoucherStatus() == null) {
			header.setVoucherStatus("正常"); // 정상
		}
		if (header.getSaleType() == null) {
			header.setSaleType("付加税率適用"); // 부가세율 적용
		}
		if (header.getCurrencyId() == null) {
			CurrencyDTO currency = commonLookup.getCurrencyByCode("KR");
			if (currency != null) {
				header.setCurrencyId(currency.getCurrencyId());
				if (header.getExchangeRate() == null) {
					header.setExchangeRate(
							currency.getExchangeRate() == null ? BigDecimal.ONE : currency.getExchangeRate());
				}
			}
		}
		if (header.getExchangeRate() == null) {
			header.setExchangeRate(BigDecimal.ONE);
		}
		if (header.getCurrAmt() == null) {
			header.setCurrAmt(BigDecimal.ZERO);
		}
		if (header.getVatAmt() == null) {
			header.setVatAmt(BigDecimal.ZERO);
		}
		if (header.getAdjustmentAmt() == null) {
			header.setAdjustmentAmt(BigDecimal.ZERO);
		}
		if (header.getTotalAmt() == null) {
			header.setTotalAmt(BigDecimal.ZERO);
		}
		header.setUpdatedAt(new Date());
	}

	/** 정상 저장만 출하창고 수량을 본다. 0이면 저장하지 않아 전표가 생기지 않는다.
	 *  正常保存だけ出荷倉庫数量を見る。0なら保存せず、伝票ができない。 */
	private void assertWarehouseStock(SaleInputTwoDTO sale) {
		if (!countsAsSale(sale.getHeader()) || sale.getItems() == null) {
			return;
		}
		Long warehousePk = sale.getHeader().getWarehousePk();
		for (SaleLineDTO item : sale.getItems()) {
			if (item.getItemPk() == null || item.getSaleQty() == null
					|| item.getSaleQty().compareTo(BigDecimal.ZERO) <= 0) {
				continue;
			}
			ItemStockDTO stock = mapper.selectItemStock(item.getItemPk(), warehousePk);
			BigDecimal whQty = stock == null || stock.getWhQty() == null ? BigDecimal.ZERO : stock.getWhQty();
			if (whQty.compareTo(BigDecimal.ZERO) <= 0) {
				throw new IllegalArgumentException(itemLabel(item) + "の出荷倉庫数量が0のため保存できません。"); // 의 출하창고 수량이 0이라 저장할 수 없습니다.
			}
		}
	}

	private String itemLabel(SaleLineDTO item) {
		if (item.getItemNm() != null && !item.getItemNm().trim().isEmpty()) {
			return item.getItemNm().trim();
		}
		if (item.getItemCode() != null && !item.getItemCode().trim().isEmpty()) {
			return item.getItemCode().trim();
		}
		return "品目"; // 품목
	}

	/** 전표상태가 정상일 때만 재고를 뺀다. 보류는 전표만 남긴다.
	 *  伝票状態が正常のときだけ在庫を引く。保留は伝票だけ残す。 */
	private boolean countsAsSale(SaleHeaderDTO header) {
		return header != null && "正常".equals(header.getVoucherStatus());
	}

	/** deduct가 참이면 판매수량을 빼고, 거짓이면 같은 수량을 되돌린다.
	 *  deduct が真なら販売数量を引き、偽なら同じ数量を戻す。 */
	private void adjustInventory(SaleHeaderDTO header, List<SaleLineDTO> items, boolean deduct) {
		if (header == null || header.getWarehousePk() == null || items == null) {
			return;
		}
		for (SaleLineDTO item : items) {
			if (item.getItemPk() == null || item.getSaleQty() == null
					|| item.getSaleQty().compareTo(BigDecimal.ZERO) <= 0) {
				continue;
			}
			BigDecimal delta = deduct ? item.getSaleQty().negate() : item.getSaleQty();
			mapper.adjustInventory(header.getWarehousePk(), item.getItemPk(), delta);
		}
	}

	/** 품목과 금액조정을 넣고 헤더 합계를 다시 쓴 뒤 이력을 남긴다. 이름이 없는 조정 줄은 건너뛴다.
	 *  品目と金額調整を入れ、ヘッダ合計を書き直したあと履歴を残す。名前のない調整行は飛ばす。 */
	private void saveLines(SaleInputTwoDTO sale, String actionType) {
		SaleHeaderDTO header = sale.getHeader();
		BigDecimal currAmt = BigDecimal.ZERO;
		BigDecimal vatAmt = BigDecimal.ZERO;
		if (sale.getItems() != null) {
			for (SaleLineDTO item : sale.getItems()) {
				if (item.getItemPk() == null || item.getSaleQty() == null
						|| item.getSaleQty().compareTo(BigDecimal.ZERO) <= 0) {
					continue;
				}
				item.setItemId(mapper.nextItemId());
				item.setSaleId(header.getSaleId());
				if (item.getSpec() == null) {
					item.setSpec(" ");
				}
				if (item.getUnitPrice() == null) {
					item.setUnitPrice(BigDecimal.ZERO);
				}
				applyLineAmounts(header, item);
				mapper.insertItem(item);
				currAmt = currAmt.add(item.getSupplyAmt());
				vatAmt = vatAmt.add(item.getVatAmt());
			}
		}

		BigDecimal adjustmentAmt = BigDecimal.ZERO;
		if (sale.getAdjustments() != null) {
			for (SaleAdjustmentDTO adjustment : sale.getAdjustments()) {
				if (adjustment.getAdjustmentName() == null || adjustment.getAdjustmentName().trim().isEmpty()) {
					continue;
				}
				adjustment.setAdjustmentName(adjustment.getAdjustmentName().trim());
				if (adjustment.getIncreaseDecrease() == null || adjustment.getIncreaseDecrease().isEmpty()) {
					adjustment.setIncreaseDecrease("INCREASE");
				}
				adjustment.setAdjustmentId(mapper.nextAdjustmentId());
				adjustment.setSaleId(header.getSaleId());
				applyAdjustmentAmounts(header, adjustment);
				mapper.insertAdjustment(adjustment);
				if ("DECREASE".equals(adjustment.getIncreaseDecrease())) {
					adjustmentAmt = adjustmentAmt.subtract(adjustment.getTotalAmt());
				} else {
					adjustmentAmt = adjustmentAmt.add(adjustment.getTotalAmt());
				}
			}
		}

		header.setCurrAmt(currAmt);
		header.setVatAmt(vatAmt);
		header.setAdjustmentAmt(adjustmentAmt);
		header.setTotalAmt(currAmt.add(vatAmt).add(adjustmentAmt));
		mapper.updateSale(header);

		SaleHistoryDTO history = new SaleHistoryDTO();
		history.setSaleHistoryId(mapper.nextHistoryId());
		history.setSaleId(header.getSaleId());
		history.setWorkDate(new Date());
		history.setWorker("system");
		history.setProgressStatusAtWork(header.getProgressStatus());
		history.setActionType(actionType);
		mapper.insertHistory(history);
	}

	/** 공급가액은 수량×단가에서 할인을 뺀다. 부가세율 미적용이면 부가세는 0이다.
	 *  供給価額は数量×単価から割引を引く。付加税率未適用なら付加税は0である。 */
	private void applyLineAmounts(SaleHeaderDTO header, SaleLineDTO item) {
		BigDecimal price = item.getUnitPrice() == null ? BigDecimal.ZERO : item.getUnitPrice();
		BigDecimal discount = item.getDiscountAmt() == null ? BigDecimal.ZERO : item.getDiscountAmt();
		BigDecimal supply = item.getSaleQty().multiply(price).subtract(discount);
		if (supply.signum() < 0) {
			supply = BigDecimal.ZERO;
		}
		BigDecimal vat = vatOf(header, supply);
		item.setSupplyAmt(supply);
		item.setVatAmt(vat);
		item.setLineAmt(supply.add(vat));
	}

	/** 조정 합계는 조정 공급가액+부가세다. 감소는 헤더 조정금액에서 뺀다.
	 *  調整合計は調整供給価額+付加税である。減少はヘッダ調整金額から引く。 */
	private void applyAdjustmentAmounts(SaleHeaderDTO header, SaleAdjustmentDTO adjustment) {
		BigDecimal supply = adjustment.getSupplyAmt() == null ? BigDecimal.ZERO : adjustment.getSupplyAmt();
		if (supply.signum() < 0) {
			supply = BigDecimal.ZERO;
		}
		BigDecimal vat = vatOf(header, supply);
		adjustment.setSupplyAmt(supply);
		adjustment.setVatAmt(vat);
		adjustment.setTotalAmt(supply.add(vat));
	}

	/** 부가세율 미적용이면 0, 적용이면 공급가액의 10%를 반올림한다.
	 *  付加税率不適用なら0、適用なら供給価額の10%を丸める。 */
	private BigDecimal vatOf(SaleHeaderDTO header, BigDecimal supply) {
		if (header.getSaleType() != null && "付加税率不適用".equals(header.getSaleType())) {
			return BigDecimal.ZERO;
		}
		return supply.multiply(new BigDecimal("0.1")).setScale(0, RoundingMode.HALF_UP);
	}

	/** 재고불러오기. 수량을 읽기만 한다. 在庫読込。数量を読むだけである。 */
	@Override
	@Transactional(readOnly = true)
	public ItemStockDTO getItemStock(Long itemPk, Long warehousePk) {
		return mapper.selectItemStock(itemPk, warehousePk);
	}

	/** POS 보류 건수. POSの保留件数。 */
	@Override
	@Transactional(readOnly = true)
	public int countHolds() {
		return mapper.countHolds();
	}

	/** POS 보류 목록. POSの保留一覧。 */
	@Override
	@Transactional(readOnly = true)
	public List<HoldSlipDTO> getHolds() {
		return mapper.selectHolds();
	}

	/** 보류전표를 화면에 채우기만 하고 행은 지우지 않는다.
	 *  保留伝票を画面に入れるだけで行は消さない。 */
	@Override
	@Transactional(readOnly = true)
	public SaleInputTwoDTO takeHold(Long saleId) {
		return get(saleId);
	}

	/** 고른 보류를 금액조정, 품목, 이력, 헤더 순으로 지운다. 재고는 되돌리지 않는다.
	 *  選んだ保留を金額調整、品目、履歴、ヘッダの順に消す。在庫は戻さない。 */
	@Override
	@Transactional
	public void deleteHolds(List<Long> saleIds) {
		if (saleIds == null) {
			return;
		}
		for (Long saleId : saleIds) {
			mapper.deleteAdjustmentsBySaleId(saleId);
			mapper.deleteItemsBySaleId(saleId);
			mapper.deleteHistoryBySaleId(saleId);
			mapper.deleteSale(saleId);
		}
	}
}
