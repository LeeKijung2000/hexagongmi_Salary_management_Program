package org.sales.sale.service;

import org.sales.sale.dto.PaymentInquiryDetailDTO;
import org.sales.sale.dto.PaymentInquiryResultDTO;
import org.sales.sale.dto.PaymentInquirySaveDTO;
import org.sales.sale.dto.PaymentInquirySearchDTO;

/**
 * 결제내역조회. 조회와 한 건 등록만 하고, 판매나 다른 전표에는 연결하지 않는다.
 * 決済履歴照会。照会と1件登録だけ行い、販売や他の伝票には繋がない。
 */
public interface PaymentInquiryService {

	/** 한 번에 돌려주는 목록 상한. 건수는 그 위 전 건이다. 一度に返す一覧の上限。件数はその上の全件である。 */
	int MAX_ROWS = 1000;

	/**
	 * 전체 목록. 검색어가 있으면 거래처명, 승인번호, 판매번호, 재고전표에 부분일치한다.
	 * 全体一覧。検索語があれば取引先名、承認番号、販売番号、在庫伝票に部分一致する。
	 */
	PaymentInquiryResultDTO search(PaymentInquirySearchDTO search);

	/** 선택 결제 상세. 선택한 PAYMENT_ID 한 건이다.
	 *  選択した決済の詳細。選んだ PAYMENT_ID の1件である。 */
	PaymentInquiryDetailDTO detail(Long paymentId);

	/** 신규 한 건. 판매나 다른 전표에 연결하지 않고 TB_PAYMENT만 넣는다.
	 *  新規1件。販売や他の伝票に繋がないで TB_PAYMENT だけ入れる。 */
	PaymentInquiryDetailDTO create(PaymentInquirySaveDTO save);

	/** 재결제. 승인실패와 취소만 새 요청중 결제로 한 건 넣는다.
	 *  再決済。承認失敗と取消だけ、新しい依頼中の決済を1件入れる。 */
	PaymentInquiryDetailDTO repay(Long paymentId);
}
