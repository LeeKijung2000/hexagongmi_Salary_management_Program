package org.sales.sale.service;

import java.math.BigDecimal;
import java.util.List;

import org.sales.sale.dto.SalePriceChangeApplyResultDTO;
import org.sales.sale.dto.SalePriceChangeResultDTO;
import org.sales.sale.dto.SalePriceChangeSearchDTO;

/**
 * 판매단가일괄변경. 조회와 단가, 환율 변경을 나눈다.
 * 販売単価一括変更。照会と単価、為替の変更を分ける。
 */
public interface SalePriceChangeService {

	/** 조건에 맞는 판매 품목. 시작일이 종료일보다 늦으면 조회하지 않는다.
	 *  条件に合う販売品目。開始日が終了日より遅ければ照会しない。 */
	SalePriceChangeResultDTO search(SalePriceChangeSearchDTO search);

	/** 고른 줄의 단가를 화면 단가로 바꾸고, 그 전표의 헤더 금액을 다시 더한다.
	 *  選んだ行の単価を画面単価へ変え、その伝票のヘッダ金額を足し直す。 */
	SalePriceChangeApplyResultDTO changePrice(List<Long> saleItemIds, BigDecimal unitPrice);

	/** 줄마다 다른 단가를 저장한다. 같은 전표의 줄은 한 트랜잭션에서 고친다.
	 *  行ごとに違う単価を保存する。同じ伝票の行は1トランザクションで直す。 */
	SalePriceChangeApplyResultDTO changePrices(List<Long> saleItemIds, List<BigDecimal> unitPrices);

	/** 고른 줄이 속한 외자 전표의 환율을 통화 마스터 값으로 바꾸고 금액을 다시 계산한다.
	 *  選んだ行が属する外貨伝票の為替を通貨マスタの値へ変え、金額を計算し直す。 */
	SalePriceChangeApplyResultDTO changeRate(List<Long> saleItemIds);
}
