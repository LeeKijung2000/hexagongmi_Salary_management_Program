package org.sales.sale.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.sales.sale.dao.PaymentInquiryDao;
import org.sales.sale.dto.PaymentInquiryDetailDTO;
import org.sales.sale.dto.PaymentInquiryResultDTO;
import org.sales.sale.dto.PaymentInquiryRowDTO;
import org.sales.sale.dto.PaymentInquirySaveDTO;
import org.sales.sale.dto.PaymentInquirySearchDTO;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
@AllArgsConstructor
/**
 * 결제내역조회. 신규와 재결제는 TB_PAYMENT INSERT 하나이고, 판매·재고·수불은 같은 트랜잭션에 넣지 않는다.
 * 決済履歴照会。新規と再決済は TB_PAYMENT の INSERT 一つであり、販売・在庫・受払は同じトランザクションに入れない。
 */
public class PaymentInquiryServiceImpl implements PaymentInquiryService {

	private static final int KEYWORD_LIMIT = 100;
	private static final int CODE_LIMIT = 50;
	private static final String DEFAULT_COMPANY = "ヘキサゴン";
	private static final String DEFAULT_VAN = "KICC";
	private static final BigDecimal DEFAULT_VAT_RATE = new BigDecimal("10");
	private static final BigDecimal HUNDRED = new BigDecimal("100");
	private static final int EASY_NO_LIMIT = 100;
	private static final Set<String> METHODS = new HashSet<String>(Arrays.asList(
			"CASH", "CARD", "TRANSFER", "EASY_PAY", "OTHER"));
	private static final Set<String> RECEIPT_TYPES = new HashSet<String>(Arrays.asList(
			"INCOME", "EXPENSE", "VOLUNTARY", "SIMPLE"));
	private static final Set<String> STATUSES = new HashSet<String>(Arrays.asList(
			"REQUESTED", "APPROVED", "FAILED", "CANCELLED", "FORCED"));
	private static final Set<String> REPAY_STATUSES = new HashSet<String>(Arrays.asList("FAILED", "CANCELLED"));
	private static final DateTimeFormatter[] REQUESTED_AT = new DateTimeFormatter[] {
			DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm"),
			DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss"),
			DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss"),
			DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"),
			DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm")
	};

	private PaymentInquiryDao mapper;

	/** 목록은 결제일시, 결제ID 내림차순이다. 화면을 열면 전체 탭으로 바로 조회한다.
	 *  一覧は決済日時、決済IDの降順である。画面を開くと全体タブですぐ照会する。 */
	@Override
	@Transactional(readOnly = true)
	public PaymentInquiryResultDTO search(PaymentInquirySearchDTO search) {
		log.info("search......" + search);
		if (search == null) {
			search = new PaymentInquirySearchDTO();
		}
		search.setLikeKeyword(like(search.getKeyword()));
		search.setMaxRows(MAX_ROWS);
		int count = mapper.countList(search);
		List<PaymentInquiryRowDTO> rows = count == 0 ? new ArrayList<PaymentInquiryRowDTO>()
				: mapper.selectList(search);
		PaymentInquiryResultDTO result = new PaymentInquiryResultDTO();
		result.setRows(rows);
		result.setTotalCount(count);
		result.setTruncated(count > MAX_ROWS);
		return result;
	}

	/** 내역 보기. 없는 결제는 400에 해당하는 예외로 막는다.
	 *  内訳表示。ない決済は 400 に当たる例外で止める。 */
	@Override
	@Transactional(readOnly = true)
	public PaymentInquiryDetailDTO detail(Long paymentId) {
		log.info("detail......" + paymentId);
		return requireDetail(paymentId);
	}

	/** 신규. 회사코드, VAN, 영수증출력, 부가세율이 비어 있으면 기본값을 넣어 한 건 저장한다.
	 *  新規。会社コード、VAN、領収書出力、付加税率が空なら既定値を入れて1件保存する。 */
	@Override
	@Transactional
	public PaymentInquiryDetailDTO create(PaymentInquirySaveDTO save) {
		log.info("create......" + save);
		prepare(save);
		mapper.insertPayment(save);
		return requireDetail(save.getPaymentId());
	}

	/** 재결제. 원 결제는 그대로 두고, 판매 전표는 잇지 않은 채 같은 금액으로 요청중 결제를 새로 넣는다.
	 *  再決済。元の決済はそのまま置き、販売伝票は繋がないまま同じ金額で依頼中の決済を新しく入れる。 */
	@Override
	@Transactional
	public PaymentInquiryDetailDTO repay(Long paymentId) {
		log.info("repay......" + paymentId);
		PaymentInquiryDetailDTO source = requireDetail(paymentId);
		if (source.getPaymentStatus() == null || !REPAY_STATUSES.contains(source.getPaymentStatus())) {
			throw new IllegalArgumentException("再決済できるのは承認失敗と取消だけです。"); // 재결제할 수 있는 것은 승인실패와 취소뿐입니다.
		}
		PaymentInquirySaveDTO save = new PaymentInquirySaveDTO();
		save.setRequesterId(source.getRequesterId());
		save.setBusinessPartnerId(source.getBusinessPartnerId());
		save.setWarehouseId(source.getWarehouseId());
		save.setCompanyCode(source.getCompanyCode());
		save.setVanCode(source.getVanCode());
		save.setPaymentMethod(source.getPaymentMethod());
		save.setInstallmentMonths(source.getInstallmentMonths());
		save.setReceiptType(source.getReceiptType());
		save.setEasyPaymentNo(source.getEasyPaymentNo());
		save.setReceiptPrintYn(source.getReceiptPrintYn());
		save.setSupplyAmount(source.getSupplyAmount());
		save.setVatRate(source.getVatRate());
		save.setVatAmount(source.getVatAmount());
		save.setPaymentAmount(source.getPaymentAmount());
		save.setPaymentStatus("REQUESTED");
		prepare(save);
		mapper.insertPayment(save);
		return requireDetail(save.getPaymentId());
	}

	/** 등록 값을 검사하고 비어 있는 NOT NULL 항목에 기본값을 채운다. 판매 전표 번호는 저장하지 않는다.
	 *  登録値を検査し、空の NOT NULL 項目に既定値を埋める。販売伝票番号は保存しない。 */
	private void prepare(PaymentInquirySaveDTO save) {
		if (save == null) {
			throw new IllegalArgumentException("決済内容がありません。"); // 결제 내용이 없습니다.
		}
		save.setSaleId(null);
		if (save.getBusinessPartnerId() == null) {
			throw new IllegalArgumentException("取引先を選択してください。"); // 거래처를 선택하세요.
		}
		String method = upper(save.getPaymentMethod());
		if (!METHODS.contains(method)) {
			throw new IllegalArgumentException("決済方法が正しくありません。"); // 결제방법이 올바르지 않습니다.
		}
		String status = upper(save.getPaymentStatus());
		if (!STATUSES.contains(status)) {
			throw new IllegalArgumentException("決済状態が正しくありません。"); // 결제상태가 올바르지 않습니다.
		}
		BigDecimal payment = money(save.getPaymentAmount(), "決済金額は0以上です。"); // 결제금액은 0 이상입니다.
		if (payment == null) {
			throw new IllegalArgumentException("決済金額は0以上です。"); // 결제금액은 0 이상입니다.
		}
		BigDecimal supply = money(save.getSupplyAmount(), "供給価額は0以上です。"); // 공급가액은 0 이상입니다.
		BigDecimal vat = money(save.getVatAmount(), "付加税は0以上です。"); // 부가세는 0 이상입니다.
		BigDecimal rate = rate(save.getVatRate());
		String receipt = receipt(save.getReceiptPrintYn());
		String approval = limit(blankToNull(save.getApprovalNumber()), CODE_LIMIT, "承認番号は50文字までです。"); // 승인번호는 50자까지입니다.
		String company = limit(blankToNull(save.getCompanyCode()), CODE_LIMIT, "会社コードは50文字までです。"); // 회사코드는 50자까지입니다.
		String van = limit(blankToNull(save.getVanCode()), CODE_LIMIT, "VANコードは50文字までです。"); // VAN코드는 50자까지입니다.
		if (mapper.countPartner(save.getBusinessPartnerId()) == 0) {
			throw new IllegalArgumentException("取引先がありません。"); // 거래처가 없습니다.
		}
		if (save.getRequesterId() != null && mapper.countManager(save.getRequesterId()) == 0) {
			throw new IllegalArgumentException("依頼者がありません。"); // 요청자가 없습니다.
		}
		if (save.getWarehouseId() != null && mapper.countWarehouse(save.getWarehouseId()) == 0) {
			throw new IllegalArgumentException("倉庫がありません。"); // 창고가 없습니다.
		}
		save.setRequestedAt(parseRequestedAt(save.getRequestedAtText()));
		save.setPaymentMethod(method);
		applyMethodDetail(save, method);
		save.setPaymentStatus(status);
		save.setPaymentAmount(payment);
		save.setSupplyAmount(supply == null ? BigDecimal.ZERO.setScale(2) : supply);
		save.setVatAmount(vat == null ? BigDecimal.ZERO.setScale(2) : vat);
		save.setVatRate(rate);
		save.setReceiptPrintYn(receipt);
		save.setApprovalNumber(approval);
		save.setCompanyCode(company == null ? DEFAULT_COMPANY : company);
		save.setVanCode(van == null ? DEFAULT_VAN : van);
		save.setForcedYn("FORCED".equals(status) ? "Y" : "N");
		save.setFailureReason(null);
		save.setInventoryVoucherNo(null);
		save.setAccountingVoucherNo(null);
		save.setCancelledAt(null);
	}

	/** 결제방법별 추가 칸. 신용은 할부개월, 현금은 영수증구분, 간편은 식별번호만 남긴다.
	 *  決済方法ごとの追加欄。信用は分割月数、現金は領収書区分、簡単決済は識別番号だけ残す。 */
	private void applyMethodDetail(PaymentInquirySaveDTO save, String method) {
		if ("CARD".equals(method)) {
			save.setReceiptType(null);
			save.setEasyPaymentNo(null);
			save.setInstallmentMonths(months(save.getInstallmentMonths()));
			return;
		}
		if ("CASH".equals(method)) {
			save.setInstallmentMonths(null);
			save.setEasyPaymentNo(null);
			String type = upper(save.getReceiptType());
			if (type == null) {
				type = "INCOME";
			}
			if (!RECEIPT_TYPES.contains(type)) {
				throw new IllegalArgumentException("領収書区分が正しくありません。"); // 영수증 구분이 올바르지 않습니다.
			}
			save.setReceiptType(type);
			return;
		}
		if ("EASY_PAY".equals(method)) {
			save.setInstallmentMonths(null);
			save.setReceiptType(null);
			save.setEasyPaymentNo(limit(blankToNull(save.getEasyPaymentNo()), EASY_NO_LIMIT,
					"簡単決済識別番号は100文字までです。")); // 간편결제 식별번호는 100자까지입니다.
			return;
		}
		save.setInstallmentMonths(null);
		save.setReceiptType(null);
		save.setEasyPaymentNo(null);
	}

	/** 할부개월. 비어 있으면 일시불이고, 있으면 1 이상 99 이하다.
	 *  分割月数。空なら一括であり、あれば 1 以上 99 以下である。 */
	private Integer months(Integer months) {
		if (months == null) {
			return null;
		}
		if (months < 1 || months > 99) {
			throw new IllegalArgumentException("分割月数は1以上99以下です。"); // 할부 개월은 1 이상 99 이하입니다.
		}
		return months;
	}

	/** 결제일시. 비어 있으면 지금이고, 형식이 다르면 막는다.
	 *  決済日時。空なら今であり、形式が違えば止める。 */
	private Date parseRequestedAt(String text) {
		if (text == null || text.trim().isEmpty()) {
			return new Date();
		}
		String value = text.trim();
		for (DateTimeFormatter format : REQUESTED_AT) {
			try {
				LocalDateTime dateTime = LocalDateTime.parse(value, format);
				return Date.from(dateTime.atZone(ZoneId.systemDefault()).toInstant());
			} catch (DateTimeParseException ignored) {
				continue;
			}
		}
		throw new IllegalArgumentException("決済日時が正しくありません。"); // 결제일시가 올바르지 않습니다.
	}

	/** 부가세율. 비어 있으면 10이고, 0 이상 100 이하다.
	 *  付加税率。空なら 10 であり、0 以上 100 以下である。 */
	private BigDecimal rate(BigDecimal value) {
		BigDecimal rate = value == null ? DEFAULT_VAT_RATE : value;
		rate = rate.setScale(2, RoundingMode.HALF_UP);
		if (rate.compareTo(BigDecimal.ZERO) < 0 || rate.compareTo(HUNDRED) > 0) {
			throw new IllegalArgumentException("付加税率は0以上100以下です。"); // 부가세율은 0 이상 100 이하입니다.
		}
		return rate;
	}

	/** 금액. 비어 있으면 null이고, 0 미만이면 막는다. 소수 둘째 자리로 맞춘다.
	 *  金額。空なら null であり、0 未満なら止める。小数第2位に合わせる。 */
	private BigDecimal money(BigDecimal value, String message) {
		if (value == null) {
			return null;
		}
		BigDecimal amount = value.setScale(2, RoundingMode.HALF_UP);
		if (amount.signum() < 0) {
			throw new IllegalArgumentException(message);
		}
		return amount;
	}

	/** 영수증 출력. 비어 있으면 N이다.
	 *  領収書出力。空なら N である。 */
	private String receipt(String value) {
		String yn = upper(value);
		if (yn == null) {
			return "N";
		}
		if (!"Y".equals(yn) && !"N".equals(yn)) {
			throw new IllegalArgumentException("領収書出力はYまたはNです。"); // 영수증출력은 Y 또는 N입니다.
		}
		return yn;
	}

	/** 결제 한 건. 번호가 없거나 조회가 비면 막는다.
	 *  決済1件。番号がないか照会が空なら止める。 */
	private PaymentInquiryDetailDTO requireDetail(Long paymentId) {
		if (paymentId == null) {
			throw new IllegalArgumentException("該当する決済がありません。"); // 해당하는 결제가 없습니다.
		}
		PaymentInquiryDetailDTO detail = mapper.selectDetail(paymentId);
		if (detail == null) {
			throw new IllegalArgumentException("該当する決済がありません。"); // 해당하는 결제가 없습니다.
		}
		return detail;
	}

	/** 부분일치. 빈 검색어는 조건에서 빼고, 100자를 넘으면 막는다.
	 *  部分一致。空の検索語は条件から外し、100字を超えると止める。 */
	private String like(String keyword) {
		if (keyword == null) {
			return null;
		}
		String trimmed = keyword.trim();
		if (trimmed.isEmpty()) {
			return null;
		}
		if (trimmed.length() > KEYWORD_LIMIT) {
			throw new IllegalArgumentException("検索語は100文字までです。"); // 검색어는 100자까지입니다.
		}
		String upper = trimmed.toUpperCase().replace("/", "//").replace("%", "/%").replace("_", "/_");
		return "%" + upper + "%";
	}

	private String upper(String value) {
		String text = blankToNull(value);
		return text == null ? null : text.toUpperCase();
	}

	private String blankToNull(String value) {
		if (value == null) {
			return null;
		}
		String trimmed = value.trim();
		return trimmed.isEmpty() ? null : trimmed;
	}

	private String limit(String value, int max, String message) {
		if (value != null && value.length() > max) {
			throw new IllegalArgumentException(message);
		}
		return value;
	}
}
