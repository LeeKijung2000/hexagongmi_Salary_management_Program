package org.sales.sale.dto;

import lombok.Data;

/** 창고검색. 구분, 창고코드, 창고명.
 *  倉庫検索。区分、倉庫コード、倉庫名。 */
@Data
public class WarehouseLookupDTO {

	private Long warehousePk;
	private String warehouseDivName;
	private String warehouseCode;
	private String warehouseName;
}
