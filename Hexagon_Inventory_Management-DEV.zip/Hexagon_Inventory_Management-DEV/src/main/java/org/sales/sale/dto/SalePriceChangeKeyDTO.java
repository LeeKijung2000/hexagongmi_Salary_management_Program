package org.sales.sale.dto;

import lombok.Data;

/**
 * 화면에서 고른 판매 품목이 어느 전표인지. 변경은 이 키로 전표를 묶는다.
 * 画面で選んだ販売品目がどの伝票か。変更はこのキーで伝票を束ねる。
 */
@Data
public class SalePriceChangeKeyDTO {

	private Long saleId;
	private Long saleItemId;
}
