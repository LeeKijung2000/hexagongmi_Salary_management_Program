package org.sales.sale.service;

import java.util.List;

import org.sales.sale.dao.CommonLookupDao;
import org.sales.sale.dto.CurrencyDTO;
import org.sales.sale.dto.ItemLookupDTO;
import org.sales.sale.dto.ManagerLookupDTO;
import org.sales.sale.dto.PartnerLookupDTO;
import org.sales.sale.dto.WarehouseLookupDTO;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

/**
 * 공통 조회. 거래처, 창고, 담당자, 품목 조회의 신규는 페이지로 이동하지 않고 조회 모달 위에서 등록한다.
 * 共通照会。取引先、倉庫、担当者、品目照会の新規はページへ移動せず、照会モーダルの上で登録する。
 */
@Log4j
@Service
@AllArgsConstructor
public class CommonLookupServiceImpl implements CommonLookupService {

	private CommonLookupDao dao;

	@Override
	@Transactional(readOnly = true)
	public List<PartnerLookupDTO> getPartners(String keyword, boolean includeUnused) {
		log.info("partners keyword: " + keyword);
		return dao.selectPartners(keyword, includeUnused);
	}

	@Override
	@Transactional(readOnly = true)
	public List<WarehouseLookupDTO> getWarehouses(String keyword, boolean includeUnused) {
		log.info("warehouses keyword: " + keyword);
		return dao.selectWarehouses(keyword, includeUnused);
	}

	@Override
	@Transactional(readOnly = true)
	public List<ManagerLookupDTO> getManagers(String keyword) {
		log.info("managers keyword: " + keyword);
		return dao.selectManagers(keyword);
	}

	@Override
	@Transactional(readOnly = true)
	public List<ItemLookupDTO> getItems(String keyword) {
		log.info("items keyword: " + keyword);
		return dao.selectItems(keyword);
	}

	@Override
	@Transactional(readOnly = true)
	public List<CurrencyDTO> getCurrencies() {
		return dao.selectCurrencies();
	}

	@Override
	@Transactional(readOnly = true)
	public CurrencyDTO getCurrencyByName(String currencyName) {
		return dao.selectCurrencyByName(currencyName);
	}

	@Override
	@Transactional(readOnly = true)
	public CurrencyDTO getCurrencyByCode(String currencyCode) {
		return dao.selectCurrencyByCode(currencyCode);
	}

	/** 통화명, 코드, 환율을 검사한 뒤 한 건을 넣는다. 이름이 같거나 KR이면 등록하지 않는다.
	 *  通貨名、コード、為替を検査したあと1件入れる。名前が同じか KR なら登録しない。 */
	@Override
	@Transactional
	public CurrencyDTO addCurrency(CurrencyDTO currency) {
		if (currency == null || currency.getCurrencyName() == null || currency.getCurrencyName().trim().isEmpty()) {
			throw new IllegalArgumentException("通貨名を入力してください。"); // 통화명을 입력하세요.
		}
		String name = currency.getCurrencyName().trim();
		if (name.length() > 50) {
			throw new IllegalArgumentException("通貨名は50字以内で入力してください。"); // 통화명은 50자 이내로 입력하세요.
		}
		if (dao.selectCurrencyByName(name) != null) {
			throw new IllegalArgumentException("既にある通貨です。"); // 이미 있는 통화입니다.
		}
		String code = currency.getCurrencyCode() == null ? "" : currency.getCurrencyCode().trim();
		if (code.length() > 10) {
			throw new IllegalArgumentException("通貨コードは10字以内で入力してください。"); // 통화코드는 10자 이내로 입력하세요.
		}
		if ("KR".equalsIgnoreCase(code)) {
			throw new IllegalArgumentException("KRは既定の韓国ウォンです。"); // KR은 기본 원화
		}
		if (currency.getExchangeRate() == null) {
			throw new IllegalArgumentException("為替レートを入力してください。"); // 환율을 입력하세요.
		}
		currency.setCurrencyCode(code.isEmpty() ? null : code);
		currency.setCurrencyName(name);
		currency.setCurrencyId(dao.nextCurrencyId());
		dao.insertCurrency(currency);
		return currency;
	}
}
