package org.sales.sale.dto;

import java.util.Date;

import lombok.Data;

/**
 * 판매 저장 이력. SALE_HISTORY.
 * 등록과 수정이 끝날 때마다 한 줄 남긴다. 작업자는 system이고, 구분에는 등록 또는 수정이 들어간다.
 * 販売保存履歴。SALE_HISTORY。
 * 登録と修正が終わるたびに1行残す。作業者はsystemであり、区分には登録または修正が入る。
 */
@Data
public class SaleHistoryDTO {

    private Long saleHistoryId;
    private Long saleId;
    private Date workDate;
    private String worker;
    private String progressStatusAtWork;
    private String actionType;
}
