package org.sales.sale.dto;

import java.math.BigDecimal;

import lombok.Data;

/**
 * 재고를 되돌리거나 수불을 남길 판매 품목 한 줄. 재고관리여부가 Y인 줄만 수불을 만든다.
 * 在庫を戻すか受払を残す販売品目の1行。在庫管理可否が Y の行だけ受払を作る。
 */
@Data
public class SaleStockLineDTO {

	private Long itemId;
	private BigDecimal quantity;
	/** TB_ITEM.INVENTORY_CONTROL_YN. Y만 수불 대상이다. Yだけ受払の対象である。 */
	private String inventoryControlYn;
}
