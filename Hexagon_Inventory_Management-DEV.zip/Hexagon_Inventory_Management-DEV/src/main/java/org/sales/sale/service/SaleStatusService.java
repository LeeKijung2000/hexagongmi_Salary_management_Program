package org.sales.sale.service;

import org.sales.sale.dto.SaleStatusResultDTO;
import org.sales.sale.dto.SaleStatusSearchDTO;

/**
 * 판매현황. 조회만 하고 TB_SALE, TB_SALE_ITEM은 고치지 않는다.
 * 販売状況。照会だけ行い、TB_SALE、TB_SALE_ITEM は直さない。
 */
public interface SaleStatusService {

	/** 한 번에 돌려주는 목록 상한. 합계는 그 위 전 건이다. 一度に返す一覧の上限。合計はその上の全件である。 */
	int MAX_ROWS = 1000;

	/**
	 * 현황 탭. 품목 줄을 날짜순으로 돌려준다. 월 합계 행은 화면에서 끼워 넣는다.
	 * 現状タブ。品目行を日付順で返す。月合計行は画面で挟む。
	 */
	SaleStatusResultDTO searchLines(SaleStatusSearchDTO search);

	/**
	 * 집계 탭. 집계조건이 한 칸도 없으면 조회하지 않고, 고른 조건 순서대로 묶는다.
	 * 월 계 행과 총합계 문구는 화면에서 붙인다.
	 * 集計タブ。集計条件が1枠もなければ照会せず、選んだ条件の順で束ねる。
	 * 月計行と総合計の文言は画面で付ける。
	 */
	SaleStatusResultDTO searchSummary(SaleStatusSearchDTO search);
}
