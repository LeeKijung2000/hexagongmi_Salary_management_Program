package org.sales.sale.controller;

import java.util.List;
import java.util.Map;

import org.sales.sale.dto.CurrencyDTO;
import org.sales.sale.dto.ItemLookupDTO;
import org.sales.sale.dto.ManagerLookupDTO;
import org.sales.sale.dto.PartnerLookupDTO;
import org.sales.sale.dto.WarehouseLookupDTO;
import org.sales.sale.service.CommonLookupService;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/common/lookup")
@AllArgsConstructor
/**
 * 거래처, 창고, 담당자, 품목 공통 조회. 여러 화면에서 같이 쓴다.
 * 검색 결과에는 각 조회 화면에 있는 컬럼만 돌려준다.
 * 取引先、倉庫、担当者、品目の共通照会。複数の画面で一緒に使う。
 * 検索結果には各照会画面にある列だけ返す。
 */
public class CommonLookupController {

	private CommonLookupService service;

	/** 거래처검색. 키워드와 사용중단포함을 받아 코드, 거래처명, 검색창내용만 JSON으로 돌려준다.
	 *  取引先検索。キーワードと使用中止含むを受け、コード、取引先名、検索窓内容だけJSONで返す。 */
	@GetMapping("/partners")
	@ResponseBody
	public List<PartnerLookupDTO> partners(@RequestParam(value = "keyword", required = false) String keyword,
			@RequestParam(value = "includeUnused", defaultValue = "false") boolean includeUnused) {
		log.info("partners keyword: " + keyword);
		return service.getPartners(keyword, includeUnused);
	}

	/** 창고검색. 구분, 창고코드, 창고명을 돌려준다. 사용중단 창고는 체크했을 때만 포함한다.
	 *  倉庫検索。区分、倉庫コード、倉庫名を返す。使用中止の倉庫はチェックしたときだけ含める。 */
	@GetMapping("/warehouses")
	@ResponseBody
	public List<WarehouseLookupDTO> warehouses(@RequestParam(value = "keyword", required = false) String keyword,
			@RequestParam(value = "includeUnused", defaultValue = "false") boolean includeUnused) {
		log.info("warehouses keyword: " + keyword);
		return service.getWarehouses(keyword, includeUnused);
	}

	/** 사원검색. 사원코드와 사원명을 돌려준다. 신규 등록은 조회 모달에서 하고, 이 조회는 사용중단 조건을 받지 않는다.
	 *  社員検索。社員コードと社員名を返す。新規登録は照会モーダルで行い、この照会は使用中止の条件を受け取らない。 */
	@GetMapping("/managers")
	@ResponseBody
	public List<ManagerLookupDTO> managers(@RequestParam(value = "keyword", required = false) String keyword) {
		log.info("managers keyword: " + keyword);
		return service.getManagers(keyword);
	}

	/** 품목검색. 품목코드, 품목명, 검색창내용, 규격, 전체재고, 출고단가를 돌려준다. 판매입력에서는 여러 품목을 고를 수 있다.
	 *  品目検索。品目コード、品目名、検索窓内容、規格、全体在庫、出庫単価を返す。販売入力では複数品目を選べる。 */
	@GetMapping("/items")
	@ResponseBody
	public List<ItemLookupDTO> items(@RequestParam(value = "keyword", required = false) String keyword) {
		log.info("items keyword: " + keyword);
		return service.getItems(keyword);
	}

	/** 통화 목록. TB_CURRENCY의 사용 중인 통화를 돌려준다.
	 *  通貨一覧。TB_CURRENCYの使用中通貨を返す。 */
	@GetMapping("/currencies")
	@ResponseBody
	public List<CurrencyDTO> currencies() {
		return service.getCurrencies();
	}

	/** 통화 추가. 이름, 코드, 환율을 TB_CURRENCY에 넣고 새 키를 돌려준다. 이름이 비었거나 같으면 400이다.
	 *  通貨追加。名前、コード、為替レートをTB_CURRENCYに入れ新しいキーを返す。名前が空か同じなら400である。 */
	@PostMapping("/currencies")
	@ResponseBody
	public ResponseEntity<Map<String, Object>> addCurrency(CurrencyDTO currency) {
		try {
			CurrencyDTO saved = service.addCurrency(currency);
			Map<String, Object> body = new java.util.HashMap<String, Object>();
			body.put("currencyId", saved.getCurrencyId());
			body.put("currencyCode", saved.getCurrencyCode());
			body.put("currencyName", saved.getCurrencyName());
			body.put("exchangeRate", saved.getExchangeRate());
			return ResponseEntity.ok(body);
		} catch (IllegalArgumentException e) {
			Map<String, Object> body = new java.util.HashMap<String, Object>();
			body.put("message", e.getMessage());
			return ResponseEntity.badRequest().body(body);
		}
	}
}
