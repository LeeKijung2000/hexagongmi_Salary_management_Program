package org.sales.sale.dao;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.sales.sale.dto.HoldSlipDTO;
import org.sales.sale.dto.ItemProfitDTO;
import org.sales.sale.dto.ItemStockDTO;
import org.sales.sale.dto.SaleCurrDTO;
import org.sales.sale.dto.SaleCurrItemDTO;
import org.sales.sale.dto.SaleHistoryDTO;
import org.sales.sale.dto.SaleSlipLinkDTO;
import org.sales.sale.dto.SlipListDTO;
import org.sales.sale.dto.SlipSourceLineDTO;

/**
 * 판매입력1(S0110) Dao. SALE_CURR / SALE_CURR_ITEM / SALE_SLIP_LINK / SALE_HISTORY.
 * 거래처, 창고, 담당자, 품목, 통화 조회는 org.sales.sale.dao.CommonLookupDao가 담당한다.
 * 販売入力1(S0110) Dao。SALE_CURR / SALE_CURR_ITEM / SALE_SLIP_LINK / SALE_HISTORY。
 * 取引先、倉庫、担当者、品目、通貨の照会はorg.sales.sale.dao.CommonLookupDaoが担当する。
 */
public interface SaleInputOneDao {

    /** 헤더 한 건. 거래처, 담당자, 창고의 코드와 이름, 통화명을 조인해 화면에 바로 쓴다. 코드는 표시용이고 전표에는 키만 저장한다.
     *  ヘッダ1件。取引先、担当者、倉庫のコードと名前、通貨名を結合して画面にそのまま使う。コードは表示用であり、伝票にはキーだけ保存する。 */
    SaleCurrDTO selectSale(@Param("saleId") Long saleId);

    /** 품목 라인. 할인금액은 저장해 둔 문자열을 숫자로 읽어 온다.
     *  品目行。割引金額は保存してある文字列を数値で読み取る。 */
    List<SaleCurrItemDTO> selectItems(@Param("saleId") Long saleId);

    /** 주문, 견적, 판매 원천 연결을 한 목록으로 합친다. 서비스가 품목 줄에 붙인다.
     *  注文、見積、販売の元伝票接続を一つの一覧にまとめる。サービスが品目行に付ける。 */
    List<SaleSlipLinkDTO> selectLinks(@Param("saleId") Long saleId);

    /** 헤더 등록. 전표번호는 S 뒤에 판매아이디를 8자리로 채워 만든다. 통화와 환율은 넘어온 값을 그대로 저장한다.
     *  ヘッダ登録。伝票番号はSのあとに販売IDを8桁で埋めて作る。通貨と為替レートは渡された値をそのまま保存する。 */
    int insertSale(SaleCurrDTO sale);

    /** 헤더 수정. 일자, 거래처, 담당자, 창고, 거래유형, 통화, 금액, 전표상태를 다시 쓴다.
     *  ヘッダ修正。日付、取引先、担当者、倉庫、取引類型、通貨、金額、伝票状態を書き直す。 */
    int updateSale(SaleCurrDTO sale);

    /** 그 전표 품목에 걸린 주문, 견적, 판매 연결을 지운다. 수정과 보류 삭제 전에 쓴다.
     *  その伝票の品目に付いた注文、見積、販売の接続を消す。修正と保留削除の前に使う。 */
    int deleteLinksBySaleId(@Param("saleId") Long saleId);

    /** 그 전표의 품목 라인을 지운다. 연결을 먼저 지운 뒤에 호출한다.
     *  その伝票の品目行を消す。接続を先に消したあとに呼ぶ。 */
    int deleteItemsBySaleId(@Param("saleId") Long saleId);

    /** 그 전표의 저장 이력을 지운다. 보류 삭제 때만 쓰고, 수정 때는 이력을 남긴다.
     *  その伝票の保存履歴を消す。保留削除のときだけ使い、修正のときは履歴を残す。 */
    int deleteHistoryBySaleId(@Param("saleId") Long saleId);

    /** 헤더 한 건을 지운다. 연결, 품목, 이력을 지운 뒤에 호출한다.
     *  ヘッダ1件を消す。接続、品目、履歴を消したあとに呼ぶ。 */
    int deleteSale(@Param("saleId") Long saleId);

    /** 보류 상태 전표 수. 새 보류가 5건을 넘는지 볼 때 쓴다.
     *  保留状態の伝票数。新しい保留が5件を超えるか見るときに使う。 */
    int countHolds();

    /** 보류 목록. 보류번호, 거래처, 품목 요약, 금액, 유형, 창고만 가져온다.
     *  保留一覧。保留番号、取引先、品目の要約、金額、類型、倉庫だけ取る。 */
    List<HoldSlipDTO> selectHolds();

    /** 품목 한 줄. 품목코드가 없으면 품목 마스터의 코드를 쓰고, 그것도 없으면 '-'를 넣는다.
     *  品目1行。品目コードがなければ品目マスタのコードを使い、それもなければ'-'を入れる。 */
    int insertItem(SaleCurrItemDTO item);

    /** 원천 연결 한 줄. SRC_TYPE에 따라 주문, 견적, 판매 연결 테이블 중 하나에 넣는다.
     *  元伝票接続1行。SRC_TYPEに応じて注文、見積、販売の接続テーブルの一つに入れる。 */
    int insertLink(SaleSlipLinkDTO link);

    /** 저장 이력 한 줄. 등록 또는 수정이 끝난 뒤에 남긴다.
     *  保存履歴1行。登録または修正が終わったあとに残す。 */
    int insertHistory(SaleHistoryDTO history);

    /** 다음 판매 전표 번호.
     *  次の販売伝票番号。 */
    Long nextSaleId();

    /** 다음 품목 라인 번호.
     *  次の品目行番号。 */
    Long nextItemId();

    /** 다음 원천 연결 번호.
     *  次の元伝票接続番号。 */
    Long nextLinkId();

    /** 다음 저장 이력 번호.
     *  次の保存履歴番号。 */
    Long nextHistoryId();

    /** 거래내역보기와 판매조회. 날짜가 있으면 그 구간만, 없으면 보류를 뺀 판매서 전체를 일자 내림차순으로 본다.
     *  取引履歴と販売照会。日付があればその区間だけ、なければ保留を除いた販売書全体を日付の降順で見る。 */
    List<SlipListDTO> selectSaleSlips(@Param("fromDate") Date fromDate, @Param("toDate") Date toDate);

    /** 거래내역보기와 주문서조회. 삭제되지 않은 주문만, 날짜가 있으면 그 구간만 본다.
     *  取引履歴と注文書照会。削除されていない注文だけ、日付があればその区間だけ見る。 */
    List<SlipListDTO> selectOrderSlips(@Param("fromDate") Date fromDate, @Param("toDate") Date toDate);

    /** 거래내역보기와 견적서조회. 날짜가 있으면 그 구간만, 없으면 견적 전체를 본다.
     *  取引履歴と見積書照会。日付があればその区間だけ、なければ見積全体を見る。 */
    List<SlipListDTO> selectQuoteSlips(@Param("fromDate") Date fromDate, @Param("toDate") Date toDate);

    /** 주문 버튼용 미판매 라인. 주문수량에서 이미 판매로 연결한 수량(SRC_TYPE=ORDER)을 뺀 나머지가 0보다 큰 줄만 가져온다.
     *  注文ボタン用の未販売行。注文数量から既に販売へ接続した数量(SRC_TYPE=ORDER)を引いた残りが0より大きい行だけ取る。 */
    List<SlipSourceLineDTO> selectUnsoldOrders(@Param("businessPartnerId") Long businessPartnerId);

    /** 남은 수량이 있는 견적 줄. 거래처가 있으면 그 거래처만 본다. 전표불러오기 버튼은 견적서 조회 JSP를 모달에 열고 이 조회를 쓰지 않는다.
     *  残数量がある見積行。取引先があればその取引先だけ見る。伝票読込ボタンは見積書照会JSPをモーダルに開き、この照会は使わない。 */
    List<SlipSourceLineDTO> selectQuoteLines(@Param("businessPartnerId") Long businessPartnerId);

    /** 보류와 취소를 빼고, 아직 다른 판매로 다 넘기지 않은 품목. 전표불러오기 버튼은 조회 JSP를 모달에 열고 이 조회를 쓰지 않는다.
     *  保留と取消を除き、まだ他の販売へ渡し切っていない品目。伝票読込ボタンは照会JSPをモーダルに開き、この照会は使わない。 */
    List<SlipSourceLineDTO> selectSaleLines(@Param("businessPartnerId") Long businessPartnerId);

    /** 재고불러오기용 조회. 전체 창고 합계와 출하창고 수량만 읽는다. 차감은 이 조회가 아니라 정상 저장에서 한다.
     *  在庫読込用の照会。全倉庫合計と出荷倉庫数量だけ読む。減算はこの照会ではなく正常保存で行う。 */
    ItemStockDTO selectItemStock(@Param("itemPk") Long itemPk, @Param("warehousePk") Long warehousePk);

    /** 출하창고 재고를 더하거나 뺀다. delta가 음수면 판매 저장 차감이고, 양수면 수정 전 수량을 되돌리는 것이다. 행이 없으면 그 수량으로 만든다.
     *  出荷倉庫の在庫を足すか引く。deltaが負なら販売保存の減算であり、正なら修正前の数量を戻すものである。行がなければその数量で作る。 */
    int adjustInventory(@Param("warehousePk") Long warehousePk, @Param("itemPk") Long itemPk, @Param("delta") BigDecimal delta);

    /** 이익계산. 매입·판매 단가와 재료, 경비, 노무, 외주 표준원가를 읽고 재고나 전표는 바꾸지 않는다.
     *  利益計算。仕入・販売単価と材料、経費、労務、外注の標準原価を読み、在庫や伝票は変えない。 */
    ItemProfitDTO selectItemProfit(@Param("itemPk") Long itemPk);
}
