package org.sales.sale.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;
import java.util.List;

import org.sales.sale.dto.CurrencyDTO;
import org.sales.sale.service.CommonLookupService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.sales.sale.dto.HoldSlipDTO;
import org.sales.sale.dto.ItemProfitDTO;
import org.sales.sale.dto.ItemStockDTO;
import org.sales.sale.dto.SaleCurrItemDTO;
import org.sales.sale.dto.SaleCurrDTO;
import org.sales.sale.dto.SaleHistoryDTO;
import org.sales.sale.dto.SaleInputOneDTO;
import org.sales.sale.dto.SaleSlipLinkDTO;
import org.sales.sale.dto.SlipListDTO;
import org.sales.sale.dto.SlipSourceLineDTO;
import org.sales.sale.dao.SaleInputOneDao;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
@AllArgsConstructor
/**
 * 판매입력1 저장. 헤더는 SALE_CURR, 품목은 SALE_CURR_ITEM에 넣고 공급가액과 부가세 합계를 헤더에 다시 쓴다.
 * 전표상태가 정상인 저장만 출하창고 재고에서 판매수량을 뺀다. 그 출하창고 수량이 0이면 저장하지 않는다. 보류는 재고를 줄이지 않는다.
 * 販売入力1の保存。ヘッダはSALE_CURR、品目はSALE_CURR_ITEMに入れ、供給価額と付加税の合計をヘッダへ書き戻す。
 * 伝票状態が正常の保存だけ出荷倉庫の在庫から販売数量を引く。その出荷倉庫数量が0なら保存しない。保留は在庫を減らさない。
 */
public class SaleInputOneServiceImpl implements SaleInputOneService {

	private SaleInputOneDao mapper;

	private CommonLookupService commonLookup;

	/**
	 * 신규 저장. 검사 후 새 전표번호를 따고 헤더, 품목, 원천 연결, 이력(등록)을 넣는다.
	 * 新規保存。検査のあと新しい伝票番号を取り、ヘッダ、品目、元伝票の接続、履歴(登録)を入れる。
	 */
	@Override
	@Transactional
	public void register(SaleInputOneDTO sale) {
		log.info("register......" + sale);
		validate(sale);
		prepareHeader(sale.getHeader(), false);
		// 정상 저장은 출하창고 재고가 0인 품목을 넣지 않는다. 차감 전에 검사해서 전표가 생기지 않게 한다.
		// 正常保存は出荷倉庫の在庫が0の品目を入れない。減算の前に検査し、伝票ができないようにする。
		assertWarehouseStock(sale);
		mapper.insertSale(sale.getHeader());
		saveLines(sale, "등록");
		// 정상 저장만 출하창고 재고에서 판매수량을 뺀다. 보류는 전표만 남긴다.
		// 正常保存だけ出荷倉庫の在庫から販売数量を引く。保留は伝票だけ残す。
		if (countsAsSale(sale.getHeader())) {
			adjustInventory(sale.getHeader(), sale.getItems(), true);
		}
	}

	/**
	 * 조회. 품목마다 주문, 견적, 판매 연결 중 같은 품목 키를 가진 첫 연결만 붙인다.
	 * 照会。品目ごとに注文、見積、販売の接続のうち同じ品目キーを持つ最初の接続だけ付ける。
	 */
	@Override
	@Transactional(readOnly = true)
	public SaleInputOneDTO get(Long saleId) {
		log.info("get......" + saleId);
		SaleInputOneDTO sale = new SaleInputOneDTO();
		sale.setHeader(mapper.selectSale(saleId));
		List<SaleCurrItemDTO> items = mapper.selectItems(saleId);
		List<SaleSlipLinkDTO> links = mapper.selectLinks(saleId);
		for (SaleCurrItemDTO item : items) {
			for (SaleSlipLinkDTO link : links) {
				if (item.getItemId().equals(link.getSaleItemId())) {
					item.setSlipLink(link);
					break;
				}
			}
		}
		sale.setItems(items);
		return sale;
	}

	/**
	 * 수정. 헤더를 고친 뒤 기존 연결과 품목을 지우고 화면 줄로 다시 넣는다. 이력은 수정으로 한 줄 더 남긴다.
	 * 修正。ヘッダを直したあと既存の接続と品目を消し、画面の行で入れ直す。履歴は修正で1行追加する。
	 */
	@Override
	@Transactional
	public boolean modify(SaleInputOneDTO sale) {
		log.info("modify......" + sale);
		validate(sale);
		Long saleId = sale.getHeader().getSaleId();
		SaleCurrDTO previousHeader = mapper.selectSale(saleId);
		List<SaleCurrItemDTO> previousItems = mapper.selectItems(saleId);
		// 판매입력 화면은 진행상태를 보내지 않는다. 수정 저장은 조회에서 바꾼 확인, 미확인을 유지한다.
		// 販売入力画面は進行状態を送らない。修正保存は照会で変えた確認、未確認を維持する。
		if (sale.getHeader().getProgressStatus() == null && previousHeader != null) {
			sale.getHeader().setProgressStatus(previousHeader.getProgressStatus());
		}
		prepareHeader(sale.getHeader(), true);
		if (mapper.updateSale(sale.getHeader()) != 1) {
			return false;
		}
		// 이미 정상으로 빠져 있던 수량은 먼저 되돌린다. 그다음 이번 저장이 정상이면 새 판매수량으로 다시 뺀다.
		// 既に正常で引いてあった数量は先に戻す。その後今回の保存が正常なら新しい販売数量で再び引く。
		if (countsAsSale(previousHeader)) {
			adjustInventory(previousHeader, previousItems, false);
		}
		// 이미 빠져 있던 수량을 되돌린 뒤의 출하창고 수량으로 검사한다. 0이면 이번 수정도 롤백된다.
		// 既に引いてあった数量を戻したあとの出荷倉庫数量で検査する。0なら今回の修正もロールバックされる。
		assertWarehouseStock(sale);
		mapper.deleteLinksBySaleId(saleId);
		mapper.deleteItemsBySaleId(saleId);
		saveLines(sale, "수정");
		if (countsAsSale(sale.getHeader())) {
			adjustInventory(sale.getHeader(), sale.getItems(), true);
		}
		return true;
	}

	// 저장 전에 검사한다. 거래처, 출하창고, 담당자는 조회해서 받은 키가 있어야 하고, 품목이 한 줄도 없거나 그 수량이 0 이하면 저장하지
	// 않는다. 품목이 없는 빈 줄은 넘어간다.
	// 保存前に検査する。取引先、出荷倉庫、担当者は照会で受け取ったキーが必要で、品目が1行もないかその数量が0以下なら保存しない。品目のない空行は飛ばす。
	private void validate(SaleInputOneDTO sale) {
		SaleCurrDTO header = sale.getHeader();
		if (header == null || header.getBusinessPartnerId() == null) {
			throw new IllegalArgumentException("取引先を選択してください。"); // 거래처를 선택하세요.
		}
		if (header.getWarehousePk() == null) {
			throw new IllegalArgumentException("出荷倉庫を選択してください。"); // 출하창고를 선택하세요.
		}
		if (header.getManagerId() == null) {
			throw new IllegalArgumentException("担当者を選択してください。"); // 담당자를 선택하세요.
		}
		boolean hasItem = false;
		if (sale.getItems() != null) {
			for (SaleCurrItemDTO item : sale.getItems()) {
				if (item.getItemPk() == null) {
					continue;
				}
				hasItem = true;
				if (item.getSaleQty() == null || item.getSaleQty().compareTo(BigDecimal.ZERO) <= 0) {
					throw new IllegalArgumentException("数量は0より大きい必要があります。"); // 수량은 0보다 커야 합니다.
				}
			}
		}
		if (!hasItem) {
			throw new IllegalArgumentException("品目を入力してください。"); // 품목을 입력하세요.
		}
	}

	/**
	 * 화면이 안 보낸 기본값. 수정이면 전표번호를 유지하고, 통화가 없으면 KR을 넣는다.
	 * 画面が送らなかった既定値。修正なら伝票番号を維持し、通貨がなければKRを入れる。
	 */
	private void prepareHeader(SaleCurrDTO header, boolean keepId) {
		if (!keepId) {
			header.setSaleId(mapper.nextSaleId());
			// 신규 저장의 진행상태는 항상 미확인이다. 확인은 판매조회에서만 바꾼다.
			// 新規保存の進行状態は常に未確認である。確認は販売照会でだけ変える。
			header.setProgressStatus("未確認");
		}
		if (header.getSaleDiv() == null) {
			header.setSaleDiv("一般"); // 일반
		}
		if (keepId && header.getProgressStatus() == null) {
			header.setProgressStatus("未確認"); // 미확인
		}
		if (header.getVoucherStatus() == null) {
			header.setVoucherStatus("正常"); // 정상
		}
		if (header.getSaleType() == null) {
			header.setSaleType("付加税率適用"); // 부가세율 적용
		}
		if (header.getCurrencyId() == null) {
			CurrencyDTO currency = commonLookup.getCurrencyByCode("KR");
			if (currency != null) {
				header.setCurrencyId(currency.getCurrencyId());
				if (header.getExchangeRate() == null) {
					header.setExchangeRate(
							currency.getExchangeRate() == null ? BigDecimal.ONE : currency.getExchangeRate());
				}
			}
		}
		if (header.getExchangeRate() == null) {
			header.setExchangeRate(BigDecimal.ONE);
		}
		if (header.getCurrAmt() == null) {
			header.setCurrAmt(BigDecimal.ZERO);
		}
		if (header.getVatAmt() == null) {
			header.setVatAmt(BigDecimal.ZERO);
		}
		header.setUpdatedAt(new Date());
	}

	/**
	 * 정상 저장만 출하창고 재고를 확인한다. 품목의 출하창고 수량이 0 이하면 저장하지 않는다. 보류는 재고를 쓰지 않으므로 통과시킨다.
	 * 正常保存だけ出荷倉庫の在庫を確認する。品目の出荷倉庫数量が0以下なら保存しない。保留は在庫を使わないので通す。
	 */
	private void assertWarehouseStock(SaleInputOneDTO sale) {
		if (!countsAsSale(sale.getHeader()) || sale.getItems() == null) {
			return;
		}
		Long warehousePk = sale.getHeader().getWarehousePk();
		for (SaleCurrItemDTO item : sale.getItems()) {
			if (item.getItemPk() == null || item.getSaleQty() == null
					|| item.getSaleQty().compareTo(BigDecimal.ZERO) <= 0) {
				continue;
			}
			ItemStockDTO stock = mapper.selectItemStock(item.getItemPk(), warehousePk);
			BigDecimal whQty = stock == null || stock.getWhQty() == null ? BigDecimal.ZERO : stock.getWhQty();
			if (whQty.compareTo(BigDecimal.ZERO) <= 0) {
				throw new IllegalArgumentException(itemLabel(item) + "の出荷倉庫数量が0のため保存できません。"); // 의 출하창고 수량이 0이라 저장할 수 없습니다.
			}
		}
	}

	/** 출하창고 수량이 0일 때 보여줄 품목 이름. 이름이 없으면 코드, 둘 다 없으면 품목이라고 쓴다.
	 *  出荷倉庫数量が0のとき見せる品目名。名前がなければコード、両方なければ品目と書く。 */
	private String itemLabel(SaleCurrItemDTO item) {
		if (item.getItemNm() != null && !item.getItemNm().trim().isEmpty()) {
			return item.getItemNm().trim();
		}
		if (item.getItemCode() != null && !item.getItemCode().trim().isEmpty()) {
			return item.getItemCode().trim();
		}
		return "品目"; // 품목
	}

	/**
	 * 전표상태가 정상일 때만 재고를 움직인다. 보류는 차감도 복구도 하지 않는다. 伝票状態が正常のときだけ在庫を動かす。保留は減算も復旧もしない。
	 */
	private boolean countsAsSale(SaleCurrDTO header) {
		return header != null && "正常".equals(header.getVoucherStatus()); // 정상
	}

	/**
	 * deduct가 true면 판매수량을 빼고, false면 같은 수량을 출하창고에 되돌린다.
	 * deductがtrueなら販売数量を引き、falseなら同じ数量を出荷倉庫へ戻す。
	 */
	private void adjustInventory(SaleCurrDTO header, List<SaleCurrItemDTO> items, boolean deduct) {
		if (header == null || header.getWarehousePk() == null || items == null) {
			return;
		}
		for (SaleCurrItemDTO item : items) {
			if (item.getItemPk() == null || item.getSaleQty() == null
					|| item.getSaleQty().compareTo(BigDecimal.ZERO) <= 0) {
				continue;
			}
			BigDecimal delta = deduct ? item.getSaleQty().negate() : item.getSaleQty();
			mapper.adjustInventory(header.getWarehousePk(), item.getItemPk(), delta);
		}
	}

	/**
	 * 품목 저장. 빈 줄은 빼고, 주문·견적·판매에서 불러온 줄만 연결 행을 남긴 뒤 헤더 합계와 이력을 다시 쓴다.
	 * 品目保存。空行は除き、注文・見積・販売から読み込んだ行だけ接続行を残したあとヘッダ合計と履歴を書き戻す。
	 */
	private void saveLines(SaleInputOneDTO sale, String actionType) {
		SaleCurrDTO header = sale.getHeader();
		BigDecimal currAmt = BigDecimal.ZERO;
		BigDecimal vatAmt = BigDecimal.ZERO;

		if (sale.getItems() != null) {
			for (SaleCurrItemDTO item : sale.getItems()) {
				// 화면의 빈 줄은 품목 키가 없다. 그 줄과 수량이 0 이하인 줄은 전표에 넣지 않는다.
				// 画面の空行は品目キーがない。その行と数量が0以下の行は伝票に入れない。
				if (item.getItemPk() == null || item.getSaleQty() == null
						|| item.getSaleQty().compareTo(BigDecimal.ZERO) <= 0) {
					continue;
				}
				item.setItemId(mapper.nextItemId());
				item.setSaleId(header.getSaleId());
				// SALE_CURR_ITEM.SPEC은 NOT NULL이라 규격이 비어 있으면 공백 한 칸을 넣어 저장이 실패하지 않게 한다.
				// SALE_CURR_ITEM.SPECはNOT NULLなので、規格が空なら空白1文字を入れて保存が失敗しないようにする。
				if (item.getSpec() == null) {
					item.setSpec(" ");
				}
				if (item.getTotQty() == null) {
					item.setTotQty(BigDecimal.ZERO);
				}
				if (item.getWhQty() == null) {
					item.setWhQty(BigDecimal.ZERO);
				}
				if (item.getDiscountAmt() == null) {
					item.setDiscountAmt(BigDecimal.ZERO);
				}
				if (item.getUnitPrice() == null) {
					item.setUnitPrice(BigDecimal.ZERO);
				}
				// 공급가액은 수량×단가에서 할인을 뺀 값이다. 부가세율 적용이면 그 금액의 10%가 부가세이고, 합계는 둘을 더한 값이다.
				// 供給価額は数量×単価から割引を引いた値である。付加税率適用ならその金額の10%が付加税であり、合計は二つを足した値である。
				applyLineAmounts(header, item);
				mapper.insertItem(item);
				if (item.getSupplyAmt() != null) {
					currAmt = currAmt.add(item.getSupplyAmt());
				}
				if (item.getVatAmt() != null) {
					vatAmt = vatAmt.add(item.getVatAmt());
				}
				SaleSlipLinkDTO link = item.getSlipLink();
				if (link != null && link.getSrcItemId() != null) {
					link.setLinkId(mapper.nextLinkId());
					link.setSaleItemId(item.getItemId());
					if (link.getAppliedQty() == null) {
						link.setAppliedQty(item.getSaleQty());
					}
					mapper.insertLink(link);
				}
			}
		}

		header.setCurrAmt(currAmt);
		header.setVatAmt(vatAmt);
		mapper.updateSale(header);

		SaleHistoryDTO history = new SaleHistoryDTO();
		history.setSaleHistoryId(mapper.nextHistoryId());
		history.setSaleId(header.getSaleId());
		history.setWorkDate(new Date());
		history.setWorker("system");
		history.setProgressStatusAtWork(header.getProgressStatus());
		history.setActionType(actionType);
		mapper.insertHistory(history);
	}

	@Override
	@Transactional(readOnly = true)
	public List<SlipListDTO> getSlips(String kind, Date fromDate, Date toDate) {
		if ("order".equals(kind)) {
			return mapper.selectOrderSlips(fromDate, toDate);
		}
		if ("quote".equals(kind)) {
			return mapper.selectQuoteSlips(fromDate, toDate);
		}
		return mapper.selectSaleSlips(fromDate, toDate);
	}

	@Override
	@Transactional(readOnly = true)
	public List<SlipSourceLineDTO> getUnsoldOrders(Long businessPartnerId) {
		return mapper.selectUnsoldOrders(businessPartnerId);
	}

	@Override
	@Transactional(readOnly = true)
	public List<SlipSourceLineDTO> getQuoteLines(Long businessPartnerId) {
		return mapper.selectQuoteLines(businessPartnerId);
	}

	@Override
	@Transactional(readOnly = true)
	public List<SlipSourceLineDTO> getSaleLines(Long businessPartnerId) {
		return mapper.selectSaleLines(businessPartnerId);
	}

	@Override
	@Transactional(readOnly = true)
	// 재고불러오기는 수량만 읽는다. 출하창고 재고를 빼는 곳은 정상 저장이다.
	// 在庫読込は数量だけ読む。出荷倉庫の在庫を引くのは正常保存である。
	public ItemStockDTO getItemStock(Long itemPk, Long warehousePk) {
		return mapper.selectItemStock(itemPk, warehousePk);
	}

	@Override
	@Transactional(readOnly = true)
	public ItemProfitDTO getItemProfit(Long itemPk) {
		return mapper.selectItemProfit(itemPk);
	}

	@Override
	@Transactional(readOnly = true)
	public int countHolds() {
		return mapper.countHolds();
	}

	@Override
	@Transactional(readOnly = true)
	public List<HoldSlipDTO> getHolds() {
		return mapper.selectHolds();
	}

	@Override
	@Transactional(readOnly = true)
	// 보류전표를 화면에 채우기만 하고 행은 지우지 않는다. 이후 정상으로 저장하면 VOUCHER_STATUS가 정상이 되어 보류 목록에서
	// 빠진다.
	// 保留伝票を画面に入れるだけで行は消さない。その後正常で保存するとVOUCHER_STATUSが正常になり保留一覧から外れる。
	public SaleInputOneDTO takeHold(Long saleId) {
		return get(saleId);
	}

	@Override
	@Transactional
	public void deleteHolds(List<Long> saleIds) {
		if (saleIds == null) {
			return;
		}
		for (Long saleId : saleIds) {
			removeHold(saleId);
		}
	}

	/**
	 * 보류 한 건 삭제. 품목이 연결을 참조하므로 연결, 품목, 이력, 헤더 순서로 지운다.
	 * 保留1件の削除。品目が接続を参照するので接続、品目、履歴、ヘッダの順に消す。
	 */
	/** 한 줄의 공급가액, 부가세, 합계. 부가세율 미적용이면 부가세는 0이다.
	 *  1行の供給価額、付加税、合計。付加税率未適用なら付加税は0である。 */
	private void applyLineAmounts(SaleCurrDTO header, SaleCurrItemDTO item) {
		BigDecimal price = item.getUnitPrice() == null ? BigDecimal.ZERO : item.getUnitPrice();
		BigDecimal discount = item.getDiscountAmt() == null ? BigDecimal.ZERO : item.getDiscountAmt();
		BigDecimal supply = item.getSaleQty().multiply(price).subtract(discount);
		if (supply.signum() < 0) {
			supply = BigDecimal.ZERO;
		}
		BigDecimal vat = BigDecimal.ZERO;
		if (header.getSaleType() == null || !"付加税率不適用".equals(header.getSaleType())) { // 부가세율 미적용
			vat = supply.multiply(new BigDecimal("0.1")).setScale(0, RoundingMode.HALF_UP);
		}
		item.setSupplyAmt(supply);
		item.setVatAmt(vat);
		item.setLineAmt(supply.add(vat));
	}

	private void removeHold(Long saleId) {
		mapper.deleteLinksBySaleId(saleId);
		mapper.deleteItemsBySaleId(saleId);
		mapper.deleteHistoryBySaleId(saleId);
		mapper.deleteSale(saleId);
	}

}
