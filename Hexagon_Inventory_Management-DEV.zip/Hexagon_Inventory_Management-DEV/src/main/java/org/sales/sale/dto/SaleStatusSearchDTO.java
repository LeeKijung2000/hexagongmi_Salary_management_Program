package org.sales.sale.dto;

import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

/**
 * 판매현황 조회 조건. 값이 있는 항목만 SQL 조건이 된다.
 * 販売状況の照会条件。値がある項目だけ SQL 条件になる。
 */
@Data
public class SaleStatusSearchDTO {

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date fromDate;

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date toDate;

	/** DAY, MONTH, ITEM, PARTNER, MANAGER. 현황 탭의 구분이다. 비어 있으면 서버는 일별로 받고, 월 계 행은 화면이 만든다.
	 *  DAY、MONTH、ITEM、PARTNER、MANAGER。現状タブの区分である。空ならサーバーは日別として受け、月計行は画面が作る。 */
	private String viewMode;

	/** NONE, PREV_YEAR, PREV_MONTH, PREV_WEEK, PREV_DAY. 사용안함이 아니면 같은 조건으로 기간만 옮겨 다시 읽는다.
	 *  使用しないでなければ同じ条件で期間だけ移して読み直す。 */
	private String compare;

	/** TB_SALE.TRANSACTION_TYPE. 비어 있으면 전체. 空なら全体。 */
	private String transactionType;

	/** ALL, DOMESTIC, FOREIGN. 내자는 통화가 없거나 KR, 외자는 KR이 아닌 통화만 남긴다.
	 *  内貨は通貨がないか KR、外貨は KR でない通貨だけ残す。 */
	private String currencyScope;

	/** 출하창고. 비어 있으면 창고를 가리지 않는다. 出荷倉庫。空なら倉庫を問わない。 */
	private Long warehouseId;

	/** 거래처. 비어 있으면 거래처를 가리지 않는다. 取引先。空なら取引先を問わない。 */
	private Long partnerId;

	/** 품목. 비어 있으면 품목을 가리지 않는다. 品目。空なら品目を問わない。 */
	private Long itemId;

	/** ALL, NORMAL, RETURN. 반품은 전표상태가 RETURN이거나 입력구분이 RETURN인 줄만 남긴다.
	 *  返品は伝票状態が RETURN か、入力区分が RETURN の行だけ残す。 */
	private String inputScope;

	/** DATE, PARTNER, ITEM, QTY, SUPPLY, TOTAL. 현황 목록의 정렬이고, 월 계 안의 줄도 화면이 같은 기준으로 다시 정렬한다.
	 *  現状一覧の並べ替えであり、月計の中の行も画面が同じ基準で並べ直す。 */
	private String sortKey;

	/** 집계조건. 비어 있으면 집계 조회를 거절한다. 빈 칸은 빼고 앞에서부터 다시 채운다. 같은 조건은 한 번만 남긴다.
	 *  集計条件。空なら集計照会を拒む。空枠は除いて前から詰め直す。同じ条件は一度だけ残す。 */
	private String group1;
	private String group2;
	private String group3;
	private String group4;
	private String group5;
	private String group6;
	private String group7;
	/** 빈 칸을 뺀 집계조건. 화면은 group1부터 채워 보내고, 서비스가 같은 조건을 한 번만 남긴다.
	 *  空枠を除いた集計条件。画面は group1 から埋めて送り、サービスが同じ条件を一度だけ残す。 */
	private List<String> groups;

	/** 한 번에 읽는 줄 수. 서비스가 1,000으로 고정하고, 합계는 이 제한 밖의 건까지 더한다.
	 *  一度に読む行数。サービスが 1,000 に固定し、合計はこの制限の外の件まで足す。 */
	private Integer limit;
}
