package org.sales.sale.dto;

import java.math.BigDecimal;

import lombok.Data;

/**
 * 변경 대상 판매 헤더. 환율변경은 통화 마스터의 환율을 전표에 넣고, 합계는 품목 합에 조정금액을 더한다.
 * 変更対象の販売ヘッダ。為替変更は通貨マスタの為替を伝票へ入れ、合計は品目合計に調整金額を足す。
 */
@Data
public class SalePriceChangeSlipDTO {

	private Long saleId;
	private BigDecimal exchangeRate;
	private String transactionType;
	private BigDecimal adjustmentAmount;
	private String currencyCode;
	private BigDecimal currencyRate;
	private BigDecimal supplyAmount;
	private BigDecimal vatAmount;
	private BigDecimal totalAmount;
}
