package org.sales.sale.dto;

import java.util.List;

import lombok.Data;

/**
 * 판매단가일괄변경 조회 결과. 1,000건을 넘으면 목록만 자르고 건수는 전체다.
 * 販売単価一括変更の照会結果。1,000件を超えると一覧だけ切り、件数は全体である。
 */
@Data
public class SalePriceChangeResultDTO {

	private List<SalePriceChangeLineDTO> lines;
	private int totalCount;
	private boolean truncated;
}
