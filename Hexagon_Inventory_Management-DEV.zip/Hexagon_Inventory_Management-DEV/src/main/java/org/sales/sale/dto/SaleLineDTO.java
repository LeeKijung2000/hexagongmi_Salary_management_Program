package org.sales.sale.dto;

import java.math.BigDecimal;

import lombok.Data;

/**
 * 판매입력2 품목 줄. TB_SALE_ITEM.
 * 공급가액은 수량×단가에서 할인을 뺀 값이고 화면에는 계산값만 보여 준다. 고친 품목코드, 품목명, 규격은 판매 스냅에만 저장하고 품목 마스터는 바꾸지 않는다.
 * 販売入力2品目行。TB_SALE_ITEM。
 * 供給価額は数量×単価から割引を引いた値であり、画面には計算値だけ見せる。直した品目コード、品目名、規格は販売スナップだけに保存し、品目マスタは変えない。
 */
@Data
public class SaleLineDTO {

	private Long itemId;
	private Long saleId;
	private Long itemPk;
	private String itemCode;
	private String itemNm;
	private String spec;
	private BigDecimal totQty;
	private BigDecimal whQty;
	private BigDecimal saleQty;
	private BigDecimal unitPrice;
	private BigDecimal discountAmt;
	private BigDecimal supplyAmt;
	private BigDecimal vatAmt;
	private BigDecimal lineAmt;
	private String remark;
}
