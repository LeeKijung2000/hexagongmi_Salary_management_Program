package org.sales.sale.dto;

import java.math.BigDecimal;

import lombok.Data;

/**
 * 변경 대상 판매 품목. 단가와 금액을 다시 계산해 이 값으로 UPDATE 한다.
 * 変更対象の販売品目。単価と金額を計算し直し、この値で UPDATE する。
 */
@Data
public class SalePriceChangeItemDTO {

	private Long saleItemId;
	private BigDecimal quantity;
	private BigDecimal unitPrice;
	private BigDecimal supplyAmount;
	private BigDecimal vatAmount;
	private BigDecimal totalAmount;
}
