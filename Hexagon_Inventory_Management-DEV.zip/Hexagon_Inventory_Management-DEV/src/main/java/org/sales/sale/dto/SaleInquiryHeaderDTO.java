package org.sales.sale.dto;

import lombok.Data;

/**
 * 확정과 삭제 전에 잠그는 판매 헤더. 창고와 전표상태, 진행상태만 쓴다.
 * 確定と削除の前にロックする販売ヘッダ。倉庫と伝票状態、進行状態だけ使う。
 */
@Data
public class SaleInquiryHeaderDTO {

	private Long saleId;
	private Long warehouseId;
	private String voucherStatus;
	private String progressStatus;
}
