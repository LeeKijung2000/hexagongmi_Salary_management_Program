package org.sales.sale.dto;

import java.math.BigDecimal;

import lombok.Data;

/**
 * 결제내역 목록 한 줄. 요청자 칸은 사업자 코드를 그대로 보여 주고, 품목과 상태별처리는 화면에 내지 않는다.
 * 決済履歴一覧の1行。依頼者欄は事業者コードをそのまま見せ、品目と状態別処理は画面に出さない。
 */
@Data
public class PaymentInquiryRowDTO {

	private Long paymentId;
	/** 화면 표시용 결제 요청일시. yyyy/MM/dd HH:mm:ss.
	 *  画面表示用の決済依頼日時。yyyy/MM/dd HH:mm:ss。 */
	private String requestedAt;
	private Long requesterId;
	private String requesterName;
	/** 요청자 칸에 그대로 보이는 사업자. 依頼者欄にそのまま出す事業者。 */
	private String companyCode;
	private String partnerName;
	private String itemName;
	private BigDecimal paymentAmount;
	private String paymentMethod;
	private String paymentStatus;
	private String approvalNumber;
	private Long saleId;
	private String voucherNo;
}
