package org.sales.sale.service;

import java.util.List;

import org.sales.sale.dto.CurrencyDTO;
import org.sales.sale.dto.ItemLookupDTO;
import org.sales.sale.dto.ManagerLookupDTO;
import org.sales.sale.dto.PartnerLookupDTO;
import org.sales.sale.dto.WarehouseLookupDTO;

/**
 * 공통 조회 서비스. 판매입력1의 거래처, 창고, 담당자, 품목 검색창이 이 결과를 그대로 표에 그린다. 키워드가 비어 있으면 조건 없이
 * 목록을 주고, 사용중단포함은 거래처와 창고에만 적용한다.
 * 共通照会サービス。販売入力1の取引先、倉庫、担当者、品目の検索画面がこの結果をそのまま表に描く。
 * キーワードが空なら条件なしで一覧を返し、使用中止含むは取引先と倉庫だけに適用する。
 */
public interface CommonLookupService {

	/**
	 * 거래처검색. 코드, 거래처명, 검색창내용만 돌려준다. includeUnused가 아니면 사용 중인 거래처만 본다.
	 * 取引先検索。コード、取引先名、検索窓内容だけ返す。includeUnusedでなければ使用中の取引先だけ見る。
	 */
	List<PartnerLookupDTO> getPartners(String keyword, boolean includeUnused);

	/**
	 * 창고검색. 구분, 창고코드, 창고명을 돌려준다. 사용중단 창고는 includeUnused일 때만 포함한다.
	 * 倉庫検索。区分、倉庫コード、倉庫名を返す。使用中止の倉庫はincludeUnusedのときだけ含める。
	 */
	List<WarehouseLookupDTO> getWarehouses(String keyword, boolean includeUnused);

	/**
	 * 사원검색. 사원코드와 사원명만 돌려준다. 신규 등록은 조회 모달에서 하고, 이 조회는 사용중단 조건을 두지 않는다.
	 * 社員検索。社員コードと社員名だけ返す。新規登録は照会モーダルで行い、この照会は使用中止の条件を置かない。
	 */
	List<ManagerLookupDTO> getManagers(String keyword);

	/**
	 * 품목검색. 품목코드, 품목명, 검색창내용, 규격, 전체재고, 출고단가를 돌려준다. 여러 줄을 골라 판매 품목에 넣을 수 있다.
	 * 品目検索。品目コード、品目名、検索窓内容、規格、全体在庫、出庫単価を返す。複数行を選んで販売品目に入れられる。
	 */
	List<ItemLookupDTO> getItems(String keyword);

	/**
	 * 사용 중인 통화 목록. TB_CURRENCY를 여러 화면이 같이 읽는다. 使用中の通貨一覧。TB_CURRENCYを複数画面が一緒に読む。
	 */
	List<CurrencyDTO> getCurrencies();

	/**
	 * 통화명으로 한 건. 없으면 null. 通貨名で1件。なければ null。
	 */
	CurrencyDTO getCurrencyByName(String currencyName);

	/**
	 * 통화코드로 한 건. 판매입력 기본값은 KR이다. 通貨コードで1件。販売入力の既定値はKRである。
	 */
	CurrencyDTO getCurrencyByCode(String currencyCode);

	/**
	 * 통화 추가. 이름이 비었거나 같으면 등록하지 않는다. 通貨追加。名前が空か同じなら登録しない。
	 */
	CurrencyDTO addCurrency(CurrencyDTO currency);
}
