package org.sales.sale.dao;

import java.math.BigDecimal;
import java.util.List;

import org.sales.sale.dto.SaleStatusLineDTO;
import org.sales.sale.dto.SaleStatusQtyDTO;
import org.sales.sale.dto.SaleStatusSearchDTO;
import org.sales.sale.dto.SaleStatusSummaryDTO;
import org.sales.sale.dto.SaleStatusTotalDTO;

/**
 * 판매현황 Dao. TB_SALE과 TB_SALE_ITEM을 읽기만 한다.
 * 販売状況 Dao。TB_SALE と TB_SALE_ITEM を読むだけである。
 */
public interface SaleStatusDao {

	/** 현황에 나올 품목 줄 수. 보류와 취소는 세지 않고, 1,000건 제한도 적용하지 않는다.
	 *  現状に出る品目行数。保留と取消は数えず、1,000件制限も掛けない。 */
	int countLines(SaleStatusSearchDTO search);

	/** 현황 품목 줄. 금액은 저장된 공급가액, 부가세, 합계다. 기본 순서는 판매일자, 판매번호, 줄번호다.
	 *  現状の品目行。金額は保存された供給価額、付加税、合計である。基本の順は販売日付、販売番号、行番号である。 */
	List<SaleStatusLineDTO> selectLines(SaleStatusSearchDTO search);

	/** 전표 수. 같은 판매의 품목이 여러 줄이어도 판매번호로 한 번만 센다. 화면 현황은 이 조회를 쓰지 않는다.
	 *  伝票数。同じ販売の品目が複数行でも販売番号で一度だけ数える。画面の現状はこの照会を使わない。 */
	int countSlips(SaleStatusSearchDTO search);

	/** 전표를 한 줄로 합친 목록. 품목 금액을 판매번호로 더한다. 화면은 품목 줄을 받아 직접 월 계를 만든다.
	 *  伝票を1行に合算した一覧。品目金額を販売番号で足す。画面は品目行を受けて自ら月計を作る。 */
	List<SaleStatusLineDTO> selectSlips(SaleStatusSearchDTO search);

	/** 목록을 자르기 전의 수량, 공급가액, 부가세, 합계. 결과 창의 총합계가 이 값을 쓴다.
	 *  一覧を切る前の数量、供給価額、付加税、合計。結果窓の総合計がこの値を使う。 */
	SaleStatusTotalDTO selectTotals(SaleStatusSearchDTO search);

	/** 비교기간 수량 합계. 줄 단위 비교수량을 붙일 때 전체 수량으로 같이 돌려준다.
	 *  比較期間の数量合計。行単位の比較数量を付けるとき全体数量として一緒に返す。 */
	BigDecimal selectQuantity(SaleStatusSearchDTO search);

	/** 품목, 거래처, 창고가 같은 줄의 비교기간 수량. 판매 수량을 고치지 않고 옆에 붙이는 값이다.
	 *  品目、取引先、倉庫が同じ行の比較期間数量。販売数量を直さず横に付ける値である。 */
	List<SaleStatusQtyDTO> selectLineCompare(SaleStatusSearchDTO search);

	/** 거래처별 비교기간 수량. 전표 합계용이고, 지금 화면의 좌우 비교표는 품목 줄을 다시 읽는다.
	 *  取引先別の比較期間数量。伝票合計用であり、今の画面の左右比較表は品目行を読み直す。 */
	List<SaleStatusQtyDTO> selectSlipCompare(SaleStatusSearchDTO search);

	/** 집계 묶음 수. 집계조건이 있을 때만 세고, 계 행과 총합계 행은 포함하지 않는다.
	 *  集計の束の数。集計条件があるときだけ数え、計行と総合計行は含まない。 */
	int countSummaryGroups(SaleStatusSearchDTO search);

	/** 집계 줄. 이름은 집계조건 순서대로 group1Name부터 채운다. 일별은 yyyy-MM-dd, 월별은 yyyy-MM, 연별은 yyyy다.
	 *  集計行。名前は集計条件の順に group1Name から埋める。日別は yyyy-MM-dd、月別は yyyy-MM、年別は yyyy である。 */
	List<SaleStatusSummaryDTO> selectSummary(SaleStatusSearchDTO search);

	/** 같은 집계 키의 비교기간 수량. 날짜 키는 서비스가 기준기간 쪽으로 옮겨 맞춘다.
	 *  同じ集計キーの比較期間数量。日付キーはサービスが基準期間側へ移して合わせる。 */
	List<SaleStatusQtyDTO> selectSummaryCompare(SaleStatusSearchDTO search);
}
