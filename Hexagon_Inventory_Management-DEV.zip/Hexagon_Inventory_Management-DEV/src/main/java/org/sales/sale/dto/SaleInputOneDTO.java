package org.sales.sale.dto;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;

/**
 * 판매입력1 한 전표. 헤더 1건과 품목 라인 목록이다.
 * 화면의 빈 줄도 같이 들어오지만, 저장할 때 품목 키가 없는 줄은 전표에 넣지 않는다.
 * 販売入力1の伝票1件。ヘッダ1件と品目行の一覧である。
 * 画面の空行も一緒に入るが、保存時に品目キーがない行は伝票に入れない。
 */
@Data
public class SaleInputOneDTO {

    private SaleCurrDTO header;
    private List<SaleCurrItemDTO> items = new ArrayList<SaleCurrItemDTO>();
}
