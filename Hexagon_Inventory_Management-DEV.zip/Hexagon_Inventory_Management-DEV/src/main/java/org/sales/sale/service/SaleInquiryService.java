package org.sales.sale.service;

import java.util.Date;
import java.util.List;

import org.sales.sale.dto.LoadedSlipDTO;
import org.sales.sale.dto.SaleInquiryPageDTO;
import org.sales.sale.dto.SaleSlipHistoryDTO;
import org.sales.sale.dto.VoucherHistoryDTO;

/**
 * 판매조회. 목록은 정상 전표만 16건씩 보고, 확정은 진행상태와 수불을 남긴다. 판매입력1이 정상 저장 때 이미 재고를 뺐으므로 확정에서 수량을 다시 빼지 않는다.
 * 販売照会。一覧は正常伝票だけ16件ずつ見、確定は進行状態と受払を残す。販売入力1が正常保存ですでに在庫を引いているので、確定で数量を再び引かない。
 */
public interface SaleInquiryService {

	/** 한 페이지는 16건이다. 1ページは16件である。 */
	int PAGE_SIZE = 16;

	/**
	 * 기간과 탭, 검색어로 목록을 가져온다. 시작일이 종료일보다 늦으면 조회하지 않는다.
	 * 期間とタブ、検索語で一覧を取る。開始日が終了日より遅ければ照会しない。
	 */
	SaleInquiryPageDTO search(Date fromDate, Date toDate, String tab, String keyword, int page);

	/**
	 * 고른 판매의 진행상태를 확인 또는 미확인으로 바꾼다. 확인은 수불과 이력을 남기고, 미확인으로 돌려도 재고는 되돌리지 않는다.
	 * 選んだ販売の進行状態を確認または未確認へ変える。確認は受払と履歴を残し、未確認へ戻しても在庫は戻さない。
	 */
	void changeProgress(List<Long> saleIds, String progressStatus);

	/**
	 * 선택삭제. 판매입력1이 뺀 재고를 되돌리고, 확인 이력이 있으면 취소 수불을 남긴 뒤 전표를 지운다. 기존 이력은 남긴다.
	 * 選択削除。販売入力1が引いた在庫を戻し、確認履歴があれば取消受払を残したあと伝票を消す。既存の履歴は残す。
	 */
	void deleteSelected(List<Long> saleIds);

	/**
	 * 판매 이력. inputType이 NORMAL이면 판매입력1, POS면 판매입력2다. saleId가 있으면 그 전표의 신규, 수정, 삭제만 본다.
	 * 販売履歴。inputTypeが NORMAL なら販売入力1、POS なら販売入力2である。saleIdがあればその伝票の新規、修正、削除だけ見る。
	 */
	List<VoucherHistoryDTO> searchHistory(Date fromDate, Date toDate, String inputType, Long saleId, String keyword);

	/**
	 * 이력 H. 그 전표의 작업일시, 진행상태, 상태만 시간순으로 돌려준다.
	 * 履歴 H。その伝票の作業日時、進行状態、状態だけを時刻順で返す。
	 */
	SaleSlipHistoryDTO slipHistory(Long saleId);

	/**
	 * 불러온 전표. 주문, 견적, 원판매 연결이 있을 때만 목록이 있다.
	 * 読込伝票。注文、見積、元販売の接続があるときだけ一覧がある。
	 */
	List<LoadedSlipDTO> getSources(Long saleId);
}
