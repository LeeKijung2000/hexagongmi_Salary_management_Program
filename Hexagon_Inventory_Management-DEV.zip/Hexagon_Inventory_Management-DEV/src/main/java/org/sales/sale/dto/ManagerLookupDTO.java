package org.sales.sale.dto;

import lombok.Data;

/** 사원검색. 사원코드, 사원명. TB_MANAGER.
 *  社員検索。社員コード、社員名。 */
@Data
public class ManagerLookupDTO {

	private Long managerId;
	private String employeeCode;
	private String employeeName;
}
