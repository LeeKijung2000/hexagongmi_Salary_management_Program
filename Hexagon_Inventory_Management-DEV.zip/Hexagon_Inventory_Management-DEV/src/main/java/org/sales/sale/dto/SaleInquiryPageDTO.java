package org.sales.sale.dto;

import java.util.List;

import lombok.Data;

/**
 * 판매조회 한 페이지. 한 페이지는 16건이다.
 * 販売照会の1ページ。1ページは16件である。
 */
@Data
public class SaleInquiryPageDTO {

	private int page;
	private int pageSize;
	private int totalCount;
	private int totalPages;
	private List<SaleInquiryRowDTO> rows;
}
