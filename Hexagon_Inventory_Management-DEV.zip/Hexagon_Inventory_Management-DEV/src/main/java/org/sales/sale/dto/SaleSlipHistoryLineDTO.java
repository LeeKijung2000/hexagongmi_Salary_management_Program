package org.sales.sale.dto;

import lombok.Data;

/**
 * 전표 이력 창의 한 줄. 남기는 값은 작업일시, 진행상태, 상태다.
 * 伝票履歴の窓の1行。残す値は作業日時、進行状態、状態である。
 */
@Data
public class SaleSlipHistoryLineDTO {

	/** 로그인 사용자가 없으면 GUEST. ログインユーザーがなければ GUEST。 */
	private String workerName;
	/** yyyy/MM/dd 오전/오후 h:mm:ss. 作業日時。 */
	private String workedAt;
	/** 확인 또는 미확인. 確認または未確認。 */
	private String slipStatusName;
	/** 확인 또는 미확인. その作業時点の進行状態。 */
	private String progressName;
	/** 신규, 수정, 삭제, 확인, 미확인. 新規、修正、削除、確認、未確認。 */
	private String actionName;
}
