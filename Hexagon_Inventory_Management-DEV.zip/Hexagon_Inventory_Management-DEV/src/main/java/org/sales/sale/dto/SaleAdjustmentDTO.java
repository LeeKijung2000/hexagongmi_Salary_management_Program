package org.sales.sale.dto;

import java.math.BigDecimal;

import lombok.Data;

/**
 * 판매입력2 금액조정 한 줄. TB_SALE_ADJUSTMENT.
 * 증감구분은 INCREASE 또는 DECREASE다. 합계는 공급가액+부가세다.
 * 販売入力2の金額調整1行。TB_SALE_ADJUSTMENT。
 * 増減区分は INCREASE または DECREASE である。合計は供給価額+付加税である。
 */
@Data
public class SaleAdjustmentDTO {

	private Long adjustmentId;
	private Long saleId;
	private Integer lineNo;
	private String adjustmentName;
	private String increaseDecrease;
	private BigDecimal supplyAmt;
	private BigDecimal vatAmt;
	private BigDecimal totalAmt;
}
