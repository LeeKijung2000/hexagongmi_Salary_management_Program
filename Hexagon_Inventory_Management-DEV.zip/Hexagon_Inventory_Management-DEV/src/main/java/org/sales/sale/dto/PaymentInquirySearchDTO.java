package org.sales.sale.dto;

import lombok.Data;

/**
 * 결제내역 검색. 검색어는 거래처명, 승인번호, 판매번호, 재고전표에 부분일치한다.
 * 決済履歴の検索。検索語は取引先名、承認番号、販売番号、在庫伝票に部分一致する。
 */
@Data
public class PaymentInquirySearchDTO {

	private String keyword;
	/** LIKE에 넣을 값. %와 _는 이스케이프한다. LIKEに入れる値。% と _ はエスケープする。 */
	private String likeKeyword;
	private int maxRows;
}
