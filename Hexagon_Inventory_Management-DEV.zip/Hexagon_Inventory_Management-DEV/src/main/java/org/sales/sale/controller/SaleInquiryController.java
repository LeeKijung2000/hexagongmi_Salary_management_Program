package org.sales.sale.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.sales.sale.dto.LoadedSlipDTO;
import org.sales.sale.dto.SaleInquiryPageDTO;
import org.sales.sale.dto.SaleSlipHistoryDTO;
import org.sales.sale.dto.VoucherHistoryDTO;
import org.sales.sale.service.SaleInquiryService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/sales/sale")
@AllArgsConstructor
/**
 * 판매조회 화면. 목록과 확정, 선택삭제, 이력, 불러온 전표는 이 주소에서 처리하고, 신규와 수정 입력은 판매입력1 화면을 모달로 연다.
 * 販売照会画面。一覧と確定、選択削除、履歴、読込伝票はこのアドレスで処理し、新規と修正の入力は販売入力1画面をモーダルで開く。
 */
public class SaleInquiryController {

	private SaleInquiryService service;

	/** 판매조회 화면. 조회기간 기본값은 오늘 기준 30일 전과 30일 뒤다.
	 *  販売照会画面。照会期間の初期値は今日を基準に30日前と30日後である。 */
	@GetMapping("/inquiry")
	public String inquiry(Model model) {
		java.time.LocalDate today = java.time.LocalDate.now();
		model.addAttribute("fromDate", today.minusDays(30).toString());
		model.addAttribute("toDate", today.plusDays(30).toString());
		return "sales/sale/inquiry";
	}

	/** 목록 한 페이지. 시작일이 종료일보다 늦으면 400과 메시지를 돌려준다.
	 *  一覧の1ページ。開始日が終了日より遅ければ 400 とメッセージを返す。 */
	@GetMapping("/inquiry/list")
	@ResponseBody
	public ResponseEntity<?> list(
			@RequestParam("fromDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date fromDate,
			@RequestParam("toDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date toDate,
			@RequestParam(value = "tab", defaultValue = "ALL") String tab,
			@RequestParam(value = "keyword", required = false) String keyword,
			@RequestParam(value = "page", defaultValue = "1") int page) {
		log.info("inquiry list " + tab + " page " + page);
		try {
			SaleInquiryPageDTO body = service.search(fromDate, toDate, tab, keyword, page);
			return new ResponseEntity<SaleInquiryPageDTO>(body, HttpStatus.OK);
		} catch (IllegalArgumentException e) {
			return error(e.getMessage());
		}
	}

	/** 진행상태 변경. 확인은 수불을 남기고, 미확인으로 돌려도 재고는 되돌리지 않는다.
	 *  進行状態の変更。確認は受払を残し、未確認へ戻しても在庫は戻さない。 */
	@PostMapping("/inquiry/progress")
	@ResponseBody
	public ResponseEntity<Map<String, Object>> progress(@RequestParam("saleIds") List<Long> saleIds,
			@RequestParam("progressStatus") String progressStatus) {
		log.info("inquiry progress " + progressStatus + " " + saleIds);
		try {
			service.changeProgress(saleIds, progressStatus);
			return ok();
		} catch (IllegalArgumentException e) {
			return error(e.getMessage());
		}
	}

	/** 선택삭제. 재고를 되돌리고 취소 이력을 남긴 뒤 전표를 지운다.
	 *  選択削除。在庫を戻し取消履歴を残したあと伝票を消す。 */
	@PostMapping("/inquiry/delete")
	@ResponseBody
	public ResponseEntity<Map<String, Object>> delete(@RequestParam("saleIds") List<Long> saleIds) {
		log.info("inquiry delete " + saleIds);
		try {
			service.deleteSelected(saleIds);
			return ok();
		} catch (IllegalArgumentException e) {
			return error(e.getMessage());
		}
	}

	/** 판매 이력. 화살표의 판매입력1은 NORMAL, 판매입력2는 POS다. saleId가 있으면 그 전표만 돌려준다.
	 *  販売履歴。矢印の販売入力1は NORMAL、販売入力2は POS である。saleIdがあればその伝票だけ返す。 */
	@GetMapping("/inquiry/history")
	@ResponseBody
	public ResponseEntity<?> history(
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Date toDate,
			@RequestParam(value = "inputType", required = false) String inputType,
			@RequestParam(value = "saleId", required = false) Long saleId,
			@RequestParam(value = "keyword", required = false) String keyword) {
		try {
			List<VoucherHistoryDTO> body = service.searchHistory(fromDate, toDate, inputType, saleId, keyword);
			return new ResponseEntity<List<VoucherHistoryDTO>>(body, HttpStatus.OK);
		} catch (IllegalArgumentException e) {
			return error(e.getMessage());
		}
	}

	/** 이력 H. 그 전표의 작업일시, 진행상태, 상태만 돌려준다.
	 *  履歴 H。その伝票の作業日時、進行状態、状態だけ返す。 */
	@GetMapping("/inquiry/history/slip")
	@ResponseBody
	public ResponseEntity<?> slipHistory(@RequestParam("saleId") Long saleId) {
		try {
			SaleSlipHistoryDTO body = service.slipHistory(saleId);
			return new ResponseEntity<SaleSlipHistoryDTO>(body, HttpStatus.OK);
		} catch (IllegalArgumentException e) {
			return error(e.getMessage());
		}
	}

	/** 불러온 전표. 주문, 견적, 원판매 연결을 돌려준다.
	 *  読込伝票。注文、見積、元販売の接続を返す。 */
	@GetMapping("/inquiry/sources")
	@ResponseBody
	public ResponseEntity<?> sources(@RequestParam("saleId") Long saleId) {
		try {
			List<LoadedSlipDTO> body = service.getSources(saleId);
			return new ResponseEntity<List<LoadedSlipDTO>>(body, HttpStatus.OK);
		} catch (IllegalArgumentException e) {
			return error(e.getMessage());
		}
	}

	private ResponseEntity<Map<String, Object>> ok() {
		Map<String, Object> body = new HashMap<String, Object>();
		body.put("ok", Boolean.TRUE);
		return new ResponseEntity<Map<String, Object>>(body, HttpStatus.OK);
	}

	private ResponseEntity<Map<String, Object>> error(String message) {
		Map<String, Object> body = new HashMap<String, Object>();
		body.put("message", message);
		return new ResponseEntity<Map<String, Object>>(body, HttpStatus.BAD_REQUEST);
	}
}
