package org.sales.sale.dao;

import java.math.BigDecimal;
import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.sales.sale.dto.HoldSlipDTO;
import org.sales.sale.dto.ItemStockDTO;
import org.sales.sale.dto.SaleAdjustmentDTO;
import org.sales.sale.dto.SaleHeaderDTO;
import org.sales.sale.dto.SaleHistoryDTO;
import org.sales.sale.dto.SaleLineDTO;

/**
 * 판매입력2(S0120) Dao. TB_SALE / TB_SALE_ITEM / TB_SALE_ADJUSTMENT / TB_VOUCHER_HISTORY.
 * 판매입력구분은 POS다. 거래처, 창고, 담당자, 품목 조회는 CommonLookupDao가 담당한다.
 * 販売入力2(S0120) Dao。TB_SALE / TB_SALE_ITEM / TB_SALE_ADJUSTMENT / TB_VOUCHER_HISTORY。
 * 販売入力区分はPOSである。取引先、倉庫、担当者、品目の照会はCommonLookupDaoが担当する。
 */
public interface SaleInputTwoDao {

	/** 헤더 한 건. 거래처, 담당자, 창고 이름을 붙여 화면에 쓴다.
	 *  ヘッダ1件。取引先、担当者、倉庫の名前を付けて画面に使う。 */
	SaleHeaderDTO selectSale(@Param("saleId") Long saleId);

	/** 품목 라인. 적요와 할인금액을 같이 읽는다. 品目行。摘要と割引金額を一緒に読む。 */
	List<SaleLineDTO> selectItems(@Param("saleId") Long saleId);

	/** 금액조정 줄. 증감구분과 공급가액, 부가세, 합계를 읽는다.
	 *  金額調整の行。増減区分と供給価額、付加税、合計を読む。 */
	List<SaleAdjustmentDTO> selectAdjustments(@Param("saleId") Long saleId);

	/** 헤더 등록. 판매입력구분은 POS다. ヘッダ登録。販売入力区分はPOSである。 */
	int insertSale(SaleHeaderDTO sale);

	/** 헤더 수정. 일자, 거래처, 금액, 전표상태를 다시 쓴다.
	 *  ヘッダ修正。日付、取引先、金額、伝票状態を書き直す。 */
	int updateSale(SaleHeaderDTO sale);

	/** 그 전표의 품목 라인을 지운다. その伝票の品目行を消す。 */
	int deleteItemsBySaleId(@Param("saleId") Long saleId);

	/** 그 전표의 금액조정을 지운다. 수정 때 화면 줄로 다시 넣기 전에 쓴다.
	 *  その伝票の金額調整を消す。修正のとき画面の行で入れ直す前に使う。 */
	int deleteAdjustmentsBySaleId(@Param("saleId") Long saleId);

	/** 그 전표의 저장 이력을 지운다. 보류 삭제 때만 쓴다.
	 *  その伝票の保存履歴を消す。保留削除のときだけ使う。 */
	int deleteHistoryBySaleId(@Param("saleId") Long saleId);

	/** 헤더 한 건을 지운다. 금액조정, 품목, 이력을 지운 뒤에 호출한다.
	 *  ヘッダ1件を消す。金額調整、品目、履歴を消したあとに呼ぶ。 */
	int deleteSale(@Param("saleId") Long saleId);

	/** POS 보류 전표 수. POSの保留伝票数。 */
	int countHolds();

	/** POS 보류 목록. POSの保留一覧。 */
	List<HoldSlipDTO> selectHolds();

	/** 품목 한 줄. 화면에서 고친 코드, 이름, 규격은 판매 스냅에만 넣는다.
	 *  品目1行。画面で直したコード、名前、規格は販売スナップだけに入れる。 */
	int insertItem(SaleLineDTO item);

	/** 금액조정 한 줄. 金額調整1行。 */
	int insertAdjustment(SaleAdjustmentDTO adjustment);

	/** 저장 이력 한 줄. 登録または修正のあと残す保存履歴1行。 */
	int insertHistory(SaleHistoryDTO history);

	/** 다음 판매 전표 번호. 次の販売伝票番号。 */
	Long nextSaleId();

	/** 다음 품목 라인 번호. 次の品目行番号。 */
	Long nextItemId();

	/** 다음 금액조정 번호. 次の金額調整番号。 */
	Long nextAdjustmentId();

	/** 다음 저장 이력 번호. 次の保存履歴番号。 */
	Long nextHistoryId();

	/** 전체 재고와 출하창고 재고. 수량을 바꾸지 않는다.
	 *  全体在庫と出荷倉庫在庫。数量は変えない。 */
	ItemStockDTO selectItemStock(@Param("itemPk") Long itemPk, @Param("warehousePk") Long warehousePk);

	/** 출하창고 재고에 delta를 더한다. 빼려면 음수를 넘긴다.
	 *  出荷倉庫の在庫に delta を足す。引くときは負の数を渡す。 */
	int adjustInventory(@Param("warehousePk") Long warehousePk, @Param("itemPk") Long itemPk,
			@Param("delta") BigDecimal delta);
}
