package org.sales.sale.dto;

import java.math.BigDecimal;

import lombok.Data;

/** 공통 통화. TB_CURRENCY. 판매입력과 거래처가 같은 테이블을 읽는다.
 *  共通通貨。TB_CURRENCY。販売入力と取引先が同じテーブルを読む。 */
@Data
public class CurrencyDTO {

	private Long currencyId;
	private String currencyCode;
	private String currencyName;
	private BigDecimal exchangeRate;
}
