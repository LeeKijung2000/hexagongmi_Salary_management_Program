package org.sales.sale.dto;

import java.math.BigDecimal;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

/**
 * 판매입력1 헤더. SALE_CURR 한 행이 전표 하나다. 저장 시 판매구분는 일반, 진행상태는 미확인, 전표상태는 정상이다. 화살표에서
 * 보류를 고르면 전표상태만 보류가 된다. 통화를 고르지 않으면 KR을 넣고, 공급가액과 부가세는 품목 줄을 더한 값으로 다시 쓴다.
 * 販売入力1ヘッダ。SALE_CURRの1行が伝票1件である。
 * 保存時の販売区分は一般、進行状態は未確認、伝票状態は正常である。矢印で保留を選ぶと伝票状態だけ保留になる。
 * 通貨を選ばなければKRを入れ、供給価額と付加税は品目行を足した値で書き直す。
 */
@Data
public class SaleCurrDTO {

	private Long saleId;
	/** 화면 일자 입력(yyyy-MM-dd)과 맞춘다. 画面の日付入力(yyyy-MM-dd)に合わせる。 */
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date saleDt;
	private Long businessPartnerId;
	/** 화면 표시용 거래처 코드. 전표에는 거래처 키만 저장한다. 画面表示用の取引先コード。伝票には取引先キーだけ保存する。 */
	private String businessPartnerCode;
	private String businessPartnerName;
	private Long managerId;
	/** 화면 표시용 담당자 코드. 전표에는 담당자 키만 저장한다. 画面表示用の担当者コード。伝票には担当者キーだけ保存する。 */
	private String employeeCode;
	private String employeeName;
	private Long warehousePk;
	/** 화면 표시용 출하창고 코드. 전표에는 창고 키만 저장한다. 画面表示用の出荷倉庫コード。伝票には倉庫キーだけ保存する。 */
	private String warehouseCode;
	private String warehouseName;
	/** 초기값: 부가세율 적용. 初期値: 付加税率適用 */
	private String saleType;
	private Long currencyId;
	private String currencyName;
	/**
	 * 이 전표의 환율. 화면에서 고친 값이며 TB_CURRENCY는 덮지 않는다.
	 * この伝票の為替レート。画面で直した値であり、TB_CURRENCYは上書きしない。
	 */
	private BigDecimal exchangeRate;
	/** 공급가액 합계. SUM(SALE_CURR_ITEM.SUPPLY_AMT). 供給価額合計 */
	private BigDecimal currAmt;
	/** 부가세 합계. SUM(SALE_CURR_ITEM.VAT_AMT). 付加税合計 */
	private BigDecimal vatAmt;
	private String remark;
	private String saleDiv;
	private String voucherStatus;
	private String progressStatus;
	private Date updatedAt;
}
