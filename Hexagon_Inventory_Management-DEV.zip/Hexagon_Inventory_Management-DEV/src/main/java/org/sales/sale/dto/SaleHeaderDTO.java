package org.sales.sale.dto;

import java.math.BigDecimal;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

/**
 * 판매입력2 헤더. TB_SALE 한 행이 전표 하나다. 판매입력구분은 POS다.
 * 공급가액과 부가세는 품목 합계이고, 조정금액은 금액조정 합계다. 합계는 셋의 합이다.
 * 販売入力2ヘッダ。TB_SALEの1行が伝票1件である。販売入力区分はPOSである。
 * 供給価額と付加税は品目合計であり、調整金額は金額調整の合計である。合計は三つの和である。
 */
@Data
public class SaleHeaderDTO {

	private Long saleId;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date saleDt;
	private Long businessPartnerId;
	private String businessPartnerCode;
	private String businessPartnerName;
	private Long managerId;
	private String employeeCode;
	private String employeeName;
	private Long warehousePk;
	private String warehouseCode;
	private String warehouseName;
	/** 초기값: 부가세율 적용. 初期値: 付加税率適用 */
	private String saleType;
	private Long currencyId;
	private String currencyName;
	private BigDecimal exchangeRate;
	/** 품목 공급가액 합계. 品目供給価額合計 */
	private BigDecimal currAmt;
	/** 품목 부가세 합계. 品目付加税合計 */
	private BigDecimal vatAmt;
	/** 증가 조정 합계에서 감소 조정 합계를 뺀 값. 増加調整合計から減少調整合計を引いた値 */
	private BigDecimal adjustmentAmt;
	/** 공급가액 + 부가세 + 조정금액. 供給価額 + 付加税 + 調整金額 */
	private BigDecimal totalAmt;
	private String remark;
	private String saleDiv;
	private String voucherStatus;
	private String progressStatus;
	private Date updatedAt;
}
