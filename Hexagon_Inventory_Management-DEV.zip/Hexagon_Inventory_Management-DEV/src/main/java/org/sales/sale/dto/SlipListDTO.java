package org.sales.sale.dto;

import java.math.BigDecimal;

import lombok.Data;

/** 거래내역보기와 리스트 조회의 한 줄. 판매, 주문, 견적이 같은 칸으로 모달에 나온다.
 *  取引履歴とリスト照会の1行。販売、注文、見積が同じ列でモーダルに出る。 */
@Data
public class SlipListDTO {

	private Long slipId;
	private String slipNo;
	/** 화면 표시용 yyyy-MM-dd. 画面表示用 yyyy-MM-dd。 */
	private String slipDate;
	private String businessPartnerName;
	private BigDecimal supplyAmt;
	private BigDecimal vatAmt;
	private String voucherStatus;
}
