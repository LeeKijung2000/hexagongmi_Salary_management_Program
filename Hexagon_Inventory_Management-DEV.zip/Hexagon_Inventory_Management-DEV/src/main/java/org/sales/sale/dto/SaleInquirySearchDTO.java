package org.sales.sale.dto;

import java.util.Date;

import lombok.Data;

/**
 * 판매조회 검색 조건. 기간, 진행상태 탭, 검색어, 페이지 범위를 한 번에 넘긴다.
 * 販売照会の検索条件。期間、進行状態タブ、検索語、ページ範囲を一度に渡す。
 */
@Data
public class SaleInquirySearchDTO {

	private Date fromDate;
	private Date toDate;
	/** 비어 있으면 전체. 있으면 UNCONFIRMED 또는 CONFIRMED. 空なら全体。値があれば UNCONFIRMED または CONFIRMED。 */
	private String progressStatus;
	private String keyword;
	/** 1부터 세는 시작 행. 1始まりの開始行。 */
	private int startRow;
	private int endRow;
}
