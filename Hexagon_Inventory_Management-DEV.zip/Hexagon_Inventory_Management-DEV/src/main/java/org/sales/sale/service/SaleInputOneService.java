package org.sales.sale.service;

import java.util.Date;
import java.util.List;

import org.sales.sale.dto.HoldSlipDTO;
import org.sales.sale.dto.ItemProfitDTO;
import org.sales.sale.dto.ItemStockDTO;
import org.sales.sale.dto.SaleInputOneDTO;
import org.sales.sale.dto.SlipListDTO;
import org.sales.sale.dto.SlipSourceLineDTO;

/**
 * 판매입력1 서비스. 거래처, 창고, 담당자, 품목, 통화 조회는 CommonLookupService를 쓴다. 저장은 헤더와 품목, 원천
 * 연결, 이력을 한 트랜잭션으로 넣는다. 전표상태가 정상일 때만 출하창고 재고에서 판매수량을 뺀다. 그 수량이 0이면 저장하지 않고, 보류는 재고를 건드리지 않는다.
 * 販売入力1サービス。取引先、倉庫、担当者、品目、通貨の照会はCommonLookupServiceを使う。
 * 保存はヘッダと品目、元伝票の接続、履歴を一つのトランザクションで入れる。伝票状態が正常のときだけ出荷倉庫の在庫から販売数量を引く。その数量が0なら保存せず、保留は在庫を変えない。
 */
public interface SaleInputOneService {

	/**
	 * 새 전표를 저장한다. 판매구분 일반, 진행상태 미확인, 통화가 없으면 KR을 채운 뒤 품목과 이력을 넣는다. 정상이면 출하창고 수량이 0보다
	 * 큰 품목만 저장하고, 그 재고에서 판매수량을 뺀다.
	 * 新しい伝票を保存する。販売区分は一般、進行状態は未確認、通貨がなければKRを入れたあと品目と履歴を入れる。正常なら出荷倉庫数量が0より大きい品目だけ保存し、その在庫から販売数量を引く。
	 */
	public void register(SaleInputOneDTO sale);

	/**
	 * 전표 한 건. 헤더와 품목을 읽고, 주문·견적·판매 연결이 있으면 같은 품목 줄에 붙인다.
	 * 伝票1件。ヘッダと品目を読み、注文・見積・販売の接続があれば同じ品目行に付ける。
	 */
	public SaleInputOneDTO get(Long saleId);

	/**
	 * 이미 있는 전표를 고친다. 헤더를 갱신한 뒤 품목과 연결을 지우고 화면에서 온 줄로 다시 넣는다. 이전에 정상으로 빠진 재고는 되돌리고,
	 * 다시 정상이면 새 수량으로 뺀다.
	 * 既にある伝票を直す。ヘッダを更新したあと品目と接続を消し、画面から来た行で入れ直す。以前正常で引いた在庫は戻し、再び正常なら新しい数量で引く。
	 */
	public boolean modify(SaleInputOneDTO sale);

	/**
	 * 거래내역보기와 리스트 조회. kind는 sale, order, quote이다. 날짜가 둘 다 있으면 그 구간만, 없으면 전체다.
	 * 販売入力の取引履歴とリスト照会。kindはsale、order、quoteである。日付が両方あればその区間だけ、なければ全体である。
	 */
	public List<SlipListDTO> getSlips(String kind, Date fromDate, Date toDate);

	/**
	 * 주문 버튼. 주문수량에서 이미 판매로 연결한 수량을 뺀 나머지가 남은 줄만 가져온다.
	 * 注文ボタン。注文数量から既に販売へ接続した数量を引いた残りがある行だけ取る。
	 */
	public List<SlipSourceLineDTO> getUnsoldOrders(Long businessPartnerId);

	/**
	 * 남은 수량이 있는 견적 라인. 전표불러오기 버튼은 견적서 조회 JSP를 모달에 열고 이 조회를 쓰지 않는다.
	 * 残数量がある見積行。伝票読込ボタンは見積書照会JSPをモーダルに開き、この照会は使わない。
	 */
	public List<SlipSourceLineDTO> getQuoteLines(Long businessPartnerId);

	/**
	 * 아직 다른 판매로 넘기지 않은 판매 품목. 전표불러오기 버튼은 조회 JSP를 모달에 열고 이 조회를 쓰지 않는다.
	 * まだ他の販売へ渡していない販売品目。伝票読込ボタンは照会JSPをモーダルに開き、この照会は使わない。
	 */
	public List<SlipSourceLineDTO> getSaleLines(Long businessPartnerId);

	/**
	 * 재고불러오기. 전체 창고 합과 선택한 출하창고 수량만 읽는다. 이 조회는 재고를 줄이지 않고, 차감은 정상 저장에서 한다.
	 * 在庫読込。全倉庫の合計と選んだ出荷倉庫数量だけ読む。この照会は在庫を減らさず、減算は正常保存で行う。
	 */
	public ItemStockDTO getItemStock(Long itemPk, Long warehousePk);

	/**
	 * 이익계산용 원가. 매입단가와 표준원가를 읽어 화면에만 쓰고 라인에는 저장하지 않는다.
	 * 利益計算用の原価。仕入単価と標準原価を読んで画面に使うだけであり、行には保存しない。
	 */
	public ItemProfitDTO getItemProfit(Long itemPk);

	/**
	 * 보류 상태 전표 수. 새 보류 저장 전에 5건인지 확인하는 데 쓴다. 保留状態の伝票数。新しい保留保存の前に5件か確認するのに使う。
	 */
	public int countHolds();

	/**
	 * 보류 목록. 보류번호, 거래처, 품목 요약, 금액, 유형, 창고를 보여 준다. 保留一覧。保留番号、取引先、品目の要約、金額、類型、倉庫を見せる。
	 */
	public List<HoldSlipDTO> getHolds();

	/**
	 * 보류전표를 입력란에 채우기만 한다. 행은 지우지 않고, 정상 저장 때 목록에서 빠진다.
	 * 保留伝票を入力欄に入れるだけである。行は消さず、正常保存のとき一覧から外れる。
	 */
	public SaleInputOneDTO takeHold(Long saleId);

	/**
	 * 고른 보류전표를 지운다. 연결, 품목, 이력, 헤더 순서로 지운다. 選んだ保留伝票を消す。接続、品目、履歴、ヘッダの順に消す。
	 */
	public void deleteHolds(List<Long> saleIds);

}
