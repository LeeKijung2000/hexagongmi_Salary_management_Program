package org.sales.sale.dto;

import java.math.BigDecimal;

import lombok.Data;

/**
 * 판매현황 집계 한 줄. 이름은 집계조건 순서와 같다. 계 행과 총합계는 이 객체에 없고 화면이 더한다.
 * 販売状況の集計1行。名前は集計条件の順と同じである。計行と総合計はこのオブジェクトになく、画面が足す。
 */
@Data
public class SaleStatusSummaryDTO {

	private String groupKey;
	private String group1Name;
	private String group2Name;
	private String group3Name;
	private String group4Name;
	private String group5Name;
	private String group6Name;
	private String group7Name;
	private BigDecimal quantity;
	private BigDecimal supplyAmount;
	private BigDecimal vatAmount;
	private BigDecimal totalAmount;
	/** 같은 집계 키의 비교기간 수량. 차이는 화면에서 계산한다. 同じ集計キーの比較期間数量。差は画面で計算する。 */
	private BigDecimal compareQuantity;
}
