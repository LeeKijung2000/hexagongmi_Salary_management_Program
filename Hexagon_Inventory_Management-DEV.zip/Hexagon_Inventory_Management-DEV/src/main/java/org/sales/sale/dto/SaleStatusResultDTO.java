package org.sales.sale.dto;

import java.math.BigDecimal;
import java.util.List;

import lombok.Data;

/**
 * 판매현황 조회 결과. 현황은 lines, 집계는 summaries다. 합계는 목록 제한과 관계없이 조건 전체다.
 * 販売状況の照会結果。現状は lines、集計は summaries である。合計は一覧の制限に関係なく条件全体である。
 */
@Data
public class SaleStatusResultDTO {

	/** 현황 탭의 품목 줄. 월 계 행은 포함하지 않는다. 現状タブの品目行。月計行は含まない。 */
	private List<SaleStatusLineDTO> lines;
	/** 집계 탭의 묶음. 集計タブの束。 */
	private List<SaleStatusSummaryDTO> summaries;
	/** 비교기간의 품목 줄. 사용안함이면 비어 있다. 比較期間の品目行。使用しないなら空である。 */
	private List<SaleStatusLineDTO> compareLines;
	/** 비교기간의 집계 묶음. 화면이 조회기간 행과 이름을 맞춰 좌우로 붙인다. 比較期間の集計。画面が照会期間の行と名前を合わせて左右に付ける。 */
	private List<SaleStatusSummaryDTO> compareSummaries;
	/** 조건에 맞는 전체 건수. 목록은 1,000건에서 잘릴 수 있다. 条件に合う全件数。一覧は1,000件で切れることがある。 */
	private int totalCount;
	/** 1,000건을 넘으면 true. 합계는 잘린 목록이 아니라 전 건이다. 1,000件を超えると true。合計は切った一覧ではなく全件である。 */
	private boolean truncated;
	private BigDecimal quantity;
	private BigDecimal supplyAmount;
	private BigDecimal vatAmount;
	private BigDecimal totalAmount;
	/** 비교기간 수량 합계. 사용안함이면 null. 比較期間数量の合計。使用しないなら null。 */
	private BigDecimal compareQuantity;
	private BigDecimal compareSupplyAmount;
	private BigDecimal compareVatAmount;
	private BigDecimal compareTotalAmount;
}
