package org.sales.sale.service;

import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.sales.sale.dao.SaleStatusDao;
import org.sales.sale.dto.SaleStatusLineDTO;
import org.sales.sale.dto.SaleStatusQtyDTO;
import org.sales.sale.dto.SaleStatusResultDTO;
import org.sales.sale.dto.SaleStatusSearchDTO;
import org.sales.sale.dto.SaleStatusSummaryDTO;
import org.sales.sale.dto.SaleStatusTotalDTO;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
@AllArgsConstructor
/**
 * 판매현황 조회. 비교기간 수량은 같은 조건으로 다시 읽어 붙이고, 차이는 화면에 맡긴다.
 * 販売状況の照会。比較期間数量は同じ条件で読み直して付け、差は画面に任せる。
 */
public class SaleStatusServiceImpl implements SaleStatusService {

	private static final Set<String> COMPARES = new HashSet<String>(
			Arrays.asList("NONE", "PREV_YEAR", "PREV_MONTH", "PREV_WEEK", "PREV_DAY"));
	private static final Set<String> VIEWS = new HashSet<String>(
			Arrays.asList("DAY", "MONTH", "ITEM", "PARTNER", "MANAGER"));
	private static final Set<String> CURRENCIES = new HashSet<String>(Arrays.asList("ALL", "DOMESTIC", "FOREIGN"));
	private static final Set<String> INPUTS = new HashSet<String>(Arrays.asList("ALL", "NORMAL", "RETURN"));
	private static final Set<String> SORTS = new HashSet<String>(
			Arrays.asList("DATE", "PARTNER", "ITEM", "QTY", "SUPPLY", "TOTAL"));
	private static final Set<String> GROUPS = new HashSet<String>(Arrays.asList("PARTNER", "ITEM", "WAREHOUSE",
			"SALE_DATE", "MONTH", "YEAR", "TRANSACTION", "CURRENCY", "INPUT_TYPE", "MANAGER"));

	private SaleStatusDao mapper;

	/** 현황은 품목 줄을 그대로 돌려준다. 구분이 월별이어도 SQL은 줄을 합치지 않고, 화면이 월 계만 남긴다.
	 *  現状は品目行をそのまま返す。区分が月別でも SQL は行を合算せず、画面が月計だけ残す。 */
	@Override
	@Transactional(readOnly = true)
	public SaleStatusResultDTO searchLines(SaleStatusSearchDTO search) {
		log.info("searchLines......" + search);
		prepare(search);
		if (!VIEWS.contains(search.getViewMode())) {
			throw new IllegalArgumentException("区分が正しくありません。"); // 구분이 올바르지 않습니다.
		}
		int count = mapper.countLines(search);
		List<SaleStatusLineDTO> lines = count == 0 ? new ArrayList<SaleStatusLineDTO>() : mapper.selectLines(search);
		SaleStatusTotalDTO totals = mapper.selectTotals(search);
		BigDecimal compareQuantity = attachLineCompare(search, lines);
		SaleStatusResultDTO result = result(null, lines, count, totals, compareQuantity);
		attachCompareLines(search, result);
		return result;
	}

	/** 집계조건이 없으면 여기서 끊는다. 비교기간은 같은 묶음으로 기간만 옮겨 한 번 더 읽는다.
	 *  集計条件がなければここで止める。比較期間は同じ束で期間だけ移してもう一度読む。 */
	@Override
	@Transactional(readOnly = true)
	public SaleStatusResultDTO searchSummary(SaleStatusSearchDTO search) {
		log.info("searchSummary......" + search);
		prepare(search);
		normalizeGroups(search);
		if (search.getGroup1() == null) {
			throw new IllegalArgumentException("集計条件を選択してください。"); // 집계조건을 선택하세요.
		}
		SaleStatusResultDTO result = loadGrouped(search);
		attachCompareSummary(search, result);
		return result;
	}

	/** 비교기간의 품목 줄 전체. 비교 조회가 다시 비교를 타지 않도록 compare는 NONE으로 둔다.
	 *  比較期間の品目行全体。比較照会が再び比較へ入らないよう compare は NONE にする。 */
	private void attachCompareLines(SaleStatusSearchDTO search, SaleStatusResultDTO result) {
		if ("NONE".equals(search.getCompare())) {
			return;
		}
		SaleStatusSearchDTO compareSearch = shifted(search);
		compareSearch.setCompare("NONE");
		int count = mapper.countLines(compareSearch);
		List<SaleStatusLineDTO> lines = count == 0 ? new ArrayList<SaleStatusLineDTO>() : mapper.selectLines(compareSearch);
		SaleStatusTotalDTO totals = mapper.selectTotals(compareSearch);
		result.setCompareLines(lines);
		result.setCompareSupplyAmount(totals.getSupplyAmount());
		result.setCompareVatAmount(totals.getVatAmount());
		result.setCompareTotalAmount(totals.getTotalAmount());
	}

	/** 비교기간의 집계 줄과 금액 합계. 화면이 거래처명 같은 표시 이름으로 좌우 행을 맞춘다.
	 *  比較期間の集計行と金額合計。画面が取引先名のような表示名で左右の行を合わせる。 */
	private void attachCompareSummary(SaleStatusSearchDTO search, SaleStatusResultDTO result) {
		if ("NONE".equals(search.getCompare())) {
			return;
		}
		SaleStatusSearchDTO compareSearch = shifted(search);
		compareSearch.setCompare("NONE");
		SaleStatusResultDTO compared = loadGrouped(compareSearch);
		result.setCompareSummaries(compared.getSummaries());
		result.setCompareQuantity(compared.getQuantity());
		result.setCompareSupplyAmount(compared.getSupplyAmount());
		result.setCompareVatAmount(compared.getVatAmount());
		result.setCompareTotalAmount(compared.getTotalAmount());
	}

	/** 집계조건으로 합친 결과. 판매 전표 한 건씩은 넣지 않고, 계 행도 만들지 않는다.
	 *  集計条件で合算した結果。販売伝票1件ずつは入れず、計行も作らない。 */
	private SaleStatusResultDTO loadGrouped(SaleStatusSearchDTO search) {
		int count = search.getGroup1() == null ? 1 : mapper.countSummaryGroups(search);
		List<SaleStatusSummaryDTO> summaries = mapper.selectSummary(search);
		if (search.getGroup1() == null && summaries.isEmpty()) {
			count = 0;
		}
		SaleStatusTotalDTO totals = mapper.selectTotals(search);
		BigDecimal compareQuantity = attachSummaryCompare(search, summaries);
		return result(summaries, null, count, totals, compareQuantity);
	}

	private SaleStatusResultDTO result(List<SaleStatusSummaryDTO> summaries, List<SaleStatusLineDTO> lines, int count,
			SaleStatusTotalDTO totals, BigDecimal compareQuantity) {
		SaleStatusResultDTO result = new SaleStatusResultDTO();
		result.setSummaries(summaries);
		result.setLines(lines);
		result.setTotalCount(count);
		result.setTruncated(count > MAX_ROWS);
		result.setQuantity(totals.getQuantity());
		result.setSupplyAmount(totals.getSupplyAmount());
		result.setVatAmount(totals.getVatAmount());
		result.setTotalAmount(totals.getTotalAmount());
		result.setCompareQuantity(compareQuantity);
		return result;
	}

	/** 줄마다 비교수량을 붙인다. 키는 품목, 거래처, 창고다. 판매 수량은 바꾸지 않는다.
	 *  行ごとに比較数量を付ける。キーは品目、取引先、倉庫である。販売数量は変えない。 */
	private BigDecimal attachLineCompare(SaleStatusSearchDTO search, List<SaleStatusLineDTO> lines) {
		if ("NONE".equals(search.getCompare())) {
			return null;
		}
		SaleStatusSearchDTO compareSearch = shifted(search);
		BigDecimal total = mapper.selectQuantity(compareSearch);
		Map<String, BigDecimal> quantities = new HashMap<String, BigDecimal>();
		for (SaleStatusQtyDTO bucket : mapper.selectLineCompare(compareSearch)) {
			quantities.put(bucket.getItemId() + "|" + bucket.getPartnerId() + "|" + bucket.getWarehouseId(),
					nvl(bucket.getQuantity()));
		}
		for (SaleStatusLineDTO line : lines) {
			String key = line.getItemId() + "|" + line.getPartnerId() + "|" + line.getWarehouseId();
			line.setCompareQuantity(quantities.containsKey(key) ? quantities.get(key) : BigDecimal.ZERO);
		}
		return total;
	}

	/** 집계 줄의 비교수량. 일별, 월별, 연별 키는 비교기간 날짜를 기준기간 쪽으로 옮겨 같은 칸에 맞춘다.
	 *  集計行の比較数量。日別、月別、年別のキーは比較期間の日付を基準期間側へ移して同じ枠に合わせる。 */
	private BigDecimal attachSummaryCompare(SaleStatusSearchDTO search, List<SaleStatusSummaryDTO> summaries) {
		if ("NONE".equals(search.getCompare())) {
			return null;
		}
		SaleStatusSearchDTO compareSearch = shifted(search);
		BigDecimal total = mapper.selectQuantity(compareSearch);
		Map<String, BigDecimal> quantities = new HashMap<String, BigDecimal>();
		for (SaleStatusQtyDTO bucket : mapper.selectSummaryCompare(compareSearch)) {
			quantities.put(alignKey(bucket.getGroupKey(), search), nvl(bucket.getQuantity()));
		}
		for (SaleStatusSummaryDTO row : summaries) {
			row.setCompareQuantity(
					quantities.containsKey(row.getGroupKey()) ? quantities.get(row.getGroupKey()) : BigDecimal.ZERO);
		}
		return total;
	}

	/** 일별·월별 비교수량은 비교기간의 같은 위치를 기준기간 키로 맞춘다. 日別・月別の比較数量は比較期間の同じ位置を基準期間のキーに合わせる。 */
	private String alignKey(String groupKey, SaleStatusSearchDTO search) {
		if (groupKey == null) {
			return "";
		}
		String[] parts = groupKey.split("\\|", -1);
		List<String> groups = search.getGroups() == null ? new ArrayList<String>() : search.getGroups();
		StringBuilder aligned = new StringBuilder();
		for (int i = 0; i < parts.length; i++) {
			if (i > 0) {
				aligned.append('|');
			}
			String group = i < groups.size() ? groups.get(i) : null;
			aligned.append(moveLabel(parts[i], group, search.getCompare()));
		}
		return aligned.toString();
	}

	/** 비교기간에서 읽은 날짜 이름을 기준기간 이름으로 되돌린다. 거래처명처럼 날짜가 아닌 이름은 그대로 둔다.
	 *  比較期間で読んだ日付名を基準期間の名前へ戻す。取引先名のように日付でない名前はそのままにする。 */
	private String moveLabel(String label, String group, String compare) {
		if (label == null || "-".equals(label) || group == null) {
			return label;
		}
		try {
			if ("SALE_DATE".equals(group)) {
				return move(LocalDate.parse(label), compare).toString();
			}
			if ("MONTH".equals(group)) {
				return move(LocalDate.parse(label + "-01"), compare).toString().substring(0, 7);
			}
			if ("YEAR".equals(group)) {
				return String.valueOf(move(LocalDate.parse(label + "-01-01"), compare).getYear());
			}
		} catch (RuntimeException e) {
			return label;
		}
		return label;
	}

	private LocalDate move(LocalDate day, String compare) {
		if ("PREV_YEAR".equals(compare)) {
			return day.plusYears(1);
		}
		if ("PREV_MONTH".equals(compare)) {
			return day.plusMonths(1);
		}
		if ("PREV_WEEK".equals(compare)) {
			return day.plusWeeks(1);
		}
		return day.plusDays(1);
	}

	/** 비교 조회용 조건. 시작일과 종료일만 옮기고 거래처, 창고, 집계조건은 그대로 복사한다.
	 *  比較照会用の条件。開始日と終了日だけ移し、取引先、倉庫、集計条件はそのまま写す。 */
	private SaleStatusSearchDTO shifted(SaleStatusSearchDTO search) {
		SaleStatusSearchDTO copy = new SaleStatusSearchDTO();
		copy.setFromDate(shift(search.getFromDate(), search.getCompare()));
		copy.setToDate(shift(search.getToDate(), search.getCompare()));
		copy.setTransactionType(search.getTransactionType());
		copy.setCurrencyScope(search.getCurrencyScope());
		copy.setWarehouseId(search.getWarehouseId());
		copy.setPartnerId(search.getPartnerId());
		copy.setItemId(search.getItemId());
		copy.setInputScope(search.getInputScope());
		copy.setGroup1(search.getGroup1());
		copy.setGroup2(search.getGroup2());
		copy.setGroup3(search.getGroup3());
		copy.setGroup4(search.getGroup4());
		copy.setGroup5(search.getGroup5());
		copy.setGroup6(search.getGroup6());
		copy.setGroup7(search.getGroup7());
		copy.setGroups(search.getGroups());
		copy.setLimit(search.getLimit());
		return copy;
	}

	private Date shift(java.util.Date date, String compare) {
		LocalDate day = toLocal(date);
		if ("PREV_YEAR".equals(compare)) {
			day = day.minusYears(1);
		} else if ("PREV_MONTH".equals(compare)) {
			day = day.minusMonths(1);
		} else if ("PREV_WEEK".equals(compare)) {
			day = day.minusWeeks(1);
		} else {
			day = day.minusDays(1);
		}
		return Date.valueOf(day);
	}

	/** 빈 값은 화면 기본값으로 채운 뒤 허용 목록에 있는지 본다. 구분만 비어 있으면 일별이 된다.
	 *  空の値は画面の初期値で埋めたあと、許す一覧にあるか見る。区分だけ空なら日別になる。 */
	private void prepare(SaleStatusSearchDTO search) {
		if (search == null || search.getFromDate() == null || search.getToDate() == null) {
			throw new IllegalArgumentException("基準日付を入力してください。"); // 기준일자를 입력하세요.
		}
		if (toLocal(search.getFromDate()).isAfter(toLocal(search.getToDate()))) {
			throw new IllegalArgumentException("開始日が終了日より後です。"); // 시작일이 종료일보다 뒤입니다.
		}
		search.setViewMode(code(search.getViewMode(), "DAY"));
		search.setCompare(code(search.getCompare(), "NONE"));
		search.setCurrencyScope(code(search.getCurrencyScope(), "ALL"));
		search.setInputScope(code(search.getInputScope(), "ALL"));
		search.setSortKey(code(search.getSortKey(), "DATE"));
		search.setTransactionType(blankToNull(search.getTransactionType()));
		search.setGroup1(upperBlank(search.getGroup1()));
		search.setGroup2(upperBlank(search.getGroup2()));
		search.setGroup3(upperBlank(search.getGroup3()));
		search.setGroup4(upperBlank(search.getGroup4()));
		search.setGroup5(upperBlank(search.getGroup5()));
		search.setGroup6(upperBlank(search.getGroup6()));
		search.setGroup7(upperBlank(search.getGroup7()));
		if (!COMPARES.contains(search.getCompare())) {
			throw new IllegalArgumentException("比較期間が正しくありません。"); // 비교기간이 올바르지 않습니다.
		}
		if (!CURRENCIES.contains(search.getCurrencyScope())) {
			throw new IllegalArgumentException("通貨区分が正しくありません。"); // 통화 구분이 올바르지 않습니다.
		}
		if (!INPUTS.contains(search.getInputScope())) {
			throw new IllegalArgumentException("取引区分が正しくありません。"); // 거래구분이 올바르지 않습니다.
		}
		if (!SORTS.contains(search.getSortKey())) {
			throw new IllegalArgumentException("並べ替えが正しくありません。"); // 정렬이 올바르지 않습니다.
		}
		for (String group : new String[] { search.getGroup1(), search.getGroup2(), search.getGroup3(), search.getGroup4(),
				search.getGroup5(), search.getGroup6(), search.getGroup7() }) {
			if (group != null && !GROUPS.contains(group)) {
				throw new IllegalArgumentException("集計条件が正しくありません。"); // 집계조건이 올바르지 않습니다.
			}
		}
		search.setLimit(MAX_ROWS);
	}

	/** 중간에 빈 칸이 있거나 같은 조건이 두 번이면 앞쪽부터 한 번씩만 다시 심는다.
	 *  途中に空枠があるか、同じ条件が二度なら前から一度ずつ植え直す。 */
	private void normalizeGroups(SaleStatusSearchDTO search) {
		String[] raw = { search.getGroup1(), search.getGroup2(), search.getGroup3(), search.getGroup4(),
				search.getGroup5(), search.getGroup6(), search.getGroup7() };
		List<String> ordered = new ArrayList<String>();
		for (String value : raw) {
			if (value != null && !ordered.contains(value)) {
				ordered.add(value);
			}
		}
		search.setGroups(ordered);
		search.setGroup1(groupAt(ordered, 0));
		search.setGroup2(groupAt(ordered, 1));
		search.setGroup3(groupAt(ordered, 2));
		search.setGroup4(groupAt(ordered, 3));
		search.setGroup5(groupAt(ordered, 4));
		search.setGroup6(groupAt(ordered, 5));
		search.setGroup7(groupAt(ordered, 6));
	}

	private String groupAt(List<String> groups, int index) {
		return index < groups.size() ? groups.get(index) : null;
	}

	private String code(String value, String fallback) {
		String text = blankToNull(value);
		return text == null ? fallback : text.trim().toUpperCase();
	}

	private String upperBlank(String value) {
		String text = blankToNull(value);
		return text == null ? null : text.toUpperCase();
	}

	private String blankToNull(String value) {
		if (value == null) {
			return null;
		}
		String text = value.trim();
		return text.isEmpty() ? null : text;
	}

	private LocalDate toLocal(java.util.Date date) {
		if (date instanceof Date) {
			return ((Date) date).toLocalDate();
		}
		return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
	}

	private BigDecimal nvl(BigDecimal value) {
		return value == null ? BigDecimal.ZERO : value;
	}
}
