package org.sales.sale.dto;

import java.math.BigDecimal;

import lombok.Data;

/**
 * 비교기간 수량 묶음. 현황은 품목·거래처·창고, 집계는 집계 키로 맞춘다.
 * 比較期間数量の束。現状は品目・取引先・倉庫、集計は集計キーで合わせる。
 */
@Data
public class SaleStatusQtyDTO {

	private Long itemId;
	private Long partnerId;
	private Long warehouseId;
	private String groupKey;
	private BigDecimal quantity;
}
