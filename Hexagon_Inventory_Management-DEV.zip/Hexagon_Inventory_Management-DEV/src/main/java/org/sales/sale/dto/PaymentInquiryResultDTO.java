package org.sales.sale.dto;

import java.util.List;

import lombok.Data;

/**
 * 결제내역 목록. 1,000건을 넘으면 결제일시가 최근인 1,000건만 담는다.
 * 決済履歴一覧。1,000件を超えると決済日時が新しい1,000件だけ入れる。
 */
@Data
public class PaymentInquiryResultDTO {

	private List<PaymentInquiryRowDTO> rows;
	private int totalCount;
	private boolean truncated;
}
