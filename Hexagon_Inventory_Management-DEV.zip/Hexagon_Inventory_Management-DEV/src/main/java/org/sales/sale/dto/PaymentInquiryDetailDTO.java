package org.sales.sale.dto;

import java.math.BigDecimal;

import lombok.Data;

/**
 * 결제 한 건. 내역 보기와 등록 직후 응답이 이 값을 쓴다.
 * 決済1件。内訳表示と登録直後の応答がこの値を使う。
 */
@Data
public class PaymentInquiryDetailDTO {

	private Long paymentId;
	private Long saleId;
	private String voucherNo;
	private String requestedAt;
	private Long requesterId;
	private String requesterName;
	private Long businessPartnerId;
	private String partnerName;
	private Long warehouseId;
	private String itemName;
	private String companyCode;
	private String vanCode;
	private String paymentMethod;
	private Integer installmentMonths;
	private String receiptType;
	private String easyPaymentNo;
	private String receiptPrintYn;
	private BigDecimal supplyAmount;
	private BigDecimal vatRate;
	private BigDecimal vatAmount;
	private BigDecimal paymentAmount;
	private String paymentStatus;
	private String approvalNumber;
	private String failureReason;
	private String inventoryVoucherNo;
	private String accountingVoucherNo;
	private String forcedYn;
	private String cancelledAt;
}
