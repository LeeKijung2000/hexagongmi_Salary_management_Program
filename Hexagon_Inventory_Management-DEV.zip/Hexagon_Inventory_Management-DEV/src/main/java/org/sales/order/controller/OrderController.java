package org.sales.order.controller;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.sales.order.domain.OrderAggResultDTO;
import org.sales.order.domain.OrderAttachVO;
import org.sales.order.domain.OrderRegisterDTO;
import org.sales.order.domain.PageDTO;
import org.sales.order.service.OrderService;
import org.sales.sale.service.CommonLookupService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.zerock.domain.Criteria;
import org.zerock.service.BusinessPartnerService;
import org.zerock.service.ItemService;
import org.zerock.service.WarehouseService;

import lombok.AllArgsConstructor;

@Controller
@RequestMapping("sales/order/*")
@AllArgsConstructor
public class OrderController {

	// 주문서 관리 서비스
	// 受注書管理サービス
	private OrderService orderService;

	private BusinessPartnerService businessPartnerService; // 거래처 관리 서비스 取引先管理サービス
	private WarehouseService warehouseService; // 창고 관리 서비스 倉庫管理サービス
	private ItemService itemService; // 품목 관리 서비스 品目管理サービス

	// 주문서 입력(GET)
	// 受注書入力（GET）
	@GetMapping("/input")
	public void register(Model model) {
		// 1. 모델에 오늘 날짜를 저장
		// 1. モデルに今日の日付を保存
		model.addAttribute("now", LocalDate.now());

		// 2. 모델에 거래처, 창고, 담당자, 통화 정보를 저장
		// 2. モデルに取引先、倉庫、担当者、通貨情報を保存
		model.addAttribute("partners", businessPartnerService.getAllList());
		model.addAttribute("warehouses", warehouseService.getAllList());
		model.addAttribute("managers", businessPartnerService.getManagerList(null));
		model.addAttribute("currencies", businessPartnerService.getCurrencyList());
	}

	// 주문서 입력(POST)
	// 受注書入力(POST)
	@PostMapping("/input")
	public String regitser(OrderRegisterDTO dto) {
		// 1. 주문서를 DB에 입력
		// 1. 受注書をDBに入力
		orderService.register(dto);

		// 2. 주문서 조회 페이지로 리다이렉트
		// 2. 受注書照会ページへリダイレクト
		return "redirect:/sales/order/inquiry";
	}

	// 주문서 조회
	// 受注書照会
	@GetMapping("/inquiry")
	public void list(@RequestParam Map<String, Object> paramMap, Model model) {

		// 1. 파라미터를 분석하여 Map에 입력
		// 1. パラメータ分析してMapに入力

		// 페이지 넘버와 한 페이지 당 표시건수
		// ページナンバーと1ページあたりの表示件数
		String pageNum = (String) paramMap.get("pageNum");

		// 페이지에 처음 진입했을 때는 페이지 넘버를 1로 설정
		// ページに初めて進入した時はページナンバーを１に設定
		if (pageNum == null || "".equals(pageNum)) {
			paramMap.put("pageNum", 1D);
		}
		paramMap.put("pageNum", Double.parseDouble(paramMap.get("pageNum") + ""));
		paramMap.put("amount", 10D);

		// 기준일자
		// 基準日付
		String startDate = (String) paramMap.get("startDate");
		String endDate = (String) paramMap.get("endDate");

		// 페이지에 처음 진입했을 때는 2000-01-01~2030-12-31로 설정
		// ページに初めて進入した時は 2000-01-01~2030-12-31に設定
		if (startDate == null || "".equals(startDate)) {
			startDate = "2000-01-01";
		}
		if (endDate == null || "".equals(endDate)) {
			endDate = "2030-12-31";
		}
		paramMap.put("startDate", startDate);
		paramMap.put("endDate", endDate);

		// 내외자구분, 거래유형, 삭제구분
		// 内外資区分、取引類型、削除区分
		// 페이지에 처음 진입했을 떄는 '전체'로 설정
		// ページに初めて進入した時は「全体」に設定
		if (paramMap.get("currencyType") == null) {
			paramMap.put("currencyType", "");
		}
		if (paramMap.get("transactionType") == null) {
			paramMap.put("transactionType", "");
		}
		if (paramMap.get("deletedYn") == null) {
			paramMap.put("deletedYn", "N");
		}

		// 모델에 파라미터 정보를 저장
		// モデルにパラメータの情報を保存
		model.addAttribute("paramMap", paramMap);

		// 모델에 거래처, 창고, 담당자, 통화 정보를 저장
		// モデルに取引先、倉庫、担当者、通貨情報を保存
		model.addAttribute("partners", businessPartnerService.getAllList());
		model.addAttribute("warehouses", warehouseService.getAllList());
		model.addAttribute("managers", businessPartnerService.getManagerList(null));

		// 2. 파라미터 기반으로 주문서 리스트 및 게시물 수 조회하고, 모델에 저장
		// 2. パラメータをもとに受注書リストとリストの数を照会しモデルに保存
		int total = orderService.getTotalCount(paramMap);
		model.addAttribute("pageMaker", new PageDTO(paramMap, total));
		model.addAttribute("orders", orderService.getListWithPaging(paramMap));
	}

	// 주문서 첨부파일 목록
	// 受注書添付ファイル目録
	@GetMapping(value = "/getAttachList", produces = "application/json; charset=UTF-8")
	@ResponseBody
	public ResponseEntity<List<OrderAttachVO>> getAttachList(@RequestParam("orderId") Long orderId) {
		return new ResponseEntity<>(orderService.getAttachList(orderId), HttpStatus.OK);
	}

	// 주문서현황
	// 受注書一覧
	@GetMapping("/status")
	public void status(@RequestParam Map<String, Object> paramMap,
			@RequestParam(value = "types", required = false) List<String> types, Model model) {
		// 1. 파라미터를 분석하여 Map에 입력
		// 1. パラメータ分析してMapに入力

		// 기준일자는 이번달 1일~오늘 날짜로 설정
		// 基準日付は今月一日～今日の日付に設定
		paramMap.putIfAbsent("startDate", LocalDate.now().withDayOfMonth(1).toString());
		paramMap.putIfAbsent("endDate", LocalDate.now());

		// 구분은 '라인별'을 기본으로 설정
		// 区分は「ライン別」をデフォルトに設定
		paramMap.putIfAbsent("type", "line");

		// 내외자구분, 거래유형, 진행상태는 '전체'를 기본으로 설정
		// 内外資区分、取引類型、進行状態は「全体」を基本に設定
		paramMap.putIfAbsent("currencyType", "");
		paramMap.putIfAbsent("transactionType", "");
		paramMap.putIfAbsent("progressStatus", "");

		// 2. 모델에 파라미터 저장
		// 2. モデルにパラメータを保存
		model.addAttribute("paramMap", paramMap);

		// 모델에 거래처, 창고, 담당자, 통화 정보를 저장
		// モデルに取引先、倉庫、担当者、通貨情報を保存
		model.addAttribute("partners", businessPartnerService.getAllList());
		model.addAttribute("warehouses", warehouseService.getAllList());
		model.addAttribute("managers", businessPartnerService.getManagerList(null));
		model.addAttribute("currencies", businessPartnerService.getCurrencyList());
		// 3. 처음 진입이 아닐 때에는 주문서현황을 조회 후, 모델에 저장
		// 3. 初めての進入ではない時は、受注書一覧を照会し、モデルに保存
		if ("agg".equals(paramMap.get("menu"))) {
			// 집계
			OrderAggResultDTO agg = orderService.getAggList(types, paramMap);
			model.addAttribute("aggList", agg.getList());
			model.addAttribute("n", agg.getN());
			model.addAttribute("types", agg.getTypes());
		} else {
			// 현황
			model.addAttribute("list", orderService.getOrderStatus(paramMap));
		}
	}

	// 주문서 출고 처리
	@GetMapping("/release-proc")
	public void release(@RequestParam Map<String, Object> paramMap, Model model) {

		paramMap.putIfAbsent("type", "미처리");
		String type = (String) paramMap.get("type");

		LocalDate today = LocalDate.now();
		if ("처리".equals(type)) {

			paramMap.putIfAbsent("releaseStartDate", today.minusMonths(1).toString());
			paramMap.putIfAbsent("releaseEndDate", today.toString());
			model.addAttribute("list", orderService.getReleaseDoneList(paramMap));

		} else {

			paramMap.putIfAbsent("startDate", today.minusMonths(1).toString());
			paramMap.putIfAbsent("endDate", today.toString());
			paramMap.putIfAbsent("progressStatus", "");
			paramMap.putIfAbsent("currencyType", "");
			paramMap.putIfAbsent("type", "미처리");

			model.addAttribute("list", orderService.getReleaseWaitList(paramMap));
		}
		model.addAttribute("paramMap", paramMap);

		// 모델에 거래처, 창고, 담당자, 통화 정보를 저장
		// モデルに取引先、倉庫、担当者、通貨情報を保存
		model.addAttribute("partners", businessPartnerService.getAllList());
		model.addAttribute("warehouses", warehouseService.getAllList());
		model.addAttribute("managers", businessPartnerService.getManagerList(null));
	}

	// 주문서 출고처리(POST)
	// 受注書出庫処理(POST)
	@PostMapping("/release-proc")
	public String release(@RequestParam(value = "orderItemId", required = false) List<Long> ids,
			@RequestParam Map<String, String> params, RedirectAttributes rttr) {

		if (ids == null || ids.isEmpty()) {
			rttr.addFlashAttribute("msg", "出庫する項目を選択してください.");
			return "redirect:release-proc";
		}

		Map<Long, Double> qtyMap = new LinkedHashMap<>();
		for (Long id : ids) {
			String v = params.get("qty_" + id);
			qtyMap.put(id, (v == null || v.isEmpty()) ? null : Double.valueOf(v));
		}

		try {
			orderService.release(qtyMap, LocalDate.now());
			rttr.addFlashAttribute("msg", "出庫処理されました");
		} catch (IllegalArgumentException | IllegalStateException e) {
			rttr.addFlashAttribute("msg", e.getMessage());
		}
		return "redirect:release-proc";

	}

	// 주문서 수정(GET)
	// 受注書修正(GET)
	@GetMapping("/modify")
	public String modify(@RequestParam("orderId") Long orderId,
			@RequestParam(value = "returnUrl", required = false) String returnUrl, Model model) {

		// 1. 주문서 코드를 기반으로 주문서 상세 DTO 생성
		// 1. 受注書コードをもとに受注書詳細DTO生成
		OrderRegisterDTO dto = orderService.getOrder(orderId);

		// 2. 조회된 주문서가 없으면 이전 페이지로 리다이렉트
		// 2. 照会された受注書がなければ、前のページへリダイレクト
		if (dto == null) {
			return "redirect:" + returnUrl;
		}

		// 3. 모델에 주문서, 주문서 품목, 이전 페이지 URL을 저장
		// 3. モデルに受注書、受注書品目、前のページのURLを保存
		model.addAttribute("order", dto.getOrder());// 주문서 受注書
		model.addAttribute("items", dto.getItems());// 주문서 품목 受注書品目
		model.addAttribute("returnUrl", returnUrl);// 이전 페이지 URL 前のページのURL

		// 4. 모델에 거래처, 창고, 담당자, 통화 정보를 저장
		// 4. モデルに取引先、倉庫、担当者、通貨情報を保存
		model.addAttribute("partners", businessPartnerService.getAllList());
		model.addAttribute("warehouses", warehouseService.getAllList());
		model.addAttribute("managers", businessPartnerService.getManagerList(null));
		model.addAttribute("currencies", businessPartnerService.getCurrencyList());

		// 5. 주문서 수정 페이지를 반환
		// 5. 受注書修正ページを返す
		return "sales/order/modify";
	}

	// 주문서 수정(POST)
	// 受注書修正(POST)
	@PostMapping("/modify")
	public String modify(OrderRegisterDTO dto, @RequestParam(value = "returnUrl", required = false) String returnUrl,
			RedirectAttributes rttr) {
		// 1. 입력된 주문서 상세 DTO를 기반으로 수정 작업 진행
		// 1. 入力された受注書詳細DTOをもとに修正作業進行
		try {
			orderService.modify(dto);
			rttr.addFlashAttribute("msg", "修正されました。");
		}
		// 에러 발생 시 에러 메시지 저장
		// エラーが発生した時はエラーメッセージを保存
		catch (IllegalStateException e) {
			rttr.addFlashAttribute("msg", e.getMessage());
		}

		// 2. 작업 완료 후, 이전 페이지로 리다이렉트
		// 2. 作業が終わった後、前のページへリダイレクト
		if (returnUrl != null && returnUrl.startsWith("/") && !returnUrl.startsWith("//")) {
			return "redirect:" + returnUrl;
		}

		return "redirect:/sales/order/inquiry";
	}

	// 미판매현황
	// 未販売一覧
	@GetMapping("/unsold")
	public void unsoldList(@RequestParam Map<String, Object> paramMap, Model model) {
		// 1. 파라미터를 분석하여 Map에 입력
		// 1. パラメータ分析してMapに入力

		// 페이지에 처음 진입했을 때는 구분, 통화, 거래유형, 진행상태를 전체로 설정하고, 기준일자를 오늘 날짜로 설정
		// ページに初めて進入した時は、区分、通貨、取引類型、進行状態を全体に設定し、基準日付を今日の日付に設定
		// 기준일자
		// 基準日付
		if (paramMap.get("endDate") == null) {
			paramMap.put("endDate", LocalDate.now().toString());
		}
		// 구분
		// 区分
		if (paramMap.get("type") == null) {
			paramMap.put("type", 0);
		}
		// 통화
		// 通貨
		if (paramMap.get("currencyType") == null) {
			paramMap.put("currencyType", "");
		}
		// 거래유형
		// 取引類型
		if (paramMap.get("transactionType") == null) {
			paramMap.put("transactionType", "");
		}
		// 진행상태
		// 進行状態
		if (paramMap.get("progressStatus") == null) {
			paramMap.put("progressStatus", "");
		}
		// 2. 모델에 파라미터 저장
		// 2. モデルにパラメータを保存
		model.addAttribute("paramMap", paramMap);

		// 모델에 거래처, 창고, 담당자, 통화 정보를 저장
		// モデルに取引先、倉庫、担当者、通貨情報を保存
		model.addAttribute("partners", businessPartnerService.getAllList());
		model.addAttribute("warehouses", warehouseService.getAllList());
		model.addAttribute("managers", businessPartnerService.getManagerList(null));

		// 3. 처음 진입이 아닐 때에는 '구분'을 확인하고, 이를 토대로 미판매현황을 조회 후, 모델에 저장
		// 3. 初めての進入ではない時は「区分」を確認し、これをもとに未販売一覧を照会し、モデルに保存
		if ("Y".equals(paramMap.get("searched"))) {
			model.addAttribute("list", orderService.getUnsoldList(paramMap));
		}
	}

	// 주문서 삭제
	// 受注書削除
	@PostMapping("/remove")
	public String remove(@RequestParam(value = "orderId", required = false) List<Long> ids,
			@RequestParam(value = "returnUrl", required = false) String returnUrl, RedirectAttributes rttr) {

		// 주문서가 선택되지 않은 경우
		// 受注書が選択されていない場合
		if (ids == null || ids.isEmpty()) {
			rttr.addFlashAttribute("msg", "削除する受注書を選択してください");
		} else {
			// 주문서 삭ㅈ
			// 受注書削除
			try {
				orderService.removeAll(ids);
				rttr.addFlashAttribute("msg", ids.size() + "件削除されました");
			} catch (IllegalStateException e) {
				rttr.addFlashAttribute("msg", e.getMessage());
			}
		}

		// 이전 페이지로 리다이렉트
		// 前のページへリダイレクト
		if (returnUrl != null && returnUrl.startsWith("/") && !returnUrl.startsWith("//")) {
			return "redirect:" + returnUrl;
		}
		return "redirect:inquiry";
	}

	// 진행상태 변경
	// 進行状態変更
	@PostMapping(value = "/progress", produces = "test/plain; charset=UTF-8")
	@ResponseBody
	public ResponseEntity<String> changeProgress(@RequestParam("orderId") List<Long> orderIds,
			@RequestParam("newStatus") String newStatus) {
		try {
			orderService.changeStatus(orderIds, newStatus);
			return ResponseEntity.ok("OK");
		} catch (IllegalArgumentException | IllegalStateException e) {
			return ResponseEntity.status(HttpStatus.CONFLICT).body(e.getMessage());
		}
	}

	// 주문서 이력 조회
	// 受注書履歴照会
	@GetMapping("/history")
	public void history(Model model) {
		model.addAttribute("histories", orderService.getHistoryList());
	}

	////////////////////////////////////////////////// 임시
	// 견적서 목록 (모달)
	@GetMapping(value = "/quote-list", produces = "application/json; charset=UTF-8")
	@ResponseBody
	public List<Map<String, Object>> quoteList() {
		return orderService.getQuoteList();
	}

	// 선택한 견적서 불러오기: 헤더는 제일 위(첫 번째) 견적서, 품목은 전체
	@GetMapping(value = "/quote-load", produces = "application/json; charset=UTF-8")
	@ResponseBody
	public Map<String, Object> quoteLoad(@RequestParam("quoteId") List<Long> quoteIds,
			@RequestParam(value = "mode", defaultValue = "remain") String mode) {
		boolean remainOnly = "remain".equals(mode);
		Map<String, Object> res = new HashMap<>();
		res.put("header", orderService.getQuoteHeader(quoteIds.get(0)));
		res.put("items", orderService.getQuoteItems(quoteIds, remainOnly));
		return res;
	}

	// 품목 조회
	// 品目照会
	@GetMapping("/item-lookup")
	public void itemLookup(Criteria cri, Model model) {
		if (cri.getPageNum() < 1)
			cri.setPageNum(1);
		cri.setAmount(10);
		model.addAttribute("items", itemService.getList(cri));
		model.addAttribute("pager", new org.zerock.domain.PageDTO(cri, itemService.getTotal(cri)));
		model.addAttribute("keyword", cri.getKeyword());
	}

}
