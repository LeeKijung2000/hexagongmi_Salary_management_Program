package org.sales.order.domain;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import lombok.Data;

/*
 * 주문서현황 DTO(현황)
 * 受注書一覧DTO(一覧)
 */
@Data
public class OrderStatusDTO {

	private Long orderId;// 주문서ID 受注書ID
	private LocalDate orderDate;// 주문일자 受注日付
	private Long dayNo; // 일자번호 日付番号
	private String itemName;// 품목명 品目名
	private String spec; // 규격 規格
	private Double quantity;// 수량 数量
	private Long unitPrice; // 단가 単価
	private Long supplyAmount; // 공급가액 供給価格
	private Long vatAmount; // 부가세 付加税
	private String businessPartnerName;// 거래처명 取引先名
	private String remarks;// 적요 摘要

	// 주문일자를 'yyyy/MM/dd'형식으로 바꾸는 메서드
	// 受注日付を「yyyy/MM/dd」形式に変えるメソッド
	public String getOrderDateStr() {
		return orderDate == null ? "" : orderDate.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
	}

	// 주문월을 구하는 메서드
	// 受注月を取得するメソッド
	public String getOrderMonth() {
		return orderDate == null ? "" : orderDate.format(DateTimeFormatter.ofPattern("yyyy/MM"));
	}
}
