package org.sales.order.domain;

import java.time.LocalDate;
import java.time.LocalDateTime;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

/*
 * 주문서 헤더
 * 受注書ヘッダー
*/
@Data
public class OrderVO {
	private Long orderId; // 주문서ID 受注書ID
	
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate orderDate; // 주문일자 受注日付
	
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate dueDate; // 납기일자 納期日付
	
	private Long businessPartnerId; // 거래처ID 取引先ID
	private Long managerId; // 담당자ID 担当者ID
	private Long warehouseId;// 창고ID 倉庫ID
	private String transactionType;// 거래유형 取引類型
	private Long currencyId;// 통화ID 通貨ID
	private String progressStatus;// 진행상태 進行状態
	private String remarks;// 비고 備考
	private LocalDateTime createdAt; // 최초작성일자 作成日時
	private LocalDateTime updatedAt; // 최종수정일자 更新日時
	private String deletedYn; // 삭제여부 削除有無
}
