package org.sales.order.mapper;

import java.util.List;

import org.sales.order.domain.OrderAttachVO;

//주문서 첨부파일을 관리하는 매퍼
//受注書の添付ファイルを管理するマッパー
public interface OrderAttachMapper {
	
	public void insert(OrderAttachVO vo);
	
	public void delete(String uuid);

	public List<OrderAttachVO> findByOno(Long Ono);
	
	public List<OrderAttachVO> getOldFiles();
	
	public void deleteAll(Long bno);
}
