package org.sales.order.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.sales.order.domain.OrderAggResultDTO;
import org.sales.order.domain.OrderAttachVO;
import org.sales.order.domain.OrderHistoryDTO;
import org.sales.order.domain.OrderItemVO;
import org.sales.order.domain.OrderListDTO;
import org.sales.order.domain.OrderRegisterDTO;
import org.sales.order.domain.OrderReleaseVO;
import org.sales.order.domain.OrderStatusDTO;
import org.sales.order.domain.OrderVO;
import org.sales.order.domain.ReleaseDoneDTO;
import org.sales.order.domain.ReleaseWaitDTO;
import org.sales.order.domain.UnsoldDTO;
import org.sales.order.domain.VoucherHistoryVO;
import org.sales.order.mapper.OrderAttachMapper;
import org.sales.order.mapper.OrderItemMapper;
import org.sales.order.mapper.OrderMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.AllArgsConstructor;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

//주문서에 관한 CRUD 작업을 수행하는 서비스
//受注書に関するCRUD作業を修行するサービス
@Log4j
@Service
@AllArgsConstructor
@Transactional
public class OrderServiceImpl implements OrderService {

	// 주문서 매퍼
	// 受注書マッパー
	@Setter(onMethod_ = @Autowired)
	private OrderMapper orderMapper;

	// 주문서 품목 매퍼
	// 受注書品目マッパー
	@Setter(onMethod_ = @Autowired)
	private OrderItemMapper orderItemMapper;

	@Setter(onMethod_ = @Autowired)
	private OrderAttachMapper orderAttachMapper;

	// 주문서 조회(리스트)
	// 受注書照会（リスト）
	@Override
	public List<OrderListDTO> getListWithPaging(Map<String, Object> paramMap) {
		log.info("getList.....");
		List<OrderListDTO> orders = orderMapper.getListWithPaging(paramMap);
		return orders;
	}

	// 주문서 개수 조회
	// 受注書数照会
	@Override
	public int getTotalCount(Map<String, Object> paramMap) {
		log.info("getTotalCount.....");
		return orderMapper.getTotalCount(paramMap);
	}

	// 주문서 입력
	// 受注書入力
	@Override
	public void register(OrderRegisterDTO dto) {
		OrderVO order = dto.getOrder();
		List<OrderItemVO> items = dto.getItems();
		List<OrderAttachVO> attachs = dto.getAttachList();

		log.info("register....." + order);

		// 1. 입력된 주문서의 진행상태를 '진행중'으로 설정
		// 1. 入力された受注書の進行状態を「進行中」に設定
		if (order.getProgressStatus() == null || order.getProgressStatus().isEmpty()) {
			order.setProgressStatus("IN_PROGRESS");
		}

		// 2. 주문서 헤더 등록
		// 2. 受注書ヘッダー登録
		orderMapper.insert(order);

		// 2. 주문서 ID 확인
		// 2. 受注書ID確認
		Long orderId = order.getOrderId();

		// 3. 품목 등록 + 견적에서 불러온 행이면 견적 연결 기록
		// 3. 品目登録＋見積から持ってきた行なら見積連結を記録
		for (OrderItemVO item : items) {
			item.setOrderId(orderId);
			orderItemMapper.insert(item);
			if (item.getQuoteItemId() != null) {
				orderMapper.insertQuoteLink(item.getQuoteItemId(), item.getOrderItemId(),
						item.getQuantity().doubleValue());
			}
		}

		// 첨부파일 입력
		// 添付ファイル入力
		if (attachs != null) {
			for (OrderAttachVO attach : attachs) {
				attach.setOno(orderId);
				orderAttachMapper.insert(attach);
			}
		}

		// 전표 이력 작성
		// 伝票履歴作成
		writeHistory(order, "CREATE");
	}

	// 주문서현황
	// 受注書一覧
	@Override
	public List<OrderStatusDTO> getOrderStatus(Map<String, Object> paramMap) {
		List<OrderStatusDTO> list = orderMapper.getStatusList(paramMap);
		return list;
	}

	// 주문서 현황(집계)의 집계 항목과 대응하는 문자열(쿼리)를 담아놓은 셋
	// 受注書一覧（集計）の集計項目と対応する文字列を入れておいたセット
	private static final Set<String> AGG = new LinkedHashSet<>();
	static {
		AGG.add("day");// 일별
		AGG.add("month"); // 월별
		AGG.add("year"); // 연도별
		AGG.add("order"); // 전표별
		AGG.add("item"); // 품목별
		AGG.add("partner"); // 거래처별
		AGG.add("manager"); // 담당자별
	}

	// 주문서현황(집계)
	// 受注書一覧(集計)
	public OrderAggResultDTO getAggList(List<String> types, Map<String, Object> paramMap) {
		// 1. 집계 조건 분석
		// 1. 集計条件分析
		List<String> used = new ArrayList<>(); // 사용된 집계 조건 목록 使用された集計条件目録
		if (types != null) {
			for (String t : types) {
				// AGG에 있고, used에 없으면 집계 조건을 used에 추가
				// AGGにあり、usedになければ集計条件をusedに追加
				if (t != null && AGG.contains(t) && !used.contains(t)) {
					used.add(t);
				}
			}
		}

		// 2. 주문서현황(집계) DTO 생성
		// 2. 受注書一覧（集計）DTO生成
		OrderAggResultDTO result = new OrderAggResultDTO();
		result.setN(used.size());// 사용된 조건의 개수 使用された条件の数
		result.setTypes(used);// 사용된 조건 목록 使用された条件目録
		// 사용된 조건이 없는 경우 빈 집계 목록을 생성하고 return
		// 使用された条件がない場合、空いている集計目録を生成して返す
		if (used.isEmpty()) {
			result.setList(new ArrayList<Map<String, Object>>());
			return result;
		}

		// 3. 파라미터에 조건들을 추가하고, 파라미터를 기반으로 집계 목록 조회
		// 3. パラメーターに条件を追加し、パラメーターをもとに集計目録照会
		paramMap.put("types", used);
		result.setList(orderMapper.getAggList(paramMap));
		return result;
	}

	// 주문서 출고 처리
	// 受注書出庫処理
	public List<ReleaseWaitDTO> getReleaseWaitList(Map<String, Object> paramMap) {
		return orderMapper.getReleaseWaitList(paramMap);
	}

	// 미판매현황
	// 未販売一覧
	@Override
	public List<UnsoldDTO> getUnsoldList(Map<String, Object> paramMap) {
		log.info("unsoldList.......");
		// 구분을 확인 후, 구분에 맞춰 미판매현황 조회
		// 区分を確認し、区分に合わせて未販売一覧照会
		int type = Integer.valueOf((String) paramMap.get("type"));
		return type == 0 ? orderMapper.getUnsoldItemList(paramMap) : orderMapper.getUnsoldLineList(paramMap);
	}

	// 주문서 조회(개별)
	// 受注書照会(個別)
	@Override
	public OrderRegisterDTO getOrder(Long orderId) {
		OrderVO vo = orderMapper.get(orderId);
		List<OrderItemVO> items = orderItemMapper.selectByOrderId(orderId);
		if (vo == null) {
			return null;
		}
		return new OrderRegisterDTO(vo, items, null);
	}

	// 주문서 수정
	// 受注書修正
	@Override
	public void modify(OrderRegisterDTO dto) {

		// 1. 화면에 입력된 주문서 헤더와 주문서 품목 확인
		// 1. 画面に入力された受注書ヘッダー
		OrderVO order = dto.getOrder(); // 주문서 헤더 受注書ヘッダー
		List<OrderItemVO> items = dto.getItems(); // 受注書品目 受注書品目

		// 2. 화면에 남은 품목 ID 모으기
		// 2. 画面に残った品目IDを集める
		Set<Long> keep = new HashSet<>();
		for (OrderItemVO item : items) {
			if (item.getOrderItemId() != null) {
				keep.add(item.getOrderItemId());
			}
		}

		// 3. 기존 품목 중 사라진 품목은 삭제(판매 연결이 있으면 막음)
		// 3. 既存品目の中で消えた品目は削除(販売連結があれば止める)

		Long orderId = order.getOrderId(); // 주문서ID 受注書ID

		boolean modifyResult = orderMapper.update(order) == 1;

		// 주문서 ID를 기반으로 기존 품목들을 순회
		// 受注書IDをもとに既存品目を巡回
		for (OrderItemVO item : orderItemMapper.selectByOrderId(orderId)) {

			// 기존 품목이 화면에 남아있는지 확인
			// 既存品目が画面に残っているか確認
			if (!keep.contains(item.getOrderItemId())) {

				// 남아있지 않으면 해당 품목이 판매되었는지 확인
				// 残っていなければ該当品目が販売されたか確認
				if (orderItemMapper.selectSoldQty(item.getOrderItemId()) > 0) {

					// 판매되었으면 예외 발생
					// 販売されていると例外発生
					throw new IllegalStateException("판매된 품목은 삭제할 수 없습니다.: " + item.getItemNameSnap());
				}

				// 판매되지 않았으면 DB에서 삭제
				// 販売されていなければDBから削除
				orderItemMapper.delete(item.getOrderItemId(), orderId);
			}
		}

		// 4. 화면에 남은 품목들의 수정, 입력 작업
		// 4. 画面に残った品目の修正、入力作業
		for (OrderItemVO item : items) {

			// 품목에 주문서ID 부여
			// 品目に受注書ID付与
			item.setOrderId(orderId);
			if (item.getOrderItemId() != null) {
				if (item.getQuantity() < orderItemMapper.selectSoldQty(item.getOrderItemId())) {

					// 화면에 저장된 수량이 판매된 수량보다 적으면 예외 발생
					// 画面の保存された数量が販売された数量より少なければ例外発生
					throw new IllegalStateException("販売された数量より少なく修正することができません。");
				}

				// 기존 품목의 수량 수정
				// 既存品目の数量修正
				orderItemMapper.update(item);
				if (item.getQuantity() != null && item.getQuantity() > 0) {
					orderMapper.updateQuoteLinkQty(item.getOrderItemId(), item.getQuantity().doubleValue());
				}
			}

			else {
				orderItemMapper.insert(item);
				if (item.getQuoteItemId() != null) {
					orderMapper.insertQuoteLink(item.getQuoteItemId(), item.getOrderItemId(),
							item.getQuantity().doubleValue());
				}
			}

		}

		// 첨부파일 수정
		// 添付ファイル修正
		if (modifyResult) {
			orderAttachMapper.deleteAll(orderId);
			List<OrderAttachVO> attachList = dto.getAttachList();
			if (attachList != null) {
				for (OrderAttachVO attach : attachList) {
					attach.setOno(orderId);
					orderAttachMapper.insert(attach);
				}
			}
		}

		// 전표 이력을 위해 진행 상태 구하기
		// 伝票履歴のための進行状態照会
		order.setProgressStatus(orderMapper.get(orderId).getProgressStatus());
		// 전표 이력
		// 伝票履歴
		writeHistory(order, "UPDATE");

	}

	/*
	 * 주문서 출고 처리
	 * 受注書出庫処理
	 */
	@Override
	public void release(Map<Long, Double> qtyByItem, LocalDate releaseDate) {
		// 같은 주문서에 속한 품목은 출고 전표(헤더) 1건으로 묶고, 다른 주문서는 전표를 따로 만든다.
		// 예) 주문서 3장의 품목 5개를 한 번에 출고하면 전표는 3건, 전표 품목은 5건이 저장된다.
		// 同じ受注書の品目は出庫伝票（ヘッダー）一件にし、他の受注書は伝票を別々に作る
		// 例）受注書３枚の品目５つを一度に出庫すれば伝票は３件、伝票品目は５件が保存される

		// <주문서번호, <품목번호 , 출고수량>> 구조로 주문서별로 품목을 모아 둘 저장소
		// ＜受注書番号、＜品目番号、出庫数量＞＞　構造で受注書別に品目を集めておく保存所
		Map<Long, Map<Long, Double>> byOrder = new LinkedHashMap<>();

		// 1. 품목별 검사 + 주문서별로 분류
		// 1. 品目別検査＋受注書別に分類
		for (Map.Entry<Long, Double> e : qtyByItem.entrySet()) {
			Long itemId = e.getKey(); // 주문서 품목번호　受注書品目番号
			Double qty = e.getValue(); // 출고할 수량　出庫する数量

			// 출고수량이 비었거나 0 이하이면 중단
			// 出庫数量が空いていたり０以下なら中断
			if (qty == null || qty <= 0) {
				throw new IllegalArgumentException("出庫数量を入力してください.");
			}

			// 잔량(주문수량 - 이미 출고한 수량)보다 많이 출고할 수 없다
			// 残り（受注数量ー出庫されている数量）より多く出庫できない。
			Double remain = orderMapper.selectRemainQty(itemId);
			if (remain == null || qty > remain) {
				throw new IllegalStateException("残りより多く出庫することができません。");
			}

			// 이 품목이 어느 주문서의 것인지 조회
			// この品目がどの受注書のものか照会
			Long orderId = orderMapper.selectOrderIdOfItem(itemId);

			// 해당 주문서의 묶음이 아직 없으면 새로 만들고, 그 안에 (품목번호, 수량)을 추가
			//　該当受注書の束がまだなければ新しく作り、その中に（品目番号、数量）を追加
			byOrder.computeIfAbsent(orderId, k -> new LinkedHashMap<>()).put(itemId, qty);
		}

		// 2. 주문서마다 전표 1건 + 그 전표의 품목들을 저장
		// ２。受注書ごとに伝票一件＋その伝票の品目を保存
		for (Map.Entry<Long, Map<Long, Double>> o : byOrder.entrySet()) {
			Long orderId = o.getKey(); // 주문서번호　受注書番号
			Map<Long, Double> items = o.getValue(); // 이 주문서에서 출고할 <품목번호, 수량>　この受注書から出庫する<品目番号、数量>

			// 출고 전표(헤더) 저장: 주문서번호와 출고일자를 담는다
			// 出庫伝票（ヘッダー）保存：受注書番号と出庫日付を入れる
			OrderReleaseVO vo = new OrderReleaseVO();
			vo.setOrderId(orderId);
			vo.setReleaseDate(releaseDate);
			orderMapper.insertRelease(vo); 

			// 출고 전표 품목 저장: 전표번호에 품목과 수량을 하나씩 연결한다
			// 出庫伝票品目保存：伝票番号に品目と数量を一つずつ連結する
			for (Map.Entry<Long, Double> it : items.entrySet()) {
				orderMapper.insertReleaseItem(vo.getReleaseId(), it.getKey(), it.getValue());
			}
		}
	}

	// 주문서 출고 처리 처리 탭 목록: 출고 전표 목록 조회
	// 受注書出庫処理の処理タブの目録：出庫伝票の目録照会
	@Override
	public List<ReleaseDoneDTO> getReleaseDoneList(Map<String, Object> paramMap) {
		return orderMapper.getReleaseDoneList(paramMap);
	}

	// 주문서 선택 삭제: 출고 이력이 있는 주문서는 삭제할 수 없음
	// 受注書選択削除：出庫履歴がある受注書は削除できない
	@Override
	public void removeAll(List<Long> orderIds) {
		for (Long id : orderIds) {
			if (orderMapper.countReleaseByOrder(id) > 0) {
				throw new IllegalStateException("出庫された受注書は削除できません。");
			}
			orderMapper.delete(id); // 논리 삭제 (DELETED_YN = 'Y')　論理削除(DELETED_YN = 'Y')

			// 전표 이력
			OrderVO order = orderMapper.get(id);
			writeHistory(order, "CANCEL");
		}
	}

	// 진행상태 변경 (한 건, 여러 건 공용)
	// 출고 이력이 있는 주문서는 "미확인"으로 변경할 수 없고, 진행중/완료로는 변경 가능
	// 進行状態変更（一件、複数共用）
	// 出庫履歴がある受注書は「未確認」に変更できなく、進行中・完了には変更可能
	@Override
	public void changeStatus(List<Long> orderIds, String status) {
		// 허용된 상태값이 아니면 중단 (화면 전용 값인 "확인"은 저장하지 않는다)
		if (!Arrays.asList("UNCONFIRMED", "COMPLETED", "IN_PROGRESS").contains(status)) {
			throw new IllegalArgumentException("間違った進行状態です。");
		}
		for (Long id : orderIds) {
			if ("UNCONFIRMED".equals(status) && orderMapper.countReleaseByOrder(id) > 0) {
				throw new IllegalStateException("出庫された受注書は未確認に変更できません。");
			}
			orderMapper.updateProgressStatus(id, status);

			// 전표 이력
			OrderVO order = orderMapper.get(id);
			writeHistory(order, "STATUS");
		}
	}
	
	
	// 전표 이력 입력
	// 伝票履歴入力
	private void writeHistory(OrderVO order, String actionType) {
		VoucherHistoryVO vo = new VoucherHistoryVO();
		vo.setDocumentType("SALES_ORDER");
		vo.setDocumentId(order.getOrderId());
		vo.setActionType(actionType);
		vo.setBeforeStatus(order.getProgressStatus());
		vo.setWorkerId(order.getManagerId());
		orderMapper.writeHistory(vo);
	}

	// 전표 이력 조회
	// 伝票履歴照会
	public List<OrderHistoryDTO> getHistoryList() {
		return orderMapper.getHistoryList();
	}

	// 첨부파일 목록 조회
	// 添付ファイル目録照会
	@Override
	public List<OrderAttachVO> getAttachList(Long orderId) {
		return orderAttachMapper.findByOno(orderId);
	}

	
	//====================임시
	// 견적불러오기: 견적서 목록 (모달용)
	@Override
	public List<Map<String, Object>> getQuoteList() {
		List<Map<String, Object>> list = orderMapper.getQuoteList();
		if (!list.isEmpty()) {
		    System.out.println(list.get(0).keySet());
		}
		return orderMapper.getQuoteList();
	}

	// 견적불러오기: 견적서 헤더 1건 (제일 위 견적서)
	@Override
	public Map<String, Object> getQuoteHeader(Long quoteId) {
		return orderMapper.getQuoteHeader(quoteId);
	}

	// 견적불러오기: 선택한 모든 견적서의 품목 (remainOnly=true면 잔여수량만, false면 전량)
	@Override
	public List<Map<String, Object>> getQuoteItems(List<Long> quoteIds, boolean remainOnly) {
		return orderMapper.getQuoteItems(quoteIds, remainOnly);
	}

	

}
