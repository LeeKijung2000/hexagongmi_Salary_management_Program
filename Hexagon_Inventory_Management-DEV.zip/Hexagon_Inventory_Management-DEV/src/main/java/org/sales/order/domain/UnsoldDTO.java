package org.sales.order.domain;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import lombok.Data;

/*
 * 미판매현황 리스트DTO
 * 未販売一覧リストDTO
 */
@Data
public class UnsoldDTO {

	private Long orderId;// 주문서ID 受注書ID
	private LocalDate orderDate;// 주문일자 受注日付
	private Long dayNo; // 일자번호 日付番号
	private String itemName; // 품목명 品目名
	private String spec; // 규격 規格
	private Double quantity;// 수량 数量
	private Double unsoldQty;// 미판매수량 未販売数量
	private Long unsoldSupply;// 미판매공급가액 未販売供給価格
	private Long unsoldVat;// 미판매부가세 未販売付加税
	private LocalDate dueDate;// 품목별납기일자 品目別納期日付
	private String businessPartnerName;// 거래처명 取引先名
	private String remarks;// 적요 摘要

	// 주문일자를 'yyyy/MM/dd'형식으로 바꾸는 메서드
	// 受注日付を「yyyy/MM/dd」形式に変えるメソッド
	public String getOrderDateStr() {
		return orderDate == null ? "" : orderDate.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
	}
	
	// 납기일자를 'yyyy/MM/dd'형식으로 바꾸는 메서드
	// 納期日付を「yyyy/MM/dd」形式に変えるメソッド
	public String getDueDateStr() {
		return dueDate == null ? "" : dueDate.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
	}

	// 주문월을 구하는 메서드
	// 受注月を取得するメソッド
	public String getOrderMonth() {
		return orderDate == null ? "" : orderDate.format(DateTimeFormatter.ofPattern("yyyy/MM"));
	}
}
