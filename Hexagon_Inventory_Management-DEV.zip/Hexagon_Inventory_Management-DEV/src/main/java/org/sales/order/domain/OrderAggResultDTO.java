package org.sales.order.domain;

import java.util.List;
import java.util.Map;

import lombok.Data;

/*
 * 주문서 현황(집계) 데이터를 담는 DTO
 */
@Data
public class OrderAggResultDTO {
	private List<Map<String, Object>> list; // 쿼리 결과
	private int n;// 조건 개수
	private List<String> types;// 사용된 조건
}
