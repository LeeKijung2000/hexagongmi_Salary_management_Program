package org.sales.order.domain;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import lombok.Data;

/*출고 미처리 주문서 목록
*/@Data
public class ReleaseWaitDTO {
    private Long orderId;
    private Long orderItemId;
    private LocalDate orderDate;
    private Integer dayNo;
    private String businessPartnerName;
    private String itemName;
    private String spec;
    private Double remainQty;
    private LocalDate dueDate;
    private String remarks;

    public String getOrderDateStr() {
        return orderDate == null ? "" : orderDate.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
    }
}
