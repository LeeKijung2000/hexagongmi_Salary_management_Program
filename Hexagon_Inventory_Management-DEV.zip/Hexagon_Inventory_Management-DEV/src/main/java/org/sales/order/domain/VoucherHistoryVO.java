package org.sales.order.domain;

import java.time.LocalDateTime;

import lombok.Data;

/*전표 이력을 기록하는 VO*/
@Data
public class VoucherHistoryVO {
	private Long historyId;	//이력ID
	private String documentType;	//전표유형
	private Long documentId;	//전표ID
	private String actionType;	//작업유형
	private String beforeStatus;	//변경 전 상태
	private String afterStatus;	//변경 후 상태
	private Long workerId;	//담당자
	private LocalDateTime workedAt;	//작업일시
	private String description;	//작업설명
}
