package org.sales.order.domain;

import java.util.Map;

import lombok.Getter;
import lombok.ToString;

/*
 * 주문서 조회 페이징 처리를 위한 DTO
 * 受注書照会のページング処理のためのDTO
 */
@Getter
@ToString
public class PageDTO {

	// 해당 페이지의 첫페이지
	// 該当ページの最初のページ
	private int startPage;
	// 해당 페이지의 마지막 페이지
	// 該当ページの最後のページ
	private int endPage;
	// 이전, 다음 버튼 여부
	// 前、次ボタンの有無
	private boolean prev, next;

	// 주문서 총 갯수
	// 受注書の総数
	private int total;
	// 검색 파라미터
	// 検索パラメータ
	private Map<String, Object> paramMap;

	// 페이지 총갯수
	// ページの総数
	private int realEndPage;

	// 생성자
	// コンストラクタ
	public PageDTO(Map<String, Object> paraMap, int total) {

		this.paramMap = paraMap;
		this.total = total;

		this.endPage = (int) (Math.ceil((Double) paramMap.get("pageNum") / 10.0)) * 10;

		this.startPage = this.endPage - 9;

		int realEnd = (int) (Math.ceil((total * 1.0) / (Double) paraMap.get("amount")));

		if (realEnd < this.endPage) {
			this.endPage = realEnd;
		}

		realEndPage = (total % 10 == 0) ? total / 10 : (total / 10) + 1;

		this.prev = this.startPage > 1;
		this.next = this.endPage < realEnd;

	}

}
