package org.sales.order.domain;

import lombok.Data;

/*/
 * 주문서 품목 모델
 * 受注書品目モデル
*/
@Data
public class OrderItemVO {
	private Long quoteItemId;   // 견적 품목에서 가져온 행이면 값이 있음
	private Long orderItemId; // 주문품목ID
	private Long orderId; // 주문서ID 受注書ID
	private Long itemId; // 품목코드 品目コード
	private String specSnap; // 규격 規格
	private String itemNameSnap; // 품목명 品目名
	private Long quantity; // 수량 数量
	private Long unitPrice; // 단가 単価
	private Long supplyAmount; // 공급가액 供給価額
	private Long vatAmount; // 부가세 付加税
	private String remarks; // 비고 備考
}
