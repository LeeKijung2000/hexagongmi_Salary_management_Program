package org.sales.order.domain;


import lombok.Data;

@Data
public class OrderAttachVO {
	private String uuid;
	private String uploadPath;
	private String fileName;
	private boolean fileType;
	
	private Long ono;
}
