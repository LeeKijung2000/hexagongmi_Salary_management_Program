package org.sales.order.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.sales.order.domain.OrderItemVO;

//주문서 품목에 관한 CRUD 작업을 수행하는 매퍼
//受注書品目に関したCRUD作業を修行するmapper
public interface OrderItemMapper {

	// 주문서 품목 입력
	// 受注書品目入力
	public void insert(OrderItemVO orderItem);
	
	// 주문서ID를 통한 품목 조회
	// 受注書IDを通じた品目照会
	public List<OrderItemVO> selectByOrderId(Long orderId);

	// 품목의 판매된 수량을 확인하는 메서드
	// 品目の販売された数量を確認するメソッド
	public Double selectSoldQty(Long orderItemId);

	// 주문서 품목 수정
	// 受注書品目修正
	public void update(OrderItemVO orderItem);

	// 주문서 품목 삭제
	// 受注書品目削除
	public void delete(@Param("orderItemId") Long orderItemId, @Param("orderId") Long orderId);

}
