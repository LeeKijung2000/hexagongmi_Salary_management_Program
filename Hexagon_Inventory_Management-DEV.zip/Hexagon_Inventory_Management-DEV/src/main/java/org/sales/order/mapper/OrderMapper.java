package org.sales.order.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.sales.order.domain.OrderHistoryDTO;
import org.sales.order.domain.OrderListDTO;
import org.sales.order.domain.OrderReleaseVO;
import org.sales.order.domain.OrderStatusDTO;
import org.sales.order.domain.OrderVO;
import org.sales.order.domain.ReleaseDoneDTO;
import org.sales.order.domain.ReleaseWaitDTO;
import org.sales.order.domain.UnsoldDTO;
import org.sales.order.domain.VoucherHistoryVO;

//주문서에 관한 CRUD 작업을 수행하는 매퍼
//受注書に関したCRUD作業を修行するmapper
public interface OrderMapper {

	// 주문서 입력
	// 受注書入力
	public void insert(OrderVO order);

	// 주문서 조회(리스트)
	// 受注書照会（リスト）
	public List<OrderListDTO> getListWithPaging(Map<String, Object> paramMap);

	// 주문서 개수 조회
	// 受注書数照会
	public int getTotalCount(Map<String, Object> paramMap);

	// 주문서 조회(개별)
	// 受注書照会(個別)
	public OrderVO get(Long orderId);

	// 주문서현황(현황)
	// 受注書一覧(一覧)
	public List<OrderStatusDTO> getStatusList(Map<String, Object> paramMap);

	// 주문서현황(집계)
	public List<Map<String, Object>> getAggList(Map<String, Object> paramMap);

	// 주문서 출고처리
	public List<ReleaseWaitDTO> getReleaseWaitList(Map<String, Object> paramMap);

	// 미판매현황(라인별)
	// 未販売一覧（ライン別）
	public List<UnsoldDTO> getUnsoldLineList(Map<String, Object> paramMap);

	// 미판매현황(품목별)
	// 未販売一覧（品目別）
	public List<UnsoldDTO> getUnsoldItemList(Map<String, Object> paramMap);

	// 주문서 수정
	// 受注書修正
	public int update(OrderVO order);

	// 주문서 삭제
	// 受注書削除
	public void delete(Long orderId);

	// 출고 처리 되지 않은 품목 수량 확인
	// 出庫されていない品目の数量確認
	public Double selectRemainQty(@Param("orderItemId") Long orderItemId);

	// 주문서 품목 번호로 주문서 ID 확인
	// 受注書品目番号で受注書IDを確認
	public Long selectOrderIdOfItem(@Param("orderItemId") Long orderItemId);

	// 주문서 헤더 출고 처리
	// 受注書ヘッダーの出庫処理
	public int insertRelease(OrderReleaseVO vo);

	// 주문서 품목 출고 처리
	// 受注書品目の出庫処理
	public int insertReleaseItem(@Param("releaseId") Long releaseId, @Param("orderItemId") Long orderItemId,
			@Param("releasedQty") Double releasedQty);

	// 출고 완료된 DTO 목록
	// 出庫完了されたDTOの目録
	public List<ReleaseDoneDTO> getReleaseDoneList(Map<String, Object> paramMap);

	/* int countSaleLinkByOrder(@Param("orderId") Long orderId); */

	// 주문서ID를 통해 출고된 품목이 있는 지 확인
	// 受注書IDを通して出庫された品目があるのか確認
	public int countReleaseByOrder(@Param("orderId") Long orderId);

	// 주문서의 진행상태 변경
	// 受注書の進行状態の変更
	public int updateProgressStatus(@Param("orderId") Long orderId, @Param("status") String status);

	// 전표 이력 쓰기
	// 伝票履歴を書く
	public void writeHistory(VoucherHistoryVO vo);

	// 전표 이력 조회
	// 伝票履歴照会
	public List<OrderHistoryDTO> getHistoryList();

	// 견적주문 연결 입력
	// 見積注文連結入力
	public int insertQuoteLink(@Param("quoteItemId") Long quoteItemId, @Param("orderItemId") Long orderItemId,
			@Param("appliedQty") Double appliedQty);
	
	// 견적주문 연결 수정
	// 見積注文連結修正
	public int updateQuoteLinkQty(@Param("orderItemId") Long orderItemId, @Param("qty") Double qty);
	
	// 임시
	// 견적관련 메서드
	public List<Map<String, Object>> getQuoteList();

	public Map<String, Object> getQuoteHeader(@Param("quoteId") Long quoteId);

	public List<Map<String, Object>> getQuoteItems(@Param("list") List<Long> quoteIds,
			@Param("remainOnly") boolean remainOnly);


}