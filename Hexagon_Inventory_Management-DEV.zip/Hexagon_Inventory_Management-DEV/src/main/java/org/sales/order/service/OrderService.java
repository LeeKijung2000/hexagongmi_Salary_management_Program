package org.sales.order.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.sales.order.domain.OrderAggResultDTO;
import org.sales.order.domain.OrderAttachVO;
import org.sales.order.domain.OrderHistoryDTO;
import org.sales.order.domain.OrderItemVO;
import org.sales.order.domain.OrderListDTO;
import org.sales.order.domain.OrderRegisterDTO;
import org.sales.order.domain.OrderStatusDTO;
import org.sales.order.domain.OrderVO;
import org.sales.order.domain.ReleaseDoneDTO;
import org.sales.order.domain.ReleaseWaitDTO;
import org.sales.order.domain.UnsoldDTO;
import org.sales.order.domain.VoucherHistoryVO;

//주문서에 관한 CRUD 작업을 수행하는 서비스
//受注書に関するCRUD作業を修行するサービス
public interface OrderService {

	// 주문서 조회(리스트)
	// 受注書照会（リスト）
	public List<OrderListDTO> getListWithPaging(Map<String, Object> paramMap);

	// 주문서 개수 조회
	// 受注書数照会
	public int getTotalCount(Map<String, Object> paramMap);

	// 주문서 입력
	// 受注書入力
	public void register(OrderRegisterDTO dto);

	// 주문서현황(현황)
	// 受注書一覧(一覧)
	public List<OrderStatusDTO> getOrderStatus(Map<String, Object> paramMap);

	// 주문서현황(집계)
	// 受注書一覧（集計）
	public OrderAggResultDTO getAggList(List<String> types, Map<String, Object> paramMap);

	// 미판매현황
	// 未販売一覧
	public List<UnsoldDTO> getUnsoldList(Map<String, Object> paramMap);

	// 주문서 조회(개별)
	// 受注書照会(個別)
	public OrderRegisterDTO getOrder(Long orderId);

	// 주문서 수정
	// 受注書修正
	public void modify(OrderRegisterDTO dto);

	// 출고되지 않은 주문서 조회
	// 出庫されていない受注書照会
	public List<ReleaseWaitDTO> getReleaseWaitList(Map<String, Object> paramMap);

	// 주문서 출고 처리
	// 受注書出庫処理
	public void release(Map<Long, Double> qtyByItem, LocalDate releaseDate);

	// 출고 완료된 주문서 목록
	// 出庫された受注書目録
	public List<ReleaseDoneDTO> getReleaseDoneList(Map<String, Object> paramMap);

	// 주문서 삭제
	// 受注書削除
	public void removeAll(List<Long> orderIds);

	// 진행상태 변경
	// 進行状態変更
	public void changeStatus(List<Long> orderIds, String status);

	// 주문서 이력 조회
	// 受注書履歴照会
	public List<OrderHistoryDTO> getHistoryList();
	
	//주문서 첨부파일 조회
	//受注書添付ファイル照会
	List<OrderAttachVO> getAttachList(Long orderId);
	
	// ===========임시
	// 견적불러오기
	List<Map<String, Object>> getQuoteList();

	Map<String, Object> getQuoteHeader(Long quoteId);

	List<Map<String, Object>> getQuoteItems(List<Long> quoteIds, boolean remainOnly);


	
}
