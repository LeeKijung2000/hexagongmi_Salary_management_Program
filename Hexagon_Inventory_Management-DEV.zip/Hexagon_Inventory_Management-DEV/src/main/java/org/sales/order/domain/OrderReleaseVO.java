package org.sales.order.domain;

import java.time.LocalDate;
import java.time.LocalDateTime;

import lombok.Data;

/*주문서 출고 VO*/
@Data
public class OrderReleaseVO {
	
	Long releaseId;//출고ID
	String voucherNo;//전표번호
	LocalDate releaseDate;//출고처리일자
	Long orderId;//주문서ID
	String remarks;//적요
	LocalDateTime createdAt;//최초 등록일시

}
