package org.sales.order.domain;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import lombok.Data;

/*출고 처리 완료된 목록 DTO*/
@Data
public class ReleaseDoneDTO {
	private Long releaseId;// 출고ID
	private LocalDate releaseDate;// 출고일
	private Integer releaseDayNo;// 출고일 번호
	private Long orderId;// 주문서ID
	private LocalDate orderDate;// 주문일
	private Integer orderDayNo;// 주문일 번호
	private String businessPartnerName;// 거래처 이름
	private String itemName;// 품목 이름
	private Integer itemCount;// 품목 개수
	private Double totalQty;// 총 수량
	private String remarks;// 적요

	public String getReleaseDateStr() {
		return releaseDate == null ? "" : releaseDate.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
	}

	public String getOrderDateStr() {
		return orderDate == null ? "" : orderDate.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
	}
}