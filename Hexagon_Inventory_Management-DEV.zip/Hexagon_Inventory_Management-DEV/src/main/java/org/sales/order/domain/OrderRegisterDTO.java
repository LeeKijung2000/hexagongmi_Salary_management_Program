package org.sales.order.domain;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;

/*
 * 주문서 등록, 수정을 위한 DTO
 * 受注書登録、修正のためのDTO
 */
@Data
@AllArgsConstructor
public class OrderRegisterDTO {
	
	private OrderVO order;	//주문서 受注書
	private List<OrderItemVO> items;//주문서 품목　受注書品目
	private List<OrderAttachVO> attachList;//첨부파일 목록 添付ファイル目録
}
