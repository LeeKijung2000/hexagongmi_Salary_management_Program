package org.sales.order.domain;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import lombok.Data;

/*주문서 이력 조회에 사용하는 DTO*/
@Data
public class OrderHistoryDTO {
	private Long historyId;
	private Long orderId;
	private LocalDate workDate;
	private LocalDate orderDate;
	private Long dayNo;
	private String actionType;
	private String partnerCode;
	private String partnerName;
	private String employeeCode;
	private String managerName;// 담당자명 担当者名
	private String itemName; // 대표품목명代表 品目名
	private int itemCount; //품목 총갯수 品目の総数
	private String beforeStatus; //진행상태
	
	
	public String getWorkDateStr() {
		return workDate == null ? "" : workDate.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
	}
	
	// 주문일자를 'yyyy/MM/dd'형식으로 바꾸는 메서드
	// 受注日付を「yyyy/MM/dd」形式に変えるメソッド
	public String getOrderDateStr() {
		return orderDate == null ? "" : orderDate.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
	}
	
}
