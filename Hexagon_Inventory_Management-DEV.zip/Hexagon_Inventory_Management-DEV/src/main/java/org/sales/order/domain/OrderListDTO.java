package org.sales.order.domain;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import lombok.Data;

/*
 * 주문서 조회를 위한 DTO
 * 受注書照会のためのDTO
 */
@Data
public class OrderListDTO {
	private Long orderId;// 주문서ID 受注書ID
	private LocalDate orderDate; // 일자 日付
	private Long dayNo; // 일자번호 日付番号
	private String businessPartnerName; // 거래처명 取引先名
	private String managerName;// 담당자명 担当者名
	private String itemName; // 대표품목명代表 品目名
	private int itemCount; //품목 총갯수 品目の総数
	private LocalDate dueDate;// 납기일자 納期日付
	private Long totalAmount; // 주문 금액 합계 受注金額合計
	private String progressStatus; // 진행상태 進行状態
	private boolean hasSale; // 판매 전표 생성 여부 販売伝票生成有無
	
	// 주문일자를 'yyyy/MM/dd'형식으로 바꾸는 메서드
	// 受注日付を「yyyy/MM/dd」形式に変えるメソッド
	public String getOrderDateStr() {
		return orderDate == null ? "" : orderDate.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
	}
	
}
