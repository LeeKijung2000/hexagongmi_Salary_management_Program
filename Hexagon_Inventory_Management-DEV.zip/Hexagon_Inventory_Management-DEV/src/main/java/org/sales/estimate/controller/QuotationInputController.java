package org.sales.estimate.controller;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.sales.estimate.domain.QuotationInputVO;
import org.sales.estimate.service.QuotationInputService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

// 견적서입력 Controller
// 見積書入力Controller
@RestController
@RequestMapping("/sales/estimate/api/input")
public class QuotationInputController {

	private final QuotationInputService service;

	@Autowired
	public QuotationInputController(QuotationInputService service) {
		this.service = service;
	}

	// 통화 목록
	// 通貨一覧
	@GetMapping("/currencies")
	public List<Map<String, Object>> getCurrencies() {
		return service.getCurrencies();
	}

	// 기준정보 돋보기
	// マスター検索
	@GetMapping("/lookup/{type}")
	public List<Map<String, Object>> lookup(@PathVariable("type") String type,
			@RequestParam(value = "keyword", defaultValue = "") String keyword) {

		return service.searchLookup(type, keyword);
	}

	// 전체재고·창고재고 조회
	// 全体在庫・倉庫在庫の照会
	@PostMapping(value = "/inventory", consumes = MediaType.APPLICATION_JSON_VALUE)
	public List<Map<String, Object>> loadInventory(@RequestBody Map<String, Object> request) {

		Object warehouseObj = request.get("warehouse_code");

		String warehouseCode = warehouseObj == null ? "" : String.valueOf(warehouseObj);

		Object codesObj = request.get("item_codes");
		List<String> itemCodes = new ArrayList<String>();

		if (codesObj instanceof List<?>) {
			for (Object code : (List<?>) codesObj) {
				if (code != null) {
					itemCodes.add(String.valueOf(code));
				}
			}
		}

		return service.loadInventory(itemCodes, warehouseCode);
	}

	// 견적서 저장
	// 見積書保存
	@PostMapping(value = "/quotations", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, Object>> saveQuotation(@RequestBody QuotationInputVO vo) {

		Long quoteId = service.saveQuotation(vo);

		Map<String, Object> result = new HashMap<String, Object>();

		result.put("success", true);
		result.put("quote_id", quoteId);

		return ResponseEntity.status(HttpStatus.CREATED).body(result);
	}

	// 첨부파일 업로드
	// 添付ファイルのアップロード
	@PostMapping(value = "/quotations/{quote_id}/attachment", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<Map<String, Object>> upload(@PathVariable("quote_id") Long quote_id,
			@RequestParam("file") MultipartFile file) throws IOException {

		String path = service.uploadAttachment(quote_id, file);

		Map<String, Object> result = new HashMap<String, Object>();

		result.put("success", true);
		result.put("quote_id", quote_id);
		result.put("attachment_path", path);

		return ResponseEntity.ok(result);
	}

	// 첨부파일 다운로드
	// 添付ファイルのダウンロード
	@GetMapping("/quotations/{quote_id}/attachment")
	public ResponseEntity<byte[]> download(@PathVariable("quote_id") Long quote_id) throws IOException {

		byte[] bytes = service.downloadAttachment(quote_id);
		String fileName = service.getAttachmentPath(quote_id);

		return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"")
				.contentType(MediaType.APPLICATION_OCTET_STREAM).body(bytes);
	}

	// 잘못된 입력 처리
	// 不正な入力の処理
	@ExceptionHandler(IllegalArgumentException.class)
	public ResponseEntity<String> badRequest(IllegalArgumentException ex) {

		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ex.getMessage());
	}

	// 저장 충돌 오류 처리
	// 保存時の競合エラー処理
	@ExceptionHandler(IllegalStateException.class)
	public ResponseEntity<String> saveConflict(IllegalStateException ex) {

		return ResponseEntity.status(HttpStatus.CONFLICT).body(ex.getMessage());
	}

	// 첨부파일이 없는 경우
	// 添付ファイルが存在しない場合
	@ExceptionHandler(FileNotFoundException.class)
	public ResponseEntity<String> notFound(FileNotFoundException ex) {

		return ResponseEntity.status(HttpStatus.NOT_FOUND).body("添付ファイルが見つかりません。");
	}

	// 첨부파일 입출력 오류
	// 添付ファイルの入出力エラー
	@ExceptionHandler(IOException.class)
	public ResponseEntity<String> ioError(IOException ex) {

		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("添付ファイルの処理に失敗しました。");
	}
}
