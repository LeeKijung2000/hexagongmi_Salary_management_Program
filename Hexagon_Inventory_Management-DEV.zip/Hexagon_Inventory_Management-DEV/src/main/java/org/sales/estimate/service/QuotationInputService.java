package org.sales.estimate.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.sales.estimate.domain.QuotationInputVO;
import org.springframework.web.multipart.MultipartFile;

// 견적서입력 Service
// 見積書入力用Service
public interface QuotationInputService {

	// 통화 목록 조회
	// 通貨一覧
	List<Map<String, Object>> getCurrencies();

	// 거래처·담당자·창고·품목 조회
	// 取引先・担当者・倉庫・品目の検索
	List<Map<String, Object>> searchLookup(String type, String keyword);

	// 전체재고·창고재고 조회
	// 在庫照会
	List<Map<String, Object>> loadInventory(List<String> itemCodes, String warehouseCode);

	// 견적서 저장
	// 見積書保存
	Long saveQuotation(QuotationInputVO vo);

	// 첨부파일 업로드
	// 添付アップロード
	String uploadAttachment(Long quote_id, MultipartFile file) throws IOException;

	// 첨부파일 다운로드
	// 添付ダウンロード
	byte[] downloadAttachment(Long quote_id) throws IOException;

	String getAttachmentPath(Long quote_id);
}
