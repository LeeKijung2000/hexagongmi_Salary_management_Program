package org.sales.estimate.service;

import java.util.List;

import org.sales.estimate.domain.QuotationCriteria;
import org.sales.estimate.domain.QuotationUnorderVO;

// 미주문현황 Service
// 未受注現況Service
public interface QuotationUnorderService {

	List<QuotationUnorderVO> getUnorderList(QuotationCriteria search);
}
