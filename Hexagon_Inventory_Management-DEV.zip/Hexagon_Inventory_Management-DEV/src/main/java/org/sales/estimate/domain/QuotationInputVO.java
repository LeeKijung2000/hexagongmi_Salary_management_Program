package org.sales.estimate.domain;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import lombok.Data;

// 견적서입력 VO
// 見積書入力VO
@Data
public class QuotationInputVO {

	// 견적서 기본 테이블 컬럼
	// 見積書基本テーブルのカラム
	private Long quote_id;
	private String voucher_no;
	private String quote_date;

	private Long business_partner_id;
	private Long manager_id;
	private Long warehouse_id;

	// 통화 및 환율
	// 通貨および為替レート
	private Long currency_id;
	private BigDecimal exchange_rate;

	// 코드 직접 입력 시 사용
	// コードの直接入力時に使用
	private String partner_code;
	private String employee_code;
	private String warehouse_code;

	private String transaction_type;

	private BigDecimal supply_amount;
	private BigDecimal vat_amount;
	private BigDecimal total_amount;

	private String attachment_path;
	private String custom_data;
	private String remarks;

	// 견적 상세 품목
	// 見積明細品目
	private List<Item> items = new ArrayList<Item>();

	// 견적서 품목 상세 데이터
	// 見積書の品目明細データ
	@Data
	public static class Item {

		private Long quote_item_id;
		private Long quote_id;
		private Integer line_no;

		private Long item_id;
		private String item_code_snap;
		private String item_name_snap;
		private String spec_snap;
		private String unit_snap;

		private BigDecimal quantity;
		private BigDecimal unit_price;
		private BigDecimal supply_amount;
		private BigDecimal vat_amount;
		private BigDecimal total_amount;

		private String remarks;
	}
}
