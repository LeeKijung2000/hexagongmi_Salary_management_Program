package org.sales.estimate.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.sales.estimate.domain.QuotationCriteria;
import org.sales.estimate.domain.QuotationInquiryVO;
import org.sales.estimate.mapper.QuotationInquiryMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

// 견적서 조회 서비스 구현
// 見積書照会サービス実装
@Service
public class QuotationInquiryServiceImpl implements QuotationInquiryService {

	private final QuotationInquiryMapper mapper;

	@Autowired
	public QuotationInquiryServiceImpl(QuotationInquiryMapper mapper) {
		this.mapper = mapper;
	}

	// null 처리 후 문자열의 앞뒤 공백 제거
	// nullを処理し、文字列の前後の空白を除去
	private String str(Object value) {
		return value == null ? "" : String.valueOf(value).trim();
	}

	// 입력값이 비어 있는지 확인
	// 入力値が空かどうかを確認
	private boolean blank(Object value) {
		return str(value).isEmpty();
	}

	// 필수 입력값과 최대 길이 검사
	// 必須入力値と最大文字数を検証
	private String required(Object value, String label, int maxLength) {

		String text = str(value);

		if (text.isEmpty()) {
			throw new IllegalArgumentException(label + "を入力してください。");
		}

		if (text.length() > maxLength) {
			throw new IllegalArgumentException(label + "の文字数を確認してください。");
		}

		return text;
	}

	// 선택 입력값의 길이 검사
	// 任意入力値の文字数を検証
	private String optional(Object value, int maxLength) {

		String text = str(value);

		if (text.length() > maxLength) {
			throw new IllegalArgumentException("入力値の文字数を確認してください。");
		}

		return text.isEmpty() ? null : text;
	}

	// 날짜 입력값 검사
	// 日付入力値を検証
	private String date(Object value, boolean required) {

		String text = str(value);

		if (text.isEmpty() && !required) {
			return null;
		}

		try {
			LocalDate.parse(text);
			return text;

		} catch (DateTimeParseException e) {
			throw new IllegalArgumentException("日付はYYYY-MM-DD形式で入力してください。");
		}
	}

	// 숫자 자릿수와 양수 조건 검사
	// 数値の桁数と正数条件を検証
	private BigDecimal decimal(Object value, String label, int integerDigits, int scale, boolean positive) {

		BigDecimal number;

		try {
			number = new BigDecimal(str(value));

		} catch (NumberFormatException e) {
			throw new IllegalArgumentException(label + "には数値を入力してください。");
		}

		if (number.scale() > scale || number.precision() - number.scale() > integerDigits) {

			throw new IllegalArgumentException(label + "の桁数を確認してください。");
		}

		if (positive ? number.compareTo(BigDecimal.ZERO) <= 0 : number.compareTo(BigDecimal.ZERO) < 0) {

			throw new IllegalArgumentException(label + (positive ? "は0より大きい値にしてください。" : "は0以上にしてください。"));
		}

		return number;
	}

	// 기준정보의 ID 추출
	// マスター情報のIDを取得
	private Long idOf(Map<String, Object> master) {

		if (master == null || master.get("id") == null) {
			return null;
		}

		return ((Number) master.get("id")).longValue();
	}

	// 취소되지 않은 활성 견적서인지 확인
	// 取消されていない有効な見積書か確認
	private void ensureActive(Long id) {

		if (id == null || id <= 0 || mapper.countActive(id) != 1) {
			throw new IllegalArgumentException("存在しないか、取り消された見積書です。");
		}
	}

	// 주문·판매전표 연결 여부 확인
	// 受注・販売伝票との関連有無を確認
	private void ensureUnlinked(Long id) {

		if (mapper.countLinked(id) > 0) {
			throw new IllegalArgumentException("受注・売上伝票が関連付けられた見積書は " + "更新または削除できません。");
		}
	}

	// 품목별 적요 보존
	// 品目別摘要の保持

	// 수정 화면이 remarks 값을 보내지 않는 경우 기존 Oracle에 저장된 적요를 가져온다.
	// 編集画面からremarksが送られなかった場合、Oracleに保存された既存の摘要を取得します。
	private void preserveMissingRemarks(List<Map<String, Object>> existingItems,
			List<Map<String, Object>> preparedItems) {

		Map<String, List<Map<String, Object>>> oldByCode = new LinkedHashMap<String, List<Map<String, Object>>>();

		Map<String, List<Map<String, Object>>> newByCode = new LinkedHashMap<String, List<Map<String, Object>>>();

		// 기존 상세품목을 품목코드별로 정리
		// 既存の明細品目を品目コード別に整理
		for (Map<String, Object> item : existingItems) {

			String code = str(item.get("item_code"));

			if (!oldByCode.containsKey(code)) {
				oldByCode.put(code, new ArrayList<Map<String, Object>>());
			}

			oldByCode.get(code).add(item);
		}

		// 수정 요청 품목을 품목코드별로 정리
		// 修正依頼の品目を品目コード別に整理
		for (Map<String, Object> item : preparedItems) {

			String code = str(item.get("item_code"));

			if (!newByCode.containsKey(code)) {
				newByCode.put(code, new ArrayList<Map<String, Object>>());
			}

			newByCode.get(code).add(item);
		}

		// 동일 품목코드 내에서 적요 보존
		// 同一品目コード内で摘要を保持
		for (Map.Entry<String, List<Map<String, Object>>> entry : newByCode.entrySet()) {

			List<Map<String, Object>> previous = oldByCode.get(entry.getKey());

			if (previous == null) {
				continue;
			}

			List<Map<String, Object>> current = entry.getValue();

			boolean hasSavedRemarks = false;
			boolean requiresFallback = false;

			for (Map<String, Object> item : previous) {
				if (!blank(item.get("remarks"))) {
					hasSavedRemarks = true;
				}
			}

			for (Map<String, Object> item : current) {
				if (!Boolean.TRUE.equals(item.get("_remarks_supplied"))) {
					requiresFallback = true;
				}
			}

			// 적요가 있는 동일 품목의 행 수가 변경되면
			// 摘要がある同一品目の行数が変わった場合
			// 원래 어느 행의 적요인지 구분할 수 없다.
			// 元のどの行の摘要か判別できません。
			if (hasSavedRemarks && requiresFallback && previous.size() != current.size()) {

				throw new IllegalArgumentException(
						"摘要が保存されている同一品目の行数が変わりました。 " + "品目別の摘要が誤って関連付けられないよう、 " + "保存を中止しました。");
			}

			// 동일 품목이 여러 행인 경우 규격 순서를 검사
			// 同一品目が複数行ある場合、規格の順序を確認
			if (hasSavedRemarks && requiresFallback && previous.size() > 1) {

				for (int i = 0; i < previous.size(); i++) {

					String oldSpec = str(previous.get(i).get("spec"));

					String newSpec = str(current.get(i).get("spec"));

					if (!oldSpec.equals(newSpec)) {
						throw new IllegalArgumentException("同じ品目コードの規格または " + "行順序が変更されたため、 " + "摘要を保持できるか確認できません。");
					}
				}
			}

			// 변경 요청에서 적요를 생략한 경우만 기존 적요 복원
			// 修正依頼で摘要が省略された場合のみ元の摘要を復元
			for (int i = 0; i < current.size() && i < previous.size(); i++) {

				Map<String, Object> next = current.get(i);

				if (!Boolean.TRUE.equals(next.get("_remarks_supplied"))) {

					next.put("remarks", previous.get(i).get("remarks"));
				}
			}
		}

		// 전체 행 수는 같지만 적요가 있는 품목코드가
		// 全行数は同じでも摘要を持つ品目コードが
		// 사라졌다면 잘못된 적요 삭제를 막기 위해 저장 중단
		// 消えた場合、誤った摘要削除を防ぐため保存を中止
		if (existingItems.size() == preparedItems.size()) {

			for (Map.Entry<String, List<Map<String, Object>>> entry : oldByCode.entrySet()) {

				if (newByCode.containsKey(entry.getKey())) {
					continue;
				}

				for (Map<String, Object> item : entry.getValue()) {

					if (!blank(item.get("remarks"))) {
						throw new IllegalArgumentException(
								"摘要がある品目のコードが変更されました。 " + "摘要を保持できるか確認できないため、 " + "保存しませんでした。");
					}
				}
			}
		}
	}

	// 현재 화면 상태 조회
	// 現在の画面状態を取得

	// Oracle 전표이력에 화면 상태가 있으면 해당 값을 사용. 없으면 견적서의 실제 진행상태를 기준으로 결정.
	// Oracleの伝票履歴に画面状態があればそれを使用し、なければ見積書の実際の進捗状態から判定します。
	private String currentUiStatus(Long quoteId) {

		String uiStatus = mapper.getLatestUiStatus(quoteId);

		if (uiStatus != null && !uiStatus.trim().isEmpty()) {
			return uiStatus;
		}

		Map<String, Object> header = mapper.getHeader(quoteId);

		if (header != null && "COMPLETED".equals(str(header.get("progress_status")))) {

			return "COMPLETE";
		}

		return "PROGRESS";
	}

	// 기존 목록 조회
	// 一覧検索
	@Override
	@Transactional(readOnly = true)
	public List<QuotationInquiryVO> getList(QuotationCriteria criteria) {

		if (criteria == null) {
			criteria = new QuotationCriteria();
		}

		return mapper.getList(criteria);
	}

	// 견적서 상세 조회
	// 詳細照会
	@Override
	@Transactional(readOnly = true)
	public Map<String, Object> getDetail(Long quoteId) {

		ensureActive(quoteId);

		Map<String, Object> result = new HashMap<String, Object>();

		result.put("header", mapper.getHeader(quoteId));
		result.put("items", mapper.getItems(quoteId));
		result.put("linked", mapper.countLinked(quoteId) > 0);

		return result;
	}

	// 생성한 주문서 조회
	// 作成された受注伝票を取得
	@Override
	@Transactional(readOnly = true)
	public Map<String, Object> getGeneratedOrders(Long quoteId) {

		ensureActive(quoteId);

		Map<String, Object> result = new HashMap<String, Object>();

		result.put("orders", mapper.getLinkedOrders(quoteId));
		result.put("items", mapper.getLinkedOrderItems(quoteId));

		return result;
	}

	// 진행상태 변경
	// 進行状態変更
	@Override
	@Transactional
	public void changeProgress(Long quoteId, String status) {

		ensureActive(quoteId);

		if (!"PROGRESS".equals(status) && !"COMPLETE".equals(status)) {

			throw new IllegalArgumentException("Oracleに保存できない進捗状態です。");
		}

		// 연결된 주문·판매전표가 있으면 변경 방지
		// 関連する受注・販売伝票がある場合は変更を禁止
		ensureUnlinked(quoteId);

		String beforeStatus = currentUiStatus(quoteId);

		if (mapper.changeProgress(quoteId, status) != 1) {
			throw new IllegalStateException("進捗状態を変更できませんでした。");
		}

		// 화면 상태 이력 저장
		// 画面状態の履歴を保存
		if (mapper.insertUiStatusHistory(quoteId, beforeStatus, status) != 1) {

			throw new IllegalStateException("進捗履歴を保存できませんでした。");
		}
	}

	// 결재 중 / 미확인 / 확인 저장
	// 承認中／未確認／確認済みを保存
	@Override
	@Transactional
	public void changeUiStatus(Long quoteId, String status) {

		ensureActive(quoteId);

		if (!"APPROVAL".equals(status) && !"UNREAD".equals(status) && !"CONFIRMED".equals(status)) {

			throw new IllegalArgumentException("画面状態が正しくありません。");
		}

		String beforeStatus = currentUiStatus(quoteId);

		if (status.equals(beforeStatus)) {
			return;
		}

		int saved = mapper.insertUiStatusHistory(quoteId, beforeStatus, status);

		if (saved != 1) {
			throw new IllegalStateException("画面状態を保存できませんでした。");
		}
	}

	// 선택삭제(취소 처리)
	// 選択取消
	@Override
	@Transactional
	public int cancelSelected(List<Long> quoteIds) {

		if (quoteIds == null || quoteIds.isEmpty()) {
			throw new IllegalArgumentException("削除する見積書を選択してください。");
		}

		if (quoteIds.size() > 100) {
			throw new IllegalArgumentException("一度に処理できるのは最大100件です。");
		}

		Set<Long> unique = new HashSet<Long>();

		// 전체 건을 검증한 후 한 트랜잭션으로 처리
		// 全件を検証してから一つのトランザクションで処理
		for (Long id : quoteIds) {

			if (id == null || !unique.add(id)) {
				throw new IllegalArgumentException("重複または無効な見積書番号です。");
			}

			ensureActive(id);
			ensureUnlinked(id);
		}

		int count = 0;

		for (Long id : quoteIds) {
			count += mapper.cancelQuotation(id);
		}

		if (count != quoteIds.size()) {
			throw new IllegalStateException("一部の見積書の取消処理に失敗しました。");
		}

		return count;
	}

	// 수정 모달 기준정보 검색
	// 編集モーダルのマスター検索
	@Override
	@Transactional(readOnly = true)
	public List<Map<String, Object>> searchMaster(String type, String keyword) {

		if (!"partner".equals(type) && !"manager".equals(type) && !"warehouse".equals(type) && !"item".equals(type)) {

			throw new IllegalArgumentException("検索種別が正しくありません。");
		}

		String word = str(keyword);

		if (word.length() > 100) {
			throw new IllegalArgumentException("検索キーワードは100文字以内で入力してください。");
		}

		return mapper.searchMaster(type, word);
	}

	// 견적서 수정
	// 見積書修正
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(rollbackFor = Exception.class)
	public void updateQuotation(Long quoteId, Map<String, Object> request) {

		ensureActive(quoteId);
		ensureUnlinked(quoteId);

		if (request == null) {
			throw new IllegalArgumentException("更新データがありません。");
		}

		// 기존 상세행을 삭제하기 전에 적요 조회
		// 既存明細行を削除する前に摘要を取得
		List<Map<String, Object>> existingItems = mapper.getItems(quoteId);

		Map<String, Object> data = new HashMap<String, Object>();

		data.put("quote_date", date(request.get("quote_date"), true));

		data.put("valid_until", date(request.get("valid_until"), false));

		String partnerCode = required(request.get("partner_code"), "取引先", 50);

		Map<String, Object> partner = mapper.findPartner(partnerCode);

		if (partner == null) {
			throw new IllegalArgumentException("登録済みの取引先コードではありません。");
		}

		data.put("partner_id", idOf(partner));

		String managerCode = str(request.get("manager_code"));

		Long managerId = null;

		if (!managerCode.isEmpty()) {

			Map<String, Object> manager = mapper.findManager(managerCode);

			if (manager == null) {
				throw new IllegalArgumentException("登録済みの担当者コードではありません。");
			}

			managerId = idOf(manager);
		}

		data.put("manager_id", managerId);

		String warehouseCode = str(request.get("warehouse_code"));

		Long warehouseId = null;

		if (!warehouseCode.isEmpty()) {

			Map<String, Object> warehouse = mapper.findWarehouse(warehouseCode);

			if (warehouse == null) {
				throw new IllegalArgumentException("登録済みの倉庫コードではありません。");
			}

			warehouseId = idOf(warehouse);
		}

		data.put("warehouse_id", warehouseId);

		String transactionType = required(request.get("transaction_type"), "取引区分", 20);

		if (!"TAXABLE".equals(transactionType) && !"EXEMPT".equals(transactionType)) {

			throw new IllegalArgumentException("取引区分が正しくありません。");
		}

		data.put("transaction_type", transactionType);

		Long currencyId;

		try {
			currencyId = Long.valueOf(str(request.get("currency_id")));

		} catch (NumberFormatException e) {
			throw new IllegalArgumentException("通貨を選択してください。");
		}

		if (mapper.countCurrency(currencyId) != 1) {
			throw new IllegalArgumentException("利用できない通貨です。");
		}

		data.put("currency_id", currencyId);

		data.put("exchange_rate", decimal(request.get("exchange_rate"), "為替レート", 12, 6, true));

		data.put("custom_data", optional(request.get("custom_data"), 4000));

		Object itemsObject = request.get("items");

		if (!(itemsObject instanceof List<?>)) {
			throw new IllegalArgumentException("明細品目データが正しくありません。");
		}

		List<?> rawItems = (List<?>) itemsObject;

		if (rawItems.isEmpty() || rawItems.size() > 200) {
			throw new IllegalArgumentException("品目は1件以上200件以下で入力してください。");
		}

		List<Map<String, Object>> prepared = new ArrayList<Map<String, Object>>();

		BigDecimal supplyTotal = BigDecimal.ZERO;
		BigDecimal vatTotal = BigDecimal.ZERO;

		int lineNo = 1;

		for (Object raw : rawItems) {

			if (!(raw instanceof Map<?, ?>)) {
				throw new IllegalArgumentException("明細品目の形式が正しくありません。");
			}

			Map<String, Object> itemRequest = (Map<String, Object>) raw;

			String itemCode = required(itemRequest.get("item_code"), "品目コード", 50);

			Map<String, Object> master = mapper.findItem(itemCode);

			if (master == null) {
				throw new IllegalArgumentException("未登録の品目コード： " + itemCode);
			}

			Map<String, Object> item = new HashMap<String, Object>();

			item.put("line_no", lineNo++);
			item.put("item_id", idOf(master));
			item.put("item_code", master.get("code"));

			String itemName = str(itemRequest.get("item_name"));

			if (itemName.isEmpty()) {
				itemName = str(master.get("name"));
			}

			item.put("item_name", required(itemName, "品目名", 100));

			item.put("spec", optional(itemRequest.get("spec"), 100));

			String unitName = str(itemRequest.get("unit_name"));

			if (unitName.isEmpty()) {
				unitName = str(master.get("unit_name"));
			}

			item.put("unit_name", optional(unitName, 20));

			BigDecimal quantity = decimal(itemRequest.get("quantity"), "数量", 14, 4, true);

			BigDecimal unitPrice = decimal(itemRequest.get("unit_price"), "単価", 16, 2, false);

			BigDecimal supply = decimal(itemRequest.get("supply_amount"), "供給価額", 16, 2, false);

			BigDecimal vat = decimal(itemRequest.get("vat_amount"), "消費税", 16, 2, false);

			BigDecimal total = supply.add(vat).setScale(2, RoundingMode.HALF_UP);

			if (total.precision() > 18) {
				throw new IllegalArgumentException("品目の合計金額が許容範囲を超えています。");
			}

			item.put("quantity", quantity);
			item.put("unit_price", unitPrice);
			item.put("supply_amount", supply);
			item.put("vat_amount", vat);
			item.put("total_amount", total);

			// 수정 화면이 적요를 전달했는지 구분
			// 編集画面が摘要を送ったかどうかを区別
			item.put("_remarks_supplied", itemRequest.containsKey("remarks"));

			item.put("remarks", optional(itemRequest.get("remarks"), 1000));

			prepared.add(item);

			supplyTotal = supplyTotal.add(supply);
			vatTotal = vatTotal.add(vat);
		}

		// DB 변경 전에 기존 적요 보존 처리
		// DB更新前に既存の摘要を保護
		preserveMissingRemarks(existingItems, prepared);

		data.put("supply_amount", supplyTotal.setScale(2, RoundingMode.HALF_UP));

		data.put("vat_amount", vatTotal.setScale(2, RoundingMode.HALF_UP));

		data.put("total_amount", supplyTotal.add(vatTotal).setScale(2, RoundingMode.HALF_UP));

		// 견적서 기본정보 수정
		// 見積書の基本情報を更新
		if (mapper.updateHeader(quoteId, data) != 1) {
			throw new IllegalStateException("見積書の基本情報の更新に失敗しました。");
		}

		// 상세품목 재등록
		// 明細品目を再登録
		mapper.deleteItems(quoteId);

		for (Map<String, Object> item : prepared) {

			if (mapper.insertItem(quoteId, item) != 1) {
				throw new IllegalStateException("見積明細の更新に失敗しました。");
			}
		}
	}
}
