package org.sales.estimate.service;

import java.util.List;
import java.util.Map;

import org.sales.estimate.domain.QuotationCriteria;
import org.sales.estimate.domain.QuotationInquiryVO;

// 견적서 조회 서비스
// 見積書照会サービス
public interface QuotationInquiryService {

	// 견적서 목록 조회
	// 見積書一覧照会
	List<QuotationInquiryVO> getList(QuotationCriteria criteria);

	// 수정 모달에 표시할 견적서
	// 編集モーダルに表示する見積書
	Map<String, Object> getDetail(Long quoteId);

	// 견적서에서 생성한 주문서 조회
	// 見積書から作成した受注伝票を取得
	Map<String, Object> getGeneratedOrders(Long quoteId);

	// 진행 중 / 완료 변경
	// 進行中／完了への変更
	void changeProgress(Long quoteId, String status);

	// 결재 중 / 미확인 / 확인 상태 저장
	// 承認中／未確認／確認済みの状態を保存
	void changeUiStatus(Long quoteId, String status);

	// 선택한 견적서 취소
	// 選択した見積書を取り消す
	int cancelSelected(List<Long> quoteIds);

	// 견적서 기본정보 및 품목 수정
	// 見積書の基本情報と品目を修正
	void updateQuotation(Long quoteId, Map<String, Object> request);

	// 수정 모달 기준정보 검색
	// 編集モーダルのマスター検索
	List<Map<String, Object>> searchMaster(String type, String keyword);
}
