package org.sales.estimate.domain;

import java.math.BigDecimal;

import lombok.Data;

// 견적서조회 VO
// 見積書照会VO
@Data
public class QuotationInquiryVO {

	// 견적서 기본정보
	// 見積書基本情報
	private Long quote_id;
	private String voucher_no;
	private String quote_date;
	private String valid_until;

	// 조회용 표시정보
	// 一覧表示情報
	private String partner_name;
	private String manager_name;
	private String item_summary;

	private BigDecimal total_amount;

	// Oracle 견적서 진행상태
	// Oracleに保存された見積書の進捗状態
	private String progress_status;

	// Oracle 전표상태
	// Oracleの伝票状態
	private String voucher_status;

	// 연결된 주문서 존재 여부 (1: 있음, 0: 없음)
	// 関連受注伝票の有無（1：あり、0：なし）
	private Integer has_orders;

	// Oracle 전표이력에서 조회한 화면 상태
	// Oracleの伝票履歴から取得した画面状態
	private String ui_status;
}
