package org.sales.estimate.mapper;

import java.util.List;

import org.sales.estimate.domain.QuotationCriteria;
import org.sales.estimate.domain.QuotationStatusVO;

// 견적서현황 Mapper
// 見積書現況Mapper
public interface QuotationStatusMapper {

	// 조건별 견적서현황 조회
	// 条件別の見積書現況取得
	public List<QuotationStatusVO> getStatusList(QuotationCriteria criteria);
}
