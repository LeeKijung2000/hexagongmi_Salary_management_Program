package org.sales.estimate.service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;

import org.sales.estimate.domain.QuotationCriteria;
import org.sales.estimate.domain.QuotationUnorderVO;
import org.sales.estimate.mapper.QuotationUnorderMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

// 미주문현황 Service 구현
// 未受注現況Service実装
@Service
public class QuotationUnorderServiceImpl implements QuotationUnorderService {

	private static final int MAX_SEARCH_LENGTH = 100;

	private final QuotationUnorderMapper mapper;

	@Autowired
	public QuotationUnorderServiceImpl(QuotationUnorderMapper mapper) {
		this.mapper = mapper;
	}

	// 미주문현황 조회
	// 未受注現況照会
	@Override
	@Transactional(readOnly = true)
	public List<QuotationUnorderVO> getUnorderList(QuotationCriteria search) {

		if (search == null) {
			search = new QuotationCriteria();
		}

		// 검색어 앞뒤 공백 제거
		// 検索語の前後空白を除去
		search.setBase_date(clean(search.getBase_date()));

		search.setVoucher_no(clean(search.getVoucher_no()));

		search.setWarehouse_keyword(clean(search.getWarehouse_keyword()));

		search.setPartner_keyword(clean(search.getPartner_keyword()));

		search.setItem_keyword(clean(search.getItem_keyword()));

		search.setManager_keyword(clean(search.getManager_keyword()));

		search.setProgress_status(clean(search.getProgress_status()));

		// 날짜 검증
		// 日付の検証
		validateDate(search.getBase_date());

		// 검색어 길이 검증
		// 検索語の長さを検証
		validateText(search.getVoucher_no());
		validateText(search.getWarehouse_keyword());
		validateText(search.getPartner_keyword());
		validateText(search.getItem_keyword());
		validateText(search.getManager_keyword());

		// 미주문수량 범위 검증
		// 未受注数量の範囲を検証
		validateQuantity(search.getMin_unordered_qty(), search.getMax_unordered_qty());

		// 진행상태 검증
		// 進捗状態を検証
		validateStatus(search.getProgress_status());

		// Oracle 조회
		// Oracleデータの取得
		return mapper.getUnorderList(search);
	}

	// 공백을 제거하고 빈 문자열을 null로 변환
	// 空白を除去し、空文字をnullに変換
	private String clean(String value) {

		if (value == null) {
			return null;
		}

		String result = value.trim();

		return result.isEmpty() ? null : result;
	}

	// 날짜 형식 및 Oracle 유효 연도 검사
	// 日付形式とOracle有効年のチェック
	private void validateDate(String date) {

		// 날짜를 입력하지 않으면 날짜 제한 없이 조회
		// 日付が未入力の場合、期間制限なしで検索
		if (date == null) {
			return;
		}

		// YYYY-MM-DD 형식 검사
		// YYYY-MM-DD形式を検証
		if (!date.matches("[0-9]{4}-[0-9]{2}-[0-9]{2}")) {

			throw new IllegalArgumentException("基準日はyyyy-MM-dd形式で入力してください。");
		}

		try {
			// 실제 존재하는 날짜인지 확인
			// 実在する日付か確認
			LocalDate parsedDate = LocalDate.parse(date);

			// Oracle DATE의 연도 범위 검사
			// Oracle DATE型の年の範囲を確認
			if (parsedDate.getYear() < 1 || parsedDate.getYear() > 9999) {

				throw new IllegalArgumentException("基準日の年は0001年から " + "9999年まで入力できます。");
			}

		} catch (DateTimeParseException e) {

			throw new IllegalArgumentException("正しい基準日を入力してください。");
		}
	}

	// 검색어 길이 검사
	// 検索文字数チェック
	private void validateText(String value) {

		if (value != null && value.length() > MAX_SEARCH_LENGTH) {

			throw new IllegalArgumentException("検索キーワードは100文字以内で入力してください。");
		}
	}

	// 미주문수량 최소값/최대값 검사
	// 未受注数量の最小値・最大値チェック
	private void validateQuantity(BigDecimal min, BigDecimal max) {

		// 최소 미주문수량은 0 이상
		// 最小未受注数量は0以上
		if (min != null && min.compareTo(BigDecimal.ZERO) < 0) {

			throw new IllegalArgumentException("最小未受注数量は0以上にしてください。");
		}

		// 최대 미주문수량은 0 이상
		// 最大未受注数量は0以上
		if (max != null && max.compareTo(BigDecimal.ZERO) < 0) {

			throw new IllegalArgumentException("最大未受注数量は0以上にしてください。");
		}

		// 최소값이 최대값보다 클 수 없음
		// 最小値が最大値を超えることはできない
		if (min != null && max != null && min.compareTo(max) > 0) {

			throw new IllegalArgumentException("最小未受注数量は最大値を超えることができません。");
		}
	}

	// 기존 Oracle 진행상태만 허용
	// 既存のOracle進捗状態のみ許可
	private void validateStatus(String status) {

		if (status == null) {
			return;
		}

		if (!status.equals("OPEN") && !status.equals("PARTIAL") && !status.equals("COMPLETED")) {

			throw new IllegalArgumentException("進捗状態が正しくありません。");
		}
	}
}
