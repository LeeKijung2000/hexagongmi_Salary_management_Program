package org.sales.estimate.controller;

import java.util.List;

import org.sales.estimate.domain.QuotationCriteria;
import org.sales.estimate.domain.QuotationStatusVO;
import org.sales.estimate.service.QuotationStatusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

// 견적서현황 REST Controller
// 見積書現況RESTコントローラー
@RestController
@RequestMapping("/sales/estimate/api")
public class QuotationStatusController {

	private final QuotationStatusService service;

	@Autowired
	public QuotationStatusController(QuotationStatusService service) {
		this.service = service;
	}

	// 견적서현황 조회
	// 見積書現況の照会
	@GetMapping("/status")
	public ResponseEntity<List<QuotationStatusVO>> getStatus(@ModelAttribute QuotationCriteria criteria) {

		List<QuotationStatusVO> result = service.getStatusList(criteria);

		return ResponseEntity.ok(result);
	}

	// 잘못된 검색조건 처리
	// 不正な検索条件の処理
	@ExceptionHandler(IllegalArgumentException.class)
	public ResponseEntity<String> handleInvalidInput(IllegalArgumentException ex) {

		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ex.getMessage());
	}
}
