package org.sales.estimate.service;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;

import org.sales.estimate.domain.QuotationCriteria;
import org.sales.estimate.domain.QuotationStatusVO;
import org.sales.estimate.mapper.QuotationStatusMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

// 견적서현황 서비스 구현
// 見積書現況サービス実装
@Service
public class QuotationStatusServiceImpl implements QuotationStatusService {

	private final QuotationStatusMapper mapper;

	@Autowired
	public QuotationStatusServiceImpl(QuotationStatusMapper mapper) {
		this.mapper = mapper;
	}

	// 견적서현황 조회
	// 見積書現況照会
	@Override
	public List<QuotationStatusVO> getStatusList(QuotationCriteria criteria) {

		if (criteria == null) {
			criteria = new QuotationCriteria();
		}

		// 검색조건 공백 제거
		// 検索条件の前後空白を除去
		criteria.setStart_date(trimToEmpty(criteria.getStart_date()));

		criteria.setEnd_date(trimToEmpty(criteria.getEnd_date()));

		criteria.setVoucher_no(trimToEmpty(criteria.getVoucher_no()));

		criteria.setPartner_name(trimToEmpty(criteria.getPartner_name()));

		criteria.setItem_keyword(trimToEmpty(criteria.getItem_keyword()));

		criteria.setManager_name(trimToEmpty(criteria.getManager_name()));

		criteria.setProgress_status(trimToEmpty(criteria.getProgress_status()));

		// 날짜 형식 및 실제 날짜 검사
		// 日付の形式と実在する日付を検証
		LocalDate startDate = validateDate(criteria.getStart_date(), "開始日");

		LocalDate endDate = validateDate(criteria.getEnd_date(), "終了日");

		// 날짜 범위 검사
		// 日付範囲を検証
		if (startDate != null && endDate != null && startDate.isAfter(endDate)) {

			throw new IllegalArgumentException("開始日は終了日より後にできません。");
		}

		// 진행상태 검사
		// 進捗状態を検証
		String progressStatus = criteria.getProgress_status();

		if (!progressStatus.isEmpty() && !progressStatus.equals("OPEN") && !progressStatus.equals("PARTIAL")
				&& !progressStatus.equals("COMPLETED")) {

			throw new IllegalArgumentException("進捗状態が正しくありません。");
		}

		// Oracle 견적서현황 조회
		// Oracleから見積書現況を取得
		return mapper.getStatusList(criteria);
	}

	// null 처리 및 공백 제거
	// null処理と空白除去
	private String trimToEmpty(String value) {

		if (value == null) {
			return "";
		}

		return value.trim();
	}

	// 날짜 형식 검사
	// 日付形式チェック
	private LocalDate validateDate(String value, String fieldName) {

		// 날짜 미입력 시 전체 범위 허용
		// 日付未入力の場合は全期間を許可
		if (value == null || value.isEmpty()) {
			return null;
		}

		// YYYY-MM-DD 형식 확인
		// YYYY-MM-DD形式を確認
		if (!value.matches("[0-9]{4}-[0-9]{2}-[0-9]{2}")) {

			throw new IllegalArgumentException(fieldName + "はYYYY-MM-DD形式で入力してください。");
		}

		try {
			LocalDate result = LocalDate.parse(value);

			// Oracle DATE에 사용할 연도 범위 검사
			// Oracle DATEで扱える年の範囲を確認
			if (result.getYear() < 1 || result.getYear() > 9999) {

				throw new IllegalArgumentException(fieldName + "の年が正しくありません。");
			}

			return result;

		} catch (DateTimeParseException e) {

			throw new IllegalArgumentException(fieldName + "に正しい日付を入力してください。");
		}
	}
}
