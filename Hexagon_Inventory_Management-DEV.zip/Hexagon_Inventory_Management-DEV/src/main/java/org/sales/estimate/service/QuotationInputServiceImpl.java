package org.sales.estimate.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.sales.estimate.domain.QuotationInputVO;
import org.sales.estimate.mapper.QuotationInputMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

// 견적서입력 Service 구현
// 見積書入力サービス実装
@Service
public class QuotationInputServiceImpl implements QuotationInputService {

	private final QuotationInputMapper mapper;

	private static final long MAX_FILE_SIZE = 10L * 1024L * 1024L;

	private static final Set<String> ALLOWED_EXT = new HashSet<String>(
			Arrays.asList("pdf", "png", "jpg", "jpeg", "docx", "xlsx", "txt"));

	private final Path uploadRoot = Paths.get(System.getProperty("user.home"), "hexagon-attachments", "quotation")
			.toAbsolutePath().normalize();

	@Autowired
	public QuotationInputServiceImpl(QuotationInputMapper mapper) {
		this.mapper = mapper;
	}

	// 값이 비어 있는지 확인
	// 値が空かどうかを確認
	private boolean blank(String value) {
		return value == null || value.trim().isEmpty();
	}

	// 문자 길이 검사
	// 文字数の検証
	private void checkTextLength(String value, int maxLength, String label) {

		if (value != null && value.length() > maxLength) {
			throw new IllegalArgumentException(label + "は最大 " + maxLength + "文字まで入力できます。");
		}
	}

	// Oracle NUMBER 자릿수 검사
	// Oracle NUMBER型の桁数検証
	private void checkDecimalRange(BigDecimal value, int integerDigits, int scale, String label) {

		if (value == null) {
			throw new IllegalArgumentException(label + "を入力してください。");
		}

		if (value.scale() > scale || value.precision() - value.scale() > integerDigits) {

			throw new IllegalArgumentException(label + "の桁数を確認してください。");
		}
	}

	// 금액을 소수 둘째 자리로 반올림하고 자릿수 검사
	// 金額を小数第2位に丸め、桁数を検証
	private BigDecimal money(BigDecimal value) {
		if (value == null) {
			throw new IllegalArgumentException("金額を入力してください。");
		}

		BigDecimal result = value.setScale(2, RoundingMode.HALF_UP);

		// 정수 최대 16자리, 소수 최대 2자리
		// 整数部は最大16桁、小数部は最大2桁
		checkDecimalRange(result, 16, 2, "金額");

		return result;
	}

	// 통화 목록
	// 通貨一覧
	@Override
	public List<Map<String, Object>> getCurrencies() {
		return mapper.getCurrencies();
	}

	// 기준정보 조회
	// マスター検索
	@Override
	public List<Map<String, Object>> searchLookup(String type, String keyword) {

		String word = keyword == null ? "" : keyword.trim();

		if (word.length() > 100) {
			throw new IllegalArgumentException("検索キーワードは100文字以内で入力してください。");
		}

		if (type == null) {
			throw new IllegalArgumentException("検索種別が正しくありません。");
		}

		switch (type) {

		case "partner":
			return mapper.searchPartners(word);

		case "manager":
			return mapper.searchManagers(word);

		case "warehouse":
			return mapper.searchWarehouses(word);

		case "item":
			return mapper.searchItems(word);

		default:
			throw new IllegalArgumentException("検索種別が正しくありません。");
		}
	}

	// 재고불러오기
	// 在庫照会
	// 출하창고가 없어도 전체재고 조회 가능
	// 出荷倉庫が未指定でも全体在庫を照会可能
	@Override
	public List<Map<String, Object>> loadInventory(List<String> itemCodes, String warehouseCode) {

		if (itemCodes == null || itemCodes.isEmpty()) {
			throw new IllegalArgumentException("在庫を照会する品目を入力してください。");
		}

		// 중복 품목코드 제거
		// 重複コード除去
		Set<String> uniqueCodes = new LinkedHashSet<String>();

		for (String code : itemCodes) {

			if (blank(code)) {
				continue;
			}

			String normalized = code.trim();

			if (normalized.length() > 50) {
				throw new IllegalArgumentException("品目コードの長さを確認してください。");
			}

			uniqueCodes.add(normalized);
		}

		if (uniqueCodes.isEmpty()) {
			throw new IllegalArgumentException("在庫を照会する品目がありません。");
		}

		if (uniqueCodes.size() > 100) {
			throw new IllegalArgumentException("一度に照会できる品目は最大100件です。");
		}

		// 출하창고 미선택이면 null 전달
		// 出荷倉庫が未選択の場合はnullを渡す
		String selectedWarehouseCode = null;

		if (!blank(warehouseCode)) {

			Map<String, Object> warehouse = mapper.findWarehouseByCode(warehouseCode.trim());

			if (warehouse == null) {
				throw new IllegalArgumentException("未登録の出荷倉庫コードです。");
			}

			selectedWarehouseCode = String.valueOf(warehouse.get("code"));
		}

		return mapper.loadInventory(new ArrayList<String>(uniqueCodes), selectedWarehouseCode);
	}

	// 견적서 저장
	// 見積書登録
	@Override
	@Transactional(rollbackFor = Exception.class)
	public Long saveQuotation(QuotationInputVO vo) {

		if (vo == null) {
			throw new IllegalArgumentException("見積書データがありません。");
		}

		// 견적일자 확인
		// 見積日付確認
		if (blank(vo.getQuote_date())) {
			throw new IllegalArgumentException("見積日を入力してください。");
		}

		String quoteDate = vo.getQuote_date().trim();

		try {
			LocalDate.parse(quoteDate);

		} catch (RuntimeException ex) {
			throw new IllegalArgumentException("見積日を確認してください。");
		}

		vo.setQuote_date(quoteDate);

		// 거래처 확인
		// 取引先確認
		if (blank(vo.getPartner_code())) {
			throw new IllegalArgumentException("取引先を選択してください。");
		}

		checkTextLength(vo.getPartner_code().trim(), 50, "取引先コード");

		Map<String, Object> partner = mapper.findPartnerByCode(vo.getPartner_code().trim());

		if (partner == null) {
			throw new IllegalArgumentException("未登録の取引先コードです。");
		}

		vo.setBusiness_partner_id(((Number) partner.get("id")).longValue());

		// 담당자 확인
		// 担当者確認
		if (!blank(vo.getEmployee_code())) {

			Map<String, Object> manager = mapper.findManagerByCode(vo.getEmployee_code().trim());

			if (manager == null) {
				throw new IllegalArgumentException("未登録の担当者コードです。");
			}

			vo.setManager_id(((Number) manager.get("id")).longValue());

		} else {
			vo.setManager_id(null);
		}

		// 출하창고 확인
		// 倉庫確認
		if (!blank(vo.getWarehouse_code())) {

			Map<String, Object> warehouse = mapper.findWarehouseByCode(vo.getWarehouse_code().trim());

			if (warehouse == null) {
				throw new IllegalArgumentException("未登録の出荷倉庫コードです。");
			}

			vo.setWarehouse_id(((Number) warehouse.get("id")).longValue());

		} else {
			vo.setWarehouse_id(null);
		}

		// 통화 확인
		// 通貨確認
		if (vo.getCurrency_id() == null || mapper.findCurrencyById(vo.getCurrency_id()) == null) {

			throw new IllegalArgumentException("利用可能な通貨を選択してください。");
		}

		// 환율 확인
		// 為替レート確認
		if (vo.getExchange_rate() == null || vo.getExchange_rate().compareTo(BigDecimal.ZERO) <= 0) {

			throw new IllegalArgumentException("為替レートは0より大きい値にしてください。");
		}

		checkDecimalRange(vo.getExchange_rate(), 12, 6, "為替レート");

		// 거래유형 확인
		// 取引区分確認
		if (!"TAXABLE".equals(vo.getTransaction_type()) && !"EXEMPT".equals(vo.getTransaction_type())) {

			throw new IllegalArgumentException("取引区分を確認してください。");
		}

		// 견적서 적요 길이 확인
		// 見積書の摘要欄の文字数を確認
		checkTextLength(vo.getRemarks(), 1000, "見積書の摘要");

		// 상세품목 확인
		// 明細確認
		if (vo.getItems() == null || vo.getItems().isEmpty()) {
			throw new IllegalArgumentException("見積品目を1件以上入力してください。");
		}

		if (vo.getItems().size() > 200) {
			throw new IllegalArgumentException("見積品目は最大200件まで入力できます。");
		}

		BigDecimal supplyTotal = BigDecimal.ZERO;
		BigDecimal vatTotal = BigDecimal.ZERO;

		int lineNo = 1;

		for (QuotationInputVO.Item item : vo.getItems()) {

			// 품목코드 확인
			// 品目コード確認
			if (item == null || blank(item.getItem_code_snap())) {
				throw new IllegalArgumentException("品目コードを入力してください。");
			}

			String itemCode = item.getItem_code_snap().trim();

			checkTextLength(itemCode, 50, "品目コード");

			Map<String, Object> master = mapper.findItemByCode(itemCode);

			if (master == null) {
				throw new IllegalArgumentException("未登録の品目コード： " + itemCode);
			}

			item.setItem_id(((Number) master.get("id")).longValue());

			item.setItem_code_snap(String.valueOf(master.get("code")));

			// 품목명 확인
			// 品目名確認
			// 품목명 직접 수정 허용
			// 品目名の直接編集を許可
			if (blank(item.getItem_name_snap())) {
				item.setItem_name_snap(String.valueOf(master.get("name")));
			}

			if (blank(item.getItem_name_snap())) {
				throw new IllegalArgumentException("品目名を入力してください。");
			}

			checkTextLength(item.getItem_name_snap(), 100, "品目名");

			// 규격 확인
			// 規格確認
			// 규격 직접 수정 허용
			// 規格の直接編集を許可
			if (item.getSpec_snap() == null) {

				Object spec = master.get("specification");

				item.setSpec_snap(spec == null ? null : String.valueOf(spec));
			}

			checkTextLength(item.getSpec_snap(), 100, "規格");

			// 단위 확인
			// 単位確認
			if (blank(item.getUnit_snap())) {

				Object unit = master.get("unit_name");

				item.setUnit_snap(unit == null ? null : String.valueOf(unit));
			}

			checkTextLength(item.getUnit_snap(), 20, "単位");

			// 수량 확인
			// 数量確認
			if (item.getQuantity() == null || item.getQuantity().compareTo(BigDecimal.ZERO) <= 0) {

				throw new IllegalArgumentException("数量は0より大きい値にしてください。");
			}

			checkDecimalRange(item.getQuantity(), 14, 4, "数量");

			// 단가 확인
			// 単価確認
			if (item.getUnit_price() == null || item.getUnit_price().compareTo(BigDecimal.ZERO) < 0) {

				throw new IllegalArgumentException("単価は0以上にしてください。");
			}

			checkDecimalRange(item.getUnit_price(), 16, 2, "単価");

			// 공급가액 및 부가세
			// 金額確認
			// 기존 수동 입력값 유지
			// 既存の手入力値を維持
			item.setSupply_amount(money(item.getSupply_amount()));

			item.setVat_amount(money(item.getVat_amount()));

			if (item.getSupply_amount().compareTo(BigDecimal.ZERO) < 0
					|| item.getVat_amount().compareTo(BigDecimal.ZERO) < 0) {

				throw new IllegalArgumentException("供給価額と消費税は0以上にしてください。");
			}

			// 품목 합계
			// 明細合計
			BigDecimal itemTotal = item.getSupply_amount().add(item.getVat_amount());

			item.setTotal_amount(money(itemTotal));

			checkTextLength(item.getRemarks(), 1000, "品目の摘要");

			item.setLine_no(lineNo++);

			supplyTotal = supplyTotal.add(item.getSupply_amount());

			vatTotal = vatTotal.add(item.getVat_amount());
		}

		// 견적서 합계
		// 見積書合計
		vo.setSupply_amount(money(supplyTotal));
		vo.setVat_amount(money(vatTotal));

		vo.setTotal_amount(money(supplyTotal.add(vatTotal)));

		// 견적서 ID 및 전표번호 발급
		// 見積書IDと伝票番号を採番
		Long quoteId = mapper.nextQuoteId();

		vo.setQuote_id(quoteId);
		vo.setVoucher_no("EST-" + quoteId);

		// 견적서 기본정보 저장
		// 見積書の基本情報を保存
		if (mapper.insertQuotation(vo) != 1) {
			throw new IllegalStateException("見積書の基本情報の保存に失敗しました。");
		}

		// 견적서 상세품목 저장
		// 見積書の明細品目を保存
		for (QuotationInputVO.Item item : vo.getItems()) {

			if (mapper.insertQuotationItem(quoteId, item) != 1) {
				throw new IllegalStateException("見積明細の保存に失敗しました。");
			}
		}

		return quoteId;
	}

	// 첨부파일 업로드
	// 添付保存
	@Override
	@Transactional(rollbackFor = Exception.class)
	public String uploadAttachment(Long quote_id, MultipartFile file) throws IOException {

		if (quote_id == null || quote_id <= 0) {
			throw new IllegalArgumentException("見積書IDが正しくありません。");
		}

		if (file == null || file.isEmpty()) {
			throw new IllegalArgumentException("添付ファイルを選択してください。");
		}

		if (file.getSize() > MAX_FILE_SIZE) {
			throw new IllegalArgumentException("添付ファイルは10MB以下にしてください。");
		}

		String original = file.getOriginalFilename();

		if (blank(original)) {
			throw new IllegalArgumentException("ファイル名を確認してください。");
		}

		original = original.replace("\\", "/");
		original = original.substring(original.lastIndexOf("/") + 1);

		int dot = original.lastIndexOf(".");

		if (dot < 0) {
			throw new IllegalArgumentException("ファイルの拡張子がありません。");
		}

		String ext = original.substring(dot + 1).toLowerCase(Locale.ROOT);

		if (!ALLOWED_EXT.contains(ext)) {
			throw new IllegalArgumentException("許可されていないファイル形式です。");
		}

		Files.createDirectories(uploadRoot);

		String storedName = UUID.randomUUID().toString() + "." + ext;

		Path target = uploadRoot.resolve(storedName).normalize();

		if (!target.startsWith(uploadRoot)) {
			throw new IllegalArgumentException("ファイルのパスが正しくありません。");
		}

		try {
			try (InputStream input = file.getInputStream()) {
				Files.copy(input, target, StandardCopyOption.REPLACE_EXISTING);
			}

			int updated = mapper.updateAttachmentPath(quote_id, storedName);

			if (updated != 1) {
				throw new IllegalArgumentException("該当する見積書が見つかりません。");
			}

			return storedName;

		} catch (Exception ex) {

			Files.deleteIfExists(target);

			if (ex instanceof IOException) {
				throw (IOException) ex;
			}

			if (ex instanceof RuntimeException) {
				throw (RuntimeException) ex;
			}

			throw new IOException(ex);
		}
	}

	@Override
	public String getAttachmentPath(Long quote_id) {
		return mapper.getAttachmentPath(quote_id);
	}

	// 첨부파일 다운로드
	// 添付取得
	@Override
	public byte[] downloadAttachment(Long quote_id) throws IOException {

		String storedName = mapper.getAttachmentPath(quote_id);

		if (blank(storedName)) {
			throw new FileNotFoundException("添付ファイルがありません。");
		}

		if (!storedName.matches("[0-9a-fA-F-]{36}\\.(pdf|png|jpg|jpeg|docx|xlsx|txt)")) {

			throw new IllegalArgumentException("添付ファイルのパスが正しくありません。");
		}

		Path file = uploadRoot.resolve(storedName).normalize();

		if (!file.startsWith(uploadRoot)) {
			throw new IllegalArgumentException("ファイルのパスが正しくありません。");
		}

		return Files.readAllBytes(file);
	}
}
