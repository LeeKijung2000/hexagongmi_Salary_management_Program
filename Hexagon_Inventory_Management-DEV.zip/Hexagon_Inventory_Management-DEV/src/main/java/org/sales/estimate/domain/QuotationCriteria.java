package org.sales.estimate.domain;

import java.math.BigDecimal;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

// 견적서 공통 검색조건
// 見積書共通検索条件
// 견적서조회, 견적서현황, 미주문현황에서 사용
// 見積書照会、見積書現況、未受注現況で使用
@Getter
@Setter
@ToString
public class QuotationCriteria {

	// 견적서조회 검색조건
	// 見積書照会の検索条件

	// 조회 시작일
	// 検索開始日
	private String startDate;

	// 조회 종료일
	// 検索終了日
	private String endDate;

	// 검색어
	// 検索キーワード
	private String keyword;

	// 화면 상태
	// 画面状態
	private String status;

	// 견적서현황 검색조건
	// 見積書現況の検索条件

	// 조회 시작일
	// 検索開始日
	private String start_date;

	// 조회 종료일
	// 検索終了日
	private String end_date;

	// 전표번호
	// 伝票番号
	private String voucher_no;

	// 거래처명
	// 取引先名
	private String partner_name;

	// 품목 검색어
	// 品目検索キーワード
	private String item_keyword;

	// 담당자명
	// 担当者名
	private String manager_name;

	// 진행상태
	// 進捗状態
	private String progress_status;

	// 미주문현황 검색조건
	// 未受注見積書の検索条件

	// 기준일자
	// 基準日
	private String base_date;

	// 출하창고 검색어
	// 出荷倉庫検索
	private String warehouse_keyword;

	// 거래처 검색어
	// 取引先検索
	private String partner_keyword;

	// 담당자 검색어
	// 担当者検索
	private String manager_keyword;

	// 최소 미주문수량
	// 最小未受注数量
	private BigDecimal min_unordered_qty;

	// 최대 미주문수량
	// 最大未受注数量
	private BigDecimal max_unordered_qty;
}
