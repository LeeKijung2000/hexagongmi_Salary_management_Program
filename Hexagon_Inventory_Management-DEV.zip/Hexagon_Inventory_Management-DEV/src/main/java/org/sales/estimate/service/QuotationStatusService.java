package org.sales.estimate.service;

import java.util.List;

import org.sales.estimate.domain.QuotationCriteria;
import org.sales.estimate.domain.QuotationStatusVO;

// 견적서현황 서비스
// 見積書現況サービス
public interface QuotationStatusService {

	// 견적서현황 목록 조회
	// 見積書現況一覧の取得
	public List<QuotationStatusVO> getStatusList(QuotationCriteria criteria);
}
