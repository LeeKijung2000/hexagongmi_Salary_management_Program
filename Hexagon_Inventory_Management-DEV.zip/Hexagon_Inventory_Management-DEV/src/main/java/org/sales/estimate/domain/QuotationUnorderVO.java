package org.sales.estimate.domain;

import java.math.BigDecimal;

import lombok.Data;

// 미주문현황 조회 결과
// 未受注現況照会結果
@Data
public class QuotationUnorderVO {

	// 견적서 및 상세행 식별번호
	// 見積書と明細行の識別番号
	private Long quote_id;
	private Long quote_item_id;

	// 품목별 집계용 식별번호
	// 品目別の集計に使用する識別番号
	private Long item_id;

	// 견적서 기본정보
	// 見積書の基本情報
	private String voucher_no;
	private String quote_date;

	// 거래처, 담당자, 창고
	// 取引先、担当者、倉庫
	private String partner_name;
	private String manager_name;
	private String warehouse_name;

	// 품목 기본정보
	// 品目の基本情報
	private String item_code_snap;
	private String item_name_snap;
	private String spec_snap;

	// 견적수량, 주문수량, 미주문수량
	// 見積数量、受注数量、未受注数量
	private BigDecimal quote_qty;
	private BigDecimal ordered_qty;
	private BigDecimal unordered_qty;

	// 미주문 공급가액, 부가세
	// 未受注の供給価額と付加価値税
	private BigDecimal unordered_supply_amount;
	private BigDecimal unordered_vat_amount;

	// 견적서 추가항목
	// 見積書の追加項目
	private String custom_data;
}
