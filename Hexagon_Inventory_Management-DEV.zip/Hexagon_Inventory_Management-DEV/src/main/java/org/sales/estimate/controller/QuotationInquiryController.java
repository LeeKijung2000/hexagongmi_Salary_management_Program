package org.sales.estimate.controller;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.sales.estimate.domain.QuotationCriteria;
import org.sales.estimate.domain.QuotationInquiryVO;
import org.sales.estimate.service.QuotationInquiryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

// 견적서조회 REST Controller
// 見積書照会RESTコントローラー
@RestController
@RequestMapping("/sales/estimate/api")
public class QuotationInquiryController {

	private final QuotationInquiryService service;

	@Autowired
	public QuotationInquiryController(QuotationInquiryService service) {
		this.service = service;
	}

	// 견적서 목록 조회
	// 見積書一覧の取得
	@GetMapping("/quotations")
	public List<QuotationInquiryVO> getList(@ModelAttribute QuotationCriteria criteria) {

		return service.getList(criteria);
	}

	// 견적서 상세정보 조회
	// 見積書詳細情報の取得
	@GetMapping("/quotations/{id}/detail")
	public Map<String, Object> getDetail(@PathVariable("id") Long id) {

		return service.getDetail(id);
	}

	// 생성한 전표 조회
	// 作成済み伝票の照会
	@GetMapping("/quotations/{id}/orders")
	public Map<String, Object> getOrders(@PathVariable("id") Long id) {

		return service.getGeneratedOrders(id);
	}

	// 수정 화면의 기준정보 검색
	// 編集画面のマスター検索
	@GetMapping("/quotation-lookup/{type}")
	public List<Map<String, Object>> searchMaster(@PathVariable("type") String type,
			@RequestParam(value = "keyword", defaultValue = "") String keyword) {

		return service.searchMaster(type, keyword);
	}

	// 견적서 상태 변경
	// 見積書の状態変更
	@PutMapping("/quotations/{id}/status")
	public ResponseEntity<Map<String, Object>> changeStatus(@PathVariable("id") Long id,
			@RequestBody Map<String, Object> request) {

		if (request == null || request.get("status") == null) {
			throw new IllegalArgumentException("変更する状態を選択してください。");
		}

		String status = String.valueOf(request.get("status")).trim();

		// 결재 중, 미확인, 확인 상태 변경
		// 承認中・未確認・確認済み状態の変更
		if ("APPROVAL".equals(status) || "UNREAD".equals(status) || "CONFIRMED".equals(status)) {

			service.changeUiStatus(id, status);

			// 진행 중, 완료 상태 변경
			// 進行中・完了状態の変更
		} else if ("PROGRESS".equals(status) || "COMPLETE".equals(status)) {

			service.changeProgress(id, status);

		} else {
			throw new IllegalArgumentException("進捗状態が正しくありません。");
		}

		return ResponseEntity.ok(successBody("進捗状態を変更しました。", null));
	}

	// 선택한 견적서 취소 처리
	// 選択した見積書の取消処理
	@PostMapping("/quotations/cancel")
	public ResponseEntity<Map<String, Object>> cancelSelected(@RequestBody List<Long> quoteIds) {

		int count = service.cancelSelected(quoteIds);

		return ResponseEntity.ok(successBody(count + "件を取り消しました。", count));
	}

	// 견적서 수정
	// 見積書の修正
	@PutMapping("/quotations/{id}")
	public ResponseEntity<Map<String, Object>> updateQuotation(@PathVariable("id") Long id,
			@RequestBody Map<String, Object> request) {

		service.updateQuotation(id, request);

		return ResponseEntity.ok(successBody("見積書が更新されました。", null));
	}

	// 잘못된 요청 처리
	// 不正なリクエストの処理
	@ExceptionHandler(IllegalArgumentException.class)
	public ResponseEntity<Map<String, Object>> invalidRequest(IllegalArgumentException ex) {

		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorBody("VALIDATION_ERROR", ex.getMessage()));
	}

	// 처리할 수 없는 상태 오류
	// 処理できない状態のエラー
	@ExceptionHandler(IllegalStateException.class)
	public ResponseEntity<Map<String, Object>> conflict(IllegalStateException ex) {

		return ResponseEntity.status(HttpStatus.CONFLICT).body(errorBody("CONFLICT", ex.getMessage()));
	}

	// 성공 응답 데이터 생성
	// 成功レスポンスデータの生成
	private Map<String, Object> successBody(String message, Object data) {

		Map<String, Object> body = new LinkedHashMap<String, Object>();

		body.put("success", true);
		body.put("code", "OK");
		body.put("message", message);
		body.put("data", data);
		body.put("field_errors", null);

		return body;
	}

	// 오류 응답 데이터 생성
	// エラーレスポンスデータの生成
	private Map<String, Object> errorBody(String code, String message) {

		Map<String, Object> body = new LinkedHashMap<String, Object>();

		body.put("success", false);
		body.put("code", code);
		body.put("message", message);
		body.put("data", null);
		body.put("field_errors", null);

		return body;
	}
}
