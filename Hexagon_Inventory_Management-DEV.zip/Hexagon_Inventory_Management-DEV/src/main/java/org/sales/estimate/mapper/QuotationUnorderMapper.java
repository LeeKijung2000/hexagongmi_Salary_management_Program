package org.sales.estimate.mapper;

import java.util.List;

import org.sales.estimate.domain.QuotationCriteria;
import org.sales.estimate.domain.QuotationUnorderVO;

// 미주문현황 Mapper
// 未受注現況Mapper
public interface QuotationUnorderMapper {

	// 조건에 맞는 미주문 견적 품목 조회
	// 条件に一致する未受注明細の取得
	List<QuotationUnorderVO> getUnorderList(QuotationCriteria search);
}
