package org.sales.estimate.controller;

import java.util.List;

import org.sales.estimate.domain.QuotationCriteria;
import org.sales.estimate.domain.QuotationUnorderVO;
import org.sales.estimate.service.QuotationUnorderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

// 미주문현황 REST Controller
// 未受注現況RESTコントローラー
@RestController
@RequestMapping("/sales/estimate/api")
public class QuotationUnorderController {

	private final QuotationUnorderService service;

	@Autowired
	public QuotationUnorderController(QuotationUnorderService service) {
		this.service = service;
	}

	// 미주문현황 조회
	// 未受注現況の照会
	@GetMapping("/unordered")
	public ResponseEntity<List<QuotationUnorderVO>> getUnorderList(@ModelAttribute QuotationCriteria search) {

		return ResponseEntity.ok(service.getUnorderList(search));
	}

	// 잘못된 검색조건 처리
	// 不正な検索条件の処理
	@ExceptionHandler(IllegalArgumentException.class)
	public ResponseEntity<String> handleInvalidInput(IllegalArgumentException ex) {

		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ex.getMessage());
	}
}
