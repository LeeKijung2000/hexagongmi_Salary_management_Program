package org.sales.estimate.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.sales.estimate.domain.QuotationInputVO;

// 견적서입력 Mapper
// 見積書入力Mapper
public interface QuotationInputMapper {

	// 통화 목록 조회
	// 通貨一覧の取得
	List<Map<String, Object>> getCurrencies();

	Map<String, Object> findCurrencyById(@Param("currency_id") Long currency_id);

	// 견적서 ID 생성
	// 見積書IDの採番
	Long nextQuoteId();

	// 기준정보 코드 확인
	// マスターコードの確認
	Map<String, Object> findPartnerByCode(@Param("code") String code);

	Map<String, Object> findManagerByCode(@Param("code") String code);

	Map<String, Object> findWarehouseByCode(@Param("code") String code);

	Map<String, Object> findItemByCode(@Param("code") String code);

	// 돋보기 기준정보 목록 조회
	// 検索ダイアログ用マスター一覧の取得
	List<Map<String, Object>> searchPartners(@Param("keyword") String keyword);

	List<Map<String, Object>> searchManagers(@Param("keyword") String keyword);

	List<Map<String, Object>> searchWarehouses(@Param("keyword") String keyword);

	List<Map<String, Object>> searchItems(@Param("keyword") String keyword);

	// 전체재고·창고재고 조회
	// 全体在庫・倉庫在庫の照会
	List<Map<String, Object>> loadInventory(@Param("item_codes") List<String> item_codes,
			@Param("warehouse_code") String warehouse_code);

	// 견적서 저장
	// 見積書の登録
	int insertQuotation(QuotationInputVO vo);

	int insertQuotationItem(@Param("quote_id") Long quote_id, @Param("item") QuotationInputVO.Item item);

	// 첨부파일 경로 저장 및 조회
	// 添付ファイルパスの保存・取得
	int updateAttachmentPath(@Param("quote_id") Long quote_id, @Param("attachment_path") String attachment_path);

	String getAttachmentPath(@Param("quote_id") Long quote_id);
}
