package org.sales.estimate.domain;

import java.math.BigDecimal;

import lombok.Data;

// 견적서현황 조회 VO
// 見積書現況照会VO
@Data
public class QuotationStatusVO {

	// 견적서 PK
	// 見積書ID
	private Long quote_id;

	// 견적 상세행 PK
	// 見積明細ID
	private Long quote_item_id;

	// 전표번호
	// 伝票番号
	private String voucher_no;

	// 견적일자
	// 見積日付
	private String quote_date;

	// 거래처 PK
	// 取引先ID
	private Long business_partner_id;

	// 거래처명
	// 取引先名
	private String partner_name;

	// 담당자명
	// 担当者名
	private String manager_name;

	// 품목코드
	// 品目コード
	private String item_code_snap;

	// 품목명
	// 品目名
	private String item_name_snap;

	// 규격
	// 規格
	private String spec_snap;

	// 단위
	// 単位
	private String unit_snap;

	// 수량
	// 数量
	private BigDecimal quantity;

	// 단가
	// 単価
	private BigDecimal unit_price;

	// 공급가액
	// 供給価額
	private BigDecimal supply_amount;

	// 부가세
	// 付加価値税
	private BigDecimal vat_amount;

	// 합계금액
	// 合計金額
	private BigDecimal total_amount;

	// 진행상태
	// 進捗状況
	private String progress_status;

	// 새로운 항목 추가
	// ユーザー追加項目
	private String custom_data;

	// 견적서 적요
	// 見積書摘要
	private String remarks;
}
