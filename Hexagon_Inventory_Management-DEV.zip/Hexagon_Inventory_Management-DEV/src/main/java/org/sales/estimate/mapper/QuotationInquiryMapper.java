package org.sales.estimate.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.sales.estimate.domain.QuotationCriteria;
import org.sales.estimate.domain.QuotationInquiryVO;

// 견적서조회 및 수정 Mapper
// 見積書照会・修正Mapper
public interface QuotationInquiryMapper {

	// 기존 견적서 목록 조회
	// 既存見積書一覧の取得
	List<QuotationInquiryVO> getList(QuotationCriteria criteria);

	// 견적서 기본정보 및 상세품목 조회
	// 見積書基本情報・明細品目の取得
	Map<String, Object> getHeader(@Param("id") Long id);

	List<Map<String, Object>> getItems(@Param("id") Long id);

	// 견적서와 연결된 주문서 조회
	// 見積書に関連する受注伝票の取得
	List<Map<String, Object>> getLinkedOrders(@Param("id") Long id);

	List<Map<String, Object>> getLinkedOrderItems(@Param("id") Long id);

	// 활성 견적서 및 연결 전표 확인
	// 有効な見積書と関連伝票の確認
	int countActive(@Param("id") Long id);

	int countLinked(@Param("id") Long id);

	// 진행상태 변경 및 견적서 취소
	// 進捗状態の変更と見積書の取消
	int changeProgress(@Param("id") Long id, @Param("status") String status);

	int cancelQuotation(@Param("id") Long id);

	// 견적서 화면 상태 이력
	// 見積書の画面状態履歴

	// Oracle의 최근 화면 상태 조회
	// Oracleに保存された最新画面状態の取得
	String getLatestUiStatus(@Param("id") Long id);

	// 견적서 화면 상태 변경 이력 저장
	// 見積書の画面状態変更履歴の保存
	int insertUiStatusHistory(@Param("id") Long id, @Param("beforeStatus") String beforeStatus,
			@Param("afterStatus") String afterStatus);

	// 수정 화면 기준정보 검색
	// 編集画面のマスター検索
	List<Map<String, Object>> searchMaster(@Param("type") String type, @Param("keyword") String keyword);

	// 직접 입력한 코드 검사
	// 直接入力されたコードの検証
	Map<String, Object> findPartner(@Param("code") String code);

	Map<String, Object> findManager(@Param("code") String code);

	Map<String, Object> findWarehouse(@Param("code") String code);

	Map<String, Object> findItem(@Param("code") String code);

	int countCurrency(@Param("id") Long id);

	// 기존 견적서 수정
	// 既存見積書の修正
	int updateHeader(@Param("id") Long id, @Param("data") Map<String, Object> data);

	int deleteItems(@Param("id") Long id);

	int insertItem(@Param("id") Long id, @Param("item") Map<String, Object> item);
}
