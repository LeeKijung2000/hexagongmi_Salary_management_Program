package org.zerock.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletContext;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.zerock.domain.Criteria;
import org.zerock.domain.ItemBulkChangeVO;
import org.zerock.domain.HierarchyGroupType;
import org.zerock.domain.ItemGroup1VO;
import org.zerock.domain.ItemGroup2VO;
import org.zerock.domain.ItemGroup3VO;
import org.zerock.domain.ItemHierGroupVO;
import org.zerock.domain.ItemVO;
import org.zerock.domain.PageDTO;
import org.zerock.domain.ProdProcessVO;
import org.zerock.domain.QualityInspTypeVO;
import org.zerock.domain.WarehouseVO;
import org.zerock.service.HierarchyGroupService;
import org.zerock.service.ItemService;

import lombok.extern.log4j.Log4j;

@Controller
@RequestMapping("/base/item")
@Log4j
/**
 * 한국어: 품목 화면 요청을 처리하는 Controller입니다.
 * 日本語: 商品画面のリクエストを処理するControllerです。
 */
public class ItemController {

    private static final long MAX_IMAGE_SIZE = 5L * 1024L * 1024L;
    private static final String ITEM_IMAGE_UPLOAD_DIR = "C:/upload/items";

    private final ItemService service;
    private final HierarchyGroupService hierarchyGroupService;
    private final ServletContext servletContext;

    public ItemController(ItemService service,
                           HierarchyGroupService hierarchyGroupService,
                           ServletContext servletContext) {
        this.service = service;
        this.hierarchyGroupService = hierarchyGroupService;
        this.servletContext = servletContext;
    }

    @GetMapping({"", "/", "/list"})
    // 한국어: 품목 목록 화면을 출력하고 기준정보를 함께 전달합니다.
    // 日本語: 商品一覧画面を表示し、基準情報も一緒に渡します。
    public String list(Criteria cri, Model model) {
        if (cri.getPageNum() < 1) cri.setPageNum(1);
        // 품목 목록은 항상 10건 단위로 표시합니다.
        cri.setAmount(10);
        model.addAttribute("list", service.getList(cri));
        model.addAttribute("pageMaker", new PageDTO(cri, service.getTotal(cri)));
        loadReferenceData(model);
        return "base/item";
    }

    @GetMapping("/get")
    @ResponseBody
    // 한국어: 선택한 품목의 상세 정보를 AJAX로 조회합니다.
    // 日本語: 選択した商品の詳細情報をAJAXで取得します。
    public ResponseEntity<ItemVO> get(@RequestParam("itemPk") Long itemPk) {
        ItemVO item = service.get(itemPk);
        if (item == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(item, HttpStatus.OK);
    }

    @GetMapping("/check-code")
    @ResponseBody
    // 한국어: 품목코드 중복 확인 API를 제공합니다.
    // 日本語: 商品コード重複チェックAPIを提供します。
    public ResponseEntity<Boolean> checkCode(@RequestParam("itemCode") String itemCode,
                                             @RequestParam(value = "itemPk", required = false) Long itemPk) {
        return new ResponseEntity<>(service.isDuplicateCode(itemCode, itemPk), HttpStatus.OK);
    }

    @PostMapping("/register")
    @ResponseBody
    // 한국어: 품목 입력값과 이미지를 검증한 뒤 품목을 등록합니다.
    // 日本語: 商品入力値と画像を検証した後、商品を登録します。
    public ResponseEntity<String> register(ItemVO item,
                                           @RequestParam(value = "imageFile", required = false) MultipartFile imageFile) {
        String storedImagePath = null;
        try {
            normalize(item);
            validate(item, false);
            storedImagePath = saveImage(imageFile);
            item.setImagePath(storedImagePath);
            service.register(item);
            return new ResponseEntity<>("success", HttpStatus.OK);
        } catch (IllegalArgumentException e) {
            deleteImage(storedImagePath);
            log.warn("item register validation: " + e.getMessage());
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            deleteImage(storedImagePath);
            log.error("item register error", e);
            return new ResponseEntity<>("품목 등록 중 오류가 발생했습니다.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @PostMapping("/change")
    @ResponseBody
    // 한국어: 선택한 품목 필드만 변경하고 이미지 파일도 필요한 경우 교체합니다.
    // 日本語: 選択した商品フィールドだけを変更し、必要な場合は画像も差し替えます。
    public ResponseEntity<String> change(ItemVO patch,
                                         @RequestParam("fields") List<String> fields,
                                         @RequestParam(value = "imageFile", required = false) MultipartFile imageFile) {
        String newImagePath = null;
        try {
            if (patch.getItemPk() == null || patch.getItemPk() <= 0) {
                return new ResponseEntity<>("변경할 품목을 찾을 수 없습니다.", HttpStatus.BAD_REQUEST);
            }
            ItemVO current = service.get(patch.getItemPk());
            if (current == null) {
                return new ResponseEntity<>("변경할 품목을 찾을 수 없습니다.", HttpStatus.NOT_FOUND);
            }
            final String oldImagePath = current.getImagePath();

            List<String> selectedFields = normalizeChangeFields(fields);
            applyItemChangeFields(current, patch, selectedFields);

            if (selectedFields.contains("imagePath") && imageFile != null && !imageFile.isEmpty()) {
                newImagePath = saveImage(imageFile);
                current.setImagePath(newImagePath);
            }

            normalize(current);
            validate(current, true);
            boolean updated = service.modify(current);
            if (!updated) {
                deleteImage(newImagePath);
                return new ResponseEntity<>("변경된 데이터가 없습니다.", HttpStatus.BAD_REQUEST);
            }

            if (newImagePath != null && oldImagePath != null && !oldImagePath.equals(newImagePath)) {
                deleteImage(oldImagePath);
            }
            return new ResponseEntity<>("success", HttpStatus.OK);
        } catch (IllegalArgumentException e) {
            deleteImage(newImagePath);
            log.warn("item change validation: " + e.getMessage());
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            deleteImage(newImagePath);
            log.error("item change error", e);
            return new ResponseEntity<>("품목 변경 중 오류가 발생했습니다.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // 한국어: 허용된 변경 항목만 정리하여 반환합니다.
    // 日本語: 許可された変更項目だけを整理して返します。
    private List<String> normalizeChangeFields(List<String> fields) {
        if (fields == null || fields.isEmpty()) {
            throw new IllegalArgumentException("변경할 항목을 선택해주세요.");
        }
        List<String> result = new ArrayList<>();
        for (String field : fields) {
            if (field == null) continue;
            String value = field.trim();
            if (!isSupportedChangeField(value)) {
                throw new IllegalArgumentException("변경할 수 없는 항목입니다: " + value);
            }
            if (!result.contains(value)) result.add(value);
        }
        if (result.isEmpty()) throw new IllegalArgumentException("변경할 항목을 선택해주세요.");
        if (!result.contains("itemName")) result.add(0, "itemName");
        return result;
    }

    // 한국어: 변경 가능한 필드인지 확인합니다.
    // 日本語: 変更可能なフィールドか確認します。
    private boolean isSupportedChangeField(String field) {
        return "itemName".equals(field)
                || "spec".equals(field) || "unit".equals(field) || "itemDiv".equals(field)
                || "qty".equals(field) || "vatRateSales".equals(field) || "vatRatePurchase".equals(field)
                || "barcode".equals(field) || "prodProcessPk".equals(field) || "searchContent".equals(field)
                || "imagePath".equals(field) || "qualityInspMethod".equals(field) || "qualityInspTypePk".equals(field)
                || "purchasePrice".equals(field) || "salesPrice".equals(field) || "outsourcingPrice".equals(field)
                || "stdLaborTime".equals(field) || "expenseWeight".equals(field)
                || "stdCostMaterial".equals(field) || "stdCostExpense".equals(field)
                || "stdCostLabor".equals(field) || "stdCostOutsourcing".equals(field)
                || "itemGroup1Pk".equals(field) || "itemGroup2Pk".equals(field) || "itemGroup3Pk".equals(field)
                || "itemHierGroupPk".equals(field) || "warehousePks".equals(field);
    }

    // 한국어: 선택된 품목 변경 항목만 원본 객체에 반영합니다.
    // 日本語: 選択した品目の変更項目だけを元オブジェクトへ反映します。
    private void applyItemChangeFields(ItemVO target, ItemVO patch, List<String> fields) {
        for (String field : fields) {
            if ("itemName".equals(field)) target.setItemName(patch.getItemName());
            else if ("spec".equals(field)) target.setSpec(patch.getSpec());
            else if ("unit".equals(field)) target.setUnit(patch.getUnit());
            else if ("itemDiv".equals(field)) target.setItemDiv(patch.getItemDiv());
            else if ("qty".equals(field)) target.setQty(patch.getQty());
            else if ("vatRateSales".equals(field)) target.setVatRateSales(patch.getVatRateSales());
            else if ("vatRatePurchase".equals(field)) target.setVatRatePurchase(patch.getVatRatePurchase());
            else if ("barcode".equals(field)) target.setBarcode(patch.getBarcode());
            else if ("prodProcessPk".equals(field)) target.setProdProcessPk(patch.getProdProcessPk());
            else if ("searchContent".equals(field)) target.setSearchContent(patch.getSearchContent());
            else if ("qualityInspMethod".equals(field)) target.setQualityInspMethod(patch.getQualityInspMethod());
            else if ("qualityInspTypePk".equals(field)) target.setQualityInspTypePk(patch.getQualityInspTypePk());
            else if ("purchasePrice".equals(field)) target.setPurchasePrice(patch.getPurchasePrice());
            else if ("salesPrice".equals(field)) target.setSalesPrice(patch.getSalesPrice());
            else if ("outsourcingPrice".equals(field)) target.setOutsourcingPrice(patch.getOutsourcingPrice());
            else if ("stdLaborTime".equals(field)) target.setStdLaborTime(patch.getStdLaborTime());
            else if ("expenseWeight".equals(field)) target.setExpenseWeight(patch.getExpenseWeight());
            else if ("stdCostMaterial".equals(field)) target.setStdCostMaterial(patch.getStdCostMaterial());
            else if ("stdCostExpense".equals(field)) target.setStdCostExpense(patch.getStdCostExpense());
            else if ("stdCostLabor".equals(field)) target.setStdCostLabor(patch.getStdCostLabor());
            else if ("stdCostOutsourcing".equals(field)) target.setStdCostOutsourcing(patch.getStdCostOutsourcing());
            else if ("itemGroup1Pk".equals(field)) target.setItemGroup1Pk(patch.getItemGroup1Pk());
            else if ("itemGroup2Pk".equals(field)) target.setItemGroup2Pk(patch.getItemGroup2Pk());
            else if ("itemGroup3Pk".equals(field)) target.setItemGroup3Pk(patch.getItemGroup3Pk());
            else if ("itemHierGroupPk".equals(field)) target.setItemHierGroupPk(patch.getItemHierGroupPk());
            else if ("warehousePks".equals(field)) target.setWarehousePks(patch.getWarehousePks());
            else if ("imagePath".equals(field)) { /* file input is handled above */ }
        }
    }

    @PostMapping("/modify")
    @ResponseBody
    // 한국어: 기존 품목 정보를 수정합니다.
    // 日本語: 既存の品目情報を更新します。
    public ResponseEntity<String> modify(ItemVO item,
                                         @RequestParam(value = "imageFile", required = false) MultipartFile imageFile) {
        String newImagePath = null;
        try {
            normalize(item);
            validate(item, true);

            ItemVO oldItem = service.get(item.getItemPk());
            if (oldItem == null) {
                return new ResponseEntity<>("수정할 품목을 찾을 수 없습니다.", HttpStatus.NOT_FOUND);
            }

            if (imageFile != null && !imageFile.isEmpty()) {
                newImagePath = saveImage(imageFile);
                item.setImagePath(newImagePath);
            } else {
                item.setImagePath(oldItem.getImagePath());
            }

            boolean updated = service.modify(item);
            if (!updated) {
                deleteImage(newImagePath);
                return new ResponseEntity<>("수정된 데이터가 없습니다.", HttpStatus.BAD_REQUEST);
            }

            if (newImagePath != null && oldItem.getImagePath() != null
                    && !oldItem.getImagePath().equals(newImagePath)) {
                deleteImage(oldItem.getImagePath());
            }

            return new ResponseEntity<>("success", HttpStatus.OK);
        } catch (IllegalArgumentException e) {
            deleteImage(newImagePath);
            log.warn("item modify validation: " + e.getMessage());
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            deleteImage(newImagePath);
            log.error("item modify error", e);
            return new ResponseEntity<>("품목 수정 중 오류가 발생했습니다.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/remove")
    @ResponseBody
    // 한국어: 선택된 품목을 삭제합니다.
    // 日本語: 選択した商品を削除します。
    public ResponseEntity<String> remove(@RequestParam("itemPks") Long[] itemPks) {
        if (itemPks == null || itemPks.length == 0) {
            return new ResponseEntity<>("삭제할 품목을 선택해주세요.", HttpStatus.BAD_REQUEST);
        }

        try {
            List<String> imagePaths = new ArrayList<>();
            for (Long itemPk : itemPks) {
                ItemVO item = service.get(itemPk);
                if (item != null) {
                    imagePaths.add(item.getImagePath());
                }
            }

            boolean removed = service.removeAll(itemPks);
            if (!removed) {
                return new ResponseEntity<>("삭제할 품목이 없습니다.", HttpStatus.BAD_REQUEST);
            }

            for (String imagePath : imagePaths) {
                deleteImage(imagePath);
            }
            return new ResponseEntity<>("success", HttpStatus.OK);
        } catch (Exception e) {
            log.error("item remove error", e);
            return new ResponseEntity<>("품목 삭제 중 오류가 발생했습니다.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/group1-list")
    @ResponseBody
    // 한국어: 품목 그룹1 목록 API를 제공합니다.
    // 日本語: 商品グループ1一覧APIを提供します。
    public List<ItemGroup1VO> group1List() {
        return service.getGroup1List();
    }

    @GetMapping("/group2-list")
    @ResponseBody
    // 한국어: 품목 그룹2 목록 API를 제공합니다.
    // 日本語: 商品グループ2一覧APIを提供します。
    public List<ItemGroup2VO> group2List() {
        return service.getGroup2List();
    }

    @GetMapping("/group3-list")
    @ResponseBody
    // 한국어: 품목 그룹3 목록 API를 제공합니다.
    // 日本語: 商品グループ3一覧APIを提供します。
    public List<ItemGroup3VO> group3List() {
        return service.getGroup3List();
    }

    @GetMapping("/hier-group-list")
    @ResponseBody
    // 한국어: 품목 계층그룹 목록 API를 제공합니다.
    // 日本語: 商品階層グループ一覧APIを提供します。
    public List<ItemHierGroupVO> hierGroupList() {
        return service.getItemHierGroupList();
    }

    @GetMapping("/prod-process-list")
    @ResponseBody
    // 한국어: 생산공정 목록 API를 제공합니다.
    // 日本語: 生産工程一覧APIを提供します。
    public List<ProdProcessVO> prodProcessList() {
        return service.getProdProcessList();
    }

    @GetMapping("/quality-insp-type-list")
    @ResponseBody
    // 한국어: 품질검사유형 목록 API를 제공합니다.
    // 日本語: 品質検査種別一覧APIを提供します。
    public List<QualityInspTypeVO> qualityInspTypeList() {
        return service.getQualityInspTypeList();
    }

    @GetMapping("/warehouse-list")
    @ResponseBody
    // 한국어: 보관창고 목록 API를 제공합니다.
    // 日本語: 保管倉庫一覧APIを提供します。
    public List<WarehouseVO> warehouseList() {
        return service.getWarehouseList();
    }

    @PostMapping(value = "/bulk-modify", produces = MediaType.TEXT_PLAIN_VALUE + ";charset=UTF-8")
    @ResponseBody
    // 한국어: 선택 품목의 지정 필드를 일괄 변경합니다.
    // 日本語: 選択した商品の指定フィールドを一括変更します。
    public ResponseEntity<String> bulkModify(@RequestParam("itemPks") List<Long> itemPks,
                                             @RequestParam("field") String field,
                                             @RequestParam(value = "value", required = false) String value) {
        try {
            ItemBulkChangeVO change = new ItemBulkChangeVO();
            change.setField(field);
            change.setTextValue(value);
            int count = service.bulkModify(itemPks, change);
            return ResponseEntity.ok(String.valueOf(count));
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            log.error("item bulk modify error", e);
            return new ResponseEntity<>("품목 일괄변경 중 오류가 발생했습니다.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/hierarchy-members")
    @ResponseBody
    // 한국어: 선택 품목 계층그룹의 구성 품목을 조회합니다.
    // 日本語: 選択した商品階層グループの所属商品を取得します。
    public ResponseEntity<?> hierarchyMembers(@RequestParam("itemHierGroupPk") Long itemHierGroupPk) {
        try {
            return ResponseEntity.ok().cacheControl(org.springframework.http.CacheControl.noStore()).body(service.getHierarchyMembers(itemHierGroupPk));
        } catch (Exception e) {
            log.error("item hierarchy members error", e);
            return new ResponseEntity<>("품목 계층그룹 구성품목 조회 중 오류가 발생했습니다.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/bulk-hierarchy-group", produces = MediaType.TEXT_PLAIN_VALUE + ";charset=UTF-8")
    @ResponseBody
    // 한국어: 선택 품목에 계층그룹을 일괄 적용합니다.
    // 日本語: 選択した商品に階層グループを一括適用します。
    public ResponseEntity<String> bulkHierarchyGroup(@RequestParam("itemPks") List<Long> itemPks,
                                                     @RequestParam(value = "itemHierGroupPk", required = false) Long itemHierGroupPk) {
        try {
            if (itemHierGroupPk != null && itemHierGroupPk > 0
                    && hierarchyGroupService.get(HierarchyGroupType.ITEM, itemHierGroupPk) == null) {
                return new ResponseEntity<>("선택한 품목계층그룹이 존재하지 않습니다.", HttpStatus.BAD_REQUEST);
            }
            int count = service.bulkAssignItemHierGroup(itemPks, itemHierGroupPk);
            return ResponseEntity.ok(String.valueOf(count));
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            log.error("item bulk hierarchy group error", e);
            return new ResponseEntity<>("품목계층그룹 일괄변경 중 오류가 발생했습니다.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /** 선택 품목의 바코드를 조회합니다. 바코드가 없는 품목은 12자리 숫자 코드로 자동 생성합니다. */
    @GetMapping("/barcode/list")
    @ResponseBody
    // 한국어: 선택 품목의 바코드를 조회하고 필요하면 자동 생성합니다.
    // 日本語: 選択した商品のバーコードを取得し、必要なら自動生成します。
    public ResponseEntity<List<ItemVO>> barcodeList(@RequestParam("itemPks") Long[] itemPks) {
        if (itemPks == null || itemPks.length == 0) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        try {
            List<ItemVO> items = service.getBarcodeItems(itemPks);
            if (items.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
            return new ResponseEntity<>(items, HttpStatus.OK);
        } catch (IllegalArgumentException e) {
            log.warn("barcode list validation: " + e.getMessage());
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            log.error("barcode list error", e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // 한국어: 품목 화면에 필요한 그룹/공정 기준정보를 모델에 추가합니다.
    // 日本語: 商品画面に必要なグループ・工程基準情報をモデルへ追加します。
    private void loadReferenceData(Model model) {
        model.addAttribute("group1List", service.getGroup1List());
        model.addAttribute("group2List", service.getGroup2List());
        model.addAttribute("group3List", service.getGroup3List());
        model.addAttribute("itemHierGroupList", service.getItemHierGroupList());
        model.addAttribute("prodProcessList", service.getProdProcessList());
    }

    // 한국어: 품목 문자열과 FK 입력값을 정규화합니다.
    // 日本語: 商品文字列とFK入力値を正規化します。
    private void normalize(ItemVO item) {
        if (item == null) {
            throw new IllegalArgumentException("입력 데이터가 없습니다.");
        }
        item.setItemCode(trim(item.getItemCode()));
        item.setItemName(trim(item.getItemName()));
        item.setSpec(trim(item.getSpec()));
        item.setUnit(trim(item.getUnit()));
        item.setBarcode(trim(item.getBarcode()));
        item.setSearchContent(trim(item.getSearchContent()));
        // 선택하지 않은 FK/PK 값(0 이하)은 Oracle FK에 넣지 않고 NULL로 처리한다.
        item.setProdProcessPk(normalizePk(item.getProdProcessPk()));
        item.setItemGroup1Pk(normalizePk(item.getItemGroup1Pk()));
        item.setItemGroup2Pk(normalizePk(item.getItemGroup2Pk()));
        item.setItemGroup3Pk(normalizePk(item.getItemGroup3Pk()));
        item.setItemHierGroupPk(normalizePk(item.getItemHierGroupPk()));
        item.setQualityInspTypePk(normalizePk(item.getQualityInspTypePk()));
    }

    // 한국어: 품목 등록/수정 입력값의 업무 규칙을 검사합니다.
    // 日本語: 商品登録・更新入力値の業務ルールを検証します。
    private void validate(ItemVO item, boolean modify) {
        if (modify && item.getItemPk() == null) {
            throw new IllegalArgumentException("수정할 품목의 PK가 없습니다.");
        }
        if (item.getItemCode() == null || item.getItemCode().isEmpty()) {
            throw new IllegalArgumentException("품목코드는 필수입니다.");
        }
        if (item.getItemCode().length() > 50) {
            throw new IllegalArgumentException("품목코드는 50자 이내로 입력해주세요.");
        }
        if (item.getItemName() == null || item.getItemName().isEmpty()) {
            throw new IllegalArgumentException("품목명은 필수입니다.");
        }
        if (item.getItemName().length() > 100) {
            throw new IllegalArgumentException("품목명은 100자 이내로 입력해주세요.");
        }
        if (item.getSpec() != null && item.getSpec().length() > 100) {
            throw new IllegalArgumentException("규격은 100자 이내로 입력해주세요.");
        }
        if (item.getUnit() != null && item.getUnit().length() > 20) {
            throw new IllegalArgumentException("단위는 20자 이내로 입력해주세요.");
        }
        if (item.getBarcode() != null && item.getBarcode().length() > 100) {
            throw new IllegalArgumentException("바코드는 100자 이내로 입력해주세요.");
        }
        if (item.getSearchContent() != null && item.getSearchContent().length() > 200) {
            throw new IllegalArgumentException("검색창내용은 200자 이내로 입력해주세요.");
        }
        if (item.getItemDiv() != null && (item.getItemDiv() < 0 || item.getItemDiv() > 5)) {
            throw new IllegalArgumentException("품목구분 값이 올바르지 않습니다.");
        }
        if (item.getQualityInspMethod() != null
                && (item.getQualityInspMethod() < 0 || item.getQualityInspMethod() > 2)) {
            throw new IllegalArgumentException("품질검사방법 값이 올바르지 않습니다.");
        }
        if (item.getVatRateSales() != null && item.getVatRateSales().signum() < 0) {
            throw new IllegalArgumentException("매출 부가세율은 0 이상이어야 합니다.");
        }
        if (item.getVatRatePurchase() != null && item.getVatRatePurchase().signum() < 0) {
            throw new IllegalArgumentException("매입 부가세율은 0 이상이어야 합니다.");
        }
        if (item.getQty() != null && item.getQty().signum() < 0) {
            throw new IllegalArgumentException("재고수량은 0 이상이어야 합니다.");
        }
        if (item.getQty() != null && item.getQty().signum() > 0
                && (item.getWarehousePks() == null || item.getWarehousePks().isEmpty())) {
            throw new IllegalArgumentException("재고수량을 입력하려면 보관창고를 먼저 선택해주세요.");
        }
        if (service.isDuplicateCode(item.getItemCode(), modify ? item.getItemPk() : null)) {
            throw new IllegalArgumentException("이미 사용 중인 품목코드입니다.");
        }
        if (item.getBarcode() != null && !item.getBarcode().isEmpty()
                && service.isDuplicateBarcode(item.getBarcode(), modify ? item.getItemPk() : null)) {
            throw new IllegalArgumentException("이미 사용 중인 바코드입니다.");
        }
    }

    // 한국어: 업로드 이미지를 검증하고 서버에 저장합니다.
    // 日本語: アップロード画像を検証し、サーバーへ保存します。
    private String saveImage(MultipartFile imageFile) throws IOException {
        if (imageFile == null || imageFile.isEmpty()) {
            return null;
        }
        if (imageFile.getSize() > MAX_IMAGE_SIZE) {
            throw new IllegalArgumentException("이미지는 5MB 이하만 등록할 수 있습니다.");
        }
        String contentType = imageFile.getContentType();
        if (contentType == null || !contentType.toLowerCase().startsWith("image/")) {
            throw new IllegalArgumentException("이미지 파일만 등록할 수 있습니다.");
        }

        String originalName = imageFile.getOriginalFilename();
        String extension = "";
        if (originalName != null) {
            int dot = originalName.lastIndexOf('.');
            if (dot >= 0 && dot < originalName.length() - 1) {
                extension = originalName.substring(dot).toLowerCase();
                if (extension.length() > 8) {
                    extension = "";
                }
            }
        }

        String fileName = UUID.randomUUID().toString().replace("-", "") + extension;
        Path uploadDir = getUploadDirectory();
        Files.createDirectories(uploadDir);
        Path target = uploadDir.resolve(fileName).normalize();
        if (!target.getParent().equals(uploadDir)) {
            throw new IllegalArgumentException("잘못된 이미지 경로입니다.");
        }
        imageFile.transferTo(target.toFile());
        return "/item-images/" + fileName;
    }

    // 한국어: 품목 이미지는 웹 애플리케이션 바깥의 고정 업로드 폴더에 저장합니다.
    // 日本語: 商品画像はWebアプリケーション外の固定アップロードフォルダへ保存します。
    private Path getUploadDirectory() {
        return Paths.get(ITEM_IMAGE_UPLOAD_DIR).toAbsolutePath().normalize();
    }

    // 한국어: 등록 과정에서 실패하거나 교체된 이미지 파일을 정리합니다.
    // 日本語: 登録失敗時や差し替え時の画像ファイルを削除します。
    private void deleteImage(String imagePath) {
        if (imagePath == null || imagePath.trim().isEmpty()) {
            return;
        }
        try {
            String normalizedPath = imagePath.trim().replace('\\', '/');
            String fileName = Paths.get(normalizedPath).getFileName().toString();
            if (fileName.isEmpty() || ".".equals(fileName) || "..".equals(fileName)) {
                return;
            }

            if (normalizedPath.startsWith("/item-images/")) {
                Path target = getUploadDirectory().resolve(fileName).normalize();
                if (target.getParent().equals(getUploadDirectory())) {
                    Files.deleteIfExists(target);
                }
            } else if (normalizedPath.startsWith("/resources/upload/items/")) {
                // 기존 데이터 호환: 예전에 웹앱 내부에 저장된 이미지도 삭제할 수 있게 처리합니다.
                String legacyRealPath = servletContext.getRealPath(imagePath);
                if (legacyRealPath != null) {
                    Files.deleteIfExists(Paths.get(legacyRealPath));
                }
                // 동일 파일이 외부 저장 폴더로 이미 이동된 경우도 정리합니다.
                Path externalTarget = getUploadDirectory().resolve(fileName).normalize();
                if (externalTarget.getParent().equals(getUploadDirectory())) {
                    Files.deleteIfExists(externalTarget);
                }
            }
        } catch (Exception e) {
            log.warn("이미지 파일 삭제 실패: " + imagePath, e);
        }
    }

    // 한국어: ID 값을 정규화하여 유효한 양수만 반환합니다.
    // 日本語: ID値を正規化し、有効な正数だけを返します。
    private Long normalizePk(Long value) {
        return value != null && value > 0 ? value : null;
    }

    private String trim(String value) {
        return value == null ? null : value.trim();
    }
}
