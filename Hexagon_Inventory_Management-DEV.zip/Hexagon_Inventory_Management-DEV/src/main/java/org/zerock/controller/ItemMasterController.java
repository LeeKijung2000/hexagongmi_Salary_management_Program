package org.zerock.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.zerock.domain.MasterCodeVO;
import org.zerock.domain.MasterType;
import org.zerock.service.ItemMasterService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

/**
 * 품목등록에서 사용하는 생산공정/품목그룹1~3 마스터 CRUD API.
 */
@Controller
@RequestMapping("/base/master")
@Log4j
@AllArgsConstructor
public class ItemMasterController {

    private final ItemMasterService service;

    @GetMapping("/{masterType}/list")
    @ResponseBody
    public ResponseEntity<?> list(@PathVariable String masterType,
                                  @RequestParam(value = "keyword", required = false) String keyword) {
        try {
            MasterType type = resolve(masterType);
            List<MasterCodeVO> list = service.getList(type, keyword);
            return new ResponseEntity<>(list, HttpStatus.OK);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            log.error("master list error", e);
            return new ResponseEntity<>("마스터 목록 조회 중 오류가 발생했습니다.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/{masterType}/get")
    @ResponseBody
    public ResponseEntity<?> get(@PathVariable String masterType,
                                 @RequestParam("pk") Long pk) {
        try {
            MasterType type = resolve(masterType);
            MasterCodeVO vo = service.get(type, pk);
            if (vo == null) {
                return new ResponseEntity<>("조회할 데이터를 찾을 수 없습니다.", HttpStatus.NOT_FOUND);
            }
            return new ResponseEntity<>(vo, HttpStatus.OK);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            log.error("master get error", e);
            return new ResponseEntity<>("마스터 조회 중 오류가 발생했습니다.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/{masterType}/check-code")
    @ResponseBody
    public ResponseEntity<?> checkCode(@PathVariable String masterType,
                                       @RequestParam("code") String code,
                                       @RequestParam(value = "pk", required = false) Long pk) {
        try {
            MasterType type = resolve(masterType);
            return new ResponseEntity<>(service.isDuplicateCode(type, code, pk), HttpStatus.OK);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            log.error("master code check error", e);
            return new ResponseEntity<>("코드 중복확인 중 오류가 발생했습니다.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/{masterType}/register")
    @ResponseBody
    public ResponseEntity<String> register(@PathVariable String masterType,
                                           @RequestParam("code") String code,
                                           @RequestParam("name") String name) {
        try {
            MasterType type = resolve(masterType);
            MasterCodeVO vo = MasterCodeVO.builder()
                    .code(code)
                    .name(name)
                    .masterType(type.getRoute())
                    .build();
            service.register(type, vo);
            return new ResponseEntity<>(String.valueOf(vo.getPk()), HttpStatus.OK);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            log.error("master register error", e);
            return new ResponseEntity<>("마스터 등록 중 오류가 발생했습니다.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/{masterType}/modify")
    @ResponseBody
    public ResponseEntity<String> modify(@PathVariable String masterType,
                                         @RequestParam("pk") Long pk,
                                         @RequestParam("code") String code,
                                         @RequestParam("name") String name) {
        try {
            MasterType type = resolve(masterType);
            MasterCodeVO vo = MasterCodeVO.builder()
                    .pk(pk)
                    .code(code)
                    .name(name)
                    .masterType(type.getRoute())
                    .build();
            return service.modify(type, vo)
                    ? new ResponseEntity<>("success", HttpStatus.OK)
                    : new ResponseEntity<>("수정된 데이터가 없습니다.", HttpStatus.BAD_REQUEST);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            log.error("master modify error", e);
            return new ResponseEntity<>("마스터 수정 중 오류가 발생했습니다.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/{masterType}/remove")
    @ResponseBody
    public ResponseEntity<String> remove(@PathVariable String masterType,
                                         @RequestParam("pk") Long pk) {
        try {
            MasterType type = resolve(masterType);
            return service.remove(type, pk)
                    ? new ResponseEntity<>("success", HttpStatus.OK)
                    : new ResponseEntity<>("삭제된 데이터가 없습니다.", HttpStatus.BAD_REQUEST);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (IllegalStateException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.CONFLICT);
        } catch (org.springframework.dao.DataIntegrityViolationException e) {
            String message = e.getMostSpecificCause() == null ? e.getMessage() : e.getMostSpecificCause().getMessage();
            if (message != null && message.contains("ORA-02292")) {
                if (message.contains("FK_WH_PROCESS")) {
                    return new ResponseEntity<>("생산공정은(는) 현재 창고에서 사용 중이라 삭제할 수 없습니다.", HttpStatus.CONFLICT);
                }
                if (message.contains("FK_ITEM")) {
                    return new ResponseEntity<>("해당 마스터는 현재 품목에서 사용 중이라 삭제할 수 없습니다.", HttpStatus.CONFLICT);
                }
                return new ResponseEntity<>("해당 마스터는 다른 데이터에서 사용 중이라 삭제할 수 없습니다.", HttpStatus.CONFLICT);
            }
            log.error("master remove data integrity error", e);
            return new ResponseEntity<>("마스터 삭제 중 오류가 발생했습니다.", HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            log.error("master remove error", e);
            return new ResponseEntity<>("마스터 삭제 중 오류가 발생했습니다.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    private MasterType resolve(String value) {
        return MasterType.from(value);
    }
}
