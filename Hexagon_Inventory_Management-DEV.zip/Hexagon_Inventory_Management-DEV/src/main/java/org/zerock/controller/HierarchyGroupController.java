package org.zerock.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.zerock.domain.HierarchyGroupType;
import org.zerock.domain.HierarchyGroupVO;
import org.zerock.service.HierarchyGroupService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@RequestMapping("/base/hierarchy-group")
@Log4j
@AllArgsConstructor
public class HierarchyGroupController {

    private final HierarchyGroupService service;

    @GetMapping("/{groupType}/list")
    @ResponseBody
    public ResponseEntity<?> list(@PathVariable String groupType) {
        try {
            return ResponseEntity.ok(service.getList(resolve(groupType)));
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            log.error("hierarchy group list error", e);
            return new ResponseEntity<>("계층그룹 목록 조회 중 오류가 발생했습니다.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/{groupType}/get")
    @ResponseBody
    public ResponseEntity<?> get(@PathVariable String groupType, @RequestParam("pk") Long pk) {
        try {
            HierarchyGroupVO vo = service.get(resolve(groupType), pk);
            return vo == null ? new ResponseEntity<>("조회할 데이터를 찾을 수 없습니다.", HttpStatus.NOT_FOUND)
                    : ResponseEntity.ok(vo);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/{groupType}/check-code")
    @ResponseBody
    public ResponseEntity<?> checkCode(@PathVariable String groupType,
                                       @RequestParam("code") String code,
                                       @RequestParam(value = "pk", required = false) Long pk) {
        try {
            return ResponseEntity.ok(service.isDuplicateCode(resolve(groupType), code, pk));
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping(value = "/{groupType}/register", produces = MediaType.TEXT_PLAIN_VALUE + ";charset=UTF-8")
    @ResponseBody
    public ResponseEntity<String> register(@PathVariable String groupType,
                                           @RequestParam("code") String code,
                                           @RequestParam("name") String name,
                                           @RequestParam(value = "parentPk", required = false) Long parentPk) {
        try {
            HierarchyGroupVO vo = HierarchyGroupVO.builder().code(code).name(name).parentPk(parentPk).build();
            service.register(resolve(groupType), vo);
            return ResponseEntity.ok(String.valueOf(vo.getPk()));
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            log.error("hierarchy group register error", e);
            return new ResponseEntity<>("계층그룹 등록 중 오류가 발생했습니다.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/{groupType}/modify", produces = MediaType.TEXT_PLAIN_VALUE + ";charset=UTF-8")
    @ResponseBody
    public ResponseEntity<String> modify(@PathVariable String groupType,
                                         @RequestParam("pk") Long pk,
                                         @RequestParam("code") String code,
                                         @RequestParam("name") String name,
                                         @RequestParam(value = "parentPk", required = false) Long parentPk) {
        try {
            HierarchyGroupVO vo = HierarchyGroupVO.builder().pk(pk).code(code).name(name).parentPk(parentPk).build();
            return service.modify(resolve(groupType), vo) ? ResponseEntity.ok("success")
                    : new ResponseEntity<>("수정된 데이터가 없습니다.", HttpStatus.BAD_REQUEST);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            log.error("hierarchy group modify error", e);
            return new ResponseEntity<>("계층그룹 수정 중 오류가 발생했습니다.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/{groupType}/remove", produces = MediaType.TEXT_PLAIN_VALUE + ";charset=UTF-8")
    @ResponseBody
    public ResponseEntity<String> remove(@PathVariable String groupType, @RequestParam("pk") Long pk) {
        try {
            return service.remove(resolve(groupType), pk) ? ResponseEntity.ok("success")
                    : new ResponseEntity<>("삭제된 데이터가 없습니다.", HttpStatus.BAD_REQUEST);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (IllegalStateException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.CONFLICT);
        } catch (DataIntegrityViolationException e) {
            HierarchyGroupType type;
            try {
                type = resolve(groupType);
            } catch (IllegalArgumentException ignored) {
                type = null;
            }
            String message = type == HierarchyGroupType.ITEM
                    ? "품목이 남아있어서 삭제할 수 없습니다."
                    : type == HierarchyGroupType.WAREHOUSE
                    ? "창고가 남아있어서 삭제할 수 없습니다."
                    : type == HierarchyGroupType.BUSINESS_PARTNER
                    ? "거래처가 남아있어서 삭제할 수 없습니다."
                    : "연결된 데이터가 남아있어서 삭제할 수 없습니다.";
            return new ResponseEntity<>(message + " 해당 데이터를 다른 계층그룹으로 이동한 후 삭제해주세요.", HttpStatus.CONFLICT);
        } catch (Exception e) {
            log.error("hierarchy group remove error", e);
            return new ResponseEntity<>("계층그룹 삭제 중 오류가 발생했습니다.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    private HierarchyGroupType resolve(String value) {
        return HierarchyGroupType.from(value);
    }
}
