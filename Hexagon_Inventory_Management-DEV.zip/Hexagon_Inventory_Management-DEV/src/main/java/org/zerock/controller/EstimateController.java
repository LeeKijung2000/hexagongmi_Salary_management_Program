package org.zerock.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/sales/estimate")
public class EstimateController {

    @GetMapping("/inquiry")
    public String inquiry() {
        return "sales/estimate/inquiry"; // /WEB-INF/views/sales/estimate/inquiry.jsp
    }

    @GetMapping("/input")
    public String input() {
        return "sales/estimate/input"; // /WEB-INF/views/sales/estimate/input.jsp
    }

    @GetMapping("/status")
    public String status() {
        return "sales/estimate/status"; // /WEB-INF/views/sales/estimate/status.jsp
    }

    @GetMapping("/unorder")
    public String unorder() {
        return "sales/estimate/unorder"; // /WEB-INF/views/sales/estimate/unorder.jsp
    }
}