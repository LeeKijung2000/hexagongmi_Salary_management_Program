package org.zerock.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {

    // 루트 경로 접속 시 /WEB-INF/views/Inventory/index.jsp로 이동
    @GetMapping("/")
    public String mainDashboard() {
        return "Inventory/index"; 
    }
}