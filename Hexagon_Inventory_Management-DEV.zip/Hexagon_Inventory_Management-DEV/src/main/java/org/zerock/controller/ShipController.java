package org.zerock.controller;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.zerock.domain.Criteria;
import org.zerock.domain.PageDTO;
import org.zerock.domain.ShipmentVO;
import org.zerock.domain.ShippingOrderVO;
import org.zerock.service.ShipService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@RequestMapping("/sales")
@Log4j
@AllArgsConstructor
public class ShipController {

    private final ShipService service;

    // ==================== 출하지시서 ====================

    @GetMapping("/ship-order/inquiry")
    // 한국어: 출하지시서 조회 화면을 표시하고 조회 조건을 전달합니다.
    // 日本語: 出荷指示書照会画面を表示し、検索条件を渡します。
    public String shipOrderInquiry(Criteria cri, Model model) {
        normalizeCriteria(cri);
        model.addAttribute("list", service.getShippingOrderList(cri));
        model.addAttribute("pageMaker", new PageDTO(cri, service.getShippingOrderTotal(cri)));
        return "sales/ship-order/inquiry";
    }

    @GetMapping("/ship-order/input")
    // 한국어: 출하지시서 입력 화면을 표시하고 수정 대상 데이터를 전달합니다.
    // 日本語: 出荷指示書入力画面を表示し、更新対象データを渡します。
    public String shipOrderInput(@RequestParam(value = "id", required = false) Long id, Model model) {
        addMasterData(model);
        model.addAttribute("editId", id);
        return "sales/ship-order/input";
    }

    @GetMapping("/ship-order/status")
    // 한국어: 출하지시서 현황 화면을 표시합니다.
    // 日本語: 出荷指示書状況画面を表示します。
    public String shipOrderStatus(Model model) {
        addMasterData(model);
        return "sales/ship-order/status";
    }

    // ==================== 출하 ====================

    @GetMapping("/ship/inquiry")
    // 한국어: 출하 조회 화면을 표시하고 조회 조건을 전달합니다.
    // 日本語: 出荷照会画面を表示し、検索条件を渡します。
    public String shipInquiry(Criteria cri, Model model) {
        normalizeCriteria(cri);
        model.addAttribute("list", service.getShipmentList(cri));
        model.addAttribute("pageMaker", new PageDTO(cri, service.getShipmentTotal(cri)));
        return "sales/ship/inquiry";
    }

    @GetMapping("/ship/input")
    // 한국어: 출하 입력 화면을 표시하고 수정 대상 데이터를 전달합니다.
    // 日本語: 出荷入力画面を表示し、更新対象データを渡します。
    public String shipInput(@RequestParam(value = "id", required = false) Long id, Model model) {
        addMasterData(model);
        model.addAttribute("editId", id);
        return "sales/ship/input";
    }

    // ==================== 등록 API ====================

    @PostMapping("/ship-order/register")
    @ResponseBody
    // 한국어: 출하지시서를 등록하고 상세 품목 및 판매 연결 정보를 저장합니다.
    // 日本語: 出荷指示書を登録し、明細品目と販売連携情報を保存します。
    public ResponseEntity<String> registerShippingOrder(@RequestBody ShippingOrderVO vo) {
        try {
            service.registerShippingOrder(vo);
            return ResponseEntity.ok(vo.getVoucherNo());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        } catch (Exception e) {
            log.error("shipping order register error", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("출하지시서 저장 중 오류가 발생했습니다.");
        }
    }

    @PostMapping("/ship-order/update/{id}")
    @ResponseBody
    // 한국어: 출하지시서 헤더 정보를 수정합니다.
    // 日本語: 出荷指示書ヘッダー情報を更新します。
    public ResponseEntity<String> updateShippingOrder(@PathVariable("id") Long id, @RequestBody ShippingOrderVO vo) {
        try {
            if (vo == null) throw new IllegalArgumentException("입력 데이터를 확인해주세요.");
            vo.setShippingOrderId(id);
            service.updateShippingOrder(vo);
            return ResponseEntity.ok(vo.getVoucherNo());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        } catch (Exception e) {
            log.error("shipping order update error", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("출하지시서 수정 중 오류가 발생했습니다.");
        }
    }

    @PostMapping("/ship/register")
    @ResponseBody
    // 한국어: 출하 전표를 등록하고 출하지시서 연결 정보를 저장합니다.
    // 日本語: 出荷伝票を登録し、出荷指示書との連携情報を保存します。
    public ResponseEntity<String> registerShipment(@RequestBody ShipmentVO vo) {
        try {
            service.registerShipment(vo);
            return ResponseEntity.ok(vo.getVoucherNo());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        } catch (Exception e) {
            log.error("shipment register error", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("출하 저장 중 오류가 발생했습니다.");
        }
    }

    @PostMapping("/ship-order/cancel/{id}")
    @ResponseBody
    // 한국어: 출하지시서 상태를 취소로 변경합니다.
    // 日本語: 出荷指示書の状態をキャンセルへ更新します。
    public ResponseEntity<String> cancelShippingOrder(@PathVariable("id") Long id) {
        try {
            service.cancelShippingOrder(id);
            return ResponseEntity.ok("success");
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (Exception e) {
            log.error("shipping order cancel error", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("출하지시서 취소 중 오류가 발생했습니다.");
        }
    }

    @PostMapping("/ship/update/{id}")
    @ResponseBody
    // 한국어: 출하 전표 헤더 정보를 수정합니다.
    // 日本語: 出荷伝票ヘッダー情報を更新します。
    public ResponseEntity<String> updateShipment(@PathVariable("id") Long id, @RequestBody ShipmentVO vo) {
        try {
            if (vo == null) throw new IllegalArgumentException("입력 데이터를 확인해주세요.");
            vo.setShipmentId(id);
            service.updateShipment(vo);
            return ResponseEntity.ok(vo.getVoucherNo());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        } catch (Exception e) {
            log.error("shipment update error", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("출하 수정 중 오류가 발생했습니다.");
        }
    }

    @PostMapping("/ship/cancel/{id}")
    @ResponseBody
    // 한국어: 출하 전표 상태를 취소로 변경합니다.
    // 日本語: 出荷伝票の状態をキャンセルへ更新します。
    public ResponseEntity<String> cancelShipment(@PathVariable("id") Long id) {
        try {
            service.cancelShipment(id);
            return ResponseEntity.ok("success");
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (Exception e) {
            log.error("shipment cancel error", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("출하전표 취소 중 오류가 발생했습니다.");
        }
    }

    // ==================== 상세 조회 API ====================

    @GetMapping("/ship-order/get/{id}")
    @ResponseBody
    // 한국어: 출하지시서 한 건의 상세 정보를 조회합니다.
    // 日本語: 出荷指示書1件の詳細情報を取得します。
    public ResponseEntity<ShippingOrderVO> getShippingOrder(@PathVariable("id") Long id) {
        ShippingOrderVO vo = service.getShippingOrder(id);
        return vo == null ? ResponseEntity.notFound().build() : ResponseEntity.ok(vo);
    }

    @GetMapping("/ship/get/{id}")
    @ResponseBody
    // 한국어: 출하 전표 한 건의 상세 정보를 조회합니다.
    // 한국어: 요청된 출하 전표의 상세 정보를 JSON으로 반환합니다.
    // 日本語: 指定された出荷伝票の詳細情報をJSONで返します。
    public ResponseEntity<ShipmentVO> getShipment(@PathVariable("id") Long id) {
        ShipmentVO vo = service.getShipment(id);
        return vo == null ? ResponseEntity.notFound().build() : ResponseEntity.ok(vo);
    }

    // ==================== 팝업/기준정보 API ====================

    @GetMapping({"/common/partner-list", "/ship/partner-list", "/ship-order/partner-list"})
    @ResponseBody
    // 한국어: 거래처 검색 데이터를 조회합니다.
    // 日本語: 取引先検索データを取得します。
    public List<Map<String, Object>> partnerList(@RequestParam(value = "keyword", required = false) String keyword) {
        return service.getPartnerList(keyword);
    }

    @GetMapping({"/common/warehouse-list", "/ship/warehouse-list", "/ship-order/warehouse-list"})
    @ResponseBody
    public List<Map<String, Object>> warehouseList(@RequestParam(value = "keyword", required = false) String keyword) {
        return service.getWarehouseList(keyword);
    }

    @GetMapping({"/common/item-list", "/ship/item-list", "/ship-order/item-list"})
    @ResponseBody
    // 한국어: 품목 검색 데이터를 조회합니다.
    // 日本語: 品目検索データを取得します。
    public List<Map<String, Object>> itemList(@RequestParam(value = "keyword", required = false) String keyword) {
        return service.getItemList(keyword);
    }

    @GetMapping({"/common/manager-list", "/ship/manager-list", "/ship-order/manager-list"})
    @ResponseBody
    public List<Map<String, Object>> managerList(@RequestParam(value = "keyword", required = false) String keyword) {
        return service.getManagerList(keyword);
    }

    @GetMapping({"/common/project-list", "/ship/project-list", "/ship-order/project-list"})
    @ResponseBody
    // 한국어: 프로젝트 검색 데이터를 조회합니다.
    // 日本語: プロジェクト検索データを取得します。
    public List<Map<String, Object>> projectList(@RequestParam(value = "keyword", required = false) String keyword) {
        return service.getProjectList(keyword);
    }

    @GetMapping("/ship-order/sale-source")
    @ResponseBody
    public List<?> saleSource(@RequestParam(value = "keyword", required = false) String keyword,
                              @RequestParam(value = "businessPartnerId", required = false) Long businessPartnerId,
                              @RequestParam(value = "warehouseId", required = false) Long warehouseId) {
        try {
            return service.getSaleSourceList(keyword, businessPartnerId, warehouseId);
        } catch (Exception e) {
            log.error("sale source search error", e);
            return Collections.emptyList();
        }
    }

    @GetMapping("/ship/unshipped-source")
    @ResponseBody
    // 한국어: 출하 입력에 사용할 미출하 자료 조회 요청을 처리합니다.
    // 日本語: 出荷入力に使用する未出荷資料照会リクエストを処理します。
    public List<?> unshippedSource(@RequestParam(value = "keyword", required = false) String keyword,
                                   @RequestParam(value = "businessPartnerId", required = false) Long businessPartnerId,
                                   @RequestParam(value = "warehouseId", required = false) Long warehouseId) {
        try {
            return service.getUnshippedSourceList(keyword, businessPartnerId, warehouseId);
        } catch (Exception e) {
            log.error("unshipped source search error", e);
            return Collections.emptyList();
        }
    }

    @GetMapping("/ship-order/status-data")
    @ResponseBody
    // 한국어: 출하 현황 조회 요청을 처리합니다.
    // 日本語: 出荷状況照会リクエストを処理します。
    public List<?> shippingStatus(@RequestParam(value = "warehouseId", required = false) Long warehouseId,
                                  @RequestParam(value = "businessPartnerId", required = false) Long businessPartnerId,
                                  @RequestParam(value = "itemId", required = false) Long itemId,
                                  @RequestParam(value = "projectId", required = false) Long projectId,
                                  @RequestParam(value = "dateFrom", required = false) String dateFrom,
                                  @RequestParam(value = "dateTo", required = false) String dateTo,
                                  @RequestParam(value = "voucherNo", required = false) String voucherNo,
                                  @RequestParam(value = "keyword", required = false) String keyword) {
        try {
            return service.getShippingStatus(warehouseId, businessPartnerId, itemId, projectId,
                    dateFrom, dateTo, voucherNo, keyword);
        } catch (Exception e) {
            log.error("shipping status search error", e);
            return Collections.emptyList();
        }
    }

    // 한국어: 출하 입력 화면에 필요한 공통 마스터 데이터를 모델에 추가합니다.
    // 日本語: 出荷入力画面に必要な共通マスターデータをModelへ追加します。
    private void addMasterData(Model model) {
        model.addAttribute("partners", service.getPartnerList(null));
        model.addAttribute("warehouses", service.getWarehouseList(null));
        model.addAttribute("managers", service.getManagerList(null));
        model.addAttribute("projects", service.getProjectList(null));
        model.addAttribute("items", service.getItemList(null));
    }

    // 한국어: 조회 조건의 페이지와 건수 기본값을 정규화합니다.
    // 日本語: 検索条件のページ番号と件数の初期値を正規化します。
    private void normalizeCriteria(Criteria cri) {
        if (cri.getPageNum() < 1) cri.setPageNum(1);
        cri.setAmount(20);
        if (cri.getStatus() != null) cri.setStatus(cri.getStatus().trim());
        if (cri.getDateFrom() != null) cri.setDateFrom(cri.getDateFrom().trim());
        if (cri.getDateTo() != null) cri.setDateTo(cri.getDateTo().trim());
    }
}
