package org.zerock.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.zerock.domain.BusinessPartnerManagerVO;
import org.zerock.domain.BusinessPartnerVO;
import org.zerock.domain.Criteria;
import org.zerock.domain.PageDTO;
import org.zerock.service.BusinessPartnerService;
import org.zerock.service.HierarchyGroupService;
import org.zerock.domain.HierarchyGroupType;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@RequestMapping("/base/account")
@Log4j
@AllArgsConstructor
/**
 * 한국어: 거래처 화면 요청을 처리하는 Controller입니다.
 * 日本語: 取引先画面のリクエストを処理するControllerです。
 */
public class BusinessPartnerController {

    private final BusinessPartnerService service;
    private final HierarchyGroupService hierarchyGroupService;

    @GetMapping({"", "/", "/list"})
    // 한국어: 거래처 목록 화면을 출력하고 페이징 데이터를 전달합니다.
    // 日本語: 取引先一覧画面を表示し、ページングデータを渡します。
    public String list(Criteria cri, Model model) {
        if (cri.getPageNum() < 1) cri.setPageNum(1);
        // 목록은 항상 10건 단위로 표시합니다.
        cri.setAmount(10);
        if (cri.getType() == null || cri.getType().trim().isEmpty()) cri.setType("TC");
        model.addAttribute("list", service.getList(cri));
        model.addAttribute("pageMaker", new PageDTO(cri, service.getTotal(cri)));
        return "base/account";
    }

    @GetMapping("/get")
    @ResponseBody
    // 한국어: 선택한 거래처의 상세 정보를 AJAX로 조회합니다.
    // 日本語: 選択した取引先の詳細情報をAJAXで取得します。
    public ResponseEntity<BusinessPartnerVO> get(@RequestParam("businessPartnerId") Long id) {
        BusinessPartnerVO vo = service.get(id);
        return vo == null ? new ResponseEntity<>(HttpStatus.NOT_FOUND) : ResponseEntity.ok(vo);
    }

    @GetMapping("/check-code")
    @ResponseBody
    // 한국어: 거래처코드 중복 확인 API를 제공합니다.
    // 日本語: 取引先コード重複チェックAPIを提供します。
    public ResponseEntity<Boolean> checkCode(@RequestParam("businessPartnerCode") String code,
                                             @RequestParam(value = "businessPartnerId", required = false) Long id) {
        return ResponseEntity.ok(service.isDuplicateCode(code, id));
    }

    @PostMapping(value = "/register", produces = MediaType.TEXT_PLAIN_VALUE + ";charset=UTF-8")
    @ResponseBody
    // 한국어: 거래처 등록 요청을 검증하고 저장합니다.
    // 日本語: 取引先登録リクエストを検証して保存します。
    public ResponseEntity<String> register(BusinessPartnerVO vo) {
        try {
            service.register(vo);
            return ResponseEntity.ok("success");
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.parseMediaType("text/plain;charset=UTF-8"))
                    .body(e.getMessage());
        } catch (Exception e) {
            log.error("business partner register error", e);
            return textResponse("거래처 등록 중 오류가 발생했습니다.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @PostMapping(value = "/quick-register", produces = MediaType.APPLICATION_JSON_VALUE + ";charset=UTF-8")
    @ResponseBody
    // 한국어: 거래처 등록 요청을 처리합니다.
    // 日本語: 取引先の登録リクエストを処理します。
    public ResponseEntity<Map<String, Object>> quickRegister(BusinessPartnerVO vo) {
        try {
            service.register(vo);
            Map<String, Object> result = new java.util.HashMap<>();
            result.put("businessPartnerId", vo.getBusinessPartnerId());
            result.put("businessPartnerCode", vo.getBusinessPartnerCode());
            result.put("businessPartnerName", vo.getBusinessPartnerName());
            result.put("phoneNumber", vo.getPhoneNumber());
            result.put("zipCode", vo.getZipCode());
            result.put("address1", vo.getAddress1());
            result.put("address2", vo.getAddress2());
            return ResponseEntity.ok(result);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(java.util.Collections.<String, Object>singletonMap("message", e.getMessage()));
        } catch (Exception e) {
            log.error("business partner quick register error", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(java.util.Collections.<String, Object>singletonMap("message", "거래처 등록 중 오류가 발생했습니다."));
        }
    }

    @PostMapping(value = "/change", produces = MediaType.TEXT_PLAIN_VALUE + ";charset=UTF-8")
    @ResponseBody
    // 한국어: 선택한 거래처 항목만 기존 데이터에 반영해 수정합니다.
    // 日本語: 選択した取引先項目だけを既存データへ反映して更新します。
    public ResponseEntity<String> change(BusinessPartnerVO patch,
                                         @RequestParam("fields") List<String> fields) {
        try {
            if (patch.getBusinessPartnerId() == null || patch.getBusinessPartnerId() <= 0) {
                return textResponse("변경할 거래처를 찾을 수 없습니다.", HttpStatus.BAD_REQUEST);
            }
            BusinessPartnerVO current = service.get(patch.getBusinessPartnerId());
            if (current == null) {
                return textResponse("변경할 거래처를 찾을 수 없습니다.", HttpStatus.NOT_FOUND);
            }
            List<String> selectedFields = normalizeChangeFields(fields);
            applyBusinessPartnerChangeFields(current, patch, selectedFields);
            boolean updated = service.modify(current);
            if (!updated) {
                return textResponse("변경된 데이터가 없습니다.", HttpStatus.BAD_REQUEST);
            }
            return ResponseEntity.ok("success");
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.parseMediaType("text/plain;charset=UTF-8"))
                    .body(e.getMessage());
        } catch (Exception e) {
            log.error("business partner change error", e);
            return textResponse("거래처 변경 중 오류가 발생했습니다.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // 한국어: 허용된 변경 항목만 정규화합니다.
    // 日本語: 許可された変更項目だけを正規化します。
    private List<String> normalizeChangeFields(List<String> fields) {
        if (fields == null || fields.isEmpty()) throw new IllegalArgumentException("변경할 항목을 선택해주세요.");
        List<String> result = new ArrayList<>();
        for (String field : fields) {
            if (field == null) continue;
            String value = field.trim();
            if (!isSupportedChangeField(value)) throw new IllegalArgumentException("변경할 수 없는 항목입니다: " + value);
            if (!result.contains(value)) result.add(value);
        }
        if (result.isEmpty()) throw new IllegalArgumentException("변경할 항목을 선택해주세요.");
        if (!result.contains("businessPartnerName")) result.add(0, "businessPartnerName");
        return result;
    }

    // 한국어: 변경 가능한 거래처 필드인지 확인합니다.
    // 日本語: 変更可能な取引先フィールドか確認します。
    private boolean isSupportedChangeField(String field) {
        return "businessPartnerName".equals(field) || "businessPartnerCodeType".equals(field)
                || "representativeName".equals(field) || "businessType".equals(field) || "businessItem".equals(field)
                || "additionalItemAvailableYn".equals(field)
                || "phoneNumber".equals(field) || "faxNumber".equals(field) || "searchContent".equals(field)
                || "mobileNumber".equals(field) || "zipCode".equals(field) || "address1".equals(field)
                || "address2".equals(field) || "homepageUrl".equals(field) || "email".equals(field)
                || "telecomBizNumber".equals(field) || "industryTypeCode".equals(field) || "managerId".equals(field)
                || "businessPartnerGroup1Id".equals(field) || "businessPartnerGroup2Id".equals(field) || "bpHierGroupId".equals(field)
                || "currencyCode".equals(field) || "shipmentTargetYn".equals(field) || "salesTransactionType".equals(field)
                || "purchaseTransactionType".equals(field) || "collectionPaymentDueType".equals(field)
                || "collectionPaymentDueValue".equals(field) || "collectionPaymentDueDay".equals(field)
                || "receivableManagementYn".equals(field) || "payableManagementYn".equals(field)
                || "creditLimit".equals(field) || "creditPeriod".equals(field)
                || "shipmentAdjustmentRate".equals(field) || "receiptAdjustmentRate".equals(field)
                || "salesPriceGroupId".equals(field) || "purchasePriceGroupId".equals(field)
                || "remark".equals(field) || "taxReportBpYn".equals(field) || "useYn".equals(field)
                || "additionalText1".equals(field) || "additionalText2".equals(field) || "additionalText3".equals(field)
                || "additionalText4".equals(field) || "additionalText5".equals(field) || "additionalText6".equals(field)
                || "additionalNumber1".equals(field) || "additionalNumber2".equals(field) || "additionalNumber3".equals(field);
    }

    // 한국어: 선택된 필드만 원본 거래처 객체에 반영합니다.
    // 日本語: 選択したフィールドだけを元の取引先オブジェクトへ反映します。
    private void applyBusinessPartnerChangeFields(BusinessPartnerVO target, BusinessPartnerVO patch, List<String> fields) {
        for (String field : fields) {
            if ("businessPartnerName".equals(field)) target.setBusinessPartnerName(patch.getBusinessPartnerName());
            else if ("businessPartnerCodeType".equals(field)) target.setBusinessPartnerCodeType(patch.getBusinessPartnerCodeType());
            else if ("representativeName".equals(field)) target.setRepresentativeName(patch.getRepresentativeName());
            else if ("businessType".equals(field)) target.setBusinessType(patch.getBusinessType());
            else if ("businessItem".equals(field)) target.setBusinessItem(patch.getBusinessItem());
            else if ("additionalItemAvailableYn".equals(field)) target.setAdditionalItemAvailableYn(patch.getAdditionalItemAvailableYn());
            else if ("phoneNumber".equals(field)) target.setPhoneNumber(patch.getPhoneNumber());
            else if ("faxNumber".equals(field)) target.setFaxNumber(patch.getFaxNumber());
            else if ("searchContent".equals(field)) target.setSearchContent(patch.getSearchContent());
            else if ("mobileNumber".equals(field)) target.setMobileNumber(patch.getMobileNumber());
            else if ("zipCode".equals(field)) target.setZipCode(patch.getZipCode());
            else if ("address1".equals(field)) target.setAddress1(patch.getAddress1());
            else if ("address2".equals(field)) target.setAddress2(patch.getAddress2());
            else if ("homepageUrl".equals(field)) target.setHomepageUrl(patch.getHomepageUrl());
            else if ("email".equals(field)) target.setEmail(patch.getEmail());
            else if ("telecomBizNumber".equals(field)) target.setTelecomBizNumber(patch.getTelecomBizNumber());
            else if ("industryTypeCode".equals(field)) target.setIndustryTypeCode(patch.getIndustryTypeCode());
            else if ("managerId".equals(field)) target.setManagerId(patch.getManagerId());
            else if ("businessPartnerGroup1Id".equals(field)) target.setBusinessPartnerGroup1Id(patch.getBusinessPartnerGroup1Id());
            else if ("businessPartnerGroup2Id".equals(field)) target.setBusinessPartnerGroup2Id(patch.getBusinessPartnerGroup2Id());
            else if ("bpHierGroupId".equals(field)) target.setBpHierGroupId(patch.getBpHierGroupId());
            else if ("currencyCode".equals(field)) target.setCurrencyCode(patch.getCurrencyCode());
            else if ("shipmentTargetYn".equals(field)) target.setShipmentTargetYn(patch.getShipmentTargetYn());
            else if ("salesTransactionType".equals(field)) target.setSalesTransactionType(patch.getSalesTransactionType());
            else if ("purchaseTransactionType".equals(field)) target.setPurchaseTransactionType(patch.getPurchaseTransactionType());
            else if ("collectionPaymentDueType".equals(field)) target.setCollectionPaymentDueType(patch.getCollectionPaymentDueType());
            else if ("collectionPaymentDueValue".equals(field)) target.setCollectionPaymentDueValue(patch.getCollectionPaymentDueValue());
            else if ("collectionPaymentDueDay".equals(field)) target.setCollectionPaymentDueDay(patch.getCollectionPaymentDueDay());
            else if ("receivableManagementYn".equals(field)) target.setReceivableManagementYn(patch.getReceivableManagementYn());
            else if ("payableManagementYn".equals(field)) target.setPayableManagementYn(patch.getPayableManagementYn());
            else if ("creditLimit".equals(field)) target.setCreditLimit(patch.getCreditLimit());
            else if ("creditPeriod".equals(field)) target.setCreditPeriod(patch.getCreditPeriod());
            else if ("shipmentAdjustmentRate".equals(field)) target.setShipmentAdjustmentRate(patch.getShipmentAdjustmentRate());
            else if ("receiptAdjustmentRate".equals(field)) target.setReceiptAdjustmentRate(patch.getReceiptAdjustmentRate());
            else if ("salesPriceGroupId".equals(field)) target.setSalesPriceGroupId(patch.getSalesPriceGroupId());
            else if ("purchasePriceGroupId".equals(field)) target.setPurchasePriceGroupId(patch.getPurchasePriceGroupId());
            else if ("remark".equals(field)) target.setRemark(patch.getRemark());
            else if ("taxReportBpYn".equals(field)) target.setTaxReportBpYn(patch.getTaxReportBpYn());
            else if ("useYn".equals(field)) target.setUseYn(patch.getUseYn());
            else if ("additionalText1".equals(field)) target.setAdditionalText1(patch.getAdditionalText1());
            else if ("additionalText2".equals(field)) target.setAdditionalText2(patch.getAdditionalText2());
            else if ("additionalText3".equals(field)) target.setAdditionalText3(patch.getAdditionalText3());
            else if ("additionalText4".equals(field)) target.setAdditionalText4(patch.getAdditionalText4());
            else if ("additionalText5".equals(field)) target.setAdditionalText5(patch.getAdditionalText5());
            else if ("additionalText6".equals(field)) target.setAdditionalText6(patch.getAdditionalText6());
            else if ("additionalNumber1".equals(field)) target.setAdditionalNumber1(patch.getAdditionalNumber1());
            else if ("additionalNumber2".equals(field)) target.setAdditionalNumber2(patch.getAdditionalNumber2());
            else if ("additionalNumber3".equals(field)) target.setAdditionalNumber3(patch.getAdditionalNumber3());
        }
    }

    @PostMapping(value = "/modify", produces = MediaType.TEXT_PLAIN_VALUE + ";charset=UTF-8")
    @ResponseBody
    // 한국어: 거래처 전체 수정 요청을 처리합니다.
    // 日本語: 取引先全体の更新リクエストを処理します。
    public ResponseEntity<String> modify(BusinessPartnerVO vo) {
        try {
            return service.modify(vo) ? ResponseEntity.ok("success")
                    : textResponse("수정된 데이터가 없습니다.", HttpStatus.BAD_REQUEST);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.parseMediaType("text/plain;charset=UTF-8"))
                    .body(e.getMessage());
        } catch (Exception e) {
            log.error("business partner modify error", e);
            return textResponse("거래처 수정 중 오류가 발생했습니다.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/remove", produces = MediaType.TEXT_PLAIN_VALUE + ";charset=UTF-8")
    @ResponseBody
    // 한국어: 거래처 삭제 요청을 처리합니다.
    // 日本語: 取引先削除リクエストを処理します。
    public ResponseEntity<String> remove(@RequestParam("businessPartnerId") Long id) {
        try {
            return service.remove(id) ? ResponseEntity.ok("success")
                    : textResponse("삭제할 거래처를 찾을 수 없습니다.", HttpStatus.BAD_REQUEST);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.parseMediaType("text/plain;charset=UTF-8"))
                    .body(e.getMessage());
        } catch (Exception e) {
            log.error("business partner remove error", e);
            return textResponse("거래처 삭제 중 오류가 발생했습니다.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/toggle-use", produces = MediaType.TEXT_PLAIN_VALUE + ";charset=UTF-8")
    @ResponseBody
    // 한국어: 거래처 사용 여부를 변경합니다.
    // 日本語: 取引先の使用有無を更新します。
    public ResponseEntity<String> toggleUse(@RequestParam("businessPartnerId") Long id,
                                            @RequestParam("useYn") String useYn) {
        BusinessPartnerVO vo = service.get(id);
        if (vo == null) return textResponse("거래처를 찾을 수 없습니다.", HttpStatus.NOT_FOUND);
        vo.setUseYn("N".equalsIgnoreCase(useYn) ? "N" : "Y");
        return service.modify(vo) ? ResponseEntity.ok("success") : textResponse("변경된 데이터가 없습니다.", HttpStatus.BAD_REQUEST);
    }

    @GetMapping("/group1-list") @ResponseBody public List<Map<String,Object>> group1List() { return service.getGroup1List(); }
    @GetMapping("/group2-list") @ResponseBody public List<Map<String,Object>> group2List() { return service.getGroup2List(); }
    @GetMapping("/sales-price-group-list") @ResponseBody public List<Map<String,Object>> salesPriceGroupList() { return service.getSalesPriceGroupList(); }
    @GetMapping("/purchase-price-group-list") @ResponseBody public List<Map<String,Object>> purchasePriceGroupList() { return service.getPurchasePriceGroupList(); }
    @GetMapping("/currency-list") @ResponseBody public List<Map<String,Object>> currencyList() { return service.getCurrencyList(); }
    @GetMapping("/manager-list") @ResponseBody public List<BusinessPartnerManagerVO> managerList(@RequestParam(value="keyword", required=false) String keyword) { return service.getManagerList(keyword); }
    @GetMapping("/hierarchy-members") @ResponseBody public ResponseEntity<List<Map<String,Object>>> hierarchyMembers(@RequestParam("bpHierGroupId") Long bpHierGroupId) { return ResponseEntity.ok().cacheControl(org.springframework.http.CacheControl.noStore()).body(service.getHierarchyMembers(bpHierGroupId)); }

    @PostMapping(value = "/bulk-hierarchy-group", produces = MediaType.TEXT_PLAIN_VALUE + ";charset=UTF-8") @ResponseBody
    // 한국어: 선택한 거래처의 계층그룹을 일괄 변경합니다.
    // 日本語: 選択した取引先の階層グループを一括変更します。
    public ResponseEntity<String> bulkHierarchyGroup(@RequestParam("businessPartnerIds") List<Long> businessPartnerIds,
                                                     @RequestParam("bpHierGroupId") Long bpHierGroupId) {
        try {
            if (hierarchyGroupService.get(HierarchyGroupType.BUSINESS_PARTNER, bpHierGroupId) == null) {
                return textResponse("선택한 거래처계층그룹이 존재하지 않습니다.", HttpStatus.BAD_REQUEST);
            }
            return ResponseEntity.ok(String.valueOf(service.bulkAssignHierarchyGroup(businessPartnerIds, bpHierGroupId)));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.parseMediaType("text/plain;charset=UTF-8"))
                    .body(e.getMessage());
        } catch (Exception e) {
            log.error("business partner bulk hierarchy group error", e);
            return textResponse("거래처계층그룹 적용 중 오류가 발생했습니다.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value="/manager-register", produces=MediaType.TEXT_PLAIN_VALUE + ";charset=UTF-8")
    @ResponseBody
    // 한국어: 담당자 팝업 등록 요청을 처리합니다.
    // 日本語: 担当者ポップアップの登録リクエストを処理します。
    public ResponseEntity<String> managerRegister(BusinessPartnerManagerVO manager) {
        try {
            service.registerManager(manager);
            return ResponseEntity.ok("success");
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.parseMediaType("text/plain;charset=UTF-8"))
                    .body(e.getMessage());
        } catch (Exception e) {
            log.error("manager register error", e);
            return textResponse("사원 등록 중 오류가 발생했습니다.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    // 한국어: 지정한 상태코드와 메시지로 응답을 생성합니다.
    // 日本語: 指定したステータスコードとメッセージでレスポンスを生成します。
    private ResponseEntity<String> textResponse(String body, HttpStatus status) {
        return ResponseEntity.status(status)
                .contentType(MediaType.parseMediaType("text/plain;charset=UTF-8"))
                .body(body);
    }

}
