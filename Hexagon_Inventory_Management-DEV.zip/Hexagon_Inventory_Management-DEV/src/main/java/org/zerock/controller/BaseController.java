package org.zerock.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.zerock.domain.Criteria;
import org.zerock.domain.PageDTO;
import org.zerock.service.WarehouseService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@RequestMapping("/base")
@Log4j
@AllArgsConstructor
public class BaseController {

    private WarehouseService warehouseService;

    // 브라우저 주소: http://localhost:8282/Inventory/base/warehouse
    // 연결될 JSP 물리 경로: /WEB-INF/views/base/warehouse.jsp
    @GetMapping("/warehouse")
    public String warehousePage(Criteria cri, Model model) {
        if (cri.getPageNum() < 1) cri.setPageNum(1);
        // 창고 목록은 항상 10건 단위로 표시합니다.
        cri.setAmount(10);
        log.info("warehouse page with criteria: " + cri);
        
        // 데이터베이스에서 창고 리스트와 페이징 정보를 가져와서 모델에 담음
        model.addAttribute("list", warehouseService.getList(cri));
        
        int total = warehouseService.getTotal(cri);
        model.addAttribute("pageMaker", new PageDTO(cri, total));
        
        // 명시적으로 뷰 경로 리턴 (/WEB-INF/views/base/warehouse.jsp)
        return "base/warehouse"; 
    }

}