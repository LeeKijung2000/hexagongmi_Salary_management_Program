package org.zerock.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.zerock.domain.Criteria;
import org.zerock.domain.HierarchyGroupType;
import org.zerock.domain.PageDTO;
import org.zerock.domain.WarehouseVO;
import org.zerock.service.HierarchyGroupService;
import org.zerock.service.WarehouseService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@RequestMapping("/warehouse/*")
@Log4j
@AllArgsConstructor
/**
 * 한국어: 창고 화면 요청을 처리하는 Controller입니다.
 * 日本語: 倉庫画面のリクエストを処理するControllerです。
 */
public class WarehouseController {

    private WarehouseService service;
    private HierarchyGroupService hierarchyGroupService;

    // 1. 리스트 조회 및 페이지 이동
    @GetMapping("/list")
    // 한국어: 창고 목록을 화면 모델에 담습니다.
    // 日本語: 倉庫一覧を画面モデルへ設定します。
    public void list(Criteria cri, Model model) {
        if (cri.getPageNum() < 1) cri.setPageNum(1);
        cri.setAmount(10);
        log.info("warehouse list: " + cri);
        model.addAttribute("list", service.getList(cri));
        int total = service.getTotal(cri);
        model.addAttribute("pageMaker", new PageDTO(cri, total));
    }

    // 2. 등록 (AJAX)
    @PostMapping(value = "/register", produces = MediaType.TEXT_PLAIN_VALUE + ";charset=UTF-8")
    @ResponseBody
    // 한국어: 창고 등록 요청을 처리합니다.
    // 日本語: 倉庫登録リクエストを処理します。
    public ResponseEntity<String> register(WarehouseVO warehouse) {
        log.info("register: " + warehouse);
        try {
            service.register(warehouse);
            return ResponseEntity.ok("success");
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.parseMediaType("text/plain;charset=UTF-8"))
                    .body(e.getMessage());
        } catch (Exception e) {
            log.error("register error: ", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .contentType(MediaType.parseMediaType("text/plain;charset=UTF-8"))
                    .body("창고 등록 중 오류가 발생했습니다.");
        }
    }

    // 3. 상세 조회 (모달 데이터 로드)
    @GetMapping("/get")
    @ResponseBody
    // 한국어: 선택한 창고의 상세 정보를 AJAX로 조회합니다.
    // 日本語: 選択した倉庫の詳細情報をAJAXで取得します。
    public ResponseEntity<WarehouseVO> get(@RequestParam("warehousePk") Long warehousePk) {
        log.info("get warehouse: " + warehousePk);
        WarehouseVO warehouse = service.get(warehousePk);
        return new ResponseEntity<>(warehouse, HttpStatus.OK);
    }

    // 4. 수정 (AJAX)
    @PostMapping(value = "/modify", produces = MediaType.TEXT_PLAIN_VALUE + ";charset=UTF-8")
    @ResponseBody
    // 한국어: 창고 수정 요청을 처리합니다.
    // 日本語: 倉庫更新リクエストを処理します。
    public ResponseEntity<String> modify(WarehouseVO warehouse) {
        log.info("modify: " + warehouse);
        try {
            boolean modifyResult = service.modify(warehouse);
            return modifyResult ? ResponseEntity.ok("success")
                    : new ResponseEntity<>("변경된 창고가 없습니다.", HttpStatus.BAD_REQUEST);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.parseMediaType("text/plain;charset=UTF-8"))
                    .body(e.getMessage());
        } catch (Exception e) {
            log.error("modify error: ", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .contentType(MediaType.parseMediaType("text/plain;charset=UTF-8"))
                    .body("창고 수정 중 오류가 발생했습니다.");
        }
    }

    @PostMapping(value = "/toggle-use", produces = MediaType.TEXT_PLAIN_VALUE + ";charset=UTF-8")
    @ResponseBody
    // 한국어: 창고 사용 여부 변경 요청을 처리합니다.
    // 日本語: 倉庫の使用有無変更リクエストを処理します。
    public ResponseEntity<String> toggleUse(@RequestParam("warehousePk") Long warehousePk, @RequestParam("useYn") String useYn) {
        try {
            return service.toggleUse(warehousePk, useYn) ? ResponseEntity.ok("success")
                    : new ResponseEntity<>("변경된 창고가 없습니다.", HttpStatus.BAD_REQUEST);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            log.error("toggle warehouse use error", e);
            return new ResponseEntity<>("창고 사용구분 변경 중 오류가 발생했습니다.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/hierarchy-members")
    @ResponseBody
    // 한국어: 창고 계층그룹 구성 창고를 조회합니다.
    // 日本語: 倉庫階層グループの所属倉庫を取得します。
    public ResponseEntity<?> hierarchyMembers(@RequestParam("whHierGroupPk") Long whHierGroupPk) {
        try {
            return ResponseEntity.ok().cacheControl(org.springframework.http.CacheControl.noStore()).body(service.getHierarchyMembers(whHierGroupPk));
        } catch (Exception e) {
            log.error("warehouse hierarchy members error", e);
            return new ResponseEntity<>("창고 계층그룹 구성창고 조회 중 오류가 발생했습니다.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/bulk-hierarchy-group", produces = MediaType.TEXT_PLAIN_VALUE + ";charset=UTF-8")
    @ResponseBody
    // 한국어: 선택 창고에 계층그룹을 일괄 적용합니다.
    // 日本語: 選択した倉庫に階層グループを一括適用します。
    public ResponseEntity<String> bulkHierarchyGroup(@RequestParam("warehousePks") List<Long> warehousePks,
                                                     @RequestParam("whHierGroupPk") Long whHierGroupPk) {
        try {
            if (hierarchyGroupService.get(HierarchyGroupType.WAREHOUSE, whHierGroupPk) == null) {
                return new ResponseEntity<>("선택한 창고계층그룹이 존재하지 않습니다.", HttpStatus.BAD_REQUEST);
            }
            return ResponseEntity.ok(String.valueOf(service.bulkAssignHierarchyGroup(warehousePks, whHierGroupPk)));
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            log.error("warehouse bulk hierarchy group error", e);
            return new ResponseEntity<>("창고계층그룹 적용 중 오류가 발생했습니다.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // 5. 삭제 (AJAX)
    @PostMapping(value = "/remove", produces = MediaType.TEXT_PLAIN_VALUE + ";charset=UTF-8")
    @ResponseBody
    // 한국어: 선택한 창고를 삭제하며, 품목이 연결된 경우 삭제를 차단합니다.
    // 日本語: 選択した倉庫を削除し、商品が紐づいている場合は削除を拒否します。
    public ResponseEntity<String> remove(@RequestParam("warehousePk") Long warehousePk) {
        log.info("remove warehouse..." + warehousePk);
        try {
            boolean removeResult = service.remove(warehousePk);
            return removeResult
                    ? ResponseEntity.ok("success")
                    : new ResponseEntity<>("삭제할 창고가 없습니다.", HttpStatus.BAD_REQUEST);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            log.error("remove warehouse error", e);
            return new ResponseEntity<>("창고 삭제 중 오류가 발생했습니다.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // --- 그룹 팝업용 데이터 조회 API (전체 포함) ---
    @GetMapping("/salesPriceGroupList")
    @ResponseBody
    // 한국어: 영업단가그룹 팝업 목록을 조회합니다.
    // 日本語: 販売単価グループのポップアップ一覧を取得します。
    public ResponseEntity<?> getSalesPriceGroupList() {
        log.info("getSalesPriceGroupList...");
        return new ResponseEntity<>(service.getSalesPriceGroupList(), HttpStatus.OK);
    }

    @GetMapping("/purPriceGroupList")
    @ResponseBody
    // 한국어: 구매단가그룹 팝업 목록을 조회합니다.
    // 日本語: 仕入単価グループのポップアップ一覧を取得します。
    public ResponseEntity<?> getPurPriceGroupList() {
        log.info("getPurPriceGroupList...");
        return new ResponseEntity<>(service.getPurPriceGroupList(), HttpStatus.OK);
    }

    @GetMapping("/whHierGroupList")
    @ResponseBody
    // 한국어: 창고 계층그룹 팝업 목록을 조회합니다.
    // 日本語: 倉庫階層グループのポップアップ一覧を取得します。
    public ResponseEntity<?> getWhHierGroupList() {
        log.info("getWhHierGroupList...");
        return new ResponseEntity<>(service.getWhHierGroupList(), HttpStatus.OK);
    }

    @GetMapping("/prod-process-list")
    @ResponseBody
    // 한국어: 생산공정 팝업 목록을 조회합니다.
    // 日本語: 生産工程のポップアップ一覧を取得します。
    public ResponseEntity<?> getProdProcessList() {
        return ResponseEntity.ok(service.getProdProcessList());
    }

    @GetMapping("/outsource-partner-list")
    @ResponseBody
    // 한국어: 외주거래처 팝업 목록을 조회합니다.
    // 日本語: 外注取引先のポップアップ一覧を取得します。
    public ResponseEntity<?> getOutsourcePartnerList() {
        return ResponseEntity.ok(service.getOutsourcePartnerList());
    }
}
