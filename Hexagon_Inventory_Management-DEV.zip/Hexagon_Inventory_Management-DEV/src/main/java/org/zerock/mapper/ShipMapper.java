package org.zerock.mapper;

import java.math.BigDecimal;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.zerock.domain.Criteria;
import org.zerock.domain.ShipSourceItemVO;
import org.zerock.domain.ShipmentItemVO;
import org.zerock.domain.ShipmentVO;
import org.zerock.domain.ShippingOrderItemVO;
import org.zerock.domain.ShippingOrderVO;
import org.zerock.domain.ShippingStatusVO;

public interface ShipMapper {
    // 한국어: 출하지시서 목록을 조회합니다.
    // 日本語: 出荷指示書一覧を取得します。
    List<ShippingOrderVO> getShippingOrderList(Criteria cri);
    ShippingOrderVO getShippingOrder(Long shippingOrderId);
    List<ShippingOrderItemVO> getShippingOrderItems(Long shippingOrderId);
    int countShippingOrders(Criteria cri);
    void insertShippingOrder(ShippingOrderVO vo);
    int updateShippingOrder(ShippingOrderVO vo);
    int deleteSaleShippingLinksByOrderId(Long shippingOrderId);
    // 한국어: 출하지시서의 기존 상세 품목을 삭제합니다.
    int deleteShippingOrderItems(Long shippingOrderId);
    // 日本語: 出荷指示書の明細品目を登録します。
    void insertShippingOrderItem(ShippingOrderItemVO item);
    int updateShippingOrderItem(ShippingOrderItemVO item);
    List<ShipSourceItemVO> getSaleSourceList(@Param("keyword") String keyword, @Param("businessPartnerId") Long businessPartnerId, @Param("warehouseId") Long warehouseId);
    void insertSaleShippingLink(@Param("saleItemId") Long saleItemId, @Param("shippingOrderItemId") Long shippingOrderItemId, @Param("appliedQty") BigDecimal appliedQty);
    BigDecimal getSaleAvailableQuantity(Long saleItemId);

    List<ShipmentVO> getShipmentList(Criteria cri);
    // 한국어: 출하 전표 한 건의 상세 정보를 조회합니다.
    ShipmentVO getShipment(Long shipmentId);
    // 日本語: 出荷伝票の明細品目一覧を取得します。
    List<ShipmentItemVO> getShipmentItems(Long shipmentId);
    int countShipments(Criteria cri);
    void insertShipment(ShipmentVO vo);
    int updateShipment(ShipmentVO vo);
    int deleteShipmentItems(Long shipmentId);
    void insertShipmentItem(ShipmentItemVO item);
    // 한국어: 출하 현황을 창고·거래처·품목·기간 등의 조건으로 조회합니다.
    // 日本語: 出荷状況を倉庫・取引先・品目・期間などの条件で取得します。
    List<ShippingStatusVO> getShippingStatus(@Param("warehouseId") Long warehouseId,
                                          @Param("businessPartnerId") Long businessPartnerId,
                                          @Param("itemId") Long itemId,
                                          @Param("projectId") Long projectId,
                                          @Param("dateFrom") String dateFrom,
                                          @Param("dateTo") String dateTo,
                                          @Param("voucherNo") String voucherNo,
                                          @Param("keyword") String keyword);
    // 한국어: 미출하 출하 대상 목록을 조회합니다.
    // 日本語: 未出荷の出荷対象一覧を取得します。
    List<ShipmentItemVO> getUnshippedSourceList(@Param("keyword") String keyword, @Param("businessPartnerId") Long businessPartnerId, @Param("warehouseId") Long warehouseId);
    void insertShipResultLink(@Param("shippingOrderItemId") Long shippingOrderItemId, @Param("shipmentItemId") Long shipmentItemId, @Param("appliedQty") BigDecimal appliedQty);
    BigDecimal getUnshippedQuantity(Long shippingOrderItemId);
    // 한국어: 출하지시 상세의 품목·거래처·창고 및 미출하수량을 검증하기 위한 원본 정보를 조회합니다.
    // 日本語: 出荷指示明細の品目・取引先・倉庫・未出荷数量を検証するための元データを取得します。
    ShipmentItemVO getShippingOrderItemSource(Long shippingOrderItemId);
    int updateShippingOrderProgress(@Param("shippingOrderItemId") Long shippingOrderItemId);
    int updateShippingOrderProgressForOrder(Long shippingOrderId);
    void cancelShippingOrder(Long shippingOrderId);
    void cancelShipment(Long shipmentId);
    // 한국어: 출하 전표에 연결된 출하지시 결과를 삭제합니다.
    // 한국어: 출하 전표에 연결된 출하지시 결과 데이터를 삭제합니다.
    // 日本語: 出荷伝票に連携された出荷指示結果データを削除します。
    int deleteShipResultLinksByShipmentId(Long shipmentId);
    // 日本語: 出荷伝票に連携された出荷指示書ID一覧を取得します。
    List<Long> getLinkedShippingOrderIds(Long shipmentId);

    List<java.util.Map<String, Object>> getPartnerList(@Param("keyword") String keyword);
    List<java.util.Map<String, Object>> getWarehouseList(@Param("keyword") String keyword);
    List<java.util.Map<String, Object>> getItemList(@Param("keyword") String keyword);
    List<java.util.Map<String, Object>> getManagerList(@Param("keyword") String keyword);
    // 한국어: 출하 화면의 프로젝트 검색 데이터를 조회합니다.
    List<java.util.Map<String, Object>> getProjectList(@Param("keyword") String keyword);
}
