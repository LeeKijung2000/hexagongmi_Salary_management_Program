package org.zerock.mapper;

import java.util.List;
import java.math.BigDecimal;

import org.apache.ibatis.annotations.Param;
import org.zerock.domain.Criteria;
import org.zerock.domain.ItemGroup1VO;
import org.zerock.domain.ItemGroup2VO;
import org.zerock.domain.ItemGroup3VO;
import org.zerock.domain.ItemHierGroupVO;
import org.zerock.domain.ItemBulkChangeVO;
import org.zerock.domain.WarehouseVO;
import org.zerock.domain.ItemVO;
import org.zerock.domain.ProdProcessVO;
import org.zerock.domain.QualityInspTypeVO;

/**
 * 한국어: 품목 SQL을 매핑하는 MyBatis Mapper입니다.
 * 日本語: 商品SQLをマッピングするMyBatis Mapperです。
 */
public interface ItemMapper {

    List<ItemVO> getList();

    List<ItemVO> getListWithPaging(Criteria cri);

    // 한국어: 품목 데이터를 저장하고 생성된 키를 반환합니다.
    // 한국어: 품목 데이터를 저장하고 생성된 품목 ID를 설정합니다.
    // 日本語: 品目データを登録し、生成された品目IDを設定します。
    void insertSelectKey(ItemVO item);

    // 日本語: 選択した品目の詳細情報を取得します。
    ItemVO read(Long itemPk);

    int delete(Long itemPk);

    int update(ItemVO item);

    // 한국어: 품목 조회 결과의 전체 건수를 계산합니다.
    int getTotalCount(Criteria cri);

    // 日本語: 品目コードの重複件数を取得します。
    int countByCode(@Param("itemCode") String itemCode, @Param("itemPk") Long itemPk);

    int countByBarcode(@Param("barcode") String barcode, @Param("itemPk") Long itemPk);

    List<ItemGroup1VO> getGroup1List();

    // 한국어: 2차 그룹 목록을 조회합니다.
    List<ItemGroup2VO> getGroup2List();

    // 日本語: 第3階層グループ一覧を取得します。
    List<ItemGroup3VO> getGroup3List();

    List<ItemHierGroupVO> getItemHierGroupList();

    List<java.util.Map<String, Object>> getHierarchyMembers(@Param("itemHierGroupPk") Long itemHierGroupPk);

    // 한국어: 생산공정 목록을 조회합니다.
    List<ProdProcessVO> getProdProcessList();

    // 日本語: 品質検査タイプ一覧を取得します。
    List<QualityInspTypeVO> getQualityInspTypeList();

    List<ItemVO> getBarcodeItems(List<Long> itemPks);

    int updateBarcode(@Param("itemPk") Long itemPk, @Param("barcode") String barcode);

    // 한국어: 창고 목록을 조회합니다.
    List<WarehouseVO> getWarehouseList();

    // 日本語: 品目に関連する倉庫ID一覧を取得します。
    List<Long> getWarehousePks(@Param("itemPk") Long itemPk);

    int deleteItemWarehouses(@Param("itemPk") Long itemPk);

    /**
     * 한국어: 품목에 연결된 단가 정보를 삭제합니다. 품목 삭제 전에 자식 데이터를 정리합니다.
     * 日本語: 商品に紐づく単価情報を削除します。商品削除前に子データを整理します。
     */
    int deleteItemPrices(@Param("itemPk") Long itemPk);

    int insertItemWarehouse(@Param("itemPk") Long itemPk,
                            @Param("warehousePk") Long warehousePk,
                            @Param("quantity") BigDecimal quantity);

    // 한국어: 품목의 가격 정보를 등록하거나 기존 가격을 갱신합니다.
    // 日本語: 品目価格情報を登録または既存データを更新します。
    int upsertItemPrice(@Param("itemPk") Long itemPk,
                        @Param("priceType") String priceType,
                        @Param("priceAmount") BigDecimal priceAmount);

    // 한국어: 선택한 데이터를 일괄 수정합니다.
    // 日本語: 選択したデータを一括更新します。
    int bulkModify(@Param("itemPks") List<Long> itemPks, @Param("change") ItemBulkChangeVO change);

    int bulkAssignItemHierGroup(@Param("itemPks") List<Long> itemPks, @Param("itemHierGroupPk") Long itemHierGroupPk);
}
