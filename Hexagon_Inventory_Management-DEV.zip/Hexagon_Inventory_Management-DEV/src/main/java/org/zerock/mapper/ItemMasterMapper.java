package org.zerock.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.zerock.domain.MasterCodeVO;

public interface ItemMasterMapper {
    // 한국어: 품목 마스터 코드 목록을 조건과 함께 조회합니다.
    // 日本語: 品目マスターコード一覧を条件付きで取得します。
    List<MasterCodeVO> getList(@Param("masterType") String masterType,
                               @Param("keyword") String keyword);

    // 한국어: 품목 마스터 코드 한 건의 상세 정보를 조회합니다.
    // 日本語: 品目マスターコード1件の詳細情報を取得します。
    MasterCodeVO read(@Param("masterType") String masterType,
                      @Param("pk") Long pk);

    // 한국어: 품목 마스터 코드의 중복 건수를 조회합니다.
    // 日本語: 品目マスターコードの重複件数を取得します。
    int countByCode(@Param("masterType") String masterType,
                    @Param("code") String code,
                    @Param("pk") Long pk);

    // 한국어: 품목 마스터 데이터를 저장합니다.
    // 日本語: 品目マスターデータを登録します。
    void insert(MasterCodeVO vo);

    int update(MasterCodeVO vo);

    int delete(@Param("masterType") String masterType,
               @Param("pk") Long pk);

    // 한국어: 품목 마스터 코드가 품목에서 참조되는 건수를 조회합니다.
    // 日本語: 品目マスターコードが品目から参照されている件数を取得します。
    int countItemReferences(@Param("masterType") String masterType,
                            @Param("pk") Long pk);

    // 한국어: 품목 마스터 관련 countWarehouseReferences 기능을 처리합니다.
    // 日本語: 品目マスター関連のcountWarehouseReferences処理を実行します。
    int countWarehouseReferences(@Param("pk") Long pk);
}
