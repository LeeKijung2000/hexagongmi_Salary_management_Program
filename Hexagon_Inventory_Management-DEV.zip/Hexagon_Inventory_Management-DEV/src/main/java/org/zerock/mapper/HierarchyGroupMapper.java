package org.zerock.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.zerock.domain.HierarchyGroupVO;

public interface HierarchyGroupMapper {
    // 한국어: 계층그룹 목록을 조회합니다.
    // 日本語: 階層グループ一覧を取得します。
    List<HierarchyGroupVO> getList(@Param("groupType") String groupType);
    HierarchyGroupVO read(@Param("groupType") String groupType, @Param("pk") Long pk);
    int countByCode(@Param("groupType") String groupType, @Param("code") String code, @Param("pk") Long pk);
    void insert(@Param("groupType") String groupType, @Param("vo") HierarchyGroupVO vo);
    int update(@Param("groupType") String groupType, @Param("vo") HierarchyGroupVO vo);
    int clearChildrenParent(@Param("groupType") String groupType, @Param("pk") Long pk);
    int clearReferences(@Param("groupType") String groupType, @Param("pk") Long pk);
    // 한국어: 계층그룹 데이터를 삭제합니다.
    int delete(@Param("groupType") String groupType, @Param("pk") Long pk);
    // 日本語: 階層グループ関連のcountChildren処理を実行します。
    int countChildren(@Param("groupType") String groupType, @Param("pk") Long pk);
    int countReferences(@Param("groupType") String groupType, @Param("pk") Long pk);
}
