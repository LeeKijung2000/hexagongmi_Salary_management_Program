package org.zerock.mapper;

import java.util.List;
import org.zerock.domain.BusinessPartnerManagerVO;
import org.zerock.domain.BusinessPartnerVO;
import org.zerock.domain.Criteria;
import org.apache.ibatis.annotations.Param;

/**
 * 한국어: 거래처 SQL을 매핑하는 MyBatis Mapper입니다.
 * 日本語: 取引先SQLをマッピングするMyBatis Mapperです。
 */
public interface BusinessPartnerMapper {
    List<BusinessPartnerVO> getListWithPaging(Criteria cri);
    BusinessPartnerVO read(Long businessPartnerId);
    void insertSelectKey(BusinessPartnerVO businessPartner);
    int update(BusinessPartnerVO businessPartner);
    int delete(Long businessPartnerId);
    // 한국어: 거래처 조회 결과의 전체 건수를 계산합니다.
    int getTotalCount(Criteria cri);
    // 日本語: 取引先コードの重複件数を取得します。
    int countByCode(@Param("businessPartnerCode") String businessPartnerCode, @Param("businessPartnerId") Long businessPartnerId);

    List<java.util.Map<String, Object>> getGroup1List();
    List<java.util.Map<String, Object>> getGroup2List();
    List<java.util.Map<String, Object>> getSalesPriceGroupList();
    List<java.util.Map<String, Object>> getPurchasePriceGroupList();
    // 한국어: 통화 목록을 조회합니다.
    List<java.util.Map<String, Object>> getCurrencyList();

    // 日本語: 担当者一覧を取得します。
    List<BusinessPartnerManagerVO> getManagerList(@Param("keyword") String keyword);
    int countManagerByEmployeeCode(@Param("employeeCode") String employeeCode);
    void insertManagerSelectKey(BusinessPartnerManagerVO manager);
    List<java.util.Map<String, Object>> getHierarchyMembers(@Param("bpHierGroupId") Long bpHierGroupId);
    int bulkAssignHierarchyGroup(@Param("businessPartnerIds") java.util.List<Long> businessPartnerIds, @Param("bpHierGroupId") Long bpHierGroupId);

    //전체 거래처 조회
    //全体取引先照会
    List<BusinessPartnerVO> getAllList();
}
