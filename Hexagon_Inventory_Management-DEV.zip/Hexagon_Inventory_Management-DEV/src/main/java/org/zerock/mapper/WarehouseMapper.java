package org.zerock.mapper;

import java.util.List;
import java.util.Map;
import org.zerock.domain.Criteria;
import org.zerock.domain.WarehouseVO;
import org.apache.ibatis.annotations.Param;

/**
 * 한국어: 창고 SQL을 매핑하는 MyBatis Mapper입니다.
 * 日本語: 倉庫SQLをマッピングするMyBatis Mapperです。
 */
public interface WarehouseMapper {
    List<WarehouseVO> getList();
    List<WarehouseVO> getListWithPaging(Criteria cri);
    void insertSelectKey(WarehouseVO warehouse);
    WarehouseVO read(Long warehousePk);
    int delete(Long warehousePk);

    /**
     * 한국어: 창고에 연결된 품목 재고 건수를 조회합니다.
     * 日本語: 倉庫に紐づく商品在庫件数を取得します。
     */
    int countInventoryItems(@org.apache.ibatis.annotations.Param("warehousePk") Long warehousePk);

    int update(WarehouseVO warehouse);
    int bulkAssignHierarchyGroup(@Param("warehousePks") java.util.List<Long> warehousePks,
                                 @Param("whHierGroupPk") Long whHierGroupPk);
    int toggleUse(@org.apache.ibatis.annotations.Param("warehousePk") Long warehousePk, @org.apache.ibatis.annotations.Param("useYn") String useYn);
    // 한국어: 창고 조회 결과의 전체 건수를 계산합니다.
    int getTotalCount(Criteria cri);

    // 팝업 데이터용 그룹 조회 쿼리 매핑
    // 日本語: 販売価格グループ一覧を取得します。
    List<Map<String, Object>> getSalesPriceGroupList();
    List<Map<String, Object>> getPurPriceGroupList();
    List<Map<String, Object>> getWhHierGroupList();
    List<Map<String, Object>> getProdProcessList();
    // 한국어: 외주 거래처 목록을 조회합니다.
    List<Map<String, Object>> getOutsourcePartnerList();
    Long findProdProcessIdByName(String processName);
    int insertProdProcessByName(String processName);
    // 日本語: 外注取引先名から取引先IDを取得します。
    Long findOutsourcePartnerIdByName(String partnerName);
    int insertOutsourcePartnerByName(String partnerName);
    List<Map<String, Object>> getHierarchyMembers(@Param("whHierGroupPk") Long whHierGroupPk);
}
