package org.zerock.service;

import java.util.List;

import org.zerock.domain.HierarchyGroupType;
import org.zerock.domain.HierarchyGroupVO;

public interface HierarchyGroupService {
    // 한국어: 계층그룹 목록을 조회합니다.
    // 日本語: 階層グループ一覧を取得します。
    List<HierarchyGroupVO> getList(HierarchyGroupType type);
    HierarchyGroupVO get(HierarchyGroupType type, Long pk);
    boolean isDuplicateCode(HierarchyGroupType type, String code, Long pk);
    void register(HierarchyGroupType type, HierarchyGroupVO vo);
    boolean modify(HierarchyGroupType type, HierarchyGroupVO vo);
    boolean remove(HierarchyGroupType type, Long pk);
}
