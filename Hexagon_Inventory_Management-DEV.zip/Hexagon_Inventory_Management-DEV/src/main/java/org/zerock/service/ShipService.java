package org.zerock.service;

import java.util.List;
import java.util.Map;
import org.zerock.domain.Criteria;
import org.zerock.domain.ShipSourceItemVO;
import org.zerock.domain.ShipmentVO;
import org.zerock.domain.ShippingOrderVO;
import org.zerock.domain.ShippingStatusVO;

public interface ShipService {
    // 한국어: 출하지시서 목록을 조회합니다.
    // 日本語: 出荷指示書一覧を取得します。
    List<ShippingOrderVO> getShippingOrderList(Criteria cri);
    int getShippingOrderTotal(Criteria cri);
    ShippingOrderVO getShippingOrder(Long id);
    void registerShippingOrder(ShippingOrderVO vo);
    void updateShippingOrder(ShippingOrderVO vo);
    List<ShipSourceItemVO> getSaleSourceList(String keyword, Long businessPartnerId, Long warehouseId);
    void cancelShippingOrder(Long id);

    // 한국어: 출하 전표 목록을 조회합니다.
    // 日本語: 出荷伝票一覧を取得します。
    List<ShipmentVO> getShipmentList(Criteria cri);
    int getShipmentTotal(Criteria cri);
    ShipmentVO getShipment(Long id);
    void registerShipment(ShipmentVO vo);
    void updateShipment(ShipmentVO vo);
    List<ShippingStatusVO> getShippingStatus(Long warehouseId, Long businessPartnerId, Long itemId,
                                             Long projectId, String dateFrom, String dateTo,
                                             String voucherNo, String keyword);
    // 한국어: 미출하 출하 대상 목록을 조회합니다.
    // 日本語: 未出荷の出荷対象一覧を取得します。
    List<org.zerock.domain.ShipmentItemVO> getUnshippedSourceList(String keyword, Long businessPartnerId, Long warehouseId);
    void cancelShipment(Long id);

    List<Map<String, Object>> getPartnerList(String keyword);
    List<Map<String, Object>> getWarehouseList(String keyword);
    List<Map<String, Object>> getItemList(String keyword);
    List<Map<String, Object>> getManagerList(String keyword);
    // 한국어: 출하 화면의 프로젝트 검색 데이터를 조회합니다.
    // 한국어: 출하 화면에서 사용할 프로젝트 검색 목록을 조회합니다.
    // 日本語: 出荷画面で使用するプロジェクト検索一覧を取得します。
    List<Map<String, Object>> getProjectList(String keyword);
}
