package org.zerock.service;

import java.util.List;

import org.zerock.domain.MasterCodeVO;
import org.zerock.domain.MasterType;

public interface ItemMasterService {
    // 한국어: 품목 마스터 목록을 조회합니다.
    // 日本語: 品目マスター一覧を取得します。
    List<MasterCodeVO> getList(MasterType type, String keyword);
    MasterCodeVO get(MasterType type, Long pk);
    boolean isDuplicateCode(MasterType type, String code, Long pk);
    void register(MasterType type, MasterCodeVO vo);
    boolean modify(MasterType type, MasterCodeVO vo);
    boolean remove(MasterType type, Long pk);
}
