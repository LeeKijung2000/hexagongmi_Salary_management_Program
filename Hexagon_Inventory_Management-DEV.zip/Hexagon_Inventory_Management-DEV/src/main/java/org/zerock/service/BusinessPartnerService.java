package org.zerock.service;

import java.util.List;
import java.util.Map;
import org.zerock.domain.BusinessPartnerManagerVO;
import org.zerock.domain.BusinessPartnerVO;
import org.zerock.domain.Criteria;

/**
 * 한국어: 거래처 업무 서비스 계층.
 * 日本語: 取引先業務のサービス層。
 */
public interface BusinessPartnerService {
    void register(BusinessPartnerVO businessPartner);
    BusinessPartnerVO get(Long businessPartnerId);
    boolean modify(BusinessPartnerVO businessPartner);
    boolean remove(Long businessPartnerId);
    List<BusinessPartnerVO> getList(Criteria cri);
    //전체 거래처 조회
    //全体取引先照会
    public List<BusinessPartnerVO> getAllList();
    // 한국어: 거래처 목록의 전체 건수를 조회합니다.
    // 한국어: 거래처 조회 결과의 전체 건수를 반환합니다.
    // 日本語: 取引先検索結果の総件数を返します。
    int getTotal(Criteria cri);
    // 日本語: 取引先コードが重複しているか確認します。
    boolean isDuplicateCode(String businessPartnerCode, Long businessPartnerId);
    List<Map<String, Object>> getGroup1List();
    List<Map<String, Object>> getGroup2List();
    List<Map<String, Object>> getSalesPriceGroupList();
    List<Map<String, Object>> getPurchasePriceGroupList();
    List<Map<String, Object>> getCurrencyList();
    // 한국어: 담당자 목록을 조회합니다.
    List<BusinessPartnerManagerVO> getManagerList(String keyword);
    // 日本語: 取引先担当者情報を登録します。
    void registerManager(BusinessPartnerManagerVO manager);
    List<Map<String, Object>> getHierarchyMembers(Long bpHierGroupId);
    int bulkAssignHierarchyGroup(List<Long> businessPartnerIds, Long bpHierGroupId);
}
