package org.zerock.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Collections;
import java.math.BigDecimal;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.zerock.domain.Criteria;
import org.zerock.domain.ItemGroup1VO;
import org.zerock.domain.ItemGroup2VO;
import org.zerock.domain.ItemGroup3VO;
import org.zerock.domain.ItemHierGroupVO;
import org.zerock.domain.ItemBulkChangeVO;
import org.zerock.domain.WarehouseVO;
import org.zerock.domain.ItemVO;
import org.zerock.domain.ProdProcessVO;
import org.zerock.domain.QualityInspTypeVO;
import org.zerock.mapper.ItemMapper;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Service
@Log4j
@AllArgsConstructor
/**
 * 한국어: 품목 업무 서비스 구현체.
 * 日本語: 商品業務サービスの実装クラス。
 */
public class ItemServiceImpl implements ItemService {

    /** 품목 바코드 기본 prefix. 품목 PK를 뒤에 4자리로 붙여 12자리 숫자 코드로 생성합니다. */
    private static final String BARCODE_PREFIX = "99887766";

    private final ItemMapper mapper;

    @Override
    @Transactional
    // 한국어: 품목을 신규 등록하고 창고·단가 정보를 함께 저장합니다.
    // 日本語: 商品を新規登録し、倉庫・単価情報も一緒に保存します。
    public void register(ItemVO item) {
        mapper.insertSelectKey(item);
        replaceItemWarehouses(item.getItemPk(), item.getWarehousePks(), item.getQty());
        saveItemPrices(item);
        if (isBlank(item.getBarcode())) {
            String barcode = generateBarcode(item.getItemPk());
            mapper.updateBarcode(item.getItemPk(), barcode);
            item.setBarcode(barcode);
        }
    }

    @Override
    @Transactional(readOnly = true)
    // 한국어: 품목 ID로 상세 정보를 조회하고 보관창고를 함께 조회합니다.
    // 日本語: 商品IDで詳細情報を取得し、保管倉庫も取得します。
    public ItemVO get(Long itemPk) {
        ItemVO item = mapper.read(itemPk);
        if (item != null) {
            item.setWarehousePks(mapper.getWarehousePks(itemPk));
        }
        return item;
    }

    @Override
    @Transactional
    // 한국어: 품목 기본정보를 수정하고 창고·단가 정보를 동기화합니다.
    // 日本語: 商品基本情報を更新し、倉庫・単価情報を同期します。
    public boolean modify(ItemVO item) {
        if (isBlank(item.getBarcode()) && item.getItemPk() != null) {
            item.setBarcode(generateBarcode(item.getItemPk()));
        }
        boolean updated = mapper.update(item) == 1;
        if (updated) {
            replaceItemWarehouses(item.getItemPk(), item.getWarehousePks(), item.getQty());
            saveItemPrices(item);
        }
        return updated;
    }

    @Override
    @Transactional
    // 한국어: 품목과 연결된 재고 정보를 먼저 삭제한 뒤 품목을 삭제합니다.
    // 日本語: 商品に紐づく在庫情報を先に削除してから商品を削除します。
    public boolean remove(Long itemPk) {
        if (itemPk == null || itemPk <= 0) {
            throw new IllegalArgumentException("삭제할 품목을 선택해주세요.");
        }
        // 한국어: 품목은 단가/재고 같은 자식 데이터를 먼저 삭제해야 외래키 오류가 발생하지 않습니다.
        // 日本語: 商品は単価・在庫などの子データを先に削除してから親データを削除します。
        mapper.deleteItemPrices(itemPk);
        mapper.deleteItemWarehouses(itemPk);
        return mapper.delete(itemPk) == 1;
    }

    @Override
    @Transactional
    // 한국어: 선택된 여러 품목과 재고 연결을 일괄 삭제합니다.
    // 日本語: 選択した複数の商品と在庫関連を一括削除します。
    public boolean removeAll(Long[] itemPks) {
        if (itemPks == null || itemPks.length == 0) {
            return false;
        }
        int count = 0;
        for (Long itemPk : Arrays.asList(itemPks)) {
            if (itemPk != null) {
                // 한국어: 일괄 삭제에서도 품목단가와 재고 연결을 먼저 정리합니다.
                // 日本語: 一括削除でも商品単価と在庫の関連データを先に整理します。
                mapper.deleteItemPrices(itemPk);
                mapper.deleteItemWarehouses(itemPk);
                count += mapper.delete(itemPk);
            }
        }
        return count > 0;
    }

    @Override
    @Transactional(readOnly = true)
    // 한국어: 검색 조건과 페이징을 적용해 품목 목록을 조회합니다.
    // 日本語: 検索条件とページングを適用して商品一覧を取得します。
    public List<ItemVO> getList(Criteria cri) {
        return mapper.getListWithPaging(cri);
    }

    @Override
    @Transactional(readOnly = true)
    // 한국어: 검색 조건에 맞는 품목 전체 건수를 조회합니다.
    // 日本語: 検索条件に一致する商品の総件数を取得します。
    public int getTotal(Criteria cri) {
        return mapper.getTotalCount(cri);
    }

    @Override
    @Transactional(readOnly = true)
    // 한국어: 품목코드의 중복 여부를 확인합니다.
    // 日本語: 商品コードの重複有無を確認します。
    public boolean isDuplicateCode(String itemCode, Long itemPk) {
        if (itemCode == null || itemCode.trim().isEmpty()) {
            return false;
        }
        return mapper.countByCode(itemCode.trim(), itemPk) > 0;
    }

    @Override
    @Transactional(readOnly = true)
    // 한국어: 바코드의 중복 여부를 확인합니다.
    // 日本語: バーコードの重複有無を確認します。
    public boolean isDuplicateBarcode(String barcode, Long itemPk) {
        if (barcode == null || barcode.trim().isEmpty()) {
            return false;
        }
        return mapper.countByBarcode(barcode.trim(), itemPk) > 0;
    }

    @Override
    @Transactional(readOnly = true)
    // 한국어: 품목 그룹1 목록을 조회합니다.
    // 日本語: 商品グループ1の一覧を取得します。
    public List<ItemGroup1VO> getGroup1List() {
        return mapper.getGroup1List();
    }

    @Override
    @Transactional(readOnly = true)
    // 한국어: 품목 그룹2 목록을 조회합니다.
    // 日本語: 商品グループ2の一覧を取得します。
    public List<ItemGroup2VO> getGroup2List() {
        return mapper.getGroup2List();
    }

    @Override
    @Transactional(readOnly = true)
    // 한국어: 품목 그룹3 목록을 조회합니다.
    // 日本語: 商品グループ3の一覧を取得します。
    public List<ItemGroup3VO> getGroup3List() {
        return mapper.getGroup3List();
    }

    @Override
    @Transactional(readOnly = true)
    // 한국어: 품목 계층그룹 목록을 조회합니다.
    // 日本語: 商品階層グループの一覧を取得します。
    public List<ItemHierGroupVO> getItemHierGroupList() {
        return mapper.getItemHierGroupList();
    }

    @Override
    @Transactional(readOnly = true)
    // 한국어: 특정 품목 계층그룹의 구성 품목을 조회합니다.
    // 日本語: 指定した商品階層グループの所属商品を取得します。
    public List<java.util.Map<String, Object>> getHierarchyMembers(Long itemHierGroupPk) {
        return mapper.getHierarchyMembers(itemHierGroupPk);
    }

    @Override
    @Transactional(readOnly = true)
    // 한국어: 생산공정 목록을 조회합니다.
    // 日本語: 生産工程の一覧を取得します。
    public List<ProdProcessVO> getProdProcessList() {
        return mapper.getProdProcessList();
    }

    @Override
    @Transactional(readOnly = true)
    // 한국어: 품질검사유형 목록을 조회합니다.
    // 日本語: 品質検査種別の一覧を取得します。
    public List<QualityInspTypeVO> getQualityInspTypeList() {
        return mapper.getQualityInspTypeList();
    }
    @Override
    @Transactional
    // 한국어: 선택 품목의 바코드 정보를 조회하고 필요하면 자동 생성합니다.
    // 日本語: 選択した商品のバーコードを取得し、必要なら自動生成します。
    public List<ItemVO> getBarcodeItems(Long[] itemPks) {
        List<ItemVO> result = new ArrayList<>();
        if (itemPks == null || itemPks.length == 0) {
            return result;
        }

        List<Long> ids = new ArrayList<>();
        for (Long itemPk : itemPks) {
            if (itemPk != null && itemPk > 0 && !ids.contains(itemPk)) {
                ids.add(itemPk);
            }
        }
        if (ids.isEmpty()) {
            return result;
        }

        List<ItemVO> items = mapper.getBarcodeItems(ids);
        if (items == null) {
            return result;
        }

        for (ItemVO item : items) {
            if (isBlank(item.getBarcode())) {
                String barcode = generateBarcode(item.getItemPk());
                mapper.updateBarcode(item.getItemPk(), barcode);
                item.setBarcode(barcode);
            }
            result.add(item);
        }
        return result;
    }

    @Override
    @Transactional(readOnly = true)
    // 한국어: 품목 등록/수정 화면에서 사용할 보관창고 목록을 조회합니다.
    // 日本語: 商品登録・更新画面で使用する保管倉庫一覧を取得します。
    public List<WarehouseVO> getWarehouseList() {
        return mapper.getWarehouseList();
    }

    @Override
    @Transactional
    // 한국어: 품목의 보관창고 연결을 기존 값과 교체합니다.
    // 日本語: 商品の保管倉庫関連を既存値から置き換えます。
    public void replaceItemWarehouses(Long itemPk, List<Long> warehousePks) {
        replaceItemWarehouses(itemPk, warehousePks, null);
    }

    // 한국어: 품목의 보관창고 연결을 기존 값과 교체합니다.
    // 日本語: 商品の保管倉庫関連を既存値から置き換えます。
    private void replaceItemWarehouses(Long itemPk, List<Long> warehousePks, BigDecimal quantity) {
        if (itemPk == null) {
            throw new IllegalArgumentException("품목 PK가 없습니다.");
        }
        mapper.deleteItemWarehouses(itemPk);
        if (warehousePks == null || warehousePks.isEmpty()) {
            return;
        }
        Long selectedWarehousePk = null;
        for (Long warehousePk : warehousePks) {
            if (warehousePk != null && warehousePk > 0) {
                if (selectedWarehousePk != null && !selectedWarehousePk.equals(warehousePk)) {
                    throw new IllegalArgumentException("품목은 보관창고를 1개만 선택할 수 있습니다.");
                }
                selectedWarehousePk = warehousePk;
            }
        }
        if (selectedWarehousePk != null) {
            mapper.insertItemWarehouse(itemPk, selectedWarehousePk, quantity);
        }
    }

    // 한국어: 품목의 가격 정보를 저장합니다.
    // 日本語: 品目の価格情報を保存します。
    private void saveItemPrices(ItemVO item) {
        Long itemPk = item.getItemPk();
        if (itemPk == null || itemPk <= 0) {
            throw new IllegalArgumentException("품목 PK가 없습니다.");
        }
        mapper.upsertItemPrice(itemPk, "PURCHASE", item.getPurchasePrice());
        mapper.upsertItemPrice(itemPk, "SALES", item.getSalesPrice());
        mapper.upsertItemPrice(itemPk, "OUTSOURCE", item.getOutsourcingPrice());
    }

    @Override
    @Transactional
    // 한국어: 선택한 품목들의 지정 필드를 일괄 변경합니다.
    // 日本語: 選択した商品の指定フィールドを一括変更します。
    public int bulkModify(List<Long> itemPks, ItemBulkChangeVO change) {
        validateBulkIds(itemPks);
        normalizeBulkChange(change);
        return mapper.bulkModify(itemPks, change);
    }

    @Override
    @Transactional
    // 한국어: 선택한 품목에 계층그룹을 일괄 적용합니다.
    // 日本語: 選択した商品に階層グループを一括適用します。
    public int bulkAssignItemHierGroup(List<Long> itemPks, Long itemHierGroupPk) {
        validateBulkIds(itemPks);
        if (itemHierGroupPk != null && itemHierGroupPk <= 0) {
            itemHierGroupPk = null;
        }
        return mapper.bulkAssignItemHierGroup(itemPks, itemHierGroupPk);
    }

    // 한국어: 일괄 처리 대상 ID 목록의 유효성을 검증합니다.
    // 日本語: 一括処理対象ID一覧の有効性を検証します。
    private void validateBulkIds(List<Long> itemPks) {
        if (itemPks == null || itemPks.isEmpty()) {
            throw new IllegalArgumentException("변경할 품목을 선택해주세요.");
        }
        for (Long pk : itemPks) {
            if (pk == null || pk <= 0) {
                throw new IllegalArgumentException("올바르지 않은 품목 PK가 포함되어 있습니다.");
            }
        }
    }

    // 한국어: 일괄 수정 값을 정규화합니다.
    // 日本語: 一括更新値を正規化します。
    private void normalizeBulkChange(ItemBulkChangeVO change) {
        if (change == null || change.getField() == null) {
            throw new IllegalArgumentException("변경 항목을 선택해주세요.");
        }
        String field = change.getField().trim();
        change.setField(field);
        String raw = change.getTextValue() == null ? "" : change.getTextValue().trim();
        if ("itemName".equals(field) || "spec".equals(field) || "unit".equals(field)) {
            change.setTextValue(raw);
            return;
        }
        if ("itemDiv".equals(field) || "qualityInspMethod".equals(field)) {
            try {
                int value = Integer.parseInt(raw);
                if ("itemDiv".equals(field) && (value < 0 || value > 5)) {
                    throw new IllegalArgumentException("품목구분 값이 올바르지 않습니다.");
                }
                if ("qualityInspMethod".equals(field) && (value < 0 || value > 2)) {
                    throw new IllegalArgumentException("품질검사방법 값이 올바르지 않습니다.");
                }
                change.setIntValue(value);
                return;
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("정수 형식으로 입력해주세요.");
            }
        }
        if ("qty".equals(field) || "purchasePrice".equals(field) || "salesPrice".equals(field)) {
            try {
                BigDecimal value = new BigDecimal(raw);
                if (value.signum() < 0) {
                    throw new IllegalArgumentException("수량/단가는 0 이상이어야 합니다.");
                }
                change.setDecimalValue(value);
                return;
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("숫자 형식으로 입력해주세요.");
            }
        }
        throw new IllegalArgumentException("지원하지 않는 일괄변경 항목입니다.");
    }

    // 한국어: 품목 ID를 기준으로 신규 바코드를 생성합니다.
    // 日本語: 品目IDを基準に新しいバーコードを生成します。
    private String generateBarcode(Long itemPk) {
        if (itemPk == null || itemPk <= 0) {
            throw new IllegalArgumentException("바코드 생성에 필요한 품목 PK가 없습니다.");
        }
        return BARCODE_PREFIX + String.format("%04d", itemPk);
    }

    // 한국어: 문자열이 비어 있는지 확인합니다.
    // 한국어: 품목 입력 문자열이 비어 있는지 확인합니다.
    // 日本語: 品目入力文字列が空かどうかを確認します。
    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }

}
