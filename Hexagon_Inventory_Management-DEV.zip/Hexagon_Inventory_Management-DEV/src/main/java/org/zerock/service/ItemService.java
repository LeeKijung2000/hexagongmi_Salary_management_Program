package org.zerock.service;

import java.util.List;

import org.zerock.domain.Criteria;
import org.zerock.domain.ItemGroup1VO;
import org.zerock.domain.ItemGroup2VO;
import org.zerock.domain.ItemGroup3VO;
import org.zerock.domain.ItemHierGroupVO;
import org.zerock.domain.ItemBulkChangeVO;
import org.zerock.domain.WarehouseVO;
import org.zerock.domain.ItemVO;
import org.zerock.domain.ProdProcessVO;
import org.zerock.domain.QualityInspTypeVO;

/**
 * 한국어: 품목 업무 서비스 계층.
 * 日本語: 商品業務のサービス層。
 */
public interface ItemService {

    void register(ItemVO item);

    ItemVO get(Long itemPk);

    // 한국어: 기존 품목 정보를 수정합니다.
    boolean modify(ItemVO item);

    // 日本語: 品目情報を削除します。
    boolean remove(Long itemPk);

    boolean removeAll(Long[] itemPks);

    List<ItemVO> getList(Criteria cri);

    // 한국어: 품목 목록의 전체 건수를 조회합니다.
    int getTotal(Criteria cri);

    // 日本語: 品目コードが重複しているか確認します。
    boolean isDuplicateCode(String itemCode, Long itemPk);

    boolean isDuplicateBarcode(String barcode, Long itemPk);

    List<ItemGroup1VO> getGroup1List();

    // 한국어: 2차 그룹 목록을 조회합니다.
    List<ItemGroup2VO> getGroup2List();

    // 日本語: 第3階層グループ一覧を取得します。
    List<ItemGroup3VO> getGroup3List();

    List<ItemHierGroupVO> getItemHierGroupList();

    List<java.util.Map<String, Object>> getHierarchyMembers(Long itemHierGroupPk);

    // 한국어: 생산공정 목록을 조회합니다.
    List<ProdProcessVO> getProdProcessList();

    // 日本語: 品質検査タイプ一覧を取得します。
    List<QualityInspTypeVO> getQualityInspTypeList();

    List<ItemVO> getBarcodeItems(Long[] itemPks);

    List<WarehouseVO> getWarehouseList();

    // 한국어: 품목의 창고 연결 정보를 전체 교체합니다.
    void replaceItemWarehouses(Long itemPk, List<Long> warehousePks);

    // 日本語: 選択したデータを一括更新します。
    int bulkModify(List<Long> itemPks, ItemBulkChangeVO change);

    int bulkAssignItemHierGroup(List<Long> itemPks, Long itemHierGroupPk);
}
