package org.zerock.service;

import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.zerock.domain.Criteria;
import org.zerock.domain.WarehouseVO;
import org.zerock.mapper.WarehouseMapper;
import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
@AllArgsConstructor
/**
 * 한국어: 창고 업무 서비스 구현체.
 * 日本語: 倉庫業務サービスの実装クラス。
 */
public class WarehouseServiceImpl implements WarehouseService {

    private WarehouseMapper mapper;

    @Override
    @Transactional
    // 한국어: 창고 정보를 신규 등록합니다.
    // 日本語: 倉庫情報を新規登録します。
    public void register(WarehouseVO warehouse) {
        log.info("register warehouse..." + warehouse);
        resolveReferenceNames(warehouse);
        mapper.insertSelectKey(warehouse);
    }

    @Override
    // 한국어: 창고 ID로 상세 정보를 조회합니다.
    // 日本語: 倉庫IDで詳細情報を取得します。
    public WarehouseVO get(Long warehousePk) {
        log.info("get warehouse..." + warehousePk);
        return mapper.read(warehousePk);
    }

    @Override
    @Transactional
    // 한국어: 창고 정보를 수정합니다.
    // 日本語: 倉庫情報を更新します。
    public boolean modify(WarehouseVO warehouse) {
        log.info("modify warehouse..." + warehouse);
        resolveReferenceNames(warehouse);
        return mapper.update(warehouse) == 1;
    }

    private void resolveReferenceNames(WarehouseVO warehouse) {
        if (warehouse == null) throw new IllegalArgumentException("창고 입력 데이터가 없습니다.");
        String processName = warehouse.getProdProcessName() == null ? "" : warehouse.getProdProcessName().trim();
        String partnerName = warehouse.getOutsourcingPartnerName() == null ? "" : warehouse.getOutsourcingPartnerName().trim();
        if (!processName.isEmpty()) {
            Long id = mapper.findProdProcessIdByName(processName);
            if (id == null) {
                mapper.insertProdProcessByName(processName);
                id = mapper.findProdProcessIdByName(processName);
            }
            warehouse.setProdProcessPk(id);
        } else {
            warehouse.setProdProcessPk(null);
        }
        if (!partnerName.isEmpty()) {
            Long id = mapper.findOutsourcePartnerIdByName(partnerName);
            if (id == null) {
                mapper.insertOutsourcePartnerByName(partnerName);
                id = mapper.findOutsourcePartnerIdByName(partnerName);
            }
            warehouse.setOutsourcePartnerId(id);
        } else {
            warehouse.setOutsourcePartnerId(null);
        }
    }

    @Override
    // 한국어: 선택한 창고들에 계층그룹을 일괄 적용합니다.
    // 日本語: 選択した倉庫に階層グループを一括適用します。
    public int bulkAssignHierarchyGroup(List<Long> warehousePks, Long whHierGroupPk) {
        if (warehousePks == null || warehousePks.isEmpty()) throw new IllegalArgumentException("계층그룹을 적용할 창고를 선택해주세요.");
        if (whHierGroupPk == null || whHierGroupPk <= 0) throw new IllegalArgumentException("적용할 창고계층그룹을 선택해주세요.");
        return mapper.bulkAssignHierarchyGroup(warehousePks, whHierGroupPk);
    }

    @Override
    // 한국어: 창고의 사용 여부를 변경합니다.
    // 日本語: 倉庫の使用有無を変更します。
    public boolean toggleUse(Long warehousePk, String useYn) {
        if (warehousePk == null) throw new IllegalArgumentException("사용구분을 변경할 창고를 선택해주세요.");
        if (!"Y".equals(useYn) && !"N".equals(useYn)) throw new IllegalArgumentException("사용구분 값이 올바르지 않습니다.");
        return mapper.toggleUse(warehousePk, useYn) == 1;
    }

    @Override
    // 한국어: 창고를 삭제합니다.
    // 日本語: 倉庫を削除します。
    public boolean remove(Long warehousePk) {
        log.info("remove warehouse..." + warehousePk);
        if (warehousePk == null || warehousePk <= 0) {
            throw new IllegalArgumentException("삭제할 창고를 선택해주세요.");
        }

        // 한국어: 창고에 품목이 하나라도 등록되어 있으면 창고를 삭제할 수 없습니다.
        // 日本語: 倉庫に商品が1件でも登録されている場合は、倉庫を削除できません。
        int inventoryCount = mapper.countInventoryItems(warehousePk);
        if (inventoryCount > 0) {
            throw new IllegalArgumentException("창고에 등록된 품목이 있어 삭제할 수 없습니다. 품목을 먼저 다른 창고로 이동하거나 삭제해주세요.");
        }

        return mapper.delete(warehousePk) == 1;
    }

    @Override
    // 한국어: 검색 조건과 페이징을 적용해 창고 목록을 조회합니다.
    // 日本語: 検索条件とページングを適用して倉庫一覧を取得します。
    public List<WarehouseVO> getList(Criteria cri) {
        log.info("get warehouse list with criteria: " + cri);
        return mapper.getListWithPaging(cri);
    }
    
    // 창고 전체 조회
    // 倉庫全体照会
    public List<WarehouseVO> getAllList(){
    	return mapper.getList();
    }

    @Override
    // 한국어: 창고 전체 건수를 조회합니다.
    // 日本語: 倉庫の総件数を取得します。
    public int getTotal(Criteria cri) {
        log.info("get total count of warehouses");
        return mapper.getTotalCount(cri);
    }

    @Override
    // 한국어: 영업단가그룹 목록을 조회합니다.
    // 日本語: 販売単価グループの一覧を取得します。
    public List<Map<String, Object>> getSalesPriceGroupList() {
        return mapper.getSalesPriceGroupList();
    }

    @Override
    // 한국어: 구매단가그룹 목록을 조회합니다.
    // 日本語: 仕入単価グループの一覧を取得します。
    public List<Map<String, Object>> getPurPriceGroupList() {
        return mapper.getPurPriceGroupList();
    }

    @Override
    // 한국어: 창고 계층그룹 목록을 조회합니다.
    // 日本語: 倉庫階層グループの一覧を取得します。
    public List<Map<String, Object>> getWhHierGroupList() {
        return mapper.getWhHierGroupList();
    }

    @Override
    // 한국어: 생산공정 목록을 조회합니다.
    // 日本語: 生産工程の一覧を取得します。
    public List<Map<String, Object>> getProdProcessList() {
        return mapper.getProdProcessList();
    }

    @Override
    // 한국어: 외주거래처 목록을 조회합니다.
    // 日本語: 外注取引先の一覧を取得します。
    public List<Map<String, Object>> getOutsourcePartnerList() {
        return mapper.getOutsourcePartnerList();
    }

    @Override
    // 한국어: 특정 창고 계층그룹의 구성 창고를 조회합니다.
    // 日本語: 指定した倉庫階層グループの所属倉庫を取得します。
    public List<Map<String, Object>> getHierarchyMembers(Long whHierGroupPk) {
        return mapper.getHierarchyMembers(whHierGroupPk);
    }
}
