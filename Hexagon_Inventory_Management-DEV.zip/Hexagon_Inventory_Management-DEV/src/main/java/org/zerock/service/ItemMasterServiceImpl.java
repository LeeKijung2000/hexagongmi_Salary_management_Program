package org.zerock.service;

import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.zerock.domain.MasterCodeVO;
import org.zerock.domain.MasterType;
import org.zerock.mapper.ItemMasterMapper;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Service
@Log4j
@AllArgsConstructor
public class ItemMasterServiceImpl implements ItemMasterService {

    private final ItemMasterMapper mapper;

    @Override
    @Transactional(readOnly = true)
    // 한국어: 품목 마스터 목록을 조회합니다.
    // 日本語: 品目マスター一覧を取得します。
    public List<MasterCodeVO> getList(MasterType type, String keyword) {
        if (type == null) {
            return Collections.emptyList();
        }
        String normalizedKeyword = keyword == null ? null : keyword.trim();
        return mapper.getList(type.getRoute(), normalizedKeyword);
    }

    @Override
    @Transactional(readOnly = true)
    // 한국어: 선택한 품목 마스터의 상세 정보를 조회합니다.
    // 日本語: 選択した品目マスターの詳細情報を取得します。
    public MasterCodeVO get(MasterType type, Long pk) {
        if (type == null || pk == null) {
            return null;
        }
        return mapper.read(type.getRoute(), pk);
    }

    @Override
    @Transactional(readOnly = true)
    // 한국어: 품목 마스터 코드가 중복되는지 확인합니다.
    // 日本語: 品目マスターコードが重複しているか確認します。
    public boolean isDuplicateCode(MasterType type, String code, Long pk) {
        if (type == null || code == null || code.trim().isEmpty()) {
            return false;
        }
        return mapper.countByCode(type.getRoute(), code.trim(), pk) > 0;
    }

    @Override
    @Transactional
    // 한국어: 품목 마스터 신규 정보를 검증하고 등록합니다.
    // 日本語: 品目マスターの新規情報を検証して登録します。
    public void register(MasterType type, MasterCodeVO vo) {
        validate(type, vo, false);
        mapper.insert(vo);
    }

    @Override
    @Transactional
    // 한국어: 기존 품목 마스터 정보를 수정합니다.
    // 한국어: 품목 마스터 코드를 수정하고 결과를 반환합니다.
    // 日本語: 品目マスターコードを更新し、結果を返します。
    public boolean modify(MasterType type, MasterCodeVO vo) {
        validate(type, vo, true);
        return mapper.update(vo) == 1;
    }

    @Override
    @Transactional
    // 日本語: 品目マスター情報を削除します。
    // 한국어: 품목 마스터 코드를 삭제하고 결과를 반환합니다.
    // 日本語: 品目マスターコードを削除し、結果を返します。
    public boolean remove(MasterType type, Long pk) {
        if (type == null || pk == null) {
            throw new IllegalArgumentException("삭제할 데이터가 없습니다.");
        }

        int itemReferenceCount = mapper.countItemReferences(type.getRoute(), pk);
        int warehouseReferenceCount = type == MasterType.PROD_PROCESS
                ? mapper.countWarehouseReferences(pk)
                : 0;

        if (itemReferenceCount > 0 || warehouseReferenceCount > 0) {
            StringBuilder message = new StringBuilder();
            if (itemReferenceCount > 0) {
                message.append(type.getLabel())
                       .append("은(는) 현재 ")
                       .append(itemReferenceCount)
                       .append("개 품목에서 사용 중이라 삭제할 수 없습니다.");
            }
            if (warehouseReferenceCount > 0) {
                if (message.length() > 0) {
                    message.append("\n");
                }
                message.append(type.getLabel())
                       .append("은(는) 현재 ")
                       .append(warehouseReferenceCount)
                       .append("개 창고에서 사용 중이라 삭제할 수 없습니다.");
            }
            throw new IllegalStateException(message.toString());
        }
        return mapper.delete(type.getRoute(), pk) == 1;
    }

    // 한국어: 품목 마스터 입력값의 필수값과 형식을 검증합니다.
    // 日本語: 品目マスターの入力値について必須項目と形式を検証します。
    private void validate(MasterType type, MasterCodeVO vo, boolean modify) {
        if (type == null) {
            throw new IllegalArgumentException("마스터 유형이 없습니다.");
        }
        if (vo == null) {
            throw new IllegalArgumentException("입력 데이터가 없습니다.");
        }
        String code = vo.getCode() == null ? "" : vo.getCode().trim();
        String name = vo.getName() == null ? "" : vo.getName().trim();
        vo.setCode(code);
        vo.setName(name);
        vo.setMasterType(type.getRoute());

        if (modify && vo.getPk() == null) {
            throw new IllegalArgumentException("수정할 데이터의 PK가 없습니다.");
        }
        if (code.isEmpty()) {
            throw new IllegalArgumentException(type.getLabel() + " 코드는 필수입니다.");
        }
        if (code.length() > 20) {
            throw new IllegalArgumentException(type.getLabel() + " 코드는 20자 이내로 입력해주세요.");
        }
        if (name.isEmpty()) {
            throw new IllegalArgumentException(type.getLabel() + " 명은 필수입니다.");
        }
        if (name.length() > 100) {
            throw new IllegalArgumentException(type.getLabel() + " 명은 100자 이내로 입력해주세요.");
        }
        if (isDuplicateCode(type, code, modify ? vo.getPk() : null)) {
            throw new IllegalArgumentException("이미 사용 중인 코드입니다.");
        }
    }
}
