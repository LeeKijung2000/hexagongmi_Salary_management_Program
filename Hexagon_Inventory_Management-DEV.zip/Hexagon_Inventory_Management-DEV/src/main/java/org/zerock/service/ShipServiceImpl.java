package org.zerock.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.zerock.domain.Criteria;
import org.zerock.domain.ShipSourceItemVO;
import org.zerock.domain.ShipmentItemVO;
import org.zerock.domain.ShipmentVO;
import org.zerock.domain.ShippingOrderItemVO;
import org.zerock.domain.ShippingOrderVO;
import org.zerock.domain.ShippingStatusVO;
import org.zerock.mapper.ShipMapper;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Service
@Log4j
@AllArgsConstructor
public class ShipServiceImpl implements ShipService {

    private final ShipMapper mapper;

    @Override
    // 한국어: 출하지시서 목록을 조회합니다.
    // 日本語: 出荷指示書一覧を取得します。
    public List<ShippingOrderVO> getShippingOrderList(Criteria cri) {
        return mapper.getShippingOrderList(cri);
    }

    @Override
    public int getShippingOrderTotal(Criteria cri) {
        return mapper.countShippingOrders(cri);
    }

    @Override
    // 한국어: 출하지시서 한 건의 상세 정보를 조회합니다.
    // 日本語: 出荷指示書1件の詳細情報を取得します。
    public ShippingOrderVO getShippingOrder(Long id) {
        if (id == null || id <= 0) return null;
        ShippingOrderVO vo = mapper.getShippingOrder(id);
        if (vo != null) vo.setItems(mapper.getShippingOrderItems(id));
        return vo;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    // 한국어: 출하지시서를 등록하고 상세 품목 및 판매 연결 정보를 저장합니다.
    // 日本語: 出荷指示書を登録し、明細品目と販売連携情報を保存します。
    public void registerShippingOrder(ShippingOrderVO vo) {
        validateHeader(vo, true);
        validateItems(vo.getItems());
        if (vo.getItems() == null || vo.getItems().isEmpty()) {
            throw new IllegalArgumentException("출하지시 품목을 1건 이상 입력해주세요.");
        }
        mapper.insertShippingOrder(vo);
        // DB INSERT에서 자동 생성된 전표번호를 VO에 다시 담아 Controller 응답에서 사용할 수 있도록 합니다.
        ShippingOrderVO saved = mapper.getShippingOrder(vo.getShippingOrderId());
        if (saved != null) {
            vo.setVoucherNo(saved.getVoucherNo());
        }
        int line = 1;
        java.util.Map<Long, BigDecimal> saleUsage = new java.util.HashMap<Long, BigDecimal>();
        for (ShippingOrderItemVO item : vo.getItems()) {
            item.setShippingOrderId(vo.getShippingOrderId());
            item.setLineNo(line++);
            mapper.insertShippingOrderItem(item);
            if (item.getSourceSaleItemId() != null && item.getQuantity() != null) {
                Long sourceId = item.getSourceSaleItemId();
                BigDecimal available = mapper.getSaleAvailableQuantity(sourceId);
                BigDecimal alreadyUsed = saleUsage.containsKey(sourceId) ? saleUsage.get(sourceId) : BigDecimal.ZERO;
                if (available == null || available.compareTo(alreadyUsed.add(item.getQuantity())) < 0) {
                    throw new IllegalArgumentException("판매자료의 미출하지시 가능수량을 초과했습니다: " + item.getItemNameSnap());
                }
                mapper.insertSaleShippingLink(sourceId, item.getShippingOrderItemId(), item.getQuantity());
                saleUsage.put(sourceId, alreadyUsed.add(item.getQuantity()));
            }
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    // 한국어: 출하지시서 헤더 정보를 수정합니다.
    // 日本語: 出荷指示書ヘッダー情報を更新します。
    public void updateShippingOrder(ShippingOrderVO vo) {
        validateHeader(vo, true);
        validateItems(vo.getItems());
        if (vo.getItems() == null || vo.getItems().isEmpty()) {
            throw new IllegalArgumentException("출하지시 품목을 1건 이상 입력해주세요.");
        }
        if (vo.getShippingOrderId() == null || vo.getShippingOrderId() <= 0) {
            throw new IllegalArgumentException("수정할 출하지시서를 선택해주세요.");
        }
        ShippingOrderVO current = mapper.getShippingOrder(vo.getShippingOrderId());
        if (current == null) throw new IllegalArgumentException("출하지시서를 찾을 수 없습니다.");
        // 수정 시에도 기존 전표번호를 응답으로 돌려줍니다.
        vo.setVoucherNo(current.getVoucherNo());
        if ("CANCELLED".equals(current.getProgressStatus())) {
            throw new IllegalArgumentException("취소된 출하지시서는 수정할 수 없습니다.");
        }

        // 출하 연결이 있는 지시서는 품목 PK를 유지해 기존 출하결과 링크를 보존합니다.
        if ("PARTIAL".equals(current.getProgressStatus()) || "COMPLETED".equals(current.getProgressStatus())) {
            if (!java.util.Objects.equals(current.getBusinessPartnerId(), vo.getBusinessPartnerId())
                    || !java.util.Objects.equals(current.getWarehouseId(), vo.getWarehouseId())) {
                throw new IllegalArgumentException("출하가 연결된 지시서는 거래처와 창고를 변경할 수 없습니다. 기존 거래처·창고를 유지해주세요.");
            }
            List<ShippingOrderItemVO> existingItems = mapper.getShippingOrderItems(vo.getShippingOrderId());
            if (vo.getItems().size() != existingItems.size()) {
                throw new IllegalArgumentException("출하가 연결된 지시서는 품목을 추가·삭제할 수 없습니다. 기존 품목을 유지하고 수량과 비고를 수정해주세요.");
            }
            java.util.Map<Long, ShippingOrderItemVO> existingById = new java.util.HashMap<Long, ShippingOrderItemVO>();
            for (ShippingOrderItemVO existing : existingItems) existingById.put(existing.getShippingOrderItemId(), existing);
            java.util.Set<Long> submittedIds = new java.util.HashSet<Long>();
            int lineNo = 1;
            for (ShippingOrderItemVO item : vo.getItems()) {
                if (item.getShippingOrderItemId() == null || !submittedIds.add(item.getShippingOrderItemId())) {
                    throw new IllegalArgumentException("출하가 연결된 지시서는 기존 품목 행을 유지해야 합니다.");
                }
                ShippingOrderItemVO existing = existingById.get(item.getShippingOrderItemId());
                if (existing == null || !java.util.Objects.equals(existing.getItemId(), item.getItemId())) {
                    throw new IllegalArgumentException("기존 출하지시 품목을 변경할 수 없습니다.");
                }
                BigDecimal shipped = existing.getShippedQuantity() == null ? BigDecimal.ZERO : existing.getShippedQuantity();
                if (item.getQuantity() == null || item.getQuantity().compareTo(shipped) < 0) {
                    throw new IllegalArgumentException("수량은 이미 출하된 수량(" + shipped.stripTrailingZeros().toPlainString() + ")보다 작을 수 없습니다: " + existing.getItemNameSnap());
                }
                item.setShippingOrderId(vo.getShippingOrderId());
                item.setLineNo(lineNo++);
                mapper.updateShippingOrderItem(item);
            }
            mapper.updateShippingOrder(vo);
            mapper.updateShippingOrderProgressForOrder(vo.getShippingOrderId());
            return;
        }

        mapper.deleteSaleShippingLinksByOrderId(vo.getShippingOrderId());
        mapper.deleteShippingOrderItems(vo.getShippingOrderId());
        mapper.updateShippingOrder(vo);

        int line = 1;
        for (ShippingOrderItemVO item : vo.getItems()) {
            item.setShippingOrderId(vo.getShippingOrderId());
            item.setLineNo(line++);
            mapper.insertShippingOrderItem(item);
            if (item.getSourceSaleItemId() != null && item.getQuantity() != null) {
                BigDecimal available = mapper.getSaleAvailableQuantity(item.getSourceSaleItemId());
                if (available == null || available.compareTo(item.getQuantity()) < 0) {
                    throw new IllegalArgumentException("판매자료의 미출하지시 가능수량을 초과했습니다: " + item.getItemNameSnap());
                }
                mapper.insertSaleShippingLink(item.getSourceSaleItemId(), item.getShippingOrderItemId(), item.getQuantity());
            }
        }
    }

    @Override
    // 한국어: 출하지시에 사용할 판매 자료 목록을 조회합니다.
    // 日本語: 出荷指示に使用する販売資料一覧を取得します。
    public List<ShipSourceItemVO> getSaleSourceList(String keyword, Long businessPartnerId, Long warehouseId) {
        return mapper.getSaleSourceList(blankToNull(keyword), positiveOrNull(businessPartnerId), positiveOrNull(warehouseId));
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void cancelShippingOrder(Long id) {
        if (id == null || id <= 0) throw new IllegalArgumentException("취소할 출하지시서를 선택해주세요.");
        ShippingOrderVO current = mapper.getShippingOrder(id);
        if (current == null) throw new IllegalArgumentException("출하지시서를 찾을 수 없습니다.");
        if ("CANCELLED".equals(current.getProgressStatus())) throw new IllegalArgumentException("이미 취소된 출하지시서입니다.");
        if ("PARTIAL".equals(current.getProgressStatus()) || "COMPLETED".equals(current.getProgressStatus())) {
            throw new IllegalArgumentException("출하가 진행된 출하지시서는 취소할 수 없습니다.");
        }
        mapper.cancelShippingOrder(id);
    }

    @Override
    // 한국어: 출하 전표 목록을 조회합니다.
    // 日本語: 出荷伝票一覧を取得します。
    public List<ShipmentVO> getShipmentList(Criteria cri) {
        return mapper.getShipmentList(cri);
    }

    @Override
    public int getShipmentTotal(Criteria cri) {
        return mapper.countShipments(cri);
    }

    @Override
    // 한국어: 출하 전표 한 건의 상세 정보를 조회합니다.
    // 日本語: 出荷伝票1件の詳細情報を取得します。
    public ShipmentVO getShipment(Long id) {
        if (id == null || id <= 0) return null;
        ShipmentVO vo = mapper.getShipment(id);
        if (vo != null) vo.setItems(mapper.getShipmentItems(id));
        return vo;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    // 한국어: 출하 전표를 등록하고 출하지시서 연결 정보를 저장합니다.
    // 日本語: 出荷伝票を登録し、出荷指示書との連携情報を保存します。
    public void registerShipment(ShipmentVO vo) {
        validateHeader(vo);
        validateShipmentItems(vo.getItems());
        mapper.insertShipment(vo);
        // DB INSERT에서 자동 생성된 전표번호를 VO에 다시 담아 Controller 응답에서 사용할 수 있도록 합니다.
        ShipmentVO saved = mapper.getShipment(vo.getShipmentId());
        if (saved != null) {
            vo.setVoucherNo(saved.getVoucherNo());
        }
        int line = 1;
        for (ShipmentItemVO item : vo.getItems()) {
            item.setShipmentId(vo.getShipmentId());
            item.setLineNo(line++);
            mapper.insertShipmentItem(item);
            if (item.getSourceShippingOrderItemId() != null && item.getQuantity() != null) {
                validateSourceOrderItem(vo, item);
                BigDecimal available = mapper.getUnshippedQuantity(item.getSourceShippingOrderItemId());
                if (available == null || available.compareTo(item.getQuantity()) < 0) {
                    throw new IllegalArgumentException("미출하수량을 초과할 수 없습니다: " + item.getItemNameSnap());
                }
                mapper.insertShipResultLink(item.getSourceShippingOrderItemId(), item.getShipmentItemId(), item.getQuantity());
            }
        }
        // 입력된 상세의 연결 관계를 기준으로 진행상태를 최신화합니다.
        for (ShipmentItemVO item : vo.getItems()) {
            if (item.getSourceShippingOrderItemId() != null) {
                mapper.updateShippingOrderProgress(item.getSourceShippingOrderItemId());
            }
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    // 한국어: 출하 전표 헤더 정보를 수정합니다.
    // 日本語: 出荷伝票ヘッダー情報を更新します。
    public void updateShipment(ShipmentVO vo) {
        validateHeader(vo);
        validateShipmentItems(vo.getItems());
        if (vo.getShipmentId() == null || vo.getShipmentId() <= 0) {
            throw new IllegalArgumentException("수정할 출하전표를 선택해주세요.");
        }
        ShipmentVO current = mapper.getShipment(vo.getShipmentId());
        if (current == null) throw new IllegalArgumentException("출하전표를 찾을 수 없습니다.");
        // 수정 시에도 기존 전표번호를 응답으로 돌려줍니다.
        vo.setVoucherNo(current.getVoucherNo());
        if ("CANCELLED".equals(current.getVoucherStatus())) {
            throw new IllegalArgumentException("취소된 출하전표는 수정할 수 없습니다.");
        }

        List<Long> oldOrderIds = mapper.getLinkedShippingOrderIds(vo.getShipmentId());
        mapper.deleteShipResultLinksByShipmentId(vo.getShipmentId());
        mapper.deleteShipmentItems(vo.getShipmentId());
        mapper.updateShipment(vo);

        int line = 1;
        for (ShipmentItemVO item : vo.getItems()) {
            item.setShipmentId(vo.getShipmentId());
            item.setLineNo(line++);
            mapper.insertShipmentItem(item);
            if (item.getSourceShippingOrderItemId() != null && item.getQuantity() != null) {
                validateSourceOrderItem(vo, item);
                BigDecimal available = mapper.getUnshippedQuantity(item.getSourceShippingOrderItemId());
                if (available == null || available.compareTo(item.getQuantity()) < 0) {
                    throw new IllegalArgumentException("미출하수량을 초과할 수 없습니다: " + item.getItemNameSnap());
                }
                mapper.insertShipResultLink(item.getSourceShippingOrderItemId(), item.getShipmentItemId(), item.getQuantity());
            }
        }

        for (Long orderId : oldOrderIds) {
            if (orderId != null) mapper.updateShippingOrderProgressForOrder(orderId);
        }
        for (ShipmentItemVO item : vo.getItems()) {
            if (item.getSourceShippingOrderItemId() != null) {
                mapper.updateShippingOrderProgress(item.getSourceShippingOrderItemId());
            }
        }
    }

    @Override
    // 한국어: 출하 현황 목록을 조회합니다.
    // 日本語: 出荷状況一覧を取得します。
    public List<ShippingStatusVO> getShippingStatus(Long warehouseId, Long businessPartnerId, Long itemId,
                                                    Long projectId, String dateFrom, String dateTo,
                                                    String voucherNo, String keyword) {
        return mapper.getShippingStatus(
                positiveOrNull(warehouseId), positiveOrNull(businessPartnerId), positiveOrNull(itemId),
                positiveOrNull(projectId), blankToNull(dateFrom), blankToNull(dateTo),
                blankToNull(voucherNo), blankToNull(keyword));
    }

    @Override
    // 한국어: 미출하 출하 대상 목록을 조회합니다.
    // 日本語: 未出荷の出荷対象一覧を取得します。
    public List<ShipmentItemVO> getUnshippedSourceList(String keyword, Long businessPartnerId, Long warehouseId) {
        return mapper.getUnshippedSourceList(blankToNull(keyword), positiveOrNull(businessPartnerId), positiveOrNull(warehouseId));
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void cancelShipment(Long id) {
        if (id == null || id <= 0) throw new IllegalArgumentException("취소할 출하전표를 선택해주세요.");
        ShipmentVO current = mapper.getShipment(id);
        if (current == null) throw new IllegalArgumentException("출하전표를 찾을 수 없습니다.");
        if ("CANCELLED".equals(current.getVoucherStatus())) throw new IllegalArgumentException("이미 취소된 출하전표입니다.");
        List<Long> orderIds = mapper.getLinkedShippingOrderIds(id);
        mapper.deleteShipResultLinksByShipmentId(id);
        mapper.cancelShipment(id);
        for (Long orderId : orderIds) {
            if (orderId != null) {
                // 연결된 출하지시서의 진행상태를 출하 연결수량 기준으로 재계산합니다.
                mapper.updateShippingOrderProgressForOrder(orderId);
            }
        }
    }

    // 한국어: 출하 화면의 거래처 검색 목록을 조회합니다.
    // 日本語: 出荷画面の取引先検索一覧を取得します。
    @Override public List<Map<String,Object>> getPartnerList(String keyword){ return mapper.getPartnerList(blankToNull(keyword)); }
    // 한국어: 출하 화면의 창고 검색 목록을 조회합니다.
    // 日本語: 出荷画面の倉庫検索一覧を取得します。
    @Override public List<Map<String,Object>> getWarehouseList(String keyword){ return mapper.getWarehouseList(blankToNull(keyword)); }
    // 한국어: 출하 화면의 품목 검색 목록을 조회합니다.
    // 日本語: 出荷画面の品目検索一覧を取得します。
    @Override public List<Map<String,Object>> getItemList(String keyword){ return mapper.getItemList(blankToNull(keyword)); }
    // 한국어: 출하 화면의 담당자 검색 목록을 조회합니다.
    // 日本語: 出荷画面の担当者検索一覧を取得します。
    @Override public List<Map<String,Object>> getManagerList(String keyword){ return mapper.getManagerList(blankToNull(keyword)); }
    // 한국어: 출하 화면의 프로젝트 검색 목록을 조회합니다.
    // 日本語: 出荷画面のプロジェクト検索一覧を取得します。
    @Override public List<Map<String,Object>> getProjectList(String keyword){ return mapper.getProjectList(blankToNull(keyword)); }

    // 한국어: 출하 상세가 실제 원본 출하지시서의 품목·거래처·창고와 일치하는지 서버에서 검증합니다.
    // 日本語: 出荷明細が元の出荷指示書の品目・取引先・倉庫と一致するかサーバー側で検証します。
    private void validateSourceOrderItem(ShipmentVO shipment, ShipmentItemVO item) {
        ShipmentItemVO source = mapper.getShippingOrderItemSource(item.getSourceShippingOrderItemId());
        if (source == null) {
            throw new IllegalArgumentException("연결할 출하지시서 품목이 없거나 취소된 출하지시서입니다.");
        }
        if (source.getItemId() == null || !source.getItemId().equals(item.getItemId())) {
            throw new IllegalArgumentException("출하지시서 품목과 출하 품목이 일치하지 않습니다: " + item.getItemNameSnap());
        }
        if (source.getBusinessPartnerId() == null || !source.getBusinessPartnerId().equals(shipment.getBusinessPartnerId())) {
            throw new IllegalArgumentException("출하지시서와 출하의 거래처가 일치하지 않습니다.");
        }
        if (source.getWarehouseId() == null || !source.getWarehouseId().equals(shipment.getWarehouseId())) {
            throw new IllegalArgumentException("출하지시서와 출하의 창고가 일치하지 않습니다.");
        }
    }

    // 한국어: 전표 헤더의 필수 입력값과 상태를 검증합니다.
    // 日本語: 伝票ヘッダーの必須入力値と状態を検証します。
    private void validateHeader(ShippingOrderVO vo, boolean order) {
        if (vo == null) throw new IllegalArgumentException("입력 데이터를 확인해주세요.");
        if (isBlank(vo.getShippingOrderDate())) throw new IllegalArgumentException("출하지시일자를 입력해주세요.");
        if (vo.getBusinessPartnerId() == null || vo.getBusinessPartnerId() <= 0) throw new IllegalArgumentException("거래처를 선택해주세요.");
        if (vo.getWarehouseId() == null || vo.getWarehouseId() <= 0) throw new IllegalArgumentException("출하창고를 선택해주세요.");
        if (order && isBlank(vo.getPlannedShipDate())) throw new IllegalArgumentException("출하예정일을 입력해주세요.");
    }

    // 한국어: 전표 헤더의 필수 입력값과 상태를 검증합니다.
    // 日本語: 伝票ヘッダーの必須入力値と状態を検証します。
    private void validateHeader(ShipmentVO vo) {
        if (vo == null) throw new IllegalArgumentException("입력 데이터를 확인해주세요.");
        if (isBlank(vo.getShipmentDate())) throw new IllegalArgumentException("출하일자를 입력해주세요.");
        if (vo.getBusinessPartnerId() == null || vo.getBusinessPartnerId() <= 0) throw new IllegalArgumentException("거래처를 선택해주세요.");
        if (vo.getWarehouseId() == null || vo.getWarehouseId() <= 0) throw new IllegalArgumentException("출하창고를 선택해주세요.");
    }

    // 한국어: 출하지시 상세 품목의 입력값과 수량을 검증합니다.
    // 한국어: 출하지시 상세 품목의 필수값과 수량을 검증합니다.
    // 日本語: 出荷指示明細の必須項目と数量を検証します。
    private void validateItems(List<ShippingOrderItemVO> items) {
        if (items == null) throw new IllegalArgumentException("품목을 입력해주세요.");
        for (ShippingOrderItemVO item : items) {
            if (item == null || item.getItemId() == null || item.getItemId() <= 0) throw new IllegalArgumentException("유효한 품목을 선택해주세요.");
            if (item.getQuantity() == null || item.getQuantity().compareTo(BigDecimal.ZERO) <= 0) throw new IllegalArgumentException("수량은 0보다 커야 합니다.");
            if (isBlank(item.getItemCodeSnap()) || isBlank(item.getItemNameSnap())) throw new IllegalArgumentException("품목코드와 품목명을 확인해주세요.");
        }
    }

    // 한국어: 출하 상세 품목의 입력값과 수량을 검증합니다.
    // 日本語: 出荷明細の入力値と数量を検証します。
    private void validateShipmentItems(List<ShipmentItemVO> items) {
        if (items == null || items.isEmpty()) throw new IllegalArgumentException("출하 품목을 1건 이상 입력해주세요.");
        for (ShipmentItemVO item : items) {
            if (item == null || item.getItemId() == null || item.getItemId() <= 0) throw new IllegalArgumentException("유효한 품목을 선택해주세요.");
            if (item.getQuantity() == null || item.getQuantity().compareTo(BigDecimal.ZERO) <= 0) throw new IllegalArgumentException("출하수량은 0보다 커야 합니다.");
            if (isBlank(item.getItemCodeSnap()) || isBlank(item.getItemNameSnap())) throw new IllegalArgumentException("품목코드와 품목명을 확인해주세요.");
        }
    }

    // 한국어: 양수인 ID만 반환하고 그 외 값은 null로 변환합니다.
    // 日本語: 正のIDのみ返し、それ以外の値はnullへ変換します。
    private static Long positiveOrNull(Long value) { return value != null && value > 0 ? value : null; }
    private static String blankToNull(String value) { return isBlank(value) ? null : value.trim(); }
    private static boolean isBlank(String value) { return value == null || value.trim().isEmpty(); }
}
