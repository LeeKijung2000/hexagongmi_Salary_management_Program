package org.zerock.service;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.zerock.domain.BusinessPartnerManagerVO;
import org.zerock.domain.BusinessPartnerVO;
import org.zerock.domain.Criteria;
import org.zerock.mapper.BusinessPartnerMapper;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
/**
 * 한국어: 거래처 업무 서비스 구현체.
 * 日本語: 取引先業務サービスの実装クラス。
 */
public class BusinessPartnerServiceImpl implements BusinessPartnerService {

    private final BusinessPartnerMapper mapper;

    @Override
    @Transactional
    // 한국어: 거래처의 신규 정보를 등록합니다.
    // 日本語: 取引先の新規情報を登録します。
    public void register(BusinessPartnerVO bp) {
        normalize(bp);
        validate(bp, false);
        setDefaults(bp);
        mapper.insertSelectKey(bp);
    }

    @Override
    @Transactional(readOnly = true)
    // 한국어: 거래처 ID로 상세 정보를 조회합니다.
    // 日本語: 取引先IDで詳細情報を取得します。
    public BusinessPartnerVO get(Long businessPartnerId) {
        return mapper.read(businessPartnerId);
    }

    @Override
    @Transactional
    // 한국어: 거래처 정보를 수정합니다.
    // 日本語: 取引先情報を更新します。
    public boolean modify(BusinessPartnerVO bp) {
        normalize(bp);
        validate(bp, true);
        setDefaults(bp);
        return mapper.update(bp) == 1;
    }

    @Override
    @Transactional
    // 한국어: 거래처를 삭제합니다.
    // 日本語: 取引先を削除します。
    public boolean remove(Long businessPartnerId) {
        if (businessPartnerId == null || businessPartnerId <= 0) {
            throw new IllegalArgumentException("삭제할 거래처가 없습니다.");
        }
        return mapper.delete(businessPartnerId) == 1;
    }

    @Override
    @Transactional(readOnly = true)
    // 한국어: 검색 조건과 페이징을 적용해 거래처 목록을 조회합니다.
    // 日本語: 検索条件とページングを適用して取引先一覧を取得します。
    public List<BusinessPartnerVO> getList(Criteria cri) {
        return mapper.getListWithPaging(cri);
    }
    
    //전체 거래처 조회
    //全体取引先照会
    public List<BusinessPartnerVO> getAllList() {
        return mapper.getAllList();
    }

    @Override
    @Transactional(readOnly = true)
    // 한국어: 검색 조건에 맞는 거래처 전체 건수를 조회합니다.
    // 日本語: 検索条件に一致する取引先の総件数を取得します。
    public int getTotal(Criteria cri) {
        return mapper.getTotalCount(cri);
    }

    @Override
    @Transactional(readOnly = true)
    // 한국어: 거래처코드의 중복 여부를 확인합니다.
    // 日本語: 取引先コードの重複有無を確認します。
    public boolean isDuplicateCode(String businessPartnerCode, Long businessPartnerId) {
        if (isBlank(businessPartnerCode)) {
            return false;
        }
        return mapper.countByCode(businessPartnerCode.trim(), businessPartnerId) > 0;
    }

    // 한국어: 거래처 1차 그룹 목록을 조회합니다.
    // 日本語: 取引先第1階層グループ一覧を取得します。
    @Override public List<Map<String, Object>> getGroup1List() { return safe(mapper.getGroup1List()); }
    // 한국어: 거래처 2차 그룹 목록을 조회합니다.
    // 日本語: 取引先第2階層グループ一覧を取得します。
    @Override public List<Map<String, Object>> getGroup2List() { return safe(mapper.getGroup2List()); }
    // 한국어: 거래처 판매 가격그룹 목록을 조회합니다.
    // 日本語: 取引先の販売価格グループ一覧を取得します。
    @Override public List<Map<String, Object>> getSalesPriceGroupList() { return safe(mapper.getSalesPriceGroupList()); }
    // 한국어: 거래처 구매 가격그룹 목록을 조회합니다.
    // 日本語: 取引先の仕入価格グループ一覧を取得します。
    @Override public List<Map<String, Object>> getPurchasePriceGroupList() { return safe(mapper.getPurchasePriceGroupList()); }
    // 한국어: 거래처에서 사용하는 통화 목록을 조회합니다.
    // 日本語: 取引先で使用する通貨一覧を取得します。
    @Override public List<Map<String, Object>> getCurrencyList() { return safe(mapper.getCurrencyList()); }

    @Override
    @Transactional(readOnly = true)
    // 한국어: 거래처 담당자 선택용 목록을 조회합니다.
    // 日本語: 取引先担当者選択用の一覧を取得します。
    public List<BusinessPartnerManagerVO> getManagerList(String keyword) {
        return mapper.getManagerList(isBlank(keyword) ? null : keyword.trim());
    }

    @Override
    @Transactional
    // 한국어: 거래처 화면에서 사용하는 담당자를 등록합니다.
    // 日本語: 取引先画面で使用する担当者を登録します。
    public void registerManager(BusinessPartnerManagerVO manager) {
        if (manager == null) {
            throw new IllegalArgumentException("담당자 입력 데이터가 없습니다.");
        }
        manager.setEmployeeCode(trim(manager.getEmployeeCode()));
        manager.setEmployeeName(trim(manager.getEmployeeName()));
        manager.setSearchContent(trim(manager.getSearchContent()));
        manager.setPositionName(trim(manager.getPositionName()));
        manager.setContactNumber(trim(manager.getContactNumber()));
        manager.setEmail(trim(manager.getEmail()));
        manager.setAdditionalItem(trim(manager.getAdditionalItem()));
        if (isBlank(manager.getEmployeeName())) {
            throw new IllegalArgumentException("사원명은 필수입니다.");
        }
        if (!isBlank(manager.getEmployeeCode()) && manager.getEmployeeCode().length() > 20) {
            throw new IllegalArgumentException("사원코드는 20자 이내로 입력해주세요.");
        }
        if (!isBlank(manager.getEmployeeCode()) && mapper.countManagerByEmployeeCode(manager.getEmployeeCode()) > 0) {
            throw new IllegalArgumentException("이미 등록된 사원코드입니다.");
        }
        mapper.insertManagerSelectKey(manager);
    }

    @Override
    @Transactional
    // 한국어: 선택한 거래처들에 계층그룹을 일괄 적용합니다.
    // 日本語: 選択した取引先に階層グループを一括適用します。
    public int bulkAssignHierarchyGroup(List<Long> businessPartnerIds, Long bpHierGroupId) {
        if (businessPartnerIds == null || businessPartnerIds.isEmpty()) {
            throw new IllegalArgumentException("계층그룹을 적용할 거래처를 선택해주세요.");
        }
        if (bpHierGroupId == null || bpHierGroupId <= 0) {
            throw new IllegalArgumentException("적용할 거래처계층그룹을 선택해주세요.");
        }
        return mapper.bulkAssignHierarchyGroup(businessPartnerIds, bpHierGroupId);
    }

    // 한국어: 특정 거래처 계층그룹에 포함된 거래처를 조회합니다.
    // 日本語: 指定した取引先階層グループに所属する取引先を取得します。
    public List<Map<String, Object>> getHierarchyMembers(Long bpHierGroupId) {
        if (bpHierGroupId == null || bpHierGroupId <= 0) return Collections.emptyList();
        return safe(mapper.getHierarchyMembers(bpHierGroupId));
    }

    private void validate(BusinessPartnerVO bp, boolean modify) {
        if (bp == null) throw new IllegalArgumentException("거래처 입력 데이터가 없습니다.");
        if (modify && (bp.getBusinessPartnerId() == null || bp.getBusinessPartnerId() <= 0)) {
            throw new IllegalArgumentException("수정할 거래처 PK가 없습니다.");
        }
        if (isBlank(bp.getBusinessPartnerCode())) throw new IllegalArgumentException("거래처코드는 필수입니다.");
        if (bp.getBusinessPartnerCode().length() > 100) throw new IllegalArgumentException("거래처코드는 100자 이내로 입력해주세요.");
        if (isBlank(bp.getBusinessPartnerName())) throw new IllegalArgumentException("상호(이름)는 필수입니다.");
        if (bp.getBusinessPartnerName().length() > 100) throw new IllegalArgumentException("상호(이름)는 100자 이내로 입력해주세요.");
        if (!isBlank(bp.getEmail()) && bp.getEmail().length() > 254) throw new IllegalArgumentException("Email은 254자 이내로 입력해주세요.");
        if (!isBlank(bp.getHomepageUrl()) && bp.getHomepageUrl().length() > 500) throw new IllegalArgumentException("홈페이지 주소는 500자 이내로 입력해주세요.");
        if (!isBlank(bp.getRemark()) && bp.getRemark().length() > 500) throw new IllegalArgumentException("적요는 500자 이내로 입력해주세요.");
        validateNumericRanges(bp);
        if (isDuplicateCode(bp.getBusinessPartnerCode(), modify ? bp.getBusinessPartnerId() : null)) throw new IllegalArgumentException("이미 사용 중인 거래처코드입니다.");
    }

    /**
     * Oracle TB_BUSINESS_PARTNER의 NUMBER 정밀도/스케일과 화면 업무범위를
     * DB에 도달하기 전에 검사한다. DB의 ORA-01438 같은 모호한 오류 대신
     * 어떤 항목이 허용값을 넘었는지 사용자에게 정확히 알려준다.
     */
    // 한국어: 거래처 관련 validateNumericRanges 기능을 처리합니다.
    // 日本語: 取引先関連のvalidateNumericRanges処理を実行します。
    private void validateNumericRanges(BusinessPartnerVO bp) {
        // CREDIT_LIMIT NUMBER(18,2): 정수부 최대 16자리, 소수부 최대 2자리
        if (bp.getCreditLimit() != null) {
            java.math.BigDecimal v = bp.getCreditLimit();
            if (v.signum() < 0) throw new IllegalArgumentException("여신한도는 0 이상이어야 합니다.");
            if (v.scale() > 2) throw new IllegalArgumentException("여신한도는 소수점 이하 2자리까지 입력할 수 있습니다.");
            if (v.compareTo(new java.math.BigDecimal("9999999999999999.99")) > 0) {
                throw new IllegalArgumentException("여신한도는 9,999,999,999,999,999.99 이하로 입력해주세요.");
            }
        }

        // CREDIT_PERIOD_DAYS NUMBER(5): 0~99,999일
        if (bp.getCreditPeriod() != null && bp.getCreditPeriod() < 0) {
            throw new IllegalArgumentException("여신기간은 0일 이상이어야 합니다.");
        }
        if (bp.getCreditPeriod() != null && bp.getCreditPeriod() > 99999) {
            throw new IllegalArgumentException("여신기간은 99,999일 이하로 입력해주세요.");
        }

        // NUMBER(9,4) + 업무범위 0~100
        validateRate("출고조정률", bp.getShipmentAdjustmentRate());
        validateRate("입고조정률", bp.getReceiptAdjustmentRate());

        // OFFSET_DAYS NUMBER(5), DAY_OF_MONTH NUMBER(2)와 대응하는 화면 입력값
        if (bp.getCollectionPaymentDueValue() != null) {
            if (bp.getCollectionPaymentDueValue() < 0) throw new IllegalArgumentException("수금/지급 예정일(일 후)은 0 이상이어야 합니다.");
            if (bp.getCollectionPaymentDueValue() > 99999) throw new IllegalArgumentException("수금/지급 예정일(일 후)은 99,999 이하로 입력해주세요.");
        }
        if (bp.getCollectionPaymentDueDay() != null) {
            if (bp.getCollectionPaymentDueDay() < 0) throw new IllegalArgumentException("수금/지급 예정일(매월)은 0 이상이어야 합니다.");
            if (bp.getCollectionPaymentDueDay() > 99) throw new IllegalArgumentException("수금/지급 예정일(매월)은 99 이하로 입력해주세요.");
        }

        // CUSTOM_NUMBER1~3 NUMBER(18,4): 정수부 최대 14자리, 소수부 최대 4자리
        validateCustomNumber("사용자 숫자항목1", bp.getAdditionalNumber1());
        validateCustomNumber("사용자 숫자항목2", bp.getAdditionalNumber2());
        validateCustomNumber("사용자 숫자항목3", bp.getAdditionalNumber3());
    }

    // 한국어: 비율 값의 허용 범위를 검증합니다.
    // 日本語: 率の許容範囲を検証します。
    private void validateRate(String label, java.math.BigDecimal value) {
        if (value == null) return;
        if (value.signum() < 0 || value.compareTo(new java.math.BigDecimal("100")) > 0) {
            throw new IllegalArgumentException(label + "은 0~100 사이로 입력해주세요.");
        }
        if (value.scale() > 4) {
            throw new IllegalArgumentException(label + "은 소수점 이하 4자리까지 입력할 수 있습니다.");
        }
    }

    // 한국어: 추가 숫자 항목의 범위를 검증합니다.
    // 日本語: 追加数値項目の範囲を検証します。
    private void validateCustomNumber(String label, java.math.BigDecimal value) {
        if (value == null) return;
        if (value.scale() > 4) throw new IllegalArgumentException(label + "은 소수점 이하 4자리까지 입력할 수 있습니다.");
        if (value.compareTo(new java.math.BigDecimal("99999999999999.9999")) > 0
                || value.compareTo(new java.math.BigDecimal("-99999999999999.9999")) < 0) {
            throw new IllegalArgumentException(label + "은 -99,999,999,999,999.9999 ~ 99,999,999,999,999.9999 범위로 입력해주세요.");
        }
    }

    // 한국어: 거래처 입력값을 정규화합니다.
    // 日本語: 取引先の入力値を正規化します。
    private void normalize(BusinessPartnerVO bp) {
        if (bp == null) return;
        bp.setBusinessPartnerCode(trim(bp.getBusinessPartnerCode()));
        bp.setBusinessPartnerName(trim(bp.getBusinessPartnerName()));
        bp.setBusinessPartnerCodeType(defaultText(bp.getBusinessPartnerCodeType(), "BUSINESS_NO"));
        bp.setRepresentativeName(trim(bp.getRepresentativeName()));
        bp.setBusinessType(trim(bp.getBusinessType()));
        bp.setBusinessItem(trim(bp.getBusinessItem()));
        bp.setPhoneNumber(trim(bp.getPhoneNumber()));
        bp.setFaxNumber(trim(bp.getFaxNumber()));
        bp.setSearchContent(trim(bp.getSearchContent()));
        bp.setMobileNumber(trim(bp.getMobileNumber()));
        bp.setZipCode(trim(bp.getZipCode()));
        bp.setAddress1(trim(bp.getAddress1()));
        bp.setAddress2(trim(bp.getAddress2()));
        bp.setAdditionalItemAvailableYn(defaultYn(bp.getAdditionalItemAvailableYn(), "N"));
        bp.setHomepageUrl(trim(bp.getHomepageUrl()));
        bp.setEmail(trim(bp.getEmail()));
        bp.setTaxReportBpYn(defaultYn(bp.getTaxReportBpYn(), "Y"));
        bp.setTelecomBizNumber(trim(bp.getTelecomBizNumber()));
        bp.setIndustryTypeCode(trim(bp.getIndustryTypeCode()));
        bp.setBusinessPartnerGroup1Id(bp.getBusinessPartnerGroup1Id());
        bp.setBusinessPartnerGroup2Id(bp.getBusinessPartnerGroup2Id());
        bp.setCurrencyCode(defaultText(bp.getCurrencyCode(), "KRW"));
        bp.setRemark(trim(bp.getRemark()));
        bp.setShipmentTargetYn(defaultYn(bp.getShipmentTargetYn(), "Y"));
        bp.setSalesTransactionType(defaultText(bp.getSalesTransactionType(), "BASIC"));
        bp.setPurchaseTransactionType(defaultText(bp.getPurchaseTransactionType(), "BASIC"));
        bp.setCollectionPaymentDueType(defaultText(bp.getCollectionPaymentDueType(), "BASIC"));
        bp.setReceivableManagementYn(defaultYn(bp.getReceivableManagementYn(), "Y"));
        bp.setPayableManagementYn(defaultYn(bp.getPayableManagementYn(), "Y"));
        bp.setBusinessPartnerStatus(defaultText(bp.getBusinessPartnerStatus(), "ACTIVE"));
        bp.setUseYn(defaultYn(bp.getUseYn(), "Y"));
        bp.setShipmentAdjustmentType(defaultText(bp.getShipmentAdjustmentType(), "BASIC"));
        bp.setReceiptAdjustmentType(defaultText(bp.getReceiptAdjustmentType(), "BASIC"));
        bp.setAdditionalText1(trim(bp.getAdditionalText1()));
        bp.setAdditionalText2(trim(bp.getAdditionalText2()));
        bp.setAdditionalText3(trim(bp.getAdditionalText3()));
        bp.setAdditionalText4(trim(bp.getAdditionalText4()));
        bp.setAdditionalText5(trim(bp.getAdditionalText5()));
        bp.setAdditionalText6(trim(bp.getAdditionalText6()));
    }

    // 한국어: 거래처 신규 등록에 필요한 기본값을 설정합니다.
    // 日本語: 取引先の新規登録に必要な初期値を設定します。
    private void setDefaults(BusinessPartnerVO bp) {
        // 선택하지 않은 연결(FK) 값은 0이 아니라 NULL로 저장해야 한다.
        // 0은 실제 PK가 아니므로 Oracle FK 제약조건을 위반한다.
        bp.setParentBusinessPartnerId(nullIfNonPositive(bp.getParentBusinessPartnerId()));
        bp.setManagerId(nullIfNonPositive(bp.getManagerId()));
        bp.setBpHierGroupId(nullIfNonPositive(bp.getBpHierGroupId()));
        bp.setBusinessPartnerGroup1Id(nullIfNonPositive(bp.getBusinessPartnerGroup1Id()));
        bp.setBusinessPartnerGroup2Id(nullIfNonPositive(bp.getBusinessPartnerGroup2Id()));
        bp.setSalesPriceGroupId(nullIfNonPositive(bp.getSalesPriceGroupId()));
        bp.setPurchasePriceGroupId(nullIfNonPositive(bp.getPurchasePriceGroupId()));

        if (bp.getBusinessPartnerFileId() == null) bp.setBusinessPartnerFileId(0L);
        if (bp.getLastModifierId2() == null) bp.setLastModifierId2(0L);
        if (bp.getFirstCreatorId2() == null) bp.setFirstCreatorId2(0L);
        if (bp.getCollectionPaymentDueValue() == null) bp.setCollectionPaymentDueValue(0);
        if (bp.getCollectionPaymentDueDay() == null) bp.setCollectionPaymentDueDay(0);
        if (bp.getCollectionPaymentDueDate() == null) bp.setCollectionPaymentDueDate(0);
        if (bp.getCreditPeriod() == null) bp.setCreditPeriod(0);
    }

    // 한국어: 0 이하의 숫자는 null로 변환합니다.
    // 日本語: 0以下の数値をnullへ変換します。
    private Long nullIfNonPositive(Long value) {
        return value == null || value <= 0L ? null : value;
    }

    private String defaultYn(String value, String def) { return isBlank(value) ? def : value; }
    private String defaultText(String value, String def) { return isBlank(value) ? def : value; }
    private String trim(String value) { return value == null ? null : value.trim(); }
    // 한국어: 문자열이 비어 있는지 확인합니다.
    // 한국어: 거래처 입력 문자열이 비어 있는지 확인합니다.
    // 日本語: 取引先入力文字列が空かどうかを確認します。
    private boolean isBlank(String value) { return value == null || value.trim().isEmpty(); }
    // 日本語: nullのコレクションを空のコレクションへ安全に変換します。
    private <T> List<T> safe(List<T> list) { return list == null ? Collections.<T>emptyList() : list; }
}
