package org.zerock.service;

import java.util.List;
import java.util.Map;
import org.zerock.domain.Criteria;
import org.zerock.domain.WarehouseVO;

/**
 * 한국어: 창고 업무 서비스 계층.
 * 日本語: 倉庫業務のサービス層。
 */
public interface WarehouseService {
    void register(WarehouseVO warehouse);
    WarehouseVO get(Long warehousePk);
    boolean modify(WarehouseVO warehouse);
    boolean remove(Long warehousePk);
    int bulkAssignHierarchyGroup(List<Long> warehousePks, Long whHierGroupPk);
    // 한국어: 창고 사용 여부를 변경합니다.
    // 한국어: 창고의 사용 여부를 변경합니다.
    // 日本語: 倉庫の使用有無を変更します。
    boolean toggleUse(Long warehousePk, String useYn);
    // 日本語: 倉庫一覧を取得します。
    List<WarehouseVO> getList(Criteria cri);
    // 창고 전체 조회
    // 倉庫全体照会
    public List<WarehouseVO> getAllList();
    int getTotal(Criteria cri);
    
    // 그룹 팝업용 목록 조회 메서드 추가
    List<Map<String, Object>> getSalesPriceGroupList();
    List<Map<String, Object>> getPurPriceGroupList();
    // 한국어: 창고 계층그룹 목록을 조회합니다.
    List<Map<String, Object>> getWhHierGroupList();
    // 日本語: 生産工程一覧を取得します。
    List<Map<String, Object>> getProdProcessList();
    List<Map<String, Object>> getOutsourcePartnerList();
    List<Map<String, Object>> getHierarchyMembers(Long whHierGroupPk);
}
