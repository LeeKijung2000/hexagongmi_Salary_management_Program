package org.zerock.service;

import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.zerock.domain.HierarchyGroupType;
import org.zerock.domain.HierarchyGroupVO;
import org.zerock.mapper.HierarchyGroupMapper;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class HierarchyGroupServiceImpl implements HierarchyGroupService {

    private final HierarchyGroupMapper mapper;

    @Override
    @Transactional(readOnly = true)
    // 한국어: 계층그룹 목록을 조회합니다.
    // 日本語: 階層グループ一覧を取得します。
    public List<HierarchyGroupVO> getList(HierarchyGroupType type) {
        return type == null ? Collections.<HierarchyGroupVO>emptyList() : mapper.getList(type.getRoute());
    }

    @Override
    @Transactional(readOnly = true)
    public HierarchyGroupVO get(HierarchyGroupType type, Long pk) {
        if (type == null || pk == null) {
            return null;
        }
        return mapper.read(type.getRoute(), pk);
    }

    @Override
    @Transactional(readOnly = true)
    // 한국어: 계층그룹 코드가 중복되는지 확인합니다.
    // 日本語: 階層グループコードが重複しているか確認します。
    public boolean isDuplicateCode(HierarchyGroupType type, String code, Long pk) {
        if (type == null || code == null || code.trim().isEmpty()) {
            return false;
        }
        return mapper.countByCode(type.getRoute(), code.trim(), pk) > 0;
    }

    @Override
    @Transactional
    // 한국어: 계층그룹 신규 정보를 검증하고 등록합니다.
    // 日本語: 階層グループの新規情報を検証して登録します。
    public void register(HierarchyGroupType type, HierarchyGroupVO vo) {
        validate(type, vo, false);
        mapper.insert(type.getRoute(), vo);
    }

    @Override
    @Transactional
    // 한국어: 기존 계층그룹 정보를 수정합니다.
    // 한국어: 계층그룹 정보를 수정하고 수정 결과를 반환합니다.
    // 日本語: 階層グループ情報を更新し、更新結果を返します。
    public boolean modify(HierarchyGroupType type, HierarchyGroupVO vo) {
        validate(type, vo, true);
        if (vo.getPk().equals(vo.getParentPk())) {
            throw new IllegalArgumentException("자기 자신을 상위 계층그룹으로 지정할 수 없습니다.");
        }
        return mapper.update(type.getRoute(), vo) == 1;
    }

    @Override
    @Transactional
    // 한국어: 계층그룹 정보를 삭제합니다.
    // 日本語: 階層グループ情報を削除します。
    public boolean remove(HierarchyGroupType type, Long pk) {
        if (type == null || pk == null) {
            throw new IllegalArgumentException("삭제할 계층그룹이 없습니다.");
        }
        // 계층그룹은 실제 거래처/창고/품목의 데이터를 삭제하지 않는다.
        // 연결된 FK만 NULL로 풀고, 하위 그룹은 최상위 그룹으로 올린 뒤 그룹 자체를 삭제한다.
        mapper.clearReferences(type.getRoute(), pk);
        mapper.clearChildrenParent(type.getRoute(), pk);
        return mapper.delete(type.getRoute(), pk) == 1;
    }

    // 한국어: 계층그룹 입력값의 필수값과 형식을 검증합니다.
    // 日本語: 階層グループの入力値について必須項目と形式を検証します。
    private void validate(HierarchyGroupType type, HierarchyGroupVO vo, boolean modify) {
        if (type == null || vo == null) {
            throw new IllegalArgumentException("계층그룹 입력 데이터가 없습니다.");
        }
        String code = vo.getCode() == null ? "" : vo.getCode().trim();
        String name = vo.getName() == null ? "" : vo.getName().trim();
        vo.setCode(code);
        vo.setName(name);
        if (modify && vo.getPk() == null) {
            throw new IllegalArgumentException("수정할 계층그룹 PK가 없습니다.");
        }
        if (code.isEmpty()) {
            throw new IllegalArgumentException(type.getLabel() + " 코드는 필수입니다.");
        }
        if (code.length() > 20) {
            throw new IllegalArgumentException(type.getLabel() + " 코드는 20자 이내로 입력해주세요.");
        }
        if (name.isEmpty()) {
            throw new IllegalArgumentException(type.getLabel() + " 명은 필수입니다.");
        }
        if (name.length() > 100) {
            throw new IllegalArgumentException(type.getLabel() + " 명은 100자 이내로 입력해주세요.");
        }
        if (vo.getParentPk() != null && mapper.read(type.getRoute(), vo.getParentPk()) == null) {
            throw new IllegalArgumentException("상위 계층그룹이 존재하지 않습니다.");
        }
        if (isDuplicateCode(type, code, modify ? vo.getPk() : null)) {
            throw new IllegalArgumentException("이미 사용 중인 코드입니다.");
        }
    }
}
