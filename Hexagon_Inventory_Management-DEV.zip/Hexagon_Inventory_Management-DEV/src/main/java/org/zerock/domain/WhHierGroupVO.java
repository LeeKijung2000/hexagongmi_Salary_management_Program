package org.zerock.domain;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WhHierGroupVO {
    private Long whHierGroupPk; // 창고계층그룹 고유 식별자 (PK)
    private String code;        // 창고계층그룹 코드
    private String name;        // 창고계층그룹 명칭
    private Long parentWhHierGroupPk; // 상위 창고계층그룹 PK
}