package org.zerock.domain;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ItemGroup2VO {
    private Long itemGroup2Pk; // 품목그룹2 고유 식별자 (PK)
    private String code;       // 그룹2 코드
    private String name;       // 그룹2 명칭
}