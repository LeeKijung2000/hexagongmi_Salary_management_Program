package org.zerock.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class HierarchyGroupVO {
    private Long pk;
    private String code;
    private String name;
    private Long parentPk;
    private Integer depth;
    private String pathName;
    private String groupType;
}
