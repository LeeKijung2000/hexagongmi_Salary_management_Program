package org.zerock.domain;

import java.math.BigDecimal;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
/**
 * 한국어: 품목 화면과 DB 사이의 품목 데이터를 전달하는 VO입니다.
 * 日本語: 画面とDBの間で商品データを受け渡すVOです。
 */
public class ItemVO {
    private Long itemPk;                // 품목 고유 식별자 (PK) / 商品の一意識別子(PK)
    private String itemCode;            // 품목 관리 코드 / 商品管理コード
    private String itemName;            // 품목 명칭 / 商品名称
    private String spec;                // 규격 / 規格
    private String unit;                // 단위 / 単位
    private Integer itemDiv;            // 품목구분 (화면: 0~5, DDL 주석은 0~3) / 商品区分(画面: 0～5、DDLコメントは0～3)
    private BigDecimal vatRateSales;    // 매출 부가세율 / 売上消費税率 (%)
    private BigDecimal vatRatePurchase; // 매입 부가세율 / 仕入消費税率 (%)
    private String barcode;             // 바코드 / バーコード
    private String searchContent;       // 검색 내용 / 検索内容
    private String imagePath;           // 이미지 경로 / 画像パス
    private Integer qualityInspMethod;  // 품질검사방법 (0: 전수검사, 1: 샘플링검사, 2: 면제) / 品質検査方法(0: 全数検査、1: サンプリング検査、2: 免除)
    private BigDecimal qty;             // 수량 / 数量
    private BigDecimal purchasePrice;   // 입고단가 / 入庫単価
    private BigDecimal salesPrice;      // 출고단가 / 出庫単価
    private BigDecimal outsourcingPrice;// 외주단가 / 外注単価
    private BigDecimal stdLaborTime;    // 표준공수 / 標準工数
    private BigDecimal expenseWeight;   // 경비배부기준 / 経費配賦基準
    private BigDecimal stdCostMaterial; // 표준재료비 / 標準材料費
    private BigDecimal stdCostExpense;  // 표준경비 / 標準経費
    private BigDecimal stdCostLabor;    // 표준노무비 / 標準労務費
    private BigDecimal stdCostOutsourcing; // 표준외주비 / 標準外注費

    private Long prodProcessPk;         // 생산공정 PK / 生産工程PK
    private Long itemGroup1Pk;          // 품목그룹1 PK / 商品グループ1 PK
    private Long itemGroup2Pk;          // 품목그룹2 PK / 商品グループ2 PK
    private Long itemGroup3Pk;          // 품목그룹3 PK / 商品グループ3 PK
    private Long qualityInspTypePk;     // 품질검사유형 PK / 品質検査種別PK
    private Long itemHierGroupPk;       // 품목계층그룹 PK / 商品階層グループPK

    // 품목-창고 다대다 관계
    private List<Long> warehousePks;     // 보관 창고 PK 목록 / 保管倉庫PK一覧

    // 조회 화면용 JOIN 필드
    private String prodProcessName;
    private String itemGroup1Name;
    private String itemGroup2Name;
    private String itemGroup3Name;
    private String itemHierGroupName;
    private String qualityInspTypeName;
    private String itemGroupName;
    private String warehouseNames;       // 조회 화면용 보관 창고명 목록 / 表示画面用の保管倉庫名一覧
}
