package org.zerock.domain;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ItemGroup3VO {
    private Long itemGroup3Pk; // 품목그룹3 고유 식별자 (PK)
    private String code;       // 그룹3 코드
    private String name;       // 그룹3 명칭
}