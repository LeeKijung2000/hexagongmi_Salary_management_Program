package org.zerock.domain;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProdProcessVO {
    private Long prodProcessPk; // 생산공정 고유 식별자 (PK)
    private String code;        // 공정 코드
    private String name;        // 공정 명칭
}