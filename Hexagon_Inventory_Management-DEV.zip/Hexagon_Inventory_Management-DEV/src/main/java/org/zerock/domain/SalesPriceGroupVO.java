package org.zerock.domain;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SalesPriceGroupVO {
    private Long salesPriceGroupPk; // 영업단가그룹 고유 식별자 (PK)
    private String code;            // 영업단가그룹 코드
    private String name;            // 영업단가그룹 명칭
}