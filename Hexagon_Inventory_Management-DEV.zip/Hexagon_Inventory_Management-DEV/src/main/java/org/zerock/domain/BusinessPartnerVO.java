package org.zerock.domain;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
/**
 * 한국어: 거래처 화면과 DB 사이의 거래처 데이터를 전달하는 VO입니다.
 * 日本語: 画面とDBの間で取引先データを受け渡すVOです。
 */
public class BusinessPartnerVO {
    private Long businessPartnerId;
    private String businessPartnerCode;
    private String businessPartnerName;
    private String businessPartnerCodeType;
    private String representativeName;
    private String businessType;
    private String businessItem;
    private String phoneNumber;
    private String faxNumber;
    private String searchContent;
    private String mobileNumber;
    private String zipCode;
    private String address1;
    private String address2;
    private String additionalItemAvailableYn;
    private String homepageUrl;
    private String email;
    private String taxReportBpYn;
    private String telecomBizNumber;
    private String industryTypeCode;
    private Long businessPartnerGroup1Id;
    private Long businessPartnerGroup2Id;

    private Long parentBusinessPartnerId;
    private Long managerId;
    private Long bpHierGroupId;
    private String currencyCode;
    private String remark;
    private String shipmentTargetYn;
    private String salesTransactionType;
    private String purchaseTransactionType;
    private String collectionPaymentDueType;
    private Integer collectionPaymentDueValue;
    private Integer collectionPaymentDueDay;
    private Integer collectionPaymentDueDate;
    private String receivableManagementYn;
    private String payableManagementYn;
    private BigDecimal creditLimit;
    private String businessPartnerStatus;
    private String useYn;
    private Long businessPartnerFileId;
    private String shipmentAdjustmentType;
    private String receiptAdjustmentType;
    private BigDecimal shipmentAdjustmentRate;
    private BigDecimal receiptAdjustmentRate;
    private Integer creditPeriod;

    private Long firstCreatorId;
    private Long firstModifierId;
    private Long lastCreatorId;
    private Long lastModifierId;
    private Long salesPriceGroupId;
    private Long purchasePriceGroupId;
    private Long lastModifierId2;
    private Long firstCreatorId2;

    private String additionalText1;
    private String additionalText2;
    private String additionalText3;
    private String additionalText4;
    private String additionalText5;
    private String additionalText6;
    private BigDecimal additionalNumber1;
    private BigDecimal additionalNumber2;
    private BigDecimal additionalNumber3;

    // 조회용 JOIN 필드
    private String managerName;
    private String businessPartnerGroup1Name;
    private String businessPartnerGroup2Name;
    private String bpHierGroupName;
    private String salesPriceGroupName;
    private String purchasePriceGroupName;
}
