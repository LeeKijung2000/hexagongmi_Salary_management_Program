package org.zerock.domain;

public enum HierarchyGroupType {
    ITEM("item", "품목계층그룹"),
    WAREHOUSE("warehouse", "창고계층그룹"),
    BUSINESS_PARTNER("business-partner", "거래처계층그룹");

    private final String route;
    private final String label;

    HierarchyGroupType(String route, String label) {
        this.route = route;
        this.label = label;
    }

    public String getRoute() {
        return route;
    }

    public String getLabel() {
        return label;
    }

    public static HierarchyGroupType from(String value) {
        for (HierarchyGroupType type : values()) {
            if (type.route.equalsIgnoreCase(value)) {
                return type;
            }
        }
        throw new IllegalArgumentException("지원하지 않는 계층그룹 유형입니다.");
    }
}
