package org.zerock.domain;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public class PageDTO {

    private int startPage;
    private int endPage;
    private boolean prev, next;

    private int total;
    private Criteria cri;

    public PageDTO(Criteria cri, int total) {
        this.cri = cri;
        this.total = total;

        // 예: 현재 페이지가 3페이지라면 -> 3 / 10.0 = 0.3 -> 올림(1) * 10 = 10 (끝 페이지)
        this.endPage = (int) (Math.ceil(cri.getPageNum() / 10.0)) * 10;

        this.startPage = this.endPage - 9;

        // 전체 데이터 수(total)를 반영한 실제 마지막 페이지 번호 계산
        int realEnd = (int) (Math.ceil((double) total / cri.getAmount()));

        if (realEnd < this.endPage) {
            this.endPage = realEnd;
        }

        // 이전 버튼은 시작 페이지가 1보다 클 때만 존재
        this.prev = this.startPage > 1;

        // 다음 버튼은 실제 마지막 페이지가 화면 끝 페이지보다 클 때만 존재
        this.next = this.endPage < realEnd;
    }
}