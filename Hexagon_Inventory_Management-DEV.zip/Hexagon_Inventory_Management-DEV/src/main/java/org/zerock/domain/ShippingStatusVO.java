package org.zerock.domain;

import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ShippingStatusVO {
    private Long shippingOrderId;
    private String voucherNo;
    private String shippingOrderDate;
    private String plannedShipDate;
    private String progressStatus;
    private Long businessPartnerId;
    private String partnerCode;
    private String partnerName;
    private Long shippingOrderItemId;
    private Long itemId;
    private String itemCodeSnap;
    private String itemNameSnap;
    private String specSnap;
    private BigDecimal orderedShipQty;
    private BigDecimal shippedQty;
    private BigDecimal unshippedQty;
    private Long warehouseId;
    private String warehouseName;
}
