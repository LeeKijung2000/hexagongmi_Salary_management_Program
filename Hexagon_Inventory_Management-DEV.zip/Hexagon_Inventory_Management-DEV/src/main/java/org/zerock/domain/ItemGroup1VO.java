package org.zerock.domain;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ItemGroup1VO {
    private Long itemGroup1Pk; // 품목그룹1 고유 식별자 (PK)
    private String code;       // 그룹1 코드
    private String name;       // 그룹1 명칭
}