package org.zerock.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 품목등록 화면에서 관리하는 공통 코드형 마스터(생산공정/품목그룹1~3/품질검사유형) VO.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MasterCodeVO {
    private Long pk;
    private String code;
    private String name;
    private String masterType;
}
