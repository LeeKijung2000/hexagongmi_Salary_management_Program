package org.zerock.domain;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ItemHierGroupVO {
    private Long itemHierGroupPk; // 품목계층그룹 고유 식별자 (PK)
    private String code;          // 계층그룹 코드
    private String name;          // 계층그룹 명칭
    private Long parentItemHierGroupPk; // 상위 품목계층그룹 PK
}