package org.zerock.domain;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ShippingOrderVO {
    private Long shippingOrderId;
    private String voucherNo;
    private String shippingOrderDate;
    private Long businessPartnerId;
    private String partnerCode;
    private String partnerName;
    private Long managerId;
    private String managerName;
    private Long warehouseId;
    private String warehouseName;
    private Long projectId;
    private String projectName;
    private String contactNumber;
    private String plannedShipDate;
    private String postalCode;
    private String address;
    private String progressStatus;
    private String remarks;
    private List<ShippingOrderItemVO> items;
    private String itemSummary;
    private java.math.BigDecimal quantityTotal;
}
