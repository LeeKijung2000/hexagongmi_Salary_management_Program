package org.zerock.domain;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class QualityInspTypeVO {
    private Long qualityInspTypePk; // 품질검사유형 고유 식별자 (PK)
    private String code;            // 검사유형 코드
    private String name;            // 검사유형 명칭
}