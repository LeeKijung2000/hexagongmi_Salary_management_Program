package org.zerock.domain;

import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ShippingOrderItemVO {
    private Long shippingOrderItemId;
    private Long shippingOrderId;
    private Integer lineNo;
    private Long itemId;
    private String itemCodeSnap;
    private String itemNameSnap;
    private String specSnap;
    private String unitSnap;
    private BigDecimal quantity;
    private String remarks;
    private Long sourceSaleItemId;
    private BigDecimal availableQuantity;
    private BigDecimal shippedQuantity;
}
