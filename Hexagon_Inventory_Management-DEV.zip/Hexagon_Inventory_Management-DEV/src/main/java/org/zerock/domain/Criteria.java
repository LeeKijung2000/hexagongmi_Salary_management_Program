package org.zerock.domain;

import org.springframework.web.util.UriComponentsBuilder;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Criteria {

    private int pageNum;
    private int amount;

    private String type;
    private String keyword;

    // 출하/출하지시 조회 공통 검색 조건
    private String status;
    private String dateFrom;
    private String dateTo;
    private Long businessPartnerId;
    private Long warehouseId;
    private Long itemId;

    // 기본 생성자: 첫 번째 페이지, 한 페이지당 10개 출력
    public Criteria() {
        this(1, 10);
    }

    public Criteria(int pageNum, int amount) {
        this.pageNum = pageNum;
        this.amount = amount;
    }

    // 검색 조건을 배열로 처리하기 위한 메서드 (예: 'TC' -> ['T', 'C'])
    public String[] getTypeArr() {
        return type == null ? new String[] {} : type.split("");
    }

    // 목록 페이지에서 조회/수정 화면으로 이동할 때 페이지 번호와 검색 파라미터를 유지하기 위함
    public String getListLink() {
        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString("")
                .queryParam("pageNum", this.pageNum)
                .queryParam("amount", this.amount)
                .queryParam("type", this.type)
                .queryParam("keyword", this.keyword);

        return builder.toUriString();
    }
}
