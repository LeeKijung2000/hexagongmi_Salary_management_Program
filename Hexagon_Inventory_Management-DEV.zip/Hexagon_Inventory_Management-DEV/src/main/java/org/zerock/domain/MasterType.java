package org.zerock.domain;

import java.util.Arrays;

/**
 * DB 테이블명을 사용자 입력으로 직접 받지 않도록 서버에서 허용할 마스터 종류를 고정한다. (생산공정/품목그룹/품질검사유형)
 */
public enum MasterType {
    PROD_PROCESS("prod-process", "생산공정", "생산공정_1단계"),
    ITEM_GROUP1("item-group1", "품목그룹1", "품목그룹1등록"),
    ITEM_GROUP2("item-group2", "품목그룹2", "품목그룹2등록"),
    ITEM_GROUP3("item-group3", "품목그룹3", "품목그룹3등록"),
    QUALITY_INSP_TYPE("quality-insp-type", "품질검사유형", "품질검사유형등록");

    private final String route;
    private final String label;
    private final String registerTitle;

    MasterType(String route, String label, String registerTitle) {
        this.route = route;
        this.label = label;
        this.registerTitle = registerTitle;
    }

    public String getRoute() {
        return route;
    }

    public String getLabel() {
        return label;
    }

    public String getRegisterTitle() {
        return registerTitle;
    }

    public static MasterType from(String value) {
        return Arrays.stream(values())
                .filter(type -> type.route.equalsIgnoreCase(value))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("지원하지 않는 마스터 유형입니다."));
    }
}
