package org.zerock.domain;

import java.math.BigDecimal;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ShipmentVO {
    private Long shipmentId;
    private String voucherNo;
    private String shipmentDate;
    private Long businessPartnerId;
    private String partnerCode;
    private String partnerName;
    private Long managerId;
    private String managerName;
    private Long warehouseId;
    private String warehouseName;
    private Long projectId;
    private String projectName;
    private String contactNumber;
    private String postalCode;
    private String address;
    private String voucherStatus;
    private String remarks;
    private List<ShipmentItemVO> items;
    private String itemSummary;
    private BigDecimal quantityTotal;
}
