package org.zerock.domain;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PurPriceGroupVO {
    private Long purPriceGroupPk; // 구매단가그룹 고유 식별자 (PK)
    private String code;          // 구매단가그룹 코드
    private String name;          // 구매단가그룹 명칭
}