package org.zerock.domain;

import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ShipmentItemVO {
    private Long shipmentItemId;
    private Long shipmentId;
    private Integer lineNo;
    private Long itemId;
    private String itemCodeSnap;
    private String itemNameSnap;
    private String specSnap;
    private String unitSnap;
    private BigDecimal quantity;
    private String remarks;
    private Long sourceShippingOrderItemId;
    private Long sourceShippingOrderId;
    private Long businessPartnerId;
    private Long warehouseId;
    private BigDecimal availableQuantity;
    private String sourceVoucherNo;
    private String sourceDate;
    private String sourcePartnerName;
    private String sourceWarehouseName;
}
