package org.zerock.domain;

import java.math.BigDecimal;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 품목 리스트 하단의 '변경' 기능에서 공통으로 사용하는 일괄변경 값입니다.
 * field는 서버에서 허용 목록으로만 처리하며, 임의의 컬럼명을 SQL로 전달하지 않습니다.
 */
@Data
@NoArgsConstructor
public class ItemBulkChangeVO {
    private String field;
    private String textValue;
    private Integer intValue;
    private BigDecimal decimalValue;
}
