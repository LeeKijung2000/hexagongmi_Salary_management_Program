package org.zerock.domain;

import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ShipSourceItemVO {
    private Long sourceItemId;
    private String voucherNo;
    private String saleDate;
    private Long businessPartnerId;
    private String partnerName;
    private Long warehouseId;
    private String warehouseName;
    private Long itemId;
    private String itemCode;
    private String itemName;
    private String spec;
    private String unit;
    private BigDecimal saleQuantity;
    private BigDecimal appliedQuantity;
    private BigDecimal availableQuantity;
}
