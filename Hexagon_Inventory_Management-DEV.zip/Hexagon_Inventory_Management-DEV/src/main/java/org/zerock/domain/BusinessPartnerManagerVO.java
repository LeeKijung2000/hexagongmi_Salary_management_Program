package org.zerock.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BusinessPartnerManagerVO {
    private Long managerId;
    private String employeeCode;
    private String employeeName;
    private String searchContent;
    private String positionName;
    private String contactNumber;
    private String email;
    private String additionalItem;
}
