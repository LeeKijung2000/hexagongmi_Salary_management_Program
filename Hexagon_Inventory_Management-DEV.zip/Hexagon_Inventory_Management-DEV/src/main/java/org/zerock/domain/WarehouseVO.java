package org.zerock.domain;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
/**
 * 한국어: 창고 화면과 DB 사이의 창고 데이터를 전달하는 VO입니다.
 * 日本語: 画面とDBの間で倉庫データを受け渡すVOです。
 */
public class WarehouseVO {
    private Long warehousePk;             // 창고 고유 식별자 (PK) / 倉庫の一意識別子(PK)
    private String warehouseCode;         // 창고 코드 / 倉庫コード
    private String warehouseName;         // 창고 명칭 / 倉庫名称
    private Integer warehouseDiv;         // 구분 (0: 일반창고, 1: 외주창고, 2: 불량창고) / 区分(0: 一般倉庫、1: 外注倉庫、2: 不良倉庫)
    private String prodProcessName;       // 생산공정 명칭 / 生産工程名称
    private String outsourcingPartnerName;// 외주거래처 명칭 / 外注取引先名称
    private String useYn;                 // 사용 여부 (Y: 사용, N: 미사용) / 使用有無(Y: 使用、N: 未使用)
    private Long prodProcessPk;            // 생산공정 FK (새 SQL) / 生産工程FK(新SQL)
    private Long outsourcePartnerId;       // 외주거래처 FK (새 SQL) / 外注取引先FK(新SQL)
    private BigDecimal vatRateSales;      // 매출 부가세율 / 売上消費税率
    private BigDecimal vatRatePurchase;   // 매입 부가세율 / 仕入消費税率
    
    // 외래키(FK) 필드
    private Long salesPriceGroupPk;       // 영업단가그룹 PK / 販売単価グループPK
    private Long purPriceGroupPk;         // 구매단가그룹 PK / 仕入単価グループPK
    private Long whHierGroupPk;           // 창고계층그룹 PK / 倉庫階層グループPK
}