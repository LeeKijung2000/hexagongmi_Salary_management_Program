package org.sales.sale.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;

import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;

import javax.sql.DataSource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.sales.sale.SaleInputOneFixture;
import org.sales.sale.dto.SaleInputOneDTO;
import org.sales.sale.service.SaleInputOneService;
import org.sales.sale.dto.SaleStatusLineDTO;
import org.sales.sale.dto.SaleStatusResultDTO;
import org.sales.sale.dto.SaleStatusSearchDTO;
import org.sales.sale.dto.SaleStatusSummaryDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

/**
 * 판매현황 조회가 판매 수량을 고치지 않는지, 보류를 빼는지, 집계조건이 없으면 거절하는지를 본다.
 * 금액은 화면에서 다시 계산하지 않고 저장된 공급가액, 부가세, 합계를 확인한다.
 * 販売状況の照会が販売数量を直さないか、保留を外すか、集計条件がなければ拒むかを見る。
 * 金額は画面で計算し直さず、保存された供給価額、付加税、合計を確かめる。
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class SaleStatusServiceTests {

	@Setter(onMethod_ = @Autowired)
	private SaleStatusService service;

	@Setter(onMethod_ = @Autowired)
	private SaleInputOneService saleInput;

	@Setter(onMethod_ = @Autowired)
	private DataSource dataSource;

	/** 판매현황 서비스가 스프링에 올라와 있는지 확인한다. 販売状況サービスがスプリングに載っているか確かめる。 */
	@Test
	public void testExist() {
		assertNotNull(service);
	}

	/** 시작일이 종료일보다 늦으면 조회하지 않는다. 開始日が終了日より遅ければ照会しない。 */
	@Test
	@Transactional
	public void testReversedPeriodIsRejected() {
		SaleStatusSearchDTO search = period(LocalDate.now(), LocalDate.now().minusDays(1));
		try {
			service.searchLines(search);
			fail();
		} catch (IllegalArgumentException e) {
			assertEquals("開始日が終了日より後です。", e.getMessage());
		}
	}

	/** 일별이어도 품목 줄을 합치지 않고, 수량 2, 단가 1000, 공급가액 2000, 부가세 200, 합계 2200을 그대로 돌려준다.
	 *  日別でも品目行は合算せず、数量 2、単価 1000、供給価額 2000、付加税 200、合計 2200 をそのまま返す。 */
	@Test
	@Transactional
	public void testDayGroupShowsStoredAmounts() {
		SaleInputOneFixture fixture = prepared();
		SaleInputOneDTO sale = fixture.newSale();
		saleInput.register(sale);

		SaleStatusSearchDTO search = partnerSearch(fixture);
		search.setViewMode("DAY");
		SaleStatusResultDTO result = service.searchLines(search);
		assertEquals(1, result.getLines().size());
		SaleStatusLineDTO row = result.getLines().get(0);
		assertEquals(0, new BigDecimal("2").compareTo(row.getQuantity()));
		assertEquals(0, new BigDecimal("1000").compareTo(row.getUnitPrice()));
		assertEquals(0, new BigDecimal("2000").compareTo(row.getSupplyAmount()));
		assertEquals(0, new BigDecimal("200").compareTo(row.getVatAmount()));
		assertEquals(0, new BigDecimal("2200").compareTo(row.getTotalAmount()));
		assertNull(row.getCompareQuantity());
	}

	/** 보류는 현황에서 빠진다. 일반은 반품을 빼고, 반품만 고르면 반품 수량만 남긴다.
	 *  保留は現状から外れる。一般は返品を除き、返品だけ選ぶと返品数量だけ残る。 */
	@Test
	@Transactional
	public void testHoldAndReturnFilter() {
		SaleInputOneFixture fixture = prepared();
		SaleInputOneDTO hold = fixture.newSale();
		hold.getHeader().setVoucherStatus("保留");
		saleInput.register(hold);

		assertEquals(0, BigDecimal.ZERO.compareTo(service.searchLines(partnerSearch(fixture)).getQuantity()));

		SaleInputOneDTO returned = fixture.newSale();
		returned.getHeader().setVoucherStatus("返品");
		saleInput.register(returned);

		SaleStatusSearchDTO normal = partnerSearch(fixture);
		normal.setInputScope("NORMAL");
		assertEquals(0, BigDecimal.ZERO.compareTo(service.searchLines(normal).getQuantity()));

		SaleStatusSearchDTO returns = partnerSearch(fixture);
		returns.setInputScope("RETURN");
		assertEquals(0, new BigDecimal("2").compareTo(service.searchLines(returns).getQuantity()));
	}

	/** 집계조건이 한 칸도 없으면 기간 합계 한 줄을 만들지 않고 거절한다.
	 *  集計条件が1枠もなければ期間合計の1行を作らず拒む。 */
	@Test
	@Transactional
	public void testSummaryWithoutGroupIsRejected() {
		SaleInputOneFixture fixture = prepared();
		saleInput.register(fixture.newSale());

		try {
			service.searchSummary(partnerSearch(fixture));
			fail("집계조건 없이 집계 조회가 되었습니다.");
		} catch (IllegalArgumentException e) {
			assertEquals("集計条件を選択してください。", e.getMessage());
		}
	}

	/** 거래처별은 거래처명으로 묶고 둘째 조건 이름은 비워 둔다. 取引先別は取引先名で束ね、二つ目の条件名は空にする。 */
	@Test
	@Transactional
	public void testSummaryByPartner() {
		SaleInputOneFixture fixture = prepared();
		saleInput.register(fixture.newSale());

		SaleStatusSearchDTO search = partnerSearch(fixture);
		search.setGroup1("PARTNER");
		SaleStatusSummaryDTO row = service.searchSummary(search).getSummaries().get(0);
		assertEquals("테스트거래처", row.getGroup1Name());
		assertEquals(0, new BigDecimal("2").compareTo(row.getQuantity()));
		assertNull(row.getGroup2Name());
	}

	/** 전월 동일기간은 지난달 수량을 옆에 붙일 뿐, 오늘 판매 수량은 그대로 둔다.
	 *  前月同一期間は先月の数量を横に付けるだけで、今日の販売数量はそのままにする。 */
	@Test
	@Transactional
	public void testCompareQuantityDoesNotUpdateSale() {
		SaleInputOneFixture fixture = prepared();
		SaleInputOneDTO past = fixture.newSale();
		past.getHeader().setSaleDt(Date.valueOf(LocalDate.now().minusMonths(1)));
		past.getItems().get(0).setSaleQty(new BigDecimal("5"));
		saleInput.register(past);
		SaleInputOneDTO today = fixture.newSale();
		saleInput.register(today);

		SaleStatusSearchDTO search = partnerSearch(fixture);
		search.setFromDate(Date.valueOf(LocalDate.now()));
		search.setToDate(Date.valueOf(LocalDate.now()));
		search.setCompare("PREV_MONTH");
		search.setViewMode("DAY");
		SaleStatusResultDTO result = service.searchLines(search);
		assertEquals(1, result.getLines().size());
		SaleStatusLineDTO row = result.getLines().get(0);

		assertEquals(0, new BigDecimal("2").compareTo(row.getQuantity()));
		assertEquals(0, new BigDecimal("5").compareTo(row.getCompareQuantity()));
		assertEquals(1, result.getCompareLines().size());
		assertEquals(0, new BigDecimal("5").compareTo(result.getCompareLines().get(0).getQuantity()));
		assertEquals(0, new BigDecimal("2").compareTo(storedQuantity(today.getHeader().getSaleId())));
	}

	/** 구분을 비워도 일별로 받아 품목 줄을 돌려준다. 월 계 행은 서비스가 만들지 않는다.
	 *  区分を空にしても日別として受け、品目行を返す。月計行はサービスが作らない。 */
	@Test
	@Transactional
	public void testBlankViewModeStillListsLines() {
		SaleInputOneFixture fixture = prepared();
		saleInput.register(fixture.newSale());

		SaleStatusSearchDTO search = partnerSearch(fixture);
		search.setViewMode("");
		SaleStatusResultDTO result = service.searchLines(search);
		assertEquals(1, result.getLines().size());
		assertEquals(0, new BigDecimal("2200").compareTo(result.getLines().get(0).getTotalAmount()));
	}

	/** 없는 구분은 일별로 바꾸지 않고 거절한다. ない区分は日別に替えず拒む。 */
	@Test
	@Transactional
	public void testUnknownViewModeIsRejected() {
		SaleStatusSearchDTO search = period(LocalDate.now(), LocalDate.now());
		search.setViewMode("SLIP");
		try {
			service.searchLines(search);
			fail("없는 구분이 조회되었습니다.");
		} catch (IllegalArgumentException e) {
			assertEquals("区分が正しくありません。", e.getMessage());
		}
	}

	/** 월별 집계 이름은 yyyy-MM이다. 계 행은 화면이 붙이므로 결과에는 그 달 한 줄만 있다.
	 *  月別集計の名前は yyyy-MM である。計行は画面が付けるので結果にはその月の1行だけある。 */
	@Test
	@Transactional
	public void testSummaryByMonth() {
		SaleInputOneFixture fixture = prepared();
		saleInput.register(fixture.newSale());

		SaleStatusSearchDTO search = partnerSearch(fixture);
		search.setGroup1("MONTH");
		SaleStatusSummaryDTO row = service.searchSummary(search).getSummaries().get(0);
		assertEquals(LocalDate.now().toString().substring(0, 7), row.getGroup1Name());
		assertEquals(0, new BigDecimal("2").compareTo(row.getQuantity()));
	}

	/** 목록에 없는 집계조건은 거절한다. 一覧にない集計条件は拒む。 */
	@Test
	@Transactional
	public void testUnknownGroupIsRejected() {
		SaleStatusSearchDTO search = period(LocalDate.now(), LocalDate.now());
		search.setGroup1("SLIP");
		try {
			service.searchSummary(search);
			fail("없는 집계조건이 조회되었습니다.");
		} catch (IllegalArgumentException e) {
			assertEquals("集計条件が正しくありません。", e.getMessage());
		}
	}

	/** 판매입력1 고정 자료. 수량 2, 단가 1000, 부가세 10%다. 販売入力1の固定資料。数量 2、単価 1000、付加税 10% である。 */
	private SaleInputOneFixture prepared() {
		SaleInputOneFixture fixture = new SaleInputOneFixture(dataSource);
		fixture.prepare();
		return fixture;
	}

	/** 그 거래처만, 두 달 전부터 오늘까지. その取引先だけ、二か月前から今日まで。 */
	private SaleStatusSearchDTO partnerSearch(SaleInputOneFixture fixture) {
		SaleStatusSearchDTO search = period(LocalDate.now().minusMonths(2), LocalDate.now());
		search.setPartnerId(fixture.getPartnerId());
		return search;
	}

	/** 시작일과 종료일만 채운 조회 조건. 開始日と終了日だけ埋めた照会条件。 */
	private SaleStatusSearchDTO period(LocalDate from, LocalDate to) {
		SaleStatusSearchDTO search = new SaleStatusSearchDTO();
		search.setFromDate(Date.valueOf(from));
		search.setToDate(Date.valueOf(to));
		return search;
	}

	/** 비교 조회 뒤에 저장된 수량이 바뀌지 않았는지 다시 읽는다. 比較照会のあと保存数量が変わっていないか読み直す。 */
	private BigDecimal storedQuantity(Long saleId) {
		return new JdbcTemplate(dataSource).queryForObject(
				"SELECT quantity FROM tb_sale_item WHERE sale_id = ?", BigDecimal.class, saleId);
	}
}
