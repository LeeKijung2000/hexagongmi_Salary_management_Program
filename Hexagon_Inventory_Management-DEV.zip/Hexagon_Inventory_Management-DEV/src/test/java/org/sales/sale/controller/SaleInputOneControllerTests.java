package org.sales.sale.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import java.nio.charset.StandardCharsets;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.sales.sale.SaleInputOneFixture;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.WebApplicationContext;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

/**
 * 판매입력1 화면과 저장 주소. 거래처가 없으면 400이고, 새 보류는 5건에서 멈춘다.
 * 販売入力1の画面と保存アドレス。取引先がなければ400であり、新しい保留は5件で止まる。
 */
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration({
		"file:src/main/webapp/WEB-INF/spring/root-context.xml",
		"file:src/main/webapp/WEB-INF/spring/appServlet/servlet-context.xml" })
@Log4j
public class SaleInputOneControllerTests {

	@Setter(onMethod_ = { @Autowired })
	private WebApplicationContext ctx;

	@Setter(onMethod_ = @Autowired)
	private DataSource dataSource;

	private MockMvc mockMvc;

	/** 스프링 화면 컨텍스트로 MockMvc를 만든다. スプリングの画面コンテキストで MockMvc を作る。 */
	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(ctx).build();
	}

	/** 판매입력 화면이 열린다. 販売入力の画面が開く。 */
	@Test
	public void testInput() throws Exception {
		log.info(mockMvc.perform(get("/sales/sale/input"))
				.andReturn()
				.getModelAndView()
				.getModelMap());
	}

	/** 보류 목록 주소가 응답한다. 保留一覧のアドレスが応答する。 */
	@Test
	public void testHolds() throws Exception {
		String result = mockMvc.perform(get("/sales").param("status", "hold"))
				.andReturn()
				.getResponse()
				.getContentAsString();
		log.info(result);
	}

	/** 거래처 없이 저장하면 400이다. 取引先なしで保存すると400である。 */
	@Test
	public void testRegisterWithoutPartner() throws Exception {
		MvcResult result = mockMvc.perform(post("/sales")
				.characterEncoding("UTF-8")
				.param("header.voucherStatus", "正常"))
				.andReturn();

		assertEquals(400, result.getResponse().getStatus());
	}

	/** 거래처, 창고, 담당자, 품목이 있으면 201로 저장된다.
	 *  取引先、倉庫、担当者、品目があれば201で保存される。 */
	@Test
	@Transactional
	public void testRegister() throws Exception {
		SaleInputOneFixture fixture = new SaleInputOneFixture(dataSource);
		fixture.prepare();

		MvcResult result = mockMvc.perform(post("/sales")
				.characterEncoding("UTF-8")
				.param("header.saleDt", "2026-10-06")
				.param("header.businessPartnerId", String.valueOf(fixture.getPartnerId()))
				.param("header.warehousePk", String.valueOf(fixture.getWarehouseId()))
				.param("header.managerId", String.valueOf(fixture.getManagerId()))
				.param("header.voucherStatus", "正常")
				.param("items[0].itemPk", String.valueOf(fixture.getItemId()))
				.param("items[0].itemNm", "테스트품목")
				.param("items[0].saleQty", "2")
				.param("items[0].unitPrice", "1000")
				.param("items[0].supplyAmt", "2000")
				.param("items[0].vatAmt", "200")
				.param("items[0].lineAmt", "2200"))
				.andReturn();

		assertEquals(201, result.getResponse().getStatus());
		log.info(result.getResponse().getContentAsString());
	}

	/** 새 보류는 5건까지만 저장된다. 6번째 새 보류는 400이고, 정상 저장은 보류 건수와 상관없이 된다.
	 *  新しい保留は5件まで保存される。6件目の新しい保留は400であり、正常保存は保留件数と関係なくできる。 */
	@Test
	@Transactional
	public void testNewHoldStopsAtFive() throws Exception {
		SaleInputOneFixture fixture = new SaleInputOneFixture(dataSource);
		fixture.prepare();
		JdbcTemplate jdbc = new JdbcTemplate(dataSource);
		int existing = jdbc.queryForObject("SELECT COUNT(*) FROM tb_sale WHERE voucher_status = 'HOLD'", Integer.class);

		for (int i = existing; i < 5; i++) {
			assertEquals(201, postSale(fixture, "保留").getResponse().getStatus());
		}

		MvcResult blocked = postSale(fixture, "保留");
		assertEquals(400, blocked.getResponse().getStatus());
		String body = new String(blocked.getResponse().getContentAsByteArray(), StandardCharsets.UTF_8);
		assertTrue(body.contains("保留伝票は最大5件まで保存されます。"));

		assertEquals(201, postSale(fixture, "正常").getResponse().getStatus());
	}

	private MvcResult postSale(SaleInputOneFixture fixture, String voucherStatus) throws Exception {
		return mockMvc.perform(post("/sales")
				.characterEncoding("UTF-8")
				.param("header.saleDt", "2026-10-12")
				.param("header.businessPartnerId", String.valueOf(fixture.getPartnerId()))
				.param("header.warehousePk", String.valueOf(fixture.getWarehouseId()))
				.param("header.managerId", String.valueOf(fixture.getManagerId()))
				.param("header.voucherStatus", voucherStatus)
				.param("items[0].itemPk", String.valueOf(fixture.getItemId()))
				.param("items[0].itemNm", "테스트품목")
				.param("items[0].saleQty", "2")
				.param("items[0].unitPrice", "1000")
				.param("items[0].supplyAmt", "2000")
				.param("items[0].vatAmt", "200")
				.param("items[0].lineAmt", "2200"))
				.andReturn();
	}
}
