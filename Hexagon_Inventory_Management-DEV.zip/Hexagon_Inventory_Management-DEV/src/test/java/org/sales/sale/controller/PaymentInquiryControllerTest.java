package org.sales.sale.controller;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.sales.sale.dto.PaymentInquiryDetailDTO;
import org.sales.sale.dto.PaymentInquiryResultDTO;
import org.sales.sale.dto.PaymentInquirySaveDTO;
import org.sales.sale.dto.PaymentInquirySearchDTO;
import org.sales.sale.service.PaymentInquiryService;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

/**
 * 화면 주소와 검증 메시지가 컨트롤러에서 그대로 나가는지 확인한다.
 * 画面アドレスと検証メッセージがコントローラからそのまま出るか確認する。
 */
public class PaymentInquiryControllerTest {

	private MockMvc mockMvc;

	@Before
	public void setUp() {
		PaymentInquiryController controller = new PaymentInquiryController(new StubService());
		mockMvc = MockMvcBuilders.standaloneSetup(controller)
				.setMessageConverters(new MappingJackson2HttpMessageConverter())
				.build();
	}

	/** 결제내역조회 화면 주소는 결제내역 뷰를 연다.
	 *  決済履歴照会の画面アドレスは決済履歴ビューを開く。 */
	@Test
	public void pageOpensPaymentInquiry() throws Exception {
		String view = mockMvc.perform(get("/sales/sale/payment-inquiry")).andReturn().getModelAndView().getViewName();
		assertEquals("sales/sale/payment-inquiry", view);
	}

	/** 너무 긴 검색어는 400과 일본어 메시지를 그대로 돌려준다.
	 *  長すぎる検索語は 400 と日本語メッセージをそのまま返す。 */
	@Test
	public void longKeywordReturnsBadRequest() throws Exception {
		String json = body(mockMvc.perform(get("/sales/sale/payment-inquiry/list").param("keyword", "too-long"))
				.andExpect(status().isBadRequest())
				.andReturn().getResponse().getContentAsByteArray());
		assertEquals(true, json.contains("検索語は100文字までです。"));
	}

	/** 없는 결제 내역은 400과 일본어 메시지를 그대로 돌려준다.
	 *  ない決済内訳は 400 と日本語メッセージをそのまま返す。 */
	@Test
	public void missingDetailReturnsBadRequest() throws Exception {
		String json = body(mockMvc.perform(get("/sales/sale/payment-inquiry/detail").param("paymentId", "0"))
				.andExpect(status().isBadRequest())
				.andReturn().getResponse().getContentAsByteArray());
		assertEquals(true, json.contains("該当する決済がありません。"));
	}

	/** 내역 응답의 사업자 코드는 요청자 칸에 그대로 쓰는 값이다.
	 *  内訳応答の事業者コードは依頼者欄にそのまま使う値である。 */
	@Test
	public void detailReturnsCompanyCodeForRequester() throws Exception {
		String json = body(mockMvc.perform(get("/sales/sale/payment-inquiry/detail").param("paymentId", "8"))
				.andExpect(status().isOk())
				.andReturn().getResponse().getContentAsByteArray());
		assertEquals(true, json.contains("\"companyCode\":\"ヘキサゴン\""));
	}

	/** 결제방법이 다르면 등록은 400과 일본어 메시지를 그대로 돌려준다.
	 *  決済方法が違えば登録は 400 と日本語メッセージをそのまま返す。 */
	@Test
	public void invalidCreateReturnsBadRequest() throws Exception {
		String json = body(mockMvc.perform(post("/sales/sale/payment-inquiry")
				.contentType(MediaType.APPLICATION_JSON)
				.content("{\"paymentMethod\":\"POINT\"}"))
				.andExpect(status().isBadRequest())
				.andReturn().getResponse().getContentAsByteArray());
		assertEquals(true, json.contains("決済方法が正しくありません。"));
	}

	/** 재결제할 수 없는 상태는 400과 일본어 메시지를 그대로 돌려준다.
	 *  再決済できない状態は 400 と日本語メッセージをそのまま返す。 */
	@Test
	public void rejectedRepayReturnsBadRequest() throws Exception {
		String json = body(mockMvc.perform(post("/sales/sale/payment-inquiry/repay").param("paymentId", "7"))
				.andExpect(status().isBadRequest())
				.andReturn().getResponse().getContentAsByteArray());
		assertEquals(true, json.contains("再決済できるのは承認失敗と取消だけです。"));
	}

	private String body(byte[] bytes) throws Exception {
		return new String(bytes, "UTF-8");
	}

	/** 서비스 대신 검증 메시지와 사업자 코드만 돌려주는 대역이다.
	 *  サービスの代わりに検証メッセージと事業者コードだけ返す代役である。 */
	private static class StubService implements PaymentInquiryService {
		public PaymentInquiryResultDTO search(PaymentInquirySearchDTO search) {
			throw new IllegalArgumentException("検索語は100文字までです。");
		}

		public PaymentInquiryDetailDTO detail(Long paymentId) {
			if (paymentId == null || paymentId.longValue() == 0L) {
				throw new IllegalArgumentException("該当する決済がありません。");
			}
			PaymentInquiryDetailDTO detail = new PaymentInquiryDetailDTO();
			detail.setPaymentId(paymentId);
			detail.setCompanyCode("ヘキサゴン");
			return detail;
		}

		public PaymentInquiryDetailDTO create(PaymentInquirySaveDTO save) {
			throw new IllegalArgumentException("決済方法が正しくありません。");
		}

		public PaymentInquiryDetailDTO repay(Long paymentId) {
			throw new IllegalArgumentException("再決済できるのは承認失敗と取消だけです。");
		}
	}
}
