package org.sales.sale.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.sales.sale.dao.SalePriceChangeDao;
import org.sales.sale.dto.SalePriceChangeApplyResultDTO;
import org.sales.sale.dto.SalePriceChangeItemDTO;
import org.sales.sale.dto.SalePriceChangeKeyDTO;
import org.sales.sale.dto.SalePriceChangeSearchDTO;
import org.sales.sale.dto.SalePriceChangeSlipDTO;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.SimpleTransactionStatus;

/**
 * 단가변경은 고른 줄만 다시 계산하고, 환율변경은 외자 전표 전체를 환율 비율로 다시 계산한다.
 * 単価変更は選んだ行だけ計算し直し、為替変更は外貨伝票全体を為替の比で計算し直す。
 */
public class SalePriceChangeServiceImplTest {

	private Map<Long, SalePriceChangeSlipDTO> slips;
	private Map<Long, List<SalePriceChangeItemDTO>> items;
	private List<SalePriceChangeKeyDTO> targets;
	private int headerAmountUpdates;
	private int headerRateUpdates;
	private int rollbacks;
	private List<String> daoCalls;
	private Long failSaleId;
	private SalePriceChangeServiceImpl service;

	/** 전표와 품목을 메모리에 두고, 실패할 전표만 롤백하는 가짜 저장소를 붙인다.
	 *  伝票と品目をメモリに置き、失敗する伝票だけロールバックする偽の保存先を付ける。 */
	@Before
	public void setUp() {
		slips = new LinkedHashMap<Long, SalePriceChangeSlipDTO>();
		items = new LinkedHashMap<Long, List<SalePriceChangeItemDTO>>();
		targets = new ArrayList<SalePriceChangeKeyDTO>();
		headerAmountUpdates = 0;
		headerRateUpdates = 0;
		rollbacks = 0;
		daoCalls = new ArrayList<String>();
		failSaleId = null;
		SalePriceChangeDao dao = (SalePriceChangeDao) Proxy.newProxyInstance(SalePriceChangeDao.class.getClassLoader(),
				new Class[] { SalePriceChangeDao.class }, (proxy, method, args) -> invoke(method, args));
		service = new SalePriceChangeServiceImpl(dao, new NoopTransactionManager());
	}

	/** 고른 줄만 단가 1000으로 바꾸고, 같은 전표의 다른 줄은 둔 채 헤더만 전 줄 합계로 맞춘다.
	 *  選んだ行だけ単価1000に変え、同じ伝票の他の行は置いたままヘッダだけ全行合計に合わせる。 */
	@Test
	public void priceChangeUpdatesCheckedLineAndKeepsTheOther() {
		slip(10L, "VAT", "KR", new BigDecimal("1"), new BigDecimal("1"), new BigDecimal("50"));
		item(10L, 1L, new BigDecimal("2"), new BigDecimal("100"));
		item(10L, 2L, new BigDecimal("3"), new BigDecimal("10"));
		target(10L, 1L);

		SalePriceChangeApplyResultDTO result = service.changePrice(Arrays.asList(1L), new BigDecimal("1000"));

		assertEquals(1, result.getChangedSlips());
		assertEquals(1, result.getChangedLines());
		assertEquals(0, result.getFailedSlips());
		SalePriceChangeItemDTO changed = items.get(10L).get(0);
		assertEquals(new BigDecimal("1000"), changed.getUnitPrice());
		assertEquals(new BigDecimal("2000"), changed.getSupplyAmount());
		assertEquals(new BigDecimal("200"), changed.getVatAmount());
		assertEquals(new BigDecimal("2200"), changed.getTotalAmount());
		SalePriceChangeItemDTO kept = items.get(10L).get(1);
		assertEquals(new BigDecimal("10"), kept.getUnitPrice());
		assertEquals(new BigDecimal("30"), kept.getSupplyAmount());
		SalePriceChangeSlipDTO header = slips.get(10L);
		assertEquals(new BigDecimal("2030"), header.getSupplyAmount());
		assertEquals(new BigDecimal("200"), header.getVatAmount());
		assertEquals(new BigDecimal("2280"), header.getTotalAmount());
		assertEquals(1, headerAmountUpdates);
		assertEquals(0, headerRateUpdates);
	}

	/** 줄마다 다른 단가를 저장한다. 공급가액은 그 줄의 수량×단가이고 헤더는 둘을 더한 값이다.
	 *  行ごとに違う単価を保存する。供給価額はその行の数量×単価であり、ヘッダは二つを足した値である。 */
	@Test
	public void eachLineKeepsItsOwnPrice() {
		slip(12L, "VAT", "KR", BigDecimal.ONE, BigDecimal.ONE, BigDecimal.ZERO);
		item(12L, 4L, new BigDecimal("2"), new BigDecimal("10"));
		item(12L, 5L, new BigDecimal("3"), new BigDecimal("10"));
		target(12L, 4L);
		target(12L, 5L);

		SalePriceChangeApplyResultDTO result = service.changePrices(Arrays.asList(4L, 5L),
				Arrays.asList(new BigDecimal("20"), new BigDecimal("30")));

		assertEquals(1, result.getChangedSlips());
		assertEquals(2, result.getChangedLines());
		assertEquals(new BigDecimal("20"), items.get(12L).get(0).getUnitPrice());
		assertEquals(new BigDecimal("40"), items.get(12L).get(0).getSupplyAmount());
		assertEquals(new BigDecimal("30"), items.get(12L).get(1).getUnitPrice());
		assertEquals(new BigDecimal("90"), items.get(12L).get(1).getSupplyAmount());
		assertEquals(new BigDecimal("130"), slips.get(12L).getSupplyAmount());
		assertEquals(new BigDecimal("13"), slips.get(12L).getVatAmount());
	}

	/** 부가세율 미적용 전표는 단가를 바꿔도 부가세가 0이다.
	 *  付加税率不適用の伝票は単価を変えても付加税が0である。 */
	@Test
	public void noVatPriceHasZeroTax() {
		slip(11L, "NO_VAT", "KR", BigDecimal.ONE, BigDecimal.ONE, BigDecimal.ZERO);
		item(11L, 3L, new BigDecimal("4"), new BigDecimal("10"));
		target(11L, 3L);

		service.changePrice(Arrays.asList(3L), new BigDecimal("25"));

		SalePriceChangeItemDTO changed = items.get(11L).get(0);
		assertEquals(new BigDecimal("100"), changed.getSupplyAmount());
		assertEquals(BigDecimal.ZERO, changed.getVatAmount());
		assertEquals(new BigDecimal("100"), changed.getTotalAmount());
	}

	/** 외자 단가는 이전 환율 대비 새 환율로 다시 계산하고, 내자 전표는 건너뛴다.
	 *  外貨単価は前の為替に対する新しい為替で計算し直し、内貨伝票は飛ばす。 */
	@Test
	public void rateChangeScalesForeignPriceAndSkipsDomestic() {
		slip(20L, "VAT", "USD", new BigDecimal("100"), new BigDecimal("120"), BigDecimal.ZERO);
		item(20L, 4L, new BigDecimal("2"), new BigDecimal("1000"));
		target(20L, 4L);
		slip(21L, "VAT", "KR", BigDecimal.ONE, BigDecimal.ONE, BigDecimal.ZERO);
		item(21L, 5L, BigDecimal.ONE, new BigDecimal("500"));
		target(21L, 5L);

		SalePriceChangeApplyResultDTO result = service.changeRate(Arrays.asList(4L, 5L));

		assertEquals(1, result.getChangedSlips());
		assertEquals(1, result.getSkippedDomestic());
		assertEquals(new BigDecimal("1200.0000"), items.get(20L).get(0).getUnitPrice());
		assertEquals(new BigDecimal("2400"), items.get(20L).get(0).getSupplyAmount());
		assertEquals(new BigDecimal("240"), items.get(20L).get(0).getVatAmount());
		assertEquals(new BigDecimal("120"), slips.get(20L).getExchangeRate());
		assertEquals(new BigDecimal("500"), items.get(21L).get(0).getUnitPrice());
		assertEquals(1, headerRateUpdates);
	}

	/** 한 전표가 실패해도 이미 고친 다른 전표는 롤백하지 않는다.
	 *  1伝票が失敗しても、すでに直した他の伝票はロールバックしない。 */
	@Test
	public void oneSlipFailureDoesNotUndoTheOther() {
		slip(30L, "VAT", "KR", BigDecimal.ONE, BigDecimal.ONE, BigDecimal.ZERO);
		item(30L, 6L, BigDecimal.ONE, BigDecimal.TEN);
		target(30L, 6L);
		slip(31L, "VAT", "KR", BigDecimal.ONE, BigDecimal.ONE, BigDecimal.ZERO);
		item(31L, 7L, BigDecimal.ONE, BigDecimal.TEN);
		target(31L, 7L);
		failSaleId = 31L;

		SalePriceChangeApplyResultDTO result = service.changePrice(Arrays.asList(6L, 7L), new BigDecimal("8"));

		assertEquals(1, result.getChangedSlips());
		assertEquals(1, result.getFailedSlips());
		assertEquals(1, rollbacks);
		assertEquals(new BigDecimal("8"), items.get(30L).get(0).getUnitPrice());
		assertEquals(new BigDecimal("10"), items.get(31L).get(0).getUnitPrice());
	}

	/** 단가 저장은 판매 품목과 판매 헤더만 고친다. 품목 마스터 메서드는 호출하지 않는다.
	 *  単価保存は販売品目と販売ヘッダだけ直す。品目マスタのメソッドは呼ばない。 */
	@Test
	public void priceSaveTouchesSaleTablesOnly() {
		slip(12L, "VAT", "KR", BigDecimal.ONE, BigDecimal.ONE, BigDecimal.ZERO);
		item(12L, 4L, new BigDecimal("2"), new BigDecimal("10"));
		item(12L, 5L, new BigDecimal("3"), new BigDecimal("10"));
		target(12L, 4L);
		target(12L, 5L);

		service.changePrices(Arrays.asList(4L, 5L), Arrays.asList(new BigDecimal("20"), new BigDecimal("30")));

		assertEquals(Arrays.asList("selectTargets", "selectSlip", "selectItems", "updateItem", "updateItem",
				"updateHeaderAmounts"), daoCalls);
		assertEquals(0, headerRateUpdates);
	}

	/** 줄 수와 단가 수가 다르거나 단가가 음수면 저장하지 않는다.
	 *  行数と単価数が違うか単価が負なら保存しない。 */
	@Test
	public void mismatchedOrNegativePriceIsRejected() {
		slip(12L, "VAT", "KR", BigDecimal.ONE, BigDecimal.ONE, BigDecimal.ZERO);
		item(12L, 4L, new BigDecimal("2"), new BigDecimal("10"));
		target(12L, 4L);
		try {
			service.changePrices(Arrays.asList(4L), Arrays.asList(new BigDecimal("20"), new BigDecimal("30")));
			fail();
		} catch (IllegalArgumentException e) {
			assertEquals("変更単価が正しくありません。", e.getMessage());
		}
		try {
			service.changePrices(Arrays.asList(4L), Arrays.asList(new BigDecimal("-1")));
			fail();
		} catch (IllegalArgumentException e) {
			assertEquals("変更単価が正しくありません。", e.getMessage());
		}
		assertEquals(0, headerAmountUpdates);
		assertEquals(new BigDecimal("10"), items.get(12L).get(0).getUnitPrice());
	}

	/** 통화 마스터에 환율이 없으면 그 전표는 실패하고 단가는 그대로다.
	 *  通貨マスタに為替がなければその伝票は失敗し、単価はそのままである。 */
	@Test
	public void missingCurrencyRateFailsThatSlip() {
		slip(20L, "VAT", "USD", new BigDecimal("100"), null, BigDecimal.ZERO);
		item(20L, 4L, new BigDecimal("2"), new BigDecimal("1000"));
		target(20L, 4L);
		try {
			SalePriceChangeApplyResultDTO result = service.changeRate(Arrays.asList(4L));
			assertEquals(0, result.getChangedSlips());
			assertEquals(1, result.getFailedSlips());
		} catch (IllegalArgumentException e) {
			fail();
		}
		assertEquals(1, rollbacks);
		assertEquals(new BigDecimal("1000"), items.get(20L).get(0).getUnitPrice());
		assertEquals(0, headerRateUpdates);
	}

	/** 이전 환율이 0이면 1로 보고 새 환율 비율을 곱한다.
	 *  前の為替が0なら1と見て、新しい為替の比を掛ける。 */
	@Test
	public void zeroOldRateIsTreatedAsOne() {
		slip(20L, "VAT", "USD", BigDecimal.ZERO, new BigDecimal("200"), BigDecimal.ZERO);
		item(20L, 4L, BigDecimal.ONE, new BigDecimal("1000"));
		target(20L, 4L);

		service.changeRate(Arrays.asList(4L));

		assertEquals(new BigDecimal("200000.0000"), items.get(20L).get(0).getUnitPrice());
		assertEquals(new BigDecimal("200"), slips.get(20L).getExchangeRate());
	}

	/** 기준일자가 없으면 조회하지 않는다.
	 *  基準日がなければ照会しない。 */
	@Test
	public void missingDateIsRejected() {
		try {
			service.search(new SalePriceChangeSearchDTO());
			fail();
		} catch (IllegalArgumentException e) {
			assertEquals("基準日を入力してください。", e.getMessage());
		}
	}

	@Test
	public void fromAfterToIsRejected() {
		SalePriceChangeSearchDTO search = new SalePriceChangeSearchDTO();
		search.setFromDate(java.sql.Date.valueOf("2026-10-20"));
		search.setToDate(java.sql.Date.valueOf("2026-10-19"));
		try {
			service.search(search);
			fail();
		} catch (IllegalArgumentException e) {
			assertEquals("開始日が終了日より後です。", e.getMessage());
		}
	}

	private void slip(Long saleId, String transactionType, String currencyCode, BigDecimal exchangeRate,
			BigDecimal currencyRate, BigDecimal adjustment) {
		SalePriceChangeSlipDTO slip = new SalePriceChangeSlipDTO();
		slip.setSaleId(saleId);
		slip.setTransactionType(transactionType);
		slip.setCurrencyCode(currencyCode);
		slip.setExchangeRate(exchangeRate);
		slip.setCurrencyRate(currencyRate);
		slip.setAdjustmentAmount(adjustment);
		slips.put(saleId, slip);
	}

	private void item(Long saleId, Long saleItemId, BigDecimal quantity, BigDecimal unitPrice) {
		SalePriceChangeItemDTO item = new SalePriceChangeItemDTO();
		item.setSaleItemId(saleItemId);
		item.setQuantity(quantity);
		item.setUnitPrice(unitPrice);
		item.setSupplyAmount(quantity.multiply(unitPrice));
		item.setVatAmount(BigDecimal.ZERO);
		List<SalePriceChangeItemDTO> rows = items.get(saleId);
		if (rows == null) {
			rows = new ArrayList<SalePriceChangeItemDTO>();
			items.put(saleId, rows);
		}
		rows.add(item);
	}

	private void target(Long saleId, Long saleItemId) {
		SalePriceChangeKeyDTO key = new SalePriceChangeKeyDTO();
		key.setSaleId(saleId);
		key.setSaleItemId(saleItemId);
		targets.add(key);
	}

	private Object invoke(Method method, Object[] args) {
		String name = method.getName();
		daoCalls.add(name);
		if ("selectTargets".equals(name)) {
			return targets;
		}
		if ("selectSlip".equals(name)) {
			if (failSaleId != null && failSaleId.equals(args[0])) {
				return null;
			}
			return slips.get(args[0]);
		}
		if ("selectItems".equals(name)) {
			return items.get(args[0]);
		}
		if ("updateItem".equals(name)) {
			return 1;
		}
		if ("updateHeaderAmounts".equals(name)) {
			headerAmountUpdates++;
			return 1;
		}
		if ("updateHeaderRate".equals(name)) {
			headerRateUpdates++;
			return 1;
		}
		if ("countLines".equals(name) || "selectLines".equals(name)) {
			throw new UnsupportedOperationException(name);
		}
		return null;
	}

	private class NoopTransactionManager implements PlatformTransactionManager {
		public TransactionStatus getTransaction(TransactionDefinition definition) {
			return new SimpleTransactionStatus();
		}

		public void commit(TransactionStatus status) {
		}

		public void rollback(TransactionStatus status) {
			rollbacks++;
		}
	}
}
