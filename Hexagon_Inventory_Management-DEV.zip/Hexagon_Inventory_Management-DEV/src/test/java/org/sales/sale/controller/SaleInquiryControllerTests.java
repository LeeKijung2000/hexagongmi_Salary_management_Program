package org.sales.sale.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.ModelAndView;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

/**
 * 판매조회 화면. 주소는 조회 화면을 열고, 기간 기본값으로 오늘 기준 30일 전과 30일 뒤를 넣는다.
 * 販売照会画面。アドレスは照会画面を開き、期間の初期値として今日を基準に30日前と30日後を入れる。
 */
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration({
		"file:src/main/webapp/WEB-INF/spring/root-context.xml",
		"file:src/main/webapp/WEB-INF/spring/appServlet/servlet-context.xml" })
@Log4j
public class SaleInquiryControllerTests {

	@Setter(onMethod_ = { @Autowired })
	private WebApplicationContext ctx;

	private MockMvc mockMvc;

	/** 스프링 화면 컨텍스트로 MockMvc를 만든다. スプリングの画面コンテキストで MockMvc を作る。 */
	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(ctx).build();
	}

	/** 판매조회 화면이 열리고 시작일, 종료일이 모델에 있다.
	 *  販売照会の画面が開き、開始日、終了日がモデルにある。 */
	@Test
	public void testInquiryPage() throws Exception {
		ModelAndView view = mockMvc.perform(get("/sales/sale/inquiry")).andReturn().getModelAndView();
		log.info(view);
		assertEquals("sales/sale/inquiry", view.getViewName());
		assertNotNull(view.getModel().get("fromDate"));
		assertNotNull(view.getModel().get("toDate"));
	}
}
