package org.sales.sale;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;

import javax.sql.DataSource;

import org.sales.sale.dto.SaleCurrDTO;
import org.sales.sale.dto.SaleCurrItemDTO;
import org.sales.sale.dto.SaleInputOneDTO;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * 판매입력 테스트용 기준정보. 담당자, 거래처, 창고, 품목을 넣고 전표 한 건을 만든다.
 * 販売入力テスト用の基準情報。担当者、取引先、倉庫、品目を入れ、伝票1件を作る。
 */
public class SaleInputOneFixture {

	private final JdbcTemplate jdbc;

	private Long managerId;
	private Long partnerId;
	private Long warehouseId;
	private Long itemId;

	public SaleInputOneFixture(DataSource dataSource) {
		this.jdbc = new JdbcTemplate(dataSource);
	}

	/** 담당자, 거래처, 창고, 품목과 출하창고 재고 100을 넣는다.
	 *  担当者、取引先、倉庫、品目と出荷倉庫在庫100を入れる。 */
	public void prepare() {
		managerId = next("tb_manager_seq");
		jdbc.update("INSERT INTO tb_manager (manager_id, employee_code, employee_name) VALUES (?, ?, ?)",
				managerId, code("M", managerId), "테스트담당");

		partnerId = next("tb_business_partner_seq");
		jdbc.update("INSERT INTO tb_business_partner (business_partner_id, partner_code, partner_name) VALUES (?, ?, ?)",
				partnerId, code("P", partnerId), "테스트거래처");

		warehouseId = next("tb_warehouse_seq");
		jdbc.update("INSERT INTO tb_warehouse (warehouse_id, warehouse_code, warehouse_name) VALUES (?, ?, ?)",
				warehouseId, code("W", warehouseId), "테스트창고");

		itemId = next("tb_item_seq");
		jdbc.update("INSERT INTO tb_item (item_id, item_code, item_name, item_type) VALUES (?, ?, ?, ?)",
				itemId, code("I", itemId), "테스트품목", "GOODS");
		// 정상 저장은 출하창고 수량이 0이면 거절하므로, 테스트 품목에는 재고를 넣어 둔다.
		// 正常保存は出荷倉庫数量が0なら拒否するので、テスト品目には在庫を入れておく。
		jdbc.update("INSERT INTO tb_inventory (warehouse_id, item_id, quantity) VALUES (?, ?, ?)",
				warehouseId, itemId, new BigDecimal("100"));
	}

	/** 수량 2, 단가 1000인 판매입력1 전표. 저장 전이라 판매번호는 없다.
	 *  数量2、単価1000の販売入力1伝票。保存前なので販売番号はない。 */
	public SaleInputOneDTO newSale() {
		SaleCurrDTO header = new SaleCurrDTO();
		header.setBusinessPartnerId(partnerId);
		header.setWarehousePk(warehouseId);
		header.setManagerId(managerId);
		header.setSaleDt(new Date());

		SaleCurrItemDTO line = new SaleCurrItemDTO();
		line.setItemPk(itemId);
		line.setItemNm("테스트품목");
		line.setSaleQty(new BigDecimal("2"));
		line.setUnitPrice(new BigDecimal("1000"));
		line.setSupplyAmt(new BigDecimal("2000"));
		line.setVatAmt(new BigDecimal("200"));
		line.setLineAmt(new BigDecimal("2200"));

		SaleInputOneDTO sale = new SaleInputOneDTO();
		sale.setHeader(header);
		sale.setItems(new ArrayList<SaleCurrItemDTO>());
		sale.getItems().add(line);
		return sale;
	}

	public Long getPartnerId() {
		return partnerId;
	}

	public Long getWarehouseId() {
		return warehouseId;
	}

	public Long getManagerId() {
		return managerId;
	}

	public Long getItemId() {
		return itemId;
	}

	/** 시퀀스 다음 값. テスト用シーケンスの次の値。 */
	private Long next(String sequence) {
		return jdbc.queryForObject("SELECT " + sequence + ".NEXTVAL FROM dual", Long.class);
	}

	/** 코드는 20자를 넘기지 않는다. 코드は20字を超えない。 */
	private String code(String prefix, Long id) {
		String value = prefix + id;
		return value.length() > 20 ? value.substring(value.length() - 20) : value;
	}
}
