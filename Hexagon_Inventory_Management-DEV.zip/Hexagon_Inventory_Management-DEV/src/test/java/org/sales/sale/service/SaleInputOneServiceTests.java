package org.sales.sale.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;

import java.math.BigDecimal;
import java.util.Collections;

import javax.sql.DataSource;

import org.junit.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import org.junit.runner.RunWith;
import org.sales.sale.service.CommonLookupService;
import org.sales.sale.SaleInputOneFixture;
import org.sales.sale.dto.SaleCurrDTO;
import org.sales.sale.dto.SaleInputOneDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

/**
 * 판매입력1 저장. 거래처가 없으면 거절하고, 정상만 재고를 빼며, 화면에서 고친 품목은 판매 스냅에만 남는다.
 * 販売入力1の保存。取引先がなければ拒み、正常だけ在庫を引き、画面で直した品目は販売スナップだけに残る。
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class SaleInputOneServiceTests {

	@Setter(onMethod_ = @Autowired)
	private SaleInputOneService service;

	@Setter(onMethod_ = @Autowired)
	private CommonLookupService commonLookup;

	@Setter(onMethod_ = @Autowired)
	private DataSource dataSource;

	/** 판매입력1 서비스가 스프링에 올라와 있는지 확인한다. 販売入力1サービスがスプリングに載っているか確かめる。 */
	@Test
	public void testExist() {
		log.info(service);
		assertNotNull(service);
	}

	/** 통화 목록과 보류 목록을 읽어 조회가 예외 없이 끝나는지 본다.
	 *  通貨一覧と保留一覧を読み、照会が例外なく終わるか見る。 */
	@Test
	public void testGetList() {
		commonLookup.getCurrencies().forEach(currency -> log.info(currency));
		service.getHolds().forEach(hold -> log.info(hold));
	}

	/** 거래처 키가 없으면 전표를 만들지 않는다. 取引先キーがなければ伝票を作らない。 */
	@Test
	public void testRegisterRequiresPartner() {
		SaleInputOneDTO sale = new SaleInputOneDTO();
		sale.setHeader(new SaleCurrDTO());

		try {
			service.register(sale);
			fail("거래처가 없으면 등록되면 안 된다.");
		} catch (IllegalArgumentException e) {
			log.info(e.getMessage());
			assertEquals("取引先を選択してください。", e.getMessage());
		}
	}

	/** 신규 저장은 정상, 미확인이고 공급가액 2000, 부가세 200을 헤더에 남긴다.
	 *  新規保存は正常、未確認であり、供給価額2000、付加税200をヘッダに残す。 */
	@Test
	@Transactional
	public void testRegister() {
		SaleInputOneDTO sale = prepared().newSale();

		service.register(sale);

		log.info("생성된 판매전표 번호: " + sale.getHeader().getSaleId());
		assertNotNull(sale.getHeader().getSaleId());
		assertEquals("正常", sale.getHeader().getVoucherStatus());
		assertEquals("未確認", sale.getHeader().getProgressStatus());
		assertEquals(new BigDecimal("2000"), sale.getHeader().getCurrAmt());
		assertEquals(new BigDecimal("200"), sale.getHeader().getVatAmt());
	}

	/** 저장한 전표를 다시 읽으면 품목 한 줄과 수량 2가 그대로다.
	 *  保存した伝票を読み直すと品目1行と数量2がそのままである。 */
	@Test
	@Transactional
	public void testGet() {
		SaleInputOneDTO sale = prepared().newSale();
		service.register(sale);

		SaleInputOneDTO loaded = service.get(sale.getHeader().getSaleId());
		log.info(loaded);
		assertNotNull(loaded.getHeader());
		assertEquals(1, loaded.getItems().size());
		assertEquals(0, new BigDecimal("2").compareTo(loaded.getItems().get(0).getSaleQty()));
	}

	/** 수량을 3으로 고치면 헤더 공급가액이 3000이 되고 적요가 남는다.
	 *  数量を3に直すとヘッダ供給価額が3000になり、摘要が残る。 */
	@Test
	@Transactional
	public void testModify() {
		SaleInputOneFixture fixture = prepared();
		SaleInputOneDTO sale = fixture.newSale();
		service.register(sale);

		sale.getItems().get(0).setSaleQty(new BigDecimal("3"));
		sale.getItems().get(0).setSupplyAmt(new BigDecimal("3000"));
		sale.getItems().get(0).setVatAmt(new BigDecimal("300"));
		sale.getItems().get(0).setLineAmt(new BigDecimal("3300"));
		sale.getHeader().setRemark("수량수정");

		service.modify(sale);

		SaleInputOneDTO loaded = service.get(sale.getHeader().getSaleId());
		log.info(loaded);
		assertEquals("수량수정", loaded.getHeader().getRemark());
		assertEquals(0, new BigDecimal("3000").compareTo(loaded.getHeader().getCurrAmt()));
		assertEquals(1, loaded.getItems().size());
	}

	/** 보류는 재고 10을 유지하고, 정상 저장과 수량 수정만 출하창고 재고를 바꾼다. 다시 보류로 바꾸면 뺀 수량을 되돌린다.
	 *  保留は在庫10を維持し、正常保存と数量修正だけ出荷倉庫の在庫を変える。再び保留に変えると引いた数量を戻す。 */
	@Test
	@Transactional
	public void testSaveDeductsInventoryAndHoldDoesNot() {
		SaleInputOneFixture fixture = prepared();
		JdbcTemplate jdbc = new JdbcTemplate(dataSource);
		jdbc.update("UPDATE tb_inventory SET quantity = ? WHERE warehouse_id = ? AND item_id = ?",
				new BigDecimal("10"), fixture.getWarehouseId(), fixture.getItemId());

		SaleInputOneDTO hold = fixture.newSale();
		hold.getHeader().setVoucherStatus("保留");
		service.register(hold);
		assertEquals(0, new BigDecimal("10").compareTo(stock(fixture)));

		hold.getHeader().setVoucherStatus("正常");
		service.modify(hold);
		assertEquals(0, new BigDecimal("8").compareTo(stock(fixture)));

		SaleInputOneDTO sale = fixture.newSale();
		service.register(sale);
		assertEquals(0, new BigDecimal("6").compareTo(stock(fixture)));

		sale.getItems().get(0).setSaleQty(new BigDecimal("3"));
		service.modify(sale);
		assertEquals(0, new BigDecimal("5").compareTo(stock(fixture)));

		sale.getHeader().setVoucherStatus("保留");
		service.modify(sale);
		assertEquals(0, new BigDecimal("8").compareTo(stock(fixture)));
	}

	private BigDecimal stock(SaleInputOneFixture fixture) {
		return service.getItemStock(fixture.getItemId(), fixture.getWarehouseId()).getWhQty();
	}

	/** 출하창고 수량이 0이면 정상 저장은 거절하고, 보류는 저장한다.
	 *  出荷倉庫数量が0なら正常保存は拒否し、保留は保存する。 */
	@Test
	@Transactional
	public void testRegisterRejectsZeroWarehouseStock() {
		SaleInputOneFixture fixture = prepared();
		JdbcTemplate jdbc = new JdbcTemplate(dataSource);
		jdbc.update("UPDATE tb_inventory SET quantity = 0 WHERE warehouse_id = ? AND item_id = ?",
				fixture.getWarehouseId(), fixture.getItemId());

		try {
			service.register(fixture.newSale());
			fail("출하창고 수량이 0이면 저장되면 안 된다.");
		} catch (IllegalArgumentException e) {
			assertEquals("테스트품목の出荷倉庫数量が0のため保存できません。", e.getMessage());
		}

		SaleInputOneDTO hold = fixture.newSale();
		hold.getHeader().setVoucherStatus("保留");
		service.register(hold);
		assertNotNull(hold.getHeader().getSaleId());
	}

	/** 보류전표를 지우면 다시 읽었을 때 헤더가 없다. 保留伝票を消すと読み直したときヘッダがない。 */
	@Test
	@Transactional
	public void testDelete() {
		SaleInputOneDTO sale = prepared().newSale();
		sale.getHeader().setVoucherStatus("保留");
		service.register(sale);
		Long saleId = sale.getHeader().getSaleId();
		log.info("삭제할 보류전표 번호: " + saleId);

		service.deleteHolds(Collections.singletonList(saleId));

		assertNull(service.get(saleId).getHeader());
	}

	/** 화면에서 고친 품목코드, 품목명, 규격은 판매 줄에만 남고 품목 마스터는 그대로다.
	 *  画面で直した品目コード、品目名、規格は販売行だけに残り、品目マスタはそのままである。 */
	@Test
	@Transactional
	public void testRegisterStoresSaleSnapWithoutChangingItem() {
		SaleInputOneFixture fixture = prepared();
		JdbcTemplate jdbc = new JdbcTemplate(dataSource);
		String masterCode = jdbc.queryForObject("SELECT item_code FROM tb_item WHERE item_id = ?", String.class,
				fixture.getItemId());
		String masterName = jdbc.queryForObject("SELECT item_name FROM tb_item WHERE item_id = ?", String.class,
				fixture.getItemId());

		SaleInputOneDTO sale = fixture.newSale();
		sale.getItems().get(0).setItemCode("화면코드");
		sale.getItems().get(0).setItemNm("화면품목명");
		sale.getItems().get(0).setSpec("화면규격");
		service.register(sale);

		SaleInputOneDTO loaded = service.get(sale.getHeader().getSaleId());
		assertEquals("화면코드", loaded.getItems().get(0).getItemCode());
		assertEquals("화면품목명", loaded.getItems().get(0).getItemNm());
		assertEquals("화면규격", loaded.getItems().get(0).getSpec());
		assertEquals(masterCode, jdbc.queryForObject("SELECT item_code FROM tb_item WHERE item_id = ?", String.class,
				fixture.getItemId()));
		assertEquals(masterName, jdbc.queryForObject("SELECT item_name FROM tb_item WHERE item_id = ?", String.class,
				fixture.getItemId()));
	}

	private SaleInputOneFixture prepared() {
		SaleInputOneFixture fixture = new SaleInputOneFixture(dataSource);
		fixture.prepare();
		return fixture;
	}
}
