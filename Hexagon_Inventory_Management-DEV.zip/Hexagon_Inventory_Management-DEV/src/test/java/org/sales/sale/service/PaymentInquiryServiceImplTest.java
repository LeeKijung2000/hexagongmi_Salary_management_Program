package org.sales.sale.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;

import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.sales.sale.dao.PaymentInquiryDao;
import org.sales.sale.dto.PaymentInquiryDetailDTO;
import org.sales.sale.dto.PaymentInquiryResultDTO;
import org.sales.sale.dto.PaymentInquiryRowDTO;
import org.sales.sale.dto.PaymentInquirySaveDTO;
import org.sales.sale.dto.PaymentInquirySearchDTO;

/**
 * 신규는 화면이 나눈 금액과 사업자 기본값을 TB_PAYMENT 한 건으로 저장한다.
 * 재결제는 승인실패·취소만 요청중으로 다시 넣고, 목록의 요청자 값은 사업자 코드다.
 * 新規は画面が分けた金額と事業者の既定値を TB_PAYMENT 1件で保存する。
 * 再決済は承認失敗・取消だけ依頼中で入れ直し、一覧の依頼者値は事業者コードである。
 */
public class PaymentInquiryServiceImplTest {

	private Map<Long, PaymentInquiryDetailDTO> details;
	private List<PaymentInquiryRowDTO> listRows;
	private PaymentInquirySaveDTO inserted;
	private PaymentInquirySearchDTO searched;
	private int sales;
	private int partners;
	private int managers;
	private int warehouses;
	private int listCalls;
	private int listCount;
	private long nextId;
	private PaymentInquiryServiceImpl service;

	@Before
	public void setUp() {
		details = new HashMap<Long, PaymentInquiryDetailDTO>();
		listRows = new ArrayList<PaymentInquiryRowDTO>();
		inserted = null;
		searched = null;
		sales = 1;
		partners = 1;
		managers = 1;
		warehouses = 1;
		listCalls = 0;
		listCount = 0;
		nextId = 99L;
		PaymentInquiryDao dao = (PaymentInquiryDao) Proxy.newProxyInstance(PaymentInquiryDao.class.getClassLoader(),
				new Class[] { PaymentInquiryDao.class }, (proxy, method, args) -> invoke(method, args));
		service = new PaymentInquiryServiceImpl(dao);
	}

	/** 빈 검색어는 조건에서 빼서 전체를 조회한다.
	 *  空の検索語は条件から外し、全体を照会する。 */
	@Test
	public void blankKeywordDoesNotFilter() {
		PaymentInquirySearchDTO search = new PaymentInquirySearchDTO();
		search.setKeyword("  ");
		PaymentInquiryResultDTO result = service.search(search);

		assertNull(searched.getLikeKeyword());
		assertEquals(PaymentInquiryService.MAX_ROWS, searched.getMaxRows());
		assertEquals(0, result.getTotalCount());
		assertEquals(1, listCalls);
	}

	/** 검색어의 %와 _는 부분일치 기호로 쓰이지 않게 이스케이프한다.
	 *  検索語の % と _ は部分一致の記号に使われないようエスケープする。 */
	@Test
	public void keywordEscapesLikeWildcards() {
		PaymentInquirySearchDTO search = new PaymentInquirySearchDTO();
		search.setKeyword("a%b_c");
		service.search(search);
		assertEquals("%A/%B/_C%", searched.getLikeKeyword());
	}

	/** 검색어가 100자를 넘으면 목록 조회 전에 막는다.
	 *  検索語が100字を超えると一覧照会の前に止める。 */
	@Test
	public void longKeywordIsRejected() {
		PaymentInquirySearchDTO search = new PaymentInquirySearchDTO();
		search.setKeyword(repeat('a', 101));
		try {
			service.search(search);
			fail();
		} catch (IllegalArgumentException e) {
			assertEquals("検索語は100文字までです。", e.getMessage());
		}
		assertEquals(0, listCalls);
	}

	/** 1,000건을 넘으면 잘렸다고 표시하고, 요청자 칸에 쓸 값은 사업자 코드다.
	 *  1,000件を超えると切れたと表示し、依頼者欄に使う値は事業者コードである。 */
	@Test
	public void searchTruncatesAndKeepsCompanyCodeForRequester() {
		listCount = 1001;
		PaymentInquiryRowDTO row = new PaymentInquiryRowDTO();
		row.setPaymentId(1L);
		row.setCompanyCode("ヘキサゴン");
		row.setRequesterName("別の担当");
		listRows.add(row);

		PaymentInquiryResultDTO result = service.search(new PaymentInquirySearchDTO());

		assertEquals(1001, result.getTotalCount());
		assertEquals(true, result.isTruncated());
		assertEquals(1, result.getRows().size());
		assertEquals("ヘキサゴン", result.getRows().get(0).getCompanyCode());
	}

	/** 비어 있는 공급가액과 부가세는 0으로 저장하고, 사업자와 VAN이 비면 ヘキサゴン과 KICC를 넣는다.
	 *  空の供給価額と付加税は 0 で保存し、事業者と VAN が空ならヘキサゴンと KICC を入れる。 */
	@Test
	public void createStoresScreenAmountsAndDefaults() {
		PaymentInquirySaveDTO save = base();
		save.setPaymentAmount(new BigDecimal("1100.239"));
		save.setSupplyAmount(null);
		save.setVatAmount(null);
		save.setVatRate(null);
		save.setCompanyCode(" ");
		save.setVanCode(null);
		save.setReceiptPrintYn(null);
		save.setRequestedAtText("2026-09-21T10:30");

		service.create(save);

		assertEquals(new BigDecimal("1100.24"), inserted.getPaymentAmount());
		assertEquals(new BigDecimal("0.00"), inserted.getSupplyAmount());
		assertEquals(new BigDecimal("0.00"), inserted.getVatAmount());
		assertEquals(new BigDecimal("10.00"), inserted.getVatRate());
		assertEquals("ヘキサゴン", inserted.getCompanyCode());
		assertEquals("KICC", inserted.getVanCode());
		assertEquals("N", inserted.getReceiptPrintYn());
		assertEquals("N", inserted.getForcedYn());
		assertEquals("CARD", inserted.getPaymentMethod());
		assertEquals("REQUESTED", inserted.getPaymentStatus());
		assertNull(inserted.getApprovalNumber());
		assertNull(inserted.getSaleId());
		assertEquals(Long.valueOf(99L), inserted.getPaymentId());
	}

	/** 화면이 결제금액에서 나눈 공급가액과 부가세는 다시 계산하지 않고 그대로 저장한다.
	 *  画面が決済金額から分けた供給価額と付加税は計算し直さず、そのまま保存する。 */
	@Test
	public void createKeepsSplitAmountsFromScreen() {
		PaymentInquirySaveDTO save = base();
		save.setPaymentAmount(new BigDecimal("11000"));
		save.setSupplyAmount(new BigDecimal("10000"));
		save.setVatAmount(new BigDecimal("1000"));
		save.setVatRate(new BigDecimal("10"));
		save.setCompanyCode("ヘキサゴン");

		service.create(save);

		assertEquals(new BigDecimal("11000.00"), inserted.getPaymentAmount());
		assertEquals(new BigDecimal("10000.00"), inserted.getSupplyAmount());
		assertEquals(new BigDecimal("1000.00"), inserted.getVatAmount());
		assertEquals(new BigDecimal("10.00"), inserted.getVatRate());
		assertEquals("ヘキサゴン", inserted.getCompanyCode());
		assertNull(inserted.getRequesterId());
	}

	/** 화면이 넣은 사업자, VAN, 영수증출력, 강제 여부는 기본값으로 덮지 않는다.
	 *  画面が入れた事業者、VAN、領収書出力、強制有無は既定値で覆さない。 */
	@Test
	public void createKeepsEnteredCompanyAndForcedFlag() {
		PaymentInquirySaveDTO save = base();
		save.setCompanyCode("ACME");
		save.setVanCode("VAN1");
		save.setPaymentStatus("FORCED");
		save.setReceiptPrintYn("y");
		save.setApprovalNumber(" 12345 ");

		service.create(save);

		assertEquals("ACME", inserted.getCompanyCode());
		assertEquals("VAN1", inserted.getVanCode());
		assertEquals("Y", inserted.getForcedYn());
		assertEquals("Y", inserted.getReceiptPrintYn());
		assertEquals("12345", inserted.getApprovalNumber());
	}

	/** 신용은 할부개월만, 현금은 영수증구분만, 간편결제는 식별번호만 남긴다.
	 *  信用は分割月数だけ、現金は領収書区分だけ、簡単決済は識別番号だけ残す。 */
	@Test
	public void createStoresMethodDetailForCardCashAndEasyPay() {
		PaymentInquirySaveDTO card = base();
		card.setInstallmentMonths(6);
		card.setReceiptType("INCOME");
		card.setEasyPaymentNo("keep-out");
		service.create(card);
		assertEquals(Integer.valueOf(6), inserted.getInstallmentMonths());
		assertNull(inserted.getReceiptType());
		assertNull(inserted.getEasyPaymentNo());

		PaymentInquirySaveDTO cash = base();
		cash.setPaymentMethod("CASH");
		cash.setReceiptType("expense");
		cash.setInstallmentMonths(3);
		service.create(cash);
		assertEquals("EXPENSE", inserted.getReceiptType());
		assertNull(inserted.getInstallmentMonths());
		assertNull(inserted.getEasyPaymentNo());

		PaymentInquirySaveDTO easy = base();
		easy.setPaymentMethod("EASY_PAY");
		easy.setEasyPaymentNo("  PAY-9  ");
		service.create(easy);
		assertEquals("PAY-9", inserted.getEasyPaymentNo());
		assertNull(inserted.getInstallmentMonths());
		assertNull(inserted.getReceiptType());

		PaymentInquirySaveDTO months = base();
		months.setInstallmentMonths(0);
		expect("分割月数は1以上99以下です。", () -> service.create(months));

		PaymentInquirySaveDTO receipt = base();
		receipt.setPaymentMethod("CASH");
		receipt.setReceiptType("TAX");
		expect("領収書区分が正しくありません。", () -> service.create(receipt));
	}

	/** 현금인데 영수증구분이 비면 소비자 소득공제를 넣고, 식별번호가 100자를 넘으면 막는다.
	 *  現金で領収書区分が空なら消費者所得控除を入れ、識別番号が100字を超えると止める。 */
	@Test
	public void createDefaultsCashReceiptAndLimitsEasyPaymentNo() {
		PaymentInquirySaveDTO cash = base();
		cash.setPaymentMethod("CASH");
		service.create(cash);
		assertEquals("INCOME", inserted.getReceiptType());
		assertNull(inserted.getInstallmentMonths());

		PaymentInquirySaveDTO easy = base();
		easy.setPaymentMethod("EASY_PAY");
		easy.setEasyPaymentNo(repeat('A', 101));
		expect("簡単決済識別番号は100文字までです。", () -> service.create(easy));
	}

	/** 결제방법, 결제금액, 부가세율이 허용 범위를 벗어나면 저장하지 않는다.
	 *  決済方法、決済金額、付加税率が許容範囲を外れると保存しない。 */
	@Test
	public void createRejectsUnknownMethodAmountAndRate() {
		PaymentInquirySaveDTO method = base();
		method.setPaymentMethod("POINT");
		expect("決済方法が正しくありません。", () -> service.create(method));

		PaymentInquirySaveDTO amount = base();
		amount.setPaymentAmount(new BigDecimal("-1"));
		expect("決済金額は0以上です。", () -> service.create(amount));

		PaymentInquirySaveDTO rate = base();
		rate.setVatRate(new BigDecimal("100.01"));
		expect("付加税率は0以上100以下です。", () -> service.create(rate));
	}

	/** 없는 거래처는 저장하지 않는다.
	 *  ない取引先は保存しない。 */
	@Test
	public void createRejectsUnknownPartner() {
		partners = 0;
		expect("取引先がありません。", () -> service.create(base()));
		assertNull(inserted);
	}

	/** 결제일시 형식이 다르면 저장하지 않는다.
	 *  決済日時の形式が違えば保存しない。 */
	@Test
	public void createRejectsBadDate() {
		PaymentInquirySaveDTO save = base();
		save.setRequestedAtText("2026/13/01 10:00:00");
		expect("決済日時が正しくありません。", () -> service.create(save));
	}

	/** 없는 결제 내역은 상세와 재결제 모두 막는다.
	 *  ない決済内訳は詳細と再決済の両方で止める。 */
	@Test
	public void missingPaymentIsRejected() {
		expect("該当する決済がありません。", () -> service.detail(null));
		expect("該当する決済がありません。", () -> service.detail(3L));
		expect("該当する決済がありません。", () -> service.repay(3L));
		assertNull(inserted);
	}

	/** 승인실패 결제는 그대로 두고, 같은 금액의 요청중 결제를 새로 넣는다. 판매 전표는 잇지 않는다.
	 *  承認失敗の決済はそのまま置き、同じ金額の依頼中決済を新しく入れる。販売伝票は繋がない。 */
	@Test
	public void repayCopiesFailedPaymentAsNewRequest() {
		PaymentInquiryDetailDTO source = new PaymentInquiryDetailDTO();
		source.setPaymentId(5L);
		source.setPaymentStatus("FAILED");
		source.setSaleId(3L);
		source.setBusinessPartnerId(4L);
		source.setRequesterId(8L);
		source.setWarehouseId(2L);
		source.setPaymentMethod("CARD");
		source.setPaymentAmount(new BigDecimal("1100"));
		source.setSupplyAmount(new BigDecimal("1000"));
		source.setVatAmount(new BigDecimal("100"));
		source.setVatRate(new BigDecimal("10"));
		source.setReceiptPrintYn("Y");
		source.setCompanyCode("ACME");
		source.setVanCode("VAN1");
		source.setApprovalNumber("OLD");
		source.setInstallmentMonths(3);
		details.put(5L, source);

		PaymentInquiryDetailDTO created = service.repay(5L);

		assertEquals("REQUESTED", inserted.getPaymentStatus());
		assertNull(inserted.getSaleId());
		assertEquals(Long.valueOf(4L), inserted.getBusinessPartnerId());
		assertEquals(Long.valueOf(8L), inserted.getRequesterId());
		assertEquals(Integer.valueOf(3), inserted.getInstallmentMonths());
		assertEquals(new BigDecimal("1100.00"), inserted.getPaymentAmount());
		assertEquals("ACME", inserted.getCompanyCode());
		assertEquals("Y", inserted.getReceiptPrintYn());
		assertEquals("N", inserted.getForcedYn());
		assertNull(inserted.getApprovalNumber());
		assertEquals(Long.valueOf(99L), created.getPaymentId());
		assertEquals("FAILED", details.get(5L).getPaymentStatus());
	}

	/** 승인된 결제는 재결제하지 않는다.
	 *  承認された決済は再決済しない。 */
	@Test
	public void repayRejectsApprovedPayment() {
		PaymentInquiryDetailDTO source = new PaymentInquiryDetailDTO();
		source.setPaymentId(7L);
		source.setPaymentStatus("APPROVED");
		details.put(7L, source);
		expect("再決済できるのは承認失敗と取消だけです。", () -> service.repay(7L));
		assertNull(inserted);
	}

	private PaymentInquirySaveDTO base() {
		PaymentInquirySaveDTO save = new PaymentInquirySaveDTO();
		save.setBusinessPartnerId(4L);
		save.setPaymentMethod("card");
		save.setPaymentStatus("requested");
		save.setPaymentAmount(new BigDecimal("1000"));
		return save;
	}

	private void expect(String message, Thunk thunk) {
		try {
			thunk.run();
			fail(message);
		} catch (IllegalArgumentException e) {
			assertEquals(message, e.getMessage());
		}
	}

	private String repeat(char ch, int count) {
		StringBuilder builder = new StringBuilder();
		for (int i = 0; i < count; i++) {
			builder.append(ch);
		}
		return builder.toString();
	}

	private Object invoke(Method method, Object[] args) {
		String name = method.getName();
		if ("countList".equals(name)) {
			listCalls++;
			searched = (PaymentInquirySearchDTO) args[0];
			return listCount;
		}
		if ("selectList".equals(name) || "selectSales".equals(name)) {
			return listRows;
		}
		if ("selectDetail".equals(name)) {
			return details.get(args[0]);
		}
		if ("countSale".equals(name)) {
			return sales;
		}
		if ("countPartner".equals(name)) {
			return partners;
		}
		if ("countManager".equals(name)) {
			return managers;
		}
		if ("countWarehouse".equals(name)) {
			return warehouses;
		}
		if ("insertPayment".equals(name)) {
			PaymentInquirySaveDTO save = (PaymentInquirySaveDTO) args[0];
			save.setPaymentId(nextId++);
			inserted = save;
			PaymentInquiryDetailDTO detail = new PaymentInquiryDetailDTO();
			detail.setPaymentId(save.getPaymentId());
			detail.setPaymentStatus(save.getPaymentStatus());
			details.put(save.getPaymentId(), detail);
			return 1;
		}
		if ("toString".equals(name)) {
			return "PaymentInquiryDao";
		}
		throw new UnsupportedOperationException(name);
	}

	private interface Thunk {
		void run();
	}
}
