package org.sales.sale.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.math.BigDecimal;
import java.util.ArrayList;

import javax.sql.DataSource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.sales.sale.SaleInputOneFixture;
import org.sales.sale.dto.SaleAdjustmentDTO;
import org.sales.sale.dto.SaleHeaderDTO;
import org.sales.sale.dto.SaleInputTwoDTO;
import org.sales.sale.dto.SaleLineDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

/**
 * 판매입력2 저장. 판매입력구분은 POS이고, 금액조정과 할인을 헤더 합계에 반영한다. 정상만 재고를 뺀다.
 * 販売入力2の保存。販売入力区分はPOSであり、金額調整と割引をヘッダ合計に反映する。正常だけ在庫を引く。
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class SaleInputTwoServiceTests {

	@Setter(onMethod_ = @Autowired)
	private SaleInputTwoService service;

	@Setter(onMethod_ = @Autowired)
	private DataSource dataSource;

	/** 거래처 키가 없으면 전표를 만들지 않는다. 取引先キーがなければ伝票を作らない。 */
	@Test
	public void testRegisterRequiresPartner() {
		SaleInputTwoDTO sale = new SaleInputTwoDTO();
		sale.setHeader(new SaleHeaderDTO());
		try {
			service.register(sale);
			fail("거래처가 없으면 등록되면 안 된다.");
		} catch (IllegalArgumentException e) {
			assertEquals("取引先を選択してください。", e.getMessage());
		}
	}

	/** POS로 저장하고 증가 100, 감소 50의 조정 합계 55를 헤더에 더한다. 이름이 없는 조정 줄은 빼 둔다.
	 *  POSで保存し、増加100、減少50の調整合計55をヘッダに足す。名前のない調整行は除いておく。 */
	@Test
	@Transactional
	public void testRegisterStoresPosAndAdjustment() {
		SaleInputOneFixture fixture = prepared();
		SaleInputTwoDTO sale = newSale(fixture);
		sale.getItems().get(0).setRemark("적요");

		SaleAdjustmentDTO increase = new SaleAdjustmentDTO();
		increase.setAdjustmentName("배송비");
		increase.setIncreaseDecrease("INCREASE");
		increase.setSupplyAmt(new BigDecimal("100"));
		SaleAdjustmentDTO decrease = new SaleAdjustmentDTO();
		decrease.setAdjustmentName("에누리");
		decrease.setIncreaseDecrease("DECREASE");
		decrease.setSupplyAmt(new BigDecimal("50"));
		sale.setAdjustments(new ArrayList<SaleAdjustmentDTO>());
		sale.getAdjustments().add(increase);
		sale.getAdjustments().add(decrease);
		sale.getAdjustments().add(new SaleAdjustmentDTO());

		service.register(sale);

		JdbcTemplate jdbc = new JdbcTemplate(dataSource);
		Long saleId = sale.getHeader().getSaleId();
		assertEquals("POS", jdbc.queryForObject("SELECT sale_input_type FROM tb_sale WHERE sale_id = ?", String.class, saleId));
		assertEquals(0, new BigDecimal("2000").compareTo(sale.getHeader().getCurrAmt()));
		assertEquals(0, new BigDecimal("200").compareTo(sale.getHeader().getVatAmt()));
		assertEquals(0, new BigDecimal("55").compareTo(sale.getHeader().getAdjustmentAmt()));
		assertEquals(0, new BigDecimal("2255").compareTo(sale.getHeader().getTotalAmt()));
		assertEquals(0, new BigDecimal("98").compareTo(service.getItemStock(fixture.getItemId(), fixture.getWarehouseId()).getWhQty()));

		SaleInputTwoDTO loaded = service.get(saleId);
		assertEquals("적요", loaded.getItems().get(0).getRemark());
		assertEquals(2, loaded.getAdjustments().size());
		assertEquals("INCREASE", loaded.getAdjustments().get(0).getIncreaseDecrease());
		assertEquals("DECREASE", loaded.getAdjustments().get(1).getIncreaseDecrease());
	}

	/** 보류는 재고를 유지하고 정상 저장과 수량 수정만 뺀다. 보류 삭제는 재고를 되돌리지 않는다.
	 *  保留は在庫を維持し、正常保存と数量修正だけ引く。保留削除は在庫を戻さない。 */
	@Test
	@Transactional
	public void testSaveDeductsInventoryAndHoldDoesNot() {
		SaleInputOneFixture fixture = prepared();
		JdbcTemplate jdbc = new JdbcTemplate(dataSource);
		jdbc.update("UPDATE tb_inventory SET quantity = ? WHERE warehouse_id = ? AND item_id = ?",
				new BigDecimal("10"), fixture.getWarehouseId(), fixture.getItemId());

		SaleInputTwoDTO hold = newSale(fixture);
		hold.getHeader().setVoucherStatus("保留");
		service.register(hold);
		assertEquals(0, new BigDecimal("10").compareTo(stock(fixture)));

		hold.getHeader().setVoucherStatus("正常");
		service.modify(hold);
		assertEquals(0, new BigDecimal("8").compareTo(stock(fixture)));

		SaleInputTwoDTO sale = newSale(fixture);
		service.register(sale);
		assertEquals(0, new BigDecimal("6").compareTo(stock(fixture)));

		sale.getItems().get(0).setSaleQty(new BigDecimal("3"));
		service.modify(sale);
		assertEquals(0, new BigDecimal("5").compareTo(stock(fixture)));

		sale.getHeader().setVoucherStatus("保留");
		service.modify(sale);
		assertEquals(0, new BigDecimal("8").compareTo(stock(fixture)));

		service.deleteHolds(java.util.Collections.singletonList(sale.getHeader().getSaleId()));
		assertEquals(0, new BigDecimal("8").compareTo(stock(fixture)));
	}

	/** 공급가액은 수량×단가에서 할인 200을 뺀 1800이고, 부가세는 그 10%다.
	 *  供給価額は数量×単価から割引200を引いた1800であり、付加税はその10%である。 */
	@Test
	@Transactional
	public void testRegisterSubtractsDiscount() {
		SaleInputOneFixture fixture = prepared();
		SaleInputTwoDTO sale = newSale(fixture);
		sale.getItems().get(0).setDiscountAmt(new BigDecimal("200"));
		service.register(sale);

		SaleInputTwoDTO loaded = service.get(sale.getHeader().getSaleId());
		assertEquals(0, new BigDecimal("1800").compareTo(loaded.getItems().get(0).getSupplyAmt()));
		assertEquals(0, new BigDecimal("180").compareTo(loaded.getItems().get(0).getVatAmt()));
		assertEquals(0, new BigDecimal("1980").compareTo(loaded.getItems().get(0).getLineAmt()));
		assertEquals(0, new BigDecimal("200").compareTo(loaded.getItems().get(0).getDiscountAmt()));
		assertEquals(0, new BigDecimal("1800").compareTo(loaded.getHeader().getCurrAmt()));
	}

	/** 보류는 재고를 빼지 않는다. 정상으로 고치면 금액조정은 새 줄 하나로 바뀌고 재고를 뺀다.
	 *  保留は在庫を引かない。正常に直すと金額調整は新しい1行に変わり、在庫を引く。 */
	@Test
	@Transactional
	public void testHoldDoesNotDeductAndModifyReplacesAdjustment() {
		SaleInputOneFixture fixture = prepared();
		SaleInputTwoDTO sale = newSale(fixture);
		sale.getHeader().setVoucherStatus("保留");
		SaleAdjustmentDTO adjustment = new SaleAdjustmentDTO();
		adjustment.setAdjustmentName("첫조정");
		adjustment.setIncreaseDecrease("INCREASE");
		adjustment.setSupplyAmt(new BigDecimal("10"));
		sale.setAdjustments(new ArrayList<SaleAdjustmentDTO>());
		sale.getAdjustments().add(adjustment);
		service.register(sale);
		assertEquals(0, new BigDecimal("100").compareTo(service.getItemStock(fixture.getItemId(), fixture.getWarehouseId()).getWhQty()));

		sale.getHeader().setVoucherStatus("正常");
		sale.getAdjustments().get(0).setAdjustmentName("수정조정");
		sale.getAdjustments().get(0).setSupplyAmt(new BigDecimal("20"));
		service.modify(sale);

		SaleInputTwoDTO loaded = service.get(sale.getHeader().getSaleId());
		assertEquals("正常", loaded.getHeader().getVoucherStatus());
		assertEquals(1, loaded.getAdjustments().size());
		assertEquals("수정조정", loaded.getAdjustments().get(0).getAdjustmentName());
		assertEquals(0, new BigDecimal("98").compareTo(service.getItemStock(fixture.getItemId(), fixture.getWarehouseId()).getWhQty()));
	}

	/** 화면에서 고친 품목코드, 품목명, 규격은 판매 줄에만 남고 품목 마스터는 그대로다.
	 *  画面で直した品目コード、品目名、規格は販売行だけに残り、品目マスタはそのままである。 */
	@Test
	@Transactional
	public void testEditedSnapDoesNotChangeItemMaster() {
		SaleInputOneFixture fixture = prepared();
		JdbcTemplate jdbc = new JdbcTemplate(dataSource);
		String masterCode = jdbc.queryForObject("SELECT item_code FROM tb_item WHERE item_id = ?", String.class, fixture.getItemId());
		String masterName = jdbc.queryForObject("SELECT item_name FROM tb_item WHERE item_id = ?", String.class, fixture.getItemId());

		SaleInputTwoDTO sale = newSale(fixture);
		sale.getItems().get(0).setItemCode("화면코드");
		sale.getItems().get(0).setItemNm("화면품목명");
		sale.getItems().get(0).setSpec("화면규격");
		service.register(sale);

		SaleInputTwoDTO loaded = service.get(sale.getHeader().getSaleId());
		assertEquals("화면코드", loaded.getItems().get(0).getItemCode());
		assertEquals("화면품목명", loaded.getItems().get(0).getItemNm());
		assertEquals("화면규격", loaded.getItems().get(0).getSpec());
		assertEquals(masterCode, jdbc.queryForObject("SELECT item_code FROM tb_item WHERE item_id = ?", String.class, fixture.getItemId()));
		assertEquals(masterName, jdbc.queryForObject("SELECT item_name FROM tb_item WHERE item_id = ?", String.class, fixture.getItemId()));
	}

	/** 출하창고 수량이 0이면 정상 저장은 거절하고, 보류는 저장한다. 재고는 0으로 남는다.
	 *  出荷倉庫数量が0なら正常保存は拒否し、保留は保存する。在庫は0のまま残る。 */
	@Test
	@Transactional
	public void testRegisterRejectsZeroWarehouseStock() {
		SaleInputOneFixture fixture = prepared();
		new JdbcTemplate(dataSource).update("UPDATE tb_inventory SET quantity = 0 WHERE warehouse_id = ? AND item_id = ?",
				fixture.getWarehouseId(), fixture.getItemId());
		try {
			service.register(newSale(fixture));
			fail("출하창고 수량이 0이면 저장되면 안 된다.");
		} catch (IllegalArgumentException e) {
			assertEquals("테스트품목の出荷倉庫数量が0のため保存できません。", e.getMessage());
		}

		SaleInputTwoDTO hold = newSale(fixture);
		hold.getHeader().setVoucherStatus("保留");
		service.register(hold);
		assertNotNull(hold.getHeader().getSaleId());
		assertEquals(0, BigDecimal.ZERO.compareTo(stock(fixture)));
	}

	private SaleInputTwoDTO newSale(SaleInputOneFixture fixture) {
		SaleHeaderDTO header = new SaleHeaderDTO();
		header.setBusinessPartnerId(fixture.getPartnerId());
		header.setWarehousePk(fixture.getWarehouseId());
		header.setManagerId(fixture.getManagerId());

		SaleLineDTO line = new SaleLineDTO();
		line.setItemPk(fixture.getItemId());
		line.setItemNm("테스트품목");
		line.setSaleQty(new BigDecimal("2"));
		line.setUnitPrice(new BigDecimal("1000"));

		SaleInputTwoDTO sale = new SaleInputTwoDTO();
		sale.setHeader(header);
		sale.setItems(new ArrayList<SaleLineDTO>());
		sale.getItems().add(line);
		return sale;
	}

	private BigDecimal stock(SaleInputOneFixture fixture) {
		return service.getItemStock(fixture.getItemId(), fixture.getWarehouseId()).getWhQty();
	}

	private SaleInputOneFixture prepared() {
		SaleInputOneFixture fixture = new SaleInputOneFixture(dataSource);
		fixture.prepare();
		return fixture;
	}
}
