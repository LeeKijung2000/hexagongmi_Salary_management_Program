package org.sales.sale.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Collections;
import java.util.Date;

import javax.sql.DataSource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.sales.sale.SaleInputOneFixture;
import org.sales.sale.dto.SaleCurrItemDTO;
import org.sales.sale.dto.SaleInputOneDTO;
import org.sales.sale.service.SaleInputOneService;
import org.sales.sale.dto.SaleInquiryPageDTO;
import org.sales.sale.dto.SaleInquiryRowDTO;
import org.sales.sale.dto.SaleSlipHistoryDTO;
import org.sales.sale.dto.SaleSlipHistoryLineDTO;
import org.sales.sale.dto.VoucherHistoryDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

/**
 * 판매조회. 보류는 목록에서 빼고, 확인은 재고를 다시 빼지 않으며, 선택삭제는 재고를 되돌리고 이력을 남긴다.
 * 販売照会。保留は一覧から外し、確認は在庫を再び引かず、選択削除は在庫を戻して履歴を残す。
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class SaleInquiryServiceTests {

	@Setter(onMethod_ = @Autowired)
	private SaleInquiryService inquiry;

	@Setter(onMethod_ = @Autowired)
	private SaleInputOneService saleInput;

	@Setter(onMethod_ = @Autowired)
	private DataSource dataSource;

	/** 판매조회 서비스가 스프링에 올라와 있는지 확인한다. 販売照会サービスがスプリングに載っているか確かめる。 */
	@Test
	public void testExist() {
		assertNotNull(inquiry);
	}

	/** 일자-No는 같은 날 판매번호 순이고, 품목이 둘이면 첫 품목 뒤에 外 1件을 붙인다. 합계는 저장된 공급가액이다.
	 *  日付-Noは同じ日の販売番号順であり、品目が二つなら先頭品目の後に外 1件を付ける。合計は保存された供給価額である。 */
	@Test
	@Transactional
	public void testSearchShowsDateNoAndExtraItems() {
		SaleInputOneFixture fixture = prepared();
		SaleInputOneDTO sale = fixture.newSale();
		SaleCurrItemDTO second = new SaleCurrItemDTO();
		second.setItemPk(fixture.getItemId());
		second.setItemNm("두번째품목");
		second.setSaleQty(new BigDecimal("1"));
		second.setUnitPrice(new BigDecimal("500"));
		sale.getItems().add(second);
		saleInput.register(sale);

		SaleInquiryRowDTO row = find(sale.getHeader().getSaleId());
		assertEquals(dateNo(sale.getHeader().getSaleId()), row.getDateNo());
		SaleInputOneDTO later = fixture.newSale();
		saleInput.register(later);
		int firstNo = daySlipNo(row.getDateNo());
		int secondNo = daySlipNo(find(later.getHeader().getSaleId()).getDateNo());
		assertEquals(firstNo + 1, secondNo);
		assertEquals("테스트품목 外 1件", row.getItemName());
		assertEquals("未確認", row.getProgressName());
		assertEquals(0, new BigDecimal("2500").compareTo(row.getSupplyAmount()));
	}

	/** 보류 전표는 판매조회 목록에 나오지 않는다. 保留伝票は販売照会の一覧に出ない。 */
	@Test
	@Transactional
	public void testHoldIsExcluded() {
		SaleInputOneFixture fixture = prepared();
		SaleInputOneDTO hold = fixture.newSale();
		hold.getHeader().setVoucherStatus("保留");
		saleInput.register(hold);

		assertFalse(contains(search(dateNo(hold.getHeader().getSaleId())).getRows(), hold.getHeader().getSaleId()));
	}

	/** 확인은 진행상태와 판매 수불만 남긴다. 정상 저장 때 이미 뺀 재고는 다시 빼지 않는다.
	 *  確認は進行状態と販売受払だけ残す。正常保存ですでに引いた在庫は再び引かない。 */
	@Test
	@Transactional
	public void testConfirmWritesMovementWithoutSecondDeduction() {
		SaleInputOneFixture fixture = prepared();
		SaleInputOneDTO sale = fixture.newSale();
		saleInput.register(sale);
		Long saleId = sale.getHeader().getSaleId();
		BigDecimal afterSave = stock(fixture);

		inquiry.changeProgress(Collections.singletonList(saleId), "CONFIRMED");

		assertEquals(0, afterSave.compareTo(stock(fixture)));
		assertEquals("CONFIRMED", progress(saleId));
		assertEquals("確認", find(saleId).getProgressName());
		assertEquals(Integer.valueOf(1), countMovement(saleId, "SALE"));
	}

	/** 미확인으로 되돌려도 재고는 되돌리지 않는다. 未確認へ戻しても在庫は戻さない。 */
	@Test
	@Transactional
	public void testUnconfirmDoesNotRestoreStock() {
		SaleInputOneFixture fixture = prepared();
		SaleInputOneDTO sale = fixture.newSale();
		saleInput.register(sale);
		Long saleId = sale.getHeader().getSaleId();
		inquiry.changeProgress(Collections.singletonList(saleId), "CONFIRMED");
		BigDecimal confirmed = stock(fixture);

		inquiry.changeProgress(Collections.singletonList(saleId), "UNCONFIRMED");

		assertEquals("UNCONFIRMED", progress(saleId));
		assertEquals(0, confirmed.compareTo(stock(fixture)));
	}

	/** 선택삭제는 재고를 되돌리고 전표를 지운다. 신규 이력은 남기고 취소 이력과 취소 수불을 추가한다.
	 *  選択削除は在庫を戻して伝票を消す。新規履歴は残し、取消履歴と取消受払を追加する。 */
	@Test
	@Transactional
	public void testDeleteRestoresStockAndKeepsHistory() {
		SaleInputOneFixture fixture = prepared();
		SaleInputOneDTO sale = fixture.newSale();
		saleInput.register(sale);
		Long saleId = sale.getHeader().getSaleId();
		inquiry.changeProgress(Collections.singletonList(saleId), "CONFIRMED");

		inquiry.deleteSelected(Collections.singletonList(saleId));

		assertEquals(0, new BigDecimal("100").compareTo(stock(fixture)));
		assertEquals(Integer.valueOf(0), jdbc().queryForObject("SELECT COUNT(*) FROM tb_sale WHERE sale_id = ?",
				Integer.class, saleId));
		assertEquals(Integer.valueOf(1), countHistory(saleId, "CREATE"));
		assertEquals(Integer.valueOf(1), countHistory(saleId, "CANCEL"));
		assertEquals(Integer.valueOf(1), countMovement(saleId, "SALE_CANCEL"));
	}

	/** 전표를 지운 뒤에도 신규, 삭제 이력에 거래처와 품목이 남는다.
	 *  伝票を消したあとも新規、削除の履歴に取引先と品目が残る。 */
	@Test
	@Transactional
	public void testHistoryKeepsSlipAfterDelete() {
		SaleInputOneFixture fixture = prepared();
		SaleInputOneDTO sale = fixture.newSale();
		saleInput.register(sale);
		Long saleId = sale.getHeader().getSaleId();

		VoucherHistoryDTO created = historyRow(inquiry.searchHistory(day(-30), day(30), "NORMAL", null, null), saleId,
				"新規");
		assertEquals("테스트거래처", created.getPartnerName());
		assertEquals("未確認", created.getProgressName());

		inquiry.deleteSelected(Collections.singletonList(saleId));

		java.util.List<VoucherHistoryDTO> rows = inquiry.searchHistory(null, null, null, saleId, null);
		VoucherHistoryDTO deleted = historyRow(rows, saleId, "削除");
		assertEquals("테스트거래처", deleted.getPartnerName());
		assertTrue(deleted.getItemName().contains("테스트품목"));
		assertNotNull(historyRow(rows, saleId, "新規"));
	}

	/** 이력 H는 작업자 GUEST, 작업일시, 진행상태, 상태를 시간순으로 남긴다. 지운 전표도 저장해 둔 일자-No를 쓴다.
	 *  履歴 H は作業者 GUEST、作業日時、進行状態、状態を時刻順で残す。消した伝票も保存しておいた日付-Noを使う。 */
	@Test
	@Transactional
	public void testSlipHistoryKeepsTimeProgressAndAction() {
		SaleInputOneFixture fixture = prepared();
		SaleInputOneDTO sale = fixture.newSale();
		saleInput.register(sale);
		Long saleId = sale.getHeader().getSaleId();

		SaleSlipHistoryLineDTO created = slipLine(inquiry.slipHistory(saleId), "新規");
		assertEquals("GUEST", created.getWorkerName());
		assertEquals("未確認", created.getProgressName());
		assertTrue(created.getWorkedAt().matches("\\d{4}/\\d{2}/\\d{2} 오[전후] \\d{1,2}:\\d{2}:\\d{2}"));

		inquiry.changeProgress(Collections.singletonList(saleId), "CONFIRMED");
		SaleSlipHistoryLineDTO confirmed = slipLine(inquiry.slipHistory(saleId), "確認");
		assertEquals("確認", confirmed.getProgressName());

		String shown = find(saleId).getDateNo();
		inquiry.deleteSelected(Collections.singletonList(saleId));
		SaleSlipHistoryDTO deletedPage = inquiry.slipHistory(saleId);
		assertEquals(shown, deletedPage.getDateNo());
		SaleSlipHistoryLineDTO deleted = slipLine(deletedPage, "削除");
		assertEquals("確認", deleted.getProgressName());
		assertNotNull(slipLine(deletedPage, "新規"));
	}

	/** 시작일이 종료일보다 늦으면 조회하지 않는다. 開始日が終了日より遅ければ照会しない。 */
	@Test
	public void testFromAfterToDoesNotSearch() {
		try {
			inquiry.search(day(1), day(-1), "ALL", null, 1);
			fail("시작일이 종료일보다 늦으면 조회되면 안 된다.");
		} catch (IllegalArgumentException e) {
			assertEquals("開始日が終了日より後です。", e.getMessage());
		}
	}

	private SaleSlipHistoryLineDTO slipLine(SaleSlipHistoryDTO page, String actionName) {
		for (SaleSlipHistoryLineDTO row : page.getRows()) {
			if (actionName.equals(row.getActionName())) {
				return row;
			}
		}
		fail(actionName + " 전표 이력이 없다.");
		return null;
	}

	private VoucherHistoryDTO historyRow(java.util.List<VoucherHistoryDTO> rows, Long saleId, String actionName) {
		for (VoucherHistoryDTO row : rows) {
			if (saleId.equals(row.getDocumentId()) && actionName.equals(row.getActionName())) {
				return row;
			}
		}
		fail(actionName + " 이력이 없다. " + saleId);
		return null;
	}

	private SaleInquiryRowDTO find(Long saleId) {
		for (SaleInquiryRowDTO row : search(dateNo(saleId)).getRows()) {
			if (saleId.equals(row.getSaleId())) {
				return row;
			}
		}
		fail("판매 " + saleId + " 가 목록에 없다.");
		return null;
	}

	private boolean contains(java.util.List<SaleInquiryRowDTO> rows, Long saleId) {
		for (SaleInquiryRowDTO row : rows) {
			if (saleId.equals(row.getSaleId())) {
				return true;
			}
		}
		return false;
	}

	private SaleInquiryPageDTO search(String keyword) {
		return inquiry.search(day(-30), day(30), "ALL", keyword, 1);
	}

	private String dateNo(Long saleId) {
		Integer no = jdbc().queryForObject(
				"SELECT COUNT(*) FROM tb_sale WHERE TRUNC(sale_date) = TRUNC(SYSDATE) AND sale_id <= ?",
				Integer.class, saleId);
		return new SimpleDateFormat("yyyy/MM/dd").format(new Date()) + "-" + no;
	}

	private int daySlipNo(String dateNo) {
		return Integer.parseInt(dateNo.substring(dateNo.lastIndexOf('-') + 1));
	}

	private Date day(int offset) {
		return Date.from(LocalDate.now().plusDays(offset).atStartOfDay(ZoneId.systemDefault()).toInstant());
	}

	private BigDecimal stock(SaleInputOneFixture fixture) {
		return jdbc().queryForObject("SELECT quantity FROM tb_inventory WHERE warehouse_id = ? AND item_id = ?",
				BigDecimal.class, fixture.getWarehouseId(), fixture.getItemId());
	}

	private String progress(Long saleId) {
		return jdbc().queryForObject("SELECT progress_status FROM tb_sale WHERE sale_id = ?", String.class, saleId);
	}

	private Integer countMovement(Long saleId, String type) {
		return jdbc().queryForObject(
				"SELECT COUNT(*) FROM tb_stock_movement WHERE reference_type = 'SALE' AND reference_id = ? AND movement_type = ?",
				Integer.class, saleId, type);
	}

	private Integer countHistory(Long saleId, String action) {
		return jdbc().queryForObject(
				"SELECT COUNT(*) FROM tb_voucher_history WHERE document_type = 'SALE' AND document_id = ? AND action_type = ?",
				Integer.class, saleId, action);
	}

	private JdbcTemplate jdbc() {
		return new JdbcTemplate(dataSource);
	}

	private SaleInputOneFixture prepared() {
		SaleInputOneFixture fixture = new SaleInputOneFixture(dataSource);
		fixture.prepare();
		return fixture;
	}
}
