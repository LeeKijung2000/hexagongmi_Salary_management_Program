package org.sales.sale.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.math.BigDecimal;

import javax.sql.DataSource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.sales.sale.dao.CommonLookupDao;
import org.sales.sale.SaleInputOneFixture;
import org.sales.sale.dto.SaleCurrDTO;
import org.sales.sale.dto.SaleCurrItemDTO;
import org.sales.sale.dto.SaleInputOneDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

/**
 * 판매입력1 Dao. 헤더 저장과 조회, 수정, 삭제, 그리고 화면 품목이 판매 스냅에만 남는지를 본다.
 * 販売入力1 Dao。ヘッダの保存と照会、修正、削除、そして画面の品目が販売スナップだけに残るかを見る。
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class SaleInputOneDaoTests {

	@Setter(onMethod_ = @Autowired)
	private SaleInputOneDao dao;

	@Setter(onMethod_ = @Autowired)
	private CommonLookupDao commonLookupDao;

	@Setter(onMethod_ = @Autowired)
	private DataSource dataSource;

	/** 판매입력1 Dao가 스프링에 올라와 있는지 확인한다. 販売入力1 Daoがスプリングに載っているか確かめる。 */
	@Test
	public void testExist() {
		log.info(dao);
		assertNotNull(dao);
	}

	/** 사용 중인 통화 목록을 읽는다. 使用中の通貨一覧を読む。 */
	@Test
	public void testSelectCurrencies() {
		commonLookupDao.selectCurrencies().forEach(currency -> log.info(currency));
	}

	/** 보류 목록 조회가 예외 없이 끝나는지 본다. 保留一覧の照会が例外なく終わるか見る。 */
	@Test
	public void testSelectHolds() {
		dao.selectHolds().forEach(hold -> log.info(hold));
	}

	/** 헤더를 넣으면 정상, 미확인으로 다시 읽힌다. ヘッダを入れると正常、未確認で読み直される。 */
	@Test
	@Transactional
	public void testInsert() {
		SaleInputOneFixture fixture = prepared();
		SaleCurrDTO header = fixture.newSale().getHeader();
		header.setSaleId(dao.nextSaleId());
		header.setCurrAmt(BigDecimal.ZERO);
		header.setVatAmt(BigDecimal.ZERO);
		header.setExchangeRate(BigDecimal.ONE);
		header.setVoucherStatus("正常");
		header.setProgressStatus("未確認");
		header.setSaleType("付加税率適用");

		dao.insertSale(header);

		SaleCurrDTO saved = dao.selectSale(header.getSaleId());
		log.info(saved);
		assertNotNull(saved);
		assertEquals(header.getSaleId(), saved.getSaleId());
		assertEquals("正常", saved.getVoucherStatus());
		assertEquals("未確認", saved.getProgressStatus());
	}

	/** 헤더와 품목 한 줄을 넣어 다시 읽는다. ヘッダと品目1行を入れて読み直す。 */
	@Test
	@Transactional
	public void testRead() {
		Long saleId = insertSale(prepared());

		log.info(dao.selectSale(saleId));
		dao.selectItems(saleId).forEach(item -> log.info(item));
		assertEquals(1, dao.selectItems(saleId).size());
	}

	/** 적요를 고치면 그 값이 헤더에 남는다. 摘要を直すとその値がヘッダに残る。 */
	@Test
	@Transactional
	public void testUpdate() {
		SaleInputOneFixture fixture = prepared();
		Long saleId = insertSale(fixture);
		SaleCurrDTO header = dao.selectSale(saleId);
		header.setRemark("수정");
		header.setCurrAmt(new BigDecimal("2000"));
		header.setVatAmt(new BigDecimal("200"));
		header.setExchangeRate(BigDecimal.ONE);

		assertEquals(1, dao.updateSale(header));
		log.info(dao.selectSale(saleId));
		assertEquals("수정", dao.selectSale(saleId).getRemark());
	}

	/** 품목과 헤더를 지우면 그 전표는 조회되지 않는다. 品目とヘッダを消すとその伝票は照会されない。 */
	@Test
	@Transactional
	public void testDelete() {
		Long saleId = insertSale(prepared());

		dao.deleteItemsBySaleId(saleId);
		dao.deleteSale(saleId);
		log.info(dao.selectSale(saleId));
		assertEquals(null, dao.selectSale(saleId));
	}

	/** 화면 품목코드, 품목명, 규격은 판매 줄에 저장되고 품목 마스터는 바뀌지 않는다.
	 *  画面の品目コード、品目名、規格は販売行に保存され、品目マスタは変わらない。 */
	@Test
	@Transactional
	public void testInsertKeepsTypedItemSnap() {
		SaleInputOneFixture fixture = prepared();
		JdbcTemplate jdbc = new JdbcTemplate(dataSource);
		String masterCode = jdbc.queryForObject("SELECT item_code FROM tb_item WHERE item_id = ?", String.class,
				fixture.getItemId());
		String masterName = jdbc.queryForObject("SELECT item_name FROM tb_item WHERE item_id = ?", String.class,
				fixture.getItemId());

		SaleInputOneDTO sale = fixture.newSale();
		SaleCurrDTO header = sale.getHeader();
		header.setSaleId(dao.nextSaleId());
		header.setCurrAmt(new BigDecimal("2000"));
		header.setVatAmt(new BigDecimal("200"));
		header.setExchangeRate(BigDecimal.ONE);
		header.setVoucherStatus("正常");
		header.setProgressStatus("未確認");
		header.setSaleType("付加税率適用");
		dao.insertSale(header);

		SaleCurrItemDTO line = sale.getItems().get(0);
		line.setItemId(dao.nextItemId());
		line.setSaleId(header.getSaleId());
		line.setItemCode("화면코드");
		line.setItemNm("화면품목명");
		line.setSpec("화면규격");
		dao.insertItem(line);

		SaleCurrItemDTO saved = dao.selectItems(header.getSaleId()).get(0);
		assertEquals("화면코드", saved.getItemCode());
		assertEquals("화면품목명", saved.getItemNm());
		assertEquals("화면규격", saved.getSpec());
		assertEquals(masterCode, jdbc.queryForObject("SELECT item_code FROM tb_item WHERE item_id = ?", String.class,
				fixture.getItemId()));
		assertEquals(masterName, jdbc.queryForObject("SELECT item_name FROM tb_item WHERE item_id = ?", String.class,
				fixture.getItemId()));
	}

	private SaleInputOneFixture prepared() {
		SaleInputOneFixture fixture = new SaleInputOneFixture(dataSource);
		fixture.prepare();
		return fixture;
	}

	private Long insertSale(SaleInputOneFixture fixture) {
		SaleInputOneDTO sale = fixture.newSale();
		SaleCurrDTO header = sale.getHeader();
		header.setSaleId(dao.nextSaleId());
		header.setCurrAmt(new BigDecimal("2000"));
		header.setVatAmt(new BigDecimal("200"));
		header.setExchangeRate(BigDecimal.ONE);
		header.setVoucherStatus("正常");
		header.setProgressStatus("未確認");
		header.setSaleType("付加税率適用");
		dao.insertSale(header);

		SaleCurrItemDTO line = sale.getItems().get(0);
		line.setItemId(dao.nextItemId());
		line.setSaleId(header.getSaleId());
		dao.insertItem(line);
		return header.getSaleId();
	}
}
