package org.sales.estimate.controller;

import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

// 견적서입력 Controller 테스트
// 見積書入力Controllerテスト
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration({ "file:src/main/webapp/WEB-INF/spring/root-context.xml",
		"file:src/main/webapp/WEB-INF/spring/appServlet/servlet-context.xml" })
public class QuotationInputControllerTests {

	@Autowired
	private WebApplicationContext context;

	private MockMvc mockMvc;

	@Before
	public void setUp() {
		mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
	}

	// 견적서입력 화면 URL 검사
	// 見積書入力画面のURL検証
	@Test
	public void testInputPage() throws Exception {
		mockMvc.perform(get("/sales/estimate/input")).andExpect(status().isOk())
				.andExpect(view().name("sales/estimate/input"));

		System.out.println("見積書入力画面への接続に成功しました");
	}

	// 통화 목록 API 검사
	// 通貨一覧APIの検証
	@Test
	public void testCurrencies() throws Exception {
		MvcResult result = mockMvc.perform(get("/sales/estimate/api/input/currencies")).andExpect(status().isOk())
				.andReturn();

		String json = result.getResponse().getContentAsString().trim();

		assertTrue(json.startsWith("["));

		System.out.println("通貨APIの照会に成功しました");
	}

	// 거래처 검색 API 검사
	// 取引先検索APIの検証
	@Test
	public void testPartnerLookup() throws Exception {
		MvcResult result = mockMvc.perform(get("/sales/estimate/api/input/lookup/partner").param("keyword", ""))
				.andExpect(status().isOk()).andReturn();

		assertTrue(result.getResponse().getContentAsString().trim().startsWith("["));

		System.out.println("取引先APIの照会に成功しました");
	}

	// 잘못된 검색 종류는 400 오류
	// 不正な検索種別にはHTTP 400を返す
	@Test
	public void testInvalidLookupType() throws Exception {
		mockMvc.perform(get("/sales/estimate/api/input/lookup/invalid")).andExpect(status().isBadRequest());

		System.out.println("不正な検索種別を正常に拒否しました");
	}

	// 필수값 없이 견적 저장 시 400 오류
	// 必須項目なしの見積書保存はHTTP 400を返す
	// 실제 견적서는 저장되지 않음
	// 実際の見積書は保存されません
	@Test
	public void testInvalidSave() throws Exception {
		mockMvc.perform(
				post("/sales/estimate/api/input/quotations").contentType(MediaType.APPLICATION_JSON).content("{}"))
				.andExpect(status().isBadRequest());

		System.out.println("不正な見積書保存を正常に拒否しました");
	}

	// 품목코드 없이 재고조회 요청
	// 品目コードなしで在庫照会を要求
	@Test
	public void testInvalidInventory() throws Exception {
		mockMvc.perform(
				post("/sales/estimate/api/input/inventory").contentType(MediaType.APPLICATION_JSON).content("{}"))
				.andExpect(status().isBadRequest());

		System.out.println("不正な在庫照会を正常に拒否しました");
	}
}
