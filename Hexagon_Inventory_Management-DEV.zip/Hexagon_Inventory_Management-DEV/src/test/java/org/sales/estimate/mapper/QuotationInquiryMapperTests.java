package org.sales.estimate.mapper;

import static org.junit.Assert.*;

import java.util.List;
import java.util.Map;

import org.junit.Assume;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.sales.estimate.domain.QuotationCriteria;
import org.sales.estimate.domain.QuotationInquiryVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

// 견적서조회 Mapper 테스트
// 見積書照会Mapperテスト
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
public class QuotationInquiryMapperTests {

	@Autowired
	private QuotationInquiryMapper mapper;

	// 견적서 목록 조회
	// 見積書一覧の取得
	@Test
	public void testGetList() {
		QuotationCriteria criteria = new QuotationCriteria();

		List<QuotationInquiryVO> list = mapper.getList(criteria);

		assertNotNull(list);

		System.out.println("見積書一覧の照会に成功しました");
		System.out.println("照会件数: " + list.size());
	}

	// 실제 견적서 상세 조회
	// 実在する見積書の詳細を取得
	@Test
	public void testGetDetail() {
		List<QuotationInquiryVO> list = mapper.getList(new QuotationCriteria());

		Assume.assumeTrue("照会対象の見積書がありません。", list != null && !list.isEmpty());

		Long quoteId = list.get(0).getQuote_id();

		Map<String, Object> header = mapper.getHeader(quoteId);

		List<Map<String, Object>> items = mapper.getItems(quoteId);

		assertNotNull(header);
		assertNotNull(items);
		assertEquals(1, mapper.countActive(quoteId));

		System.out.println("見積書詳細の照会に成功しました");
		System.out.println("見積書ID： " + quoteId);
	}

	// 견적서에 연결된 주문서 조회
	// 見積書に関連付けられた受注伝票を取得
	@Test
	public void testLinkedOrders() {
		List<QuotationInquiryVO> list = mapper.getList(new QuotationCriteria());

		Assume.assumeTrue("照会対象の見積書がありません。", list != null && !list.isEmpty());

		Long quoteId = list.get(0).getQuote_id();

		List<Map<String, Object>> orders = mapper.getLinkedOrders(quoteId);

		assertNotNull(orders);

		System.out.println("関連する受注伝票の照会に成功しました");
		System.out.println("受注伝票件数： " + orders.size());
	}
}
