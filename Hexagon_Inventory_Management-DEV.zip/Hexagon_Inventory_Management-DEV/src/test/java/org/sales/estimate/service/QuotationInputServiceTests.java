package org.sales.estimate.service;

import static org.junit.Assert.*;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.sales.estimate.domain.QuotationInputVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

// 견적서입력 Service 테스트
// 見積書入力Serviceテスト
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
public class QuotationInputServiceTests {

	@Autowired
	private QuotationInputService service;

	// 통화 목록 조회
	// 通貨一覧を取得
	@Test
	public void testGetCurrencies() {
		List<Map<String, Object>> result = service.getCurrencies();

		assertNotNull(result);

		System.out.println("Serviceの通貨照会に成功しました");
	}

	// 거래처 기준정보 조회
	// 取引先マスター情報を取得
	@Test
	public void testSearchPartner() {
		List<Map<String, Object>> result = service.searchLookup("partner", "");

		assertNotNull(result);

		System.out.println("Serviceの取引先照会に成功しました");
	}

	// 잘못된 기준정보 조회 구분 검사
	// 不正なマスター検索種別を検証
	@Test(expected = IllegalArgumentException.class)
	public void testInvalidLookupType() {
		service.searchLookup("invalid", "");
	}

	// 품목이 없는 재고조회 차단
	// 品目が空の在庫照会を拒否
	@Test(expected = IllegalArgumentException.class)
	public void testEmptyInventoryItems() {
		service.loadInventory(Collections.<String>emptyList(), "");
	}

	// 견적서 데이터가 없는 저장 요청 차단
	// 見積書データがない保存要求を拒否
	@Test(expected = IllegalArgumentException.class)
	public void testSaveNullQuotation() {
		service.saveQuotation(null);
	}

	// 견적일자가 없는 저장 요청 차단
	// 見積日がない保存要求を拒否
	@Test(expected = IllegalArgumentException.class)
	public void testSaveWithoutDate() {
		QuotationInputVO vo = new QuotationInputVO();

		service.saveQuotation(vo);
	}
}
