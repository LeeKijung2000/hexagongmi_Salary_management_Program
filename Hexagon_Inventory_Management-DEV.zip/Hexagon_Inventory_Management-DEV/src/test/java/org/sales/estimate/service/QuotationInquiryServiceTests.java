package org.sales.estimate.service;

import static org.junit.Assert.*;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.junit.Assume;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.sales.estimate.domain.QuotationCriteria;
import org.sales.estimate.domain.QuotationInquiryVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

// 견적서조회 Service 테스트
// 見積書照会Serviceテスト
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
public class QuotationInquiryServiceTests {

	@Autowired
	private QuotationInquiryService service;

	// 견적서 목록 조회
	// 見積書一覧の取得
	@Test
	public void testGetList() {
		QuotationCriteria criteria = new QuotationCriteria();

		List<QuotationInquiryVO> list = service.getList(criteria);

		assertNotNull(list);

		System.out.println("Serviceの見積書一覧照会に成功しました");
		System.out.println("照会件数: " + list.size());
	}

	// 견적서 상세 및 품목 조회
	// 見積書の詳細情報と品目を取得
	@Test
	public void testGetDetail() {
		List<QuotationInquiryVO> list = service.getList(new QuotationCriteria());

		Assume.assumeTrue("照会対象の見積書がありません。", list != null && !list.isEmpty());

		Long id = list.get(0).getQuote_id();

		Map<String, Object> detail = service.getDetail(id);

		assertNotNull(detail);
		assertNotNull(detail.get("header"));
		assertNotNull(detail.get("items"));

		System.out.println("Serviceの詳細照会に成功しました");
	}

	// 생성한 전표 조회
	// 作成済み伝票の照会
	@Test
	public void testGeneratedOrders() {
		List<QuotationInquiryVO> list = service.getList(new QuotationCriteria());

		Assume.assumeTrue("照会対象の見積書がありません。", list != null && !list.isEmpty());

		Long id = list.get(0).getQuote_id();

		Map<String, Object> result = service.getGeneratedOrders(id);

		assertNotNull(result);
		assertNotNull(result.get("orders"));
		assertNotNull(result.get("items"));

		System.out.println("Serviceの作成済み伝票照会に成功しました");
	}

	// 잘못된 기준정보 검색 구분 차단
	// 不正なマスター検索種別を拒否
	@Test(expected = IllegalArgumentException.class)
	public void testInvalidMasterType() {
		service.searchMaster("invalid", "");
	}

	// 선택하지 않고 삭제 요청 시 차단
	// 未選択での削除要求を拒否
	// 실제 삭제는 실행되지 않음
	// 実際の削除は実行されません
	@Test(expected = IllegalArgumentException.class)
	public void testCancelWithoutSelection() {
		service.cancelSelected(Collections.<Long>emptyList());
	}
}
