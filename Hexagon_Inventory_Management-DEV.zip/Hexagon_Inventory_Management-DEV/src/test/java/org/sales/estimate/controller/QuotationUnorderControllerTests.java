package org.sales.estimate.controller;

import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

// 미주문견적서 Controller 테스트
// 未受注見積書Controllerテスト
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration({ "file:src/main/webapp/WEB-INF/spring/root-context.xml",
		"file:src/main/webapp/WEB-INF/spring/appServlet/servlet-context.xml" })
public class QuotationUnorderControllerTests {

	@Autowired
	private WebApplicationContext context;

	private MockMvc mockMvc;

	@Before
	public void setUp() {
		mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
	}

	// 미주문견적서 화면 URL 검사
	// 未受注見積書画面のURL検証
	@Test
	public void testUnorderPage() throws Exception {
		mockMvc.perform(get("/sales/estimate/unorder")).andExpect(status().isOk())
				.andExpect(view().name("sales/estimate/unorder"));

		System.out.println("未受注見積書画面への接続に成功しました");
	}

	// 미주문견적서 목록 API 검사
	// 未受注見積書一覧APIの検証
	@Test
	public void testUnorderList() throws Exception {
		MvcResult result = mockMvc.perform(get("/sales/estimate/api/unordered").param("base_date", "2026-12-31"))
				.andExpect(status().isOk()).andReturn();

		assertTrue(result.getResponse().getContentAsString().trim().startsWith("["));

		System.out.println("未受注見積書APIの照会に成功しました");
	}

	// 잘못된 기준일자 검사
	// 不正な基準日の検証
	@Test
	public void testInvalidDate() throws Exception {
		mockMvc.perform(get("/sales/estimate/api/unordered").param("base_date", "2026-02-30"))
				.andExpect(status().isBadRequest());

		System.out.println("不正な基準日を正常に拒否しました");
	}

	// 음수 미주문수량 차단
	// マイナスの未受注数量を拒否
	@Test
	public void testNegativeQuantity() throws Exception {
		mockMvc.perform(get("/sales/estimate/api/unordered").param("min_unordered_qty", "-1"))
				.andExpect(status().isBadRequest());

		System.out.println("負の数量を正常に拒否しました");
	}

	// 최소수량이 최대수량보다 클 때
	// 最小数量が最大数量より大きい場合
	@Test
	public void testInvalidQuantityRange() throws Exception {
		mockMvc.perform(
				get("/sales/estimate/api/unordered").param("min_unordered_qty", "100").param("max_unordered_qty", "10"))
				.andExpect(status().isBadRequest());

		System.out.println("数量範囲の不正値を正常に拒否しました");
	}

	// 잘못된 진행상태 검색
	// 不正な進捗状態による検索
	@Test
	public void testInvalidProgressStatus() throws Exception {
		mockMvc.perform(get("/sales/estimate/api/unordered").param("progress_status", "INVALID"))
				.andExpect(status().isBadRequest());

		System.out.println("進捗状態の不正値を正常に拒否しました");
	}
}
