package org.sales.estimate.controller;

import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.util.List;

import org.junit.Assume;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.sales.estimate.domain.QuotationCriteria;
import org.sales.estimate.domain.QuotationInquiryVO;
import org.sales.estimate.service.QuotationInquiryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

// 견적서조회 Controller 테스트
// 見積書照会Controllerテスト
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration({ "file:src/main/webapp/WEB-INF/spring/root-context.xml",
		"file:src/main/webapp/WEB-INF/spring/appServlet/servlet-context.xml" })
public class QuotationInquiryControllerTests {

	@Autowired
	private WebApplicationContext context;

	@Autowired
	private QuotationInquiryService service;

	private MockMvc mockMvc;

	@Before
	public void setUp() {
		mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
	}

	// 견적서조회 화면 URL 검사
	// 見積書照会画面のURL検証
	@Test
	public void testInquiryPage() throws Exception {
		mockMvc.perform(get("/sales/estimate/inquiry")).andExpect(status().isOk())
				.andExpect(view().name("sales/estimate/inquiry"));

		System.out.println("見積書照会画面への接続に成功しました");
	}

	// 견적서 목록 API 검사
	// 見積書一覧APIの検証
	@Test
	public void testQuotationList() throws Exception {
		MvcResult result = mockMvc.perform(
				get("/sales/estimate/api/quotations").param("startDate", "2026-01-01").param("endDate", "2026-12-31"))
				.andExpect(status().isOk()).andReturn();

		assertTrue(result.getResponse().getContentAsString().trim().startsWith("["));

		System.out.println("見積書一覧APIの照会に成功しました");
	}

	// 견적서 상세정보 API 검사
	// 見積書詳細情報APIの検証
	@Test
	public void testQuotationDetail() throws Exception {
		List<QuotationInquiryVO> list = service.getList(new QuotationCriteria());

		Assume.assumeTrue("照会対象の見積書がありません。", list != null && !list.isEmpty());

		Long id = list.get(0).getQuote_id();

		MvcResult result = mockMvc.perform(get("/sales/estimate/api/quotations/" + id + "/detail"))
				.andExpect(status().isOk()).andReturn();

		assertTrue(result.getResponse().getContentAsString().contains("\"header\""));

		System.out.println("見積書詳細APIの照会に成功しました");
	}

	// 생성한 전표 조회 API 검사
	// 作成済み伝票照会APIの検証
	@Test
	public void testGeneratedOrders() throws Exception {
		List<QuotationInquiryVO> list = service.getList(new QuotationCriteria());

		Assume.assumeTrue("照会対象の見積書がありません。", list != null && !list.isEmpty());

		Long id = list.get(0).getQuote_id();

		MvcResult result = mockMvc.perform(get("/sales/estimate/api/quotations/" + id + "/orders"))
				.andExpect(status().isOk()).andReturn();

		assertTrue(result.getResponse().getContentAsString().contains("\"orders\""));

		System.out.println("作成済み伝票APIの照会に成功しました");
	}

	// 올바르지 않은 상태값은 400 오류
	// 不正な状態値にはHTTP 400を返す
	// 실제 견적서 상태는 변경되지 않음
	// 実際の見積書の状態は変更されません
	@Test
	public void testInvalidStatus() throws Exception {
		mockMvc.perform(put("/sales/estimate/api/quotations/1/status").contentType(MediaType.APPLICATION_JSON)
				.content("{\"status\":\"INVALID\"}")).andExpect(status().isBadRequest());

		System.out.println("不正な進捗状態を正常に拒否しました");
	}

	// 상태값 누락도 400 오류
	// 状態値が未指定の場合もHTTP 400を返す
	@Test
	public void testMissingStatus() throws Exception {
		mockMvc.perform(
				put("/sales/estimate/api/quotations/1/status").contentType(MediaType.APPLICATION_JSON).content("{}"))
				.andExpect(status().isBadRequest());

		System.out.println("進捗状態の未指定を正常に拒否しました");
	}
}
