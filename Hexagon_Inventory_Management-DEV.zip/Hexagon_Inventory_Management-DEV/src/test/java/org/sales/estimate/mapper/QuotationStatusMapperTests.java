package org.sales.estimate.mapper;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.sales.estimate.domain.QuotationCriteria;
import org.sales.estimate.domain.QuotationStatusVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

// 견적서현황 Mapper 테스트
// 見積書現況Mapperテスト
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
public class QuotationStatusMapperTests {

	@Autowired
	private QuotationStatusMapper mapper;

	// 견적서현황 전체 조회
	// 見積書現況一覧を取得
	@Test
	public void testGetStatusList() {
		QuotationCriteria criteria = new QuotationCriteria();

		List<QuotationStatusVO> list = mapper.getStatusList(criteria);

		assertNotNull(list);

		System.out.println("見積状況の照会に成功しました");
		System.out.println("照会件数: " + list.size());
	}

	// 진행상태 OPEN 검색
	// 進捗状態OPENで検索
	@Test
	public void testGetOpenStatus() {
		QuotationCriteria criteria = new QuotationCriteria();

		criteria.setProgress_status("OPEN");

		List<QuotationStatusVO> list = mapper.getStatusList(criteria);

		assertNotNull(list);

		// 검색 결과는 모두 OPEN 상태여야 함
		// 検索結果の進捗状態はすべてOPENであること
		for (QuotationStatusVO vo : list) {
			assertEquals("OPEN", vo.getProgress_status());
		}

		System.out.println("進行中の見積書の照会に成功しました");
	}

	// 특정 기간의 견적서현황 조회
	// 指定期間の見積書現況を取得
	@Test
	public void testGetStatusByDate() {
		QuotationCriteria criteria = new QuotationCriteria();

		criteria.setStart_date("2026-01-01");
		criteria.setEnd_date("2026-12-31");

		List<QuotationStatusVO> list = mapper.getStatusList(criteria);

		assertNotNull(list);

		System.out.println("期間別の見積状況の照会に成功しました");
	}
}
