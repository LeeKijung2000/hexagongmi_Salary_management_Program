package org.sales.estimate.controller;

import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

// 견적서현황 Controller 테스트
// 見積書現況Controllerテスト
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration({ "file:src/main/webapp/WEB-INF/spring/root-context.xml",
		"file:src/main/webapp/WEB-INF/spring/appServlet/servlet-context.xml" })
public class QuotationStatusControllerTests {

	@Autowired
	private WebApplicationContext context;

	private MockMvc mockMvc;

	@Before
	public void setUp() {
		mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
	}

	// 견적서현황 화면 URL 검사
	// 見積書現況画面のURL検証
	@Test
	public void testStatusPage() throws Exception {
		mockMvc.perform(get("/sales/estimate/status")).andExpect(status().isOk())
				.andExpect(view().name("sales/estimate/status"));

		System.out.println("見積状況画面への接続に成功しました");
	}

	// 견적서현황 목록 API 검사
	// 見積書現況一覧APIの検証
	@Test
	public void testStatusList() throws Exception {
		MvcResult result = mockMvc.perform(
				get("/sales/estimate/api/status").param("start_date", "2026-01-01").param("end_date", "2026-12-31"))
				.andExpect(status().isOk()).andReturn();

		assertTrue(result.getResponse().getContentAsString().trim().startsWith("["));

		System.out.println("見積状況APIの照会に成功しました");
	}

	// 잘못된 날짜 입력
	// 不正な日付の入力
	@Test
	public void testInvalidDate() throws Exception {
		mockMvc.perform(get("/sales/estimate/api/status").param("start_date", "2026-02-30"))
				.andExpect(status().isBadRequest());

		System.out.println("不正な日付を正常に拒否しました");
	}

	// 시작일이 종료일보다 늦은 경우
	// 開始日が終了日より後の場合
	@Test
	public void testReverseDateRange() throws Exception {
		mockMvc.perform(
				get("/sales/estimate/api/status").param("start_date", "2026-12-31").param("end_date", "2026-01-01"))
				.andExpect(status().isBadRequest());

		System.out.println("不正な期間を正常に拒否しました");
	}

	// 잘못된 진행상태
	// 不正な進捗状態
	@Test
	public void testInvalidStatus() throws Exception {
		mockMvc.perform(get("/sales/estimate/api/status").param("progress_status", "INVALID"))
				.andExpect(status().isBadRequest());

		System.out.println("進捗状態の不正値を正常に拒否しました");
	}
}
