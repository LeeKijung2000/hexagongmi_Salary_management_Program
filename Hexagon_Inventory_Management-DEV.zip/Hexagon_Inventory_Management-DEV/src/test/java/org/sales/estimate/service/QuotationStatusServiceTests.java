package org.sales.estimate.service;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.sales.estimate.domain.QuotationCriteria;
import org.sales.estimate.domain.QuotationStatusVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

// 견적서현황 Service 테스트
// 見積書現況Serviceテスト
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
public class QuotationStatusServiceTests {

	@Autowired
	private QuotationStatusService service;

	// 견적서현황 조회
	// 見積書現況を取得
	@Test
	public void testGetStatusList() {
		QuotationCriteria criteria = new QuotationCriteria();

		List<QuotationStatusVO> list = service.getStatusList(criteria);

		assertNotNull(list);

		System.out.println("Serviceの見積状況照会に成功しました");
	}

	// 정상적인 날짜 범위 검색
	// 正常な日付範囲で検索
	@Test
	public void testDateRangeSearch() {
		QuotationCriteria criteria = new QuotationCriteria();

		criteria.setStart_date("2026-01-01");
		criteria.setEnd_date("2026-12-31");

		List<QuotationStatusVO> list = service.getStatusList(criteria);

		assertNotNull(list);

		System.out.println("Serviceの期間検索に成功しました");
	}

	// 실제로 존재하지 않는 날짜 검사
	// 実在しない日付を検証
	@Test(expected = IllegalArgumentException.class)
	public void testInvalidDate() {
		QuotationCriteria criteria = new QuotationCriteria();

		criteria.setStart_date("2026-02-30");

		service.getStatusList(criteria);
	}

	// 시작일이 종료일보다 늦은 경우
	// 開始日が終了日より後の場合
	@Test(expected = IllegalArgumentException.class)
	public void testReverseDateRange() {
		QuotationCriteria criteria = new QuotationCriteria();

		criteria.setStart_date("2026-12-31");
		criteria.setEnd_date("2026-01-01");

		service.getStatusList(criteria);
	}

	// 잘못된 진행상태 검색조건 검사
	// 不正な進捗状態の検索条件を検証
	@Test(expected = IllegalArgumentException.class)
	public void testInvalidProgressStatus() {
		QuotationCriteria criteria = new QuotationCriteria();

		criteria.setProgress_status("INVALID");

		service.getStatusList(criteria);
	}
}
