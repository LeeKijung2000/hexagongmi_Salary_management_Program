package org.sales.estimate.mapper;

import static org.junit.Assert.*;

import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

// 견적서입력 Mapper 테스트
// 見積書入力Mapperテスト
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
public class QuotationInputMapperTests {

	@Autowired
	private QuotationInputMapper mapper;

	// Mapper가 Spring에 등록되었는지 확인
	// MapperがSpringに登録されているか確認
	@Test
	public void testMapperConnection() {
		assertNotNull(mapper);
		System.out.println("見積書入力Mapperへの接続に成功しました");
	}

	// Oracle 통화 목록 조회
	// Oracleの通貨一覧を取得
	@Test
	public void testGetCurrencies() {
		List<Map<String, Object>> list = mapper.getCurrencies();

		assertNotNull(list);

		System.out.println("通貨照会に成功しました");
		System.out.println("通貨数： " + list.size());
	}

	// 거래처 기준정보 조회
	// 取引先マスター情報を取得
	@Test
	public void testSearchPartners() {
		List<Map<String, Object>> list = mapper.searchPartners("");

		assertNotNull(list);

		System.out.println("取引先照会に成功しました");
		System.out.println("照会件数: " + list.size());
	}

	// 품목 기준정보 조회
	// 品目マスター情報を取得
	@Test
	public void testSearchItems() {
		List<Map<String, Object>> list = mapper.searchItems("");

		assertNotNull(list);

		System.out.println("品目照会に成功しました");
		System.out.println("照会件数: " + list.size());
	}
}
