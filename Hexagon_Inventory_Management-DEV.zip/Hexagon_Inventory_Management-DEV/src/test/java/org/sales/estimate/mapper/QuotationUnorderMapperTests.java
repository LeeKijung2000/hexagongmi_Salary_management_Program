package org.sales.estimate.mapper;

import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.sales.estimate.domain.QuotationCriteria;
import org.sales.estimate.domain.QuotationUnorderVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

// 미주문견적서 Mapper 테스트
// 未受注見積書Mapperテスト
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
public class QuotationUnorderMapperTests {

	@Autowired
	private QuotationUnorderMapper mapper;

	// 미주문견적서 전체 조회
	// 未受注見積書一覧を取得
	@Test
	public void testGetUnorderList() {
		QuotationCriteria criteria = new QuotationCriteria();

		List<QuotationUnorderVO> list = mapper.getUnorderList(criteria);

		assertNotNull(list);

		System.out.println("未受注見積書の照会に成功しました");
		System.out.println("照会件数: " + list.size());
	}

	// 미주문수량 계산 검증
	// 未受注数量の計算結果を検証
	@Test
	public void testUnorderedQuantity() {
		List<QuotationUnorderVO> list = mapper.getUnorderList(new QuotationCriteria());

		assertNotNull(list);

		for (QuotationUnorderVO vo : list) {
			BigDecimal quoteQty = vo.getQuote_qty();
			BigDecimal orderedQty = vo.getOrdered_qty();
			BigDecimal unorderedQty = vo.getUnordered_qty();

			assertNotNull(quoteQty);
			assertNotNull(orderedQty);
			assertNotNull(unorderedQty);

			// 미주문수량 = 견적수량 - 주문수량
			// 未受注数量＝見積数量－受注数量
			assertEquals(0, quoteQty.subtract(orderedQty).compareTo(unorderedQty));

			// 미주문수량은 0보다 커야 함
			// 未受注数量は0より大きいこと
			assertTrue(unorderedQty.compareTo(BigDecimal.ZERO) > 0);
		}

		System.out.println("未受注数量の計算検証に成功しました");
	}

	// 기준일자 조건 조회
	// 基準日を条件に検索
	@Test
	public void testBaseDateSearch() {
		QuotationCriteria criteria = new QuotationCriteria();

		criteria.setBase_date("2026-12-31");

		List<QuotationUnorderVO> list = mapper.getUnorderList(criteria);

		assertNotNull(list);

		for (QuotationUnorderVO vo : list) {
			assertTrue(vo.getQuote_date().compareTo("2026-12-31") <= 0);
		}

		System.out.println("未受注の基準日検索に成功しました");
	}
}
