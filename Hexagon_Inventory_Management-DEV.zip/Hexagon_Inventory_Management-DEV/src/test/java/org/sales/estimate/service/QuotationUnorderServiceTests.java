package org.sales.estimate.service;

import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.sales.estimate.domain.QuotationCriteria;
import org.sales.estimate.domain.QuotationUnorderVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

// 미주문견적서 Service 테스트
// 未受注見積書Serviceテスト
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
public class QuotationUnorderServiceTests {

	@Autowired
	private QuotationUnorderService service;

	// 미주문견적서 조회
	// 未受注見積書を取得
	@Test
	public void testGetUnorderList() {
		QuotationCriteria criteria = new QuotationCriteria();

		List<QuotationUnorderVO> list = service.getUnorderList(criteria);

		assertNotNull(list);

		System.out.println("Serviceの未受注見積書照会に成功しました");
	}

	// 정상적인 최소수량 검색
	// 正常な最小数量で検索
	@Test
	public void testMinimumQuantitySearch() {
		QuotationCriteria criteria = new QuotationCriteria();

		criteria.setMin_unordered_qty(new BigDecimal("1"));

		List<QuotationUnorderVO> list = service.getUnorderList(criteria);

		assertNotNull(list);

		for (QuotationUnorderVO vo : list) {
			assertTrue(vo.getUnordered_qty().compareTo(new BigDecimal("1")) >= 0);
		}

		System.out.println("未受注の最小数量検索に成功しました");
	}

	// 잘못된 날짜
	// 不正な日付
	@Test(expected = IllegalArgumentException.class)
	public void testInvalidDate() {
		QuotationCriteria criteria = new QuotationCriteria();

		criteria.setBase_date("2026-02-30");

		service.getUnorderList(criteria);
	}

	// 미주문수량 음수 차단
	// マイナスの未受注数量を拒否
	@Test(expected = IllegalArgumentException.class)
	public void testNegativeQuantity() {
		QuotationCriteria criteria = new QuotationCriteria();

		criteria.setMin_unordered_qty(new BigDecimal("-1"));

		service.getUnorderList(criteria);
	}

	// 최소수량이 최대수량보다 큰 경우
	// 最小数量が最大数量を超える場合
	@Test(expected = IllegalArgumentException.class)
	public void testInvalidQuantityRange() {
		QuotationCriteria criteria = new QuotationCriteria();

		criteria.setMin_unordered_qty(new BigDecimal("100"));

		criteria.setMax_unordered_qty(new BigDecimal("10"));

		service.getUnorderList(criteria);
	}

	// 잘못된 진행상태
	// 不正な進捗状態
	@Test(expected = IllegalArgumentException.class)
	public void testInvalidProgressStatus() {
		QuotationCriteria criteria = new QuotationCriteria();

		criteria.setProgress_status("INVALID");

		service.getUnorderList(criteria);
	}
}
