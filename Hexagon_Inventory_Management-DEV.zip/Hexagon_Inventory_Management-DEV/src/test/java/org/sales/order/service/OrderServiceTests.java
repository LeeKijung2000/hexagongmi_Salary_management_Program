package org.sales.order.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.sales.order.domain.OrderAggResultDTO;
import org.sales.order.domain.OrderAttachVO;
import org.sales.order.domain.OrderHistoryDTO;
import org.sales.order.domain.OrderItemVO;
import org.sales.order.domain.OrderListDTO;
import org.sales.order.domain.OrderRegisterDTO;
import org.sales.order.domain.OrderStatusDTO;
import org.sales.order.domain.OrderVO;
import org.sales.order.domain.ReleaseDoneDTO;
import org.sales.order.domain.ReleaseWaitDTO;
import org.sales.order.domain.UnsoldDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j

/*
 * 주문서 서비스 테스트 클래스 受注書サービステストクラス
 */
public class OrderServiceTests {

	@Setter(onMethod_ = @Autowired)
	OrderService service;

	// 입력 서비스 테스트
	// 入力サービステスト
	public void testRegister() {

		// 1. 주문서 생성 및 값 세팅
		// 1. 受注書の生成と値セット
		OrderVO order = new OrderVO();
		order.setOrderDate(LocalDate.of(2027, 12, 25));
		order.setDueDate(LocalDate.now().plusDays(5));
		order.setBusinessPartnerId(1L);
		order.setManagerId(1L);
		order.setWarehouseId(1L);
		order.setTransactionType("Y");
		order.setCurrencyId(1L);
		order.setProgressStatus("IN_PROGRESS");
		order.setRemarks("서비스테스트 주문입니다.");

		// 2. 주문서 품목 리스트 생성 및 값 세팅
		// 2. 受注書品目リストの生成と値セット
		List<OrderItemVO> items = new ArrayList<>();
		// 첫번째 품목
		// 一番目の品目
		OrderItemVO item = new OrderItemVO();
		item.setItemId(1L);
		item.setItemNameSnap("테스트 상품");
		item.setQuantity(5L);
		item.setUnitPrice(10000L);
		item.setSupplyAmount(50000L);
		item.setVatAmount(5000L);
		item.setSpecSnap("기본");
		item.setRemarks("테스트비고");
		items.add(item);

		// 두번째 품목
		// 二番目の品目
		OrderItemVO item2 = new OrderItemVO();
		item2.setItemId(1L);
		item2.setItemNameSnap("테스트 상품2");
		item2.setQuantity(5L);
		item2.setUnitPrice(10000L);
		item2.setSupplyAmount(50000L);
		item2.setVatAmount(5000L);
		item2.setSpecSnap("기본2");
		item2.setRemarks("테스트비고2");
		items.add(item2);

		// 3. 주문서 및 품목 입력 테스트
		// 3. 受注書と品目入力テスト
		service.register(new OrderRegisterDTO(order, items, new ArrayList<OrderAttachVO>()));
	}

	/*
	 * 주문서 목록 조회 테스트 受注書目録照会テスト
	 */
	@Test
	public void testGetListWithPaging() {
		// 1. 검색 파라미터 맵 생성
		// 1. 検索パラメーターマップ生成
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("pageNum", 1);// 페이지 번호 ページ番号
		paramMap.put("amount", 10);// 한 페이지 당 주문서 개수 一ページの受注書の数

		paramMap.put("startDate", "2000-01-01");// 기준일자(시작) 基準日付（開始）
		paramMap.put("endDate", "2030-12-31");// 기준일자(종료)基準日付（終了）
		paramMap.put("progressStatus", "확인");// 진행상태 進行状態
		paramMap.put("currencyType", "내자");// 통화 通貨
		paramMap.put("warehouseId", "1");// 창고ID 倉庫ID
		paramMap.put("businessPartnerId", "1");// 거래처ID 取引先ID
		paramMap.put("itemId", "1");// 품목ID 品目ID
		paramMap.put("dueStartDate", "2000-01-01");// 납기일자(시작) 納期日付（開始）
		paramMap.put("dueEndDate", "2030-12-31");// 납기일자(종료) 納期日付（終了）
		paramMap.put("spec", "");// 규격 規格
		paramMap.put("managerId", "1");// 담당자ID 担当者ID
		paramMap.put("businessPartnerManagerId", "");// 거래처 담당자ID 取引先担当者ID
		paramMap.put("transactionType", "Y");// 거래유형 取引類型
		paramMap.put("orderRemarks", "");// 비고 備考
		paramMap.put("itemRemarks", "");// 비고(품목) 備考（品目）
		paramMap.put("createdStartDate", "2000-01-01");// 작성일자(시작) 作成日付（開始）
		paramMap.put("createdEndDate", "2030-12-31");// 작성일자(종료) 作成日付（終了）
		paramMap.put("updatedStartDate", "2000-01-01");// 수정일자(시작) 修正日付（開始）
		paramMap.put("updatedEndDate", "2030-12-31");// 수정일자(종료) 修正日付（終了）
		paramMap.put("deletedYn", "N");// 삭제구분 削除区分
		paramMap.put("sortByUpdated", "true");// 정렬 整列

		// 2. 주문서 목록 조회 테스트
		// 2. 受注書目録照会テスト
		List<OrderListDTO> list = service.getListWithPaging(paramMap);
		for (OrderListDTO order : list) {
			System.out.println(order);
		}
	}

	/*
	 * 주문서 목록 개수 조회 테스트 受注書目録数照会テスト
	 */
	public void testGetTotalCount() {
		// 1. 검색 파라미터 맵 생성
		// 1. 検索パラメーターマップ生成
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("pageNum", 1);// 페이지 번호 ページ番号
		paramMap.put("amount", 10);// 한 페이지 당 주문서 개수 一ページの受注書の数

		paramMap.put("startDate", "2000-01-01");// 기준일자(시작) 基準日付（開始）
		paramMap.put("endDate", "2030-12-31");// 기준일자(종료)基準日付（終了）
		paramMap.put("progressStatus", "確認");// 진행상태 進行状態
		paramMap.put("currencyType", "내자");// 통화 通貨
		paramMap.put("warehouseId", "1");// 창고ID 倉庫ID
		paramMap.put("businessPartnerId", "1");// 거래처ID 取引先ID
		paramMap.put("itemId", "1");// 품목ID 品目ID
		paramMap.put("dueStartDate", "2000-01-01");// 납기일자(시작) 納期日付（開始）
		paramMap.put("dueEndDate", "2030-12-31");// 납기일자(종료) 納期日付（終了）
		paramMap.put("spec", "");// 규격 規格
		paramMap.put("managerId", "1");// 담당자ID 担当者ID
		paramMap.put("businessPartnerManagerId", "");// 거래처 담당자ID 取引先担当者ID
		paramMap.put("transactionType", "Y");// 거래유형 取引類型
		paramMap.put("orderRemarks", "");// 비고 備考
		paramMap.put("itemRemarks", "");// 비고(품목) 備考（品目）
		paramMap.put("createdStartDate", "2000-01-01");// 작성일자(시작) 作成日付（開始）
		paramMap.put("createdEndDate", "2030-12-31");// 작성일자(종료) 作成日付（終了）
		paramMap.put("updatedStartDate", "2000-01-01");// 수정일자(시작) 修正日付（開始）
		paramMap.put("updatedEndDate", "2030-12-31");// 수정일자(종료) 修正日付（終了）
		paramMap.put("deletedYn", "N");// 삭제구분 削除区分
		paramMap.put("sortByUpdated", "true");// 정렬 整列

		System.out.println(service.getTotalCount(paramMap));
	}

	// 주문서 조회
	// 受注書照会
	public void testGetOrder() {
		Long orderId = 30L;
		OrderRegisterDTO dto = service.getOrder(orderId);
		System.out.println(dto);
	}

	// 미판매현황 조회 테스트
	// 未販売一覧照会テスト
	public void testUnsoldList() {
		// 1. 검색 파라미터 맵 생성
		// 1. 検索パラメーターマップ生成
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("endDate", "2030-06-30");// 기준일자(종료)
		// paramMap.put("dueStartDate", "2026-11-01"); //납기일자(시작)
		// paramMap.put("dueEndDate", "2026-12-31"); //납기일자(종료)
		// paramMap.put("itemId", 1); //품목ID
		// paramMap.put("warehouseId", 1); //창고ID
		// paramMap.put("businessPartnerId", 1); //거래처ID
		// paramMap.put("orderRemarks", "서비스"); //주문서 비고
		// paramMap.put("itemRemarks", ""); //품목 비고
		// paramMap.put("currencyType", "내자"); //통화
		// paramMap.put("spec", "A"); //규격
		// paramMap.put("unsoldQtyFrom", "50"); //미판매수량(시작)
		// paramMap.put("unsoldQtyTo", "100"); //미판매수량(종료)
		// paramMap.put("qtyFrom", "50"); //수량(시작)
		// paramMap.put("qtyTo","100"); //수량(종료)
		paramMap.put("type", "1"); // 구분(라인별, 품목별)

		// 2. 미판매현황 조회 테스트
		// 2. 未販売一覧照会テスト
		List<UnsoldDTO> list = service.getUnsoldList(paramMap);
		for (UnsoldDTO dto : list) {
			System.out.println(dto);
		}
	}

	// 주문서현황(집계)
	// 受注書一覧（集計）
	public void testGetAggList() {
		// 1. 검색 파라미터 맵 생성
		// 1. 検索パラメーターマップ生成
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("startDate", "2026-10-01"); // 기준일자(시작) 基準日付（開始）
		paramMap.put("endDate", "2026-12-31"); // 기준일자(종료) 基準日付（終了）

		// 집계 조건
		// 集計条件
		List<String> types = new ArrayList<>();
		types.add("day");// 일별 日別
		types.add("month"); // 월별 月別
		types.add("year"); // 연도별 年度別
		types.add("partner"); // 거래처별 取引先別

		// 2. 주문서 현황(집걔) 조회
		// ２．受注書一覧（集計）照会
		OrderAggResultDTO dtos = service.getAggList(types, paramMap);
		for (Map<String, Object> dto : dtos.getList()) {
			System.out.println(dto);
		}

	}

	// 미출고 주문서 목록 조회
	// 未出庫受注書目録照会
	public void testGetReleaseWaitList() {
		// 1. 검색 파라미터 맵 생성
		// 1. 検索パラメーターマップ生成
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("startDate", "2026-06-20");// 기준일자(시작) 基準日付（開始）
		paramMap.put("endDate", "2026-06-30");// 기준일자(종료) 基準日付（終了）

		// 2. 미출고 주문서 목록 조회
		// 2. 未出庫受注書目録照会
		List<ReleaseWaitDTO> list = service.getReleaseWaitList(paramMap);
		for (ReleaseWaitDTO dto : list) {
			System.out.println(dto);
		}
	}

	// 주문서 출고 처리
	// 受注書出庫処理
	public void testRelease() {
		// 1. 주문서품목번호 맵
		// 1. 受注書品目番号マップ
		Map<Long, Double> m = new LinkedHashMap<>();
		m.put(167L, 35.0);
		m.put(166L, 35.0);
		m.put(590L, 45.0);

		// 2. 출고 처리
		// 2. 出庫処理
		service.release(m, LocalDate.now());
	}

	// 출고처리된 주문서 조회
	// 出庫処理された受注書照会
	public void testGetReleaseDoneList() {
		// 1. 검색 파라미터 맵 생성
		// 1. 検索パラメーターマップ生成
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("releaseStartDate", "2026-10-01");// 기준일자(시작) 基準日付（開始）
		paramMap.put("releaseEndDate", "2026-10-31");// 기준일자(종료) 基準日付（終了）

		// 2. 주문서 조회
		// 2. 受注書照会
		List<ReleaseDoneDTO> list = service.getReleaseDoneList(paramMap);
		for (ReleaseDoneDTO dto : list) {
			System.out.println(dto);
		}
	}

	// 주문서 현황
	// 受注書一覧
	public void testGetOrderStatus() {
		// 1. 검색 파라미터 맵 생성
		// 1. 検索パラメーターマップ生成
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("startDate", "2000-01-01");// 기준일자(시작) 基準日付（開始）
		paramMap.put("endDate", "2030-06-30");// 기준일자(종료) 基準日付（終了）
		// paramMap.put("warehouseId", 1);//창고ID 倉庫ID
		paramMap.put("businessPartnerId", 9);// 거래처ID 取引先ID
		// paramMap.put("itemId", 1);//품목ID 品目ID
		paramMap.put("currencyId", 2);// 통화유형 通貨類型
		// paramMap.put("transactionType", "N"); //거래유형 取引先類型
		// paramMap.put("spec", "m");//규격 規格
		// paramMap.put("orderRemarks", "165");//비고(주문서) 備考（受注書）
		// paramMap.put("itemRemarks", "긴급");//비고(품목) 備考（品目）
		// paramMap.put("qtyFrom", 50);//수량(시작) 数量（開始）
		// paramMap.put("qtyTo", 200);//수량(끝) 数量（終了）
		// paramMap.put("unitPriceFrom", 1);//단가(시작) 単価（開始）
		// paramMap.put("unitPriceTo", 50);//단가(끝) 単価（終了）
		// paramMap.put("vatFrom", 100);//부가세(시작) 付加税（開始）
		// paramMap.put("vatTo", 200);//부가세(끝) 付加税（終了）
		paramMap.put("progressStatus", "未確認");// 진행상태 進行状態
		paramMap.put("type", "orderItem");// 구분 区分

		// 2. 주문서 현황
		// 2. 受注書一覧
		List<OrderStatusDTO> list = service.getOrderStatus(paramMap);
		for (OrderStatusDTO dto : list) {
			System.out.println(dto);
		}
	}

	// 주문서 수정
	// 受注書修正
	public void testModify() {
		// 1. 주문서와 품목 생성 및 값 세팅
		// 1. 受注書と品目の生成と値セット
		OrderRegisterDTO dto = service.getOrder(87L);
		OrderVO order = dto.getOrder();
		order.setBusinessPartnerId(2L);

		OrderItemVO item = new OrderItemVO();
		item.setItemId(2L);
		item.setItemNameSnap("수정테스트");
		item.setOrderId(order.getOrderId());
		item.setQuantity(7L);
		item.setSupplyAmount(76L);
		item.setSpecSnap("수정 테스트");
		item.setUnitPrice(6L);
		item.setVatAmount(8787L);
		item.setRemarks("");
		dto.setOrder(order);
		dto.getItems().add(item);
		
		// 2. 주문서 수정
		// 2. 受注書修正
		service.modify(dto);

	}

	// 주문서 삭제
	// 受注書削除
	public void testRemoveAll() {
		List<Long> orderIds = new ArrayList<Long>();
		orderIds.add(305L);
		orderIds.add(304L);
		service.removeAll(orderIds);
	}

	// 진행상태 변경
	// 進行状態変更
	public void testChangeStatus() {
		List<Long> orderIds = new ArrayList<>();
		orderIds.add(51L);
		orderIds.add(52L);
		String status = "未確認";
		service.changeStatus(orderIds, status);
	}

	// 주문서 이력 조회
	// 受注書履歴照会
	public void testGetHistoryList() {
		List<OrderHistoryDTO> list = service.getHistoryList();
		for (OrderHistoryDTO dto : list) {
			System.out.println(dto);
		}
	}
}
