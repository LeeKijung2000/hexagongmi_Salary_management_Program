package org.sales.order.mapper;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.sales.order.domain.OrderHistoryDTO;
import org.sales.order.domain.OrderListDTO;
import org.sales.order.domain.OrderReleaseVO;
import org.sales.order.domain.OrderStatusDTO;
import org.sales.order.domain.OrderVO;
import org.sales.order.domain.ReleaseDoneDTO;
import org.sales.order.domain.ReleaseWaitDTO;
import org.sales.order.domain.UnsoldDTO;
import org.sales.order.domain.VoucherHistoryVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j

/*
 * 주문서 CRUD 테스트 클래스
 */
public class OrderMapperTests {

	@Setter(onMethod_ = @Autowired)
	private OrderMapper mapper;

	// 주문서 목록 조회 테스트
	public void testGetListWithPaging() {
		// 1. 검색 파라미터 맵 생성
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("pageNum", 1);// 페이지 번호
		paramMap.put("amount", 10);// 한 페이지 당 주문서 개수

		paramMap.put("startDate", "2000-01-01");// 기준일자(시작)
		paramMap.put("endDate", "2030-12-31");// 기준일자(종료)
		paramMap.put("progressStatus", "CONFIRMED");// 진행상태
		paramMap.put("currencyType", "내자");// 통화
		paramMap.put("warehousePk", "1");// 창고PK
		paramMap.put("businessPartnerId", "1");// 거래처ID
		paramMap.put("itemPk", "1");// 품목PK
		paramMap.put("dueStartDate", "2000-01-01");// 납기일자(시작)
		paramMap.put("dueEndDate", "2030-12-31");// 납기일자(종료)
		paramMap.put("spec", "");// 규격
		paramMap.put("managerId", "1");// 담당자ID
		paramMap.put("businessPartnerManagerId", "");// 거래처 담당자ID
		paramMap.put("transactionType", "Y");// 거래유형
		paramMap.put("orderRemarks", "");// 비고
		paramMap.put("itemRemarks", "");// 비고(품목)
		paramMap.put("createdStartDate", "2000-01-01");// 작성일자(시작)
		paramMap.put("createdEndDate", "2030-12-31");// 작성일자(종료)
		paramMap.put("updatedStartDate", "2000-01-01");// 수정일자(시작)
		paramMap.put("updatedEndDate", "2030-12-31");// 수정일자(종료)
		paramMap.put("deletedYn", "N");// 삭제구분
		paramMap.put("sortByUpdated", "true");// 정렬

		List<OrderListDTO> list = mapper.getListWithPaging(paramMap);
		for (OrderListDTO order : list) {
			System.out.println(order);
		}
	}

	// 주문서 목록 개수 조회 테스트
	public void testGetTotalCount() {
		// 1. 검색 파라미터 맵 생성
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("pageNum", 1);// 페이지 번호
		paramMap.put("amount", 10);// 한 페이지 당 주문서 개수

		paramMap.put("startDate", "2000-01-01");// 기준일자(시작)
		paramMap.put("endDate", "2030-12-31");// 기준일자(종료)
		paramMap.put("progressStatus", "CONFIRMED");// 진행상태
		paramMap.put("currencyType", "내자");// 통화
		paramMap.put("warehousePk", "1");// 창고PK
		paramMap.put("businessPartnerId", "1");// 거래처ID
		paramMap.put("itemPk", "1");// 품목PK
		paramMap.put("dueStartDate", "2000-01-01");// 납기일자(시작)
		paramMap.put("dueEndDate", "2030-12-31");// 납기일자(종료)
		paramMap.put("spec", "");// 규격
		paramMap.put("managerId", "1");// 담당자ID
		paramMap.put("businessPartnerManagerId", "");// 거래처 담당자ID
		paramMap.put("transactionType", "Y");// 거래유형
		paramMap.put("orderRemarks", "");// 비고
		paramMap.put("itemRemarks", "");// 비고(품목)
		paramMap.put("createdStartDate", "2000-01-01");// 작성일자(시작)
		paramMap.put("createdEndDate", "2030-12-31");// 작성일자(종료)
		paramMap.put("updatedStartDate", "2000-01-01");// 수정일자(시작)
		paramMap.put("updatedEndDate", "2030-12-31");// 수정일자(종료)
		paramMap.put("deletedYn", "N");// 삭제구분
		paramMap.put("sortByUpdated", "true");// 정렬

		System.out.println(mapper.getTotalCount(paramMap));
	}

	// 주문서 입력 테스트
	public void testInsert() {
		// 1. 주문서 생성 및 값 세팅
		OrderVO order = new OrderVO();
		order.setOrderDate(LocalDate.now());// 주문일자
		order.setDueDate(LocalDate.of(2026, 10, 5));// 납기일자
		order.setBusinessPartnerId(2L);// 거래처코드
		order.setManagerId(2L);// 담당자코드
		order.setWarehouseId(1L);// 창고PK
		order.setTransactionType("Y");// 거래유형
		order.setCurrencyId(1L);// 통화ID
		order.setProgressStatus("IN_PROGRESS");// 진행상태
		order.setRemarks("테스트비고");// 비고

		// 2. 주문서 입력 테스트
		mapper.insert(order);
		log.info("order");
	}

	// 주문서현황(현황) 테스트
	public void testGetStatusList() {
		// 1. 검색 파라미터 맵 생성
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("startDate", "2000-01-01");// 기준일자(시작)
		paramMap.put("endDate", "2030-06-30");// 기준일자(종료)
		// paramMap.put("warehouseId", 1);//창고ID
		// paramMap.put("businessPartnerId", 9);// 거래처ID
		// paramMap.put("itemId", 1);//품목ID
		// paramMap.put("currencyId", 2);// 통화유형
		// paramMap.put("transactionType", "N"); //거래유형
		// paramMap.put("spec", "m");//규격
		// paramMap.put("orderRemarks", "165");//비고(주문서)
		// paramMap.put("itemRemarks", "긴급");//비고(품목)
		// paramMap.put("qtyFrom", 50);//수량(시작)
		// paramMap.put("qtyTo", 200);//수량(끝)
		// paramMap.put("unitPriceFrom", 1);//단가(시작)
		// paramMap.put("unitPriceTo", 50);//단가(끝)
		// paramMap.put("vatFrom", 100);//부가세(시작)
		// paramMap.put("vatTo", 200);//부가세(끝)
		paramMap.put("progressStatus", "UNCONFIRMED");// 진행상태
		paramMap.put("managerId", "1");
		paramMap.put("type", "managerid");
		List<OrderStatusDTO> list = mapper.getStatusList(paramMap);
		for (OrderStatusDTO dto : list) {
			System.out.println(dto);
		}
		System.out.println(list.size());

	}

	// 주문서현황(집계) 테스트
	public void testGetAggList() {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("startDate", "2026-10-01");
		paramMap.put("endDate", "2026-12-31");

		// 집계 기준 (일별, 월별 순서로 묶음)
		paramMap.put("types", Arrays.asList("day", "month"));

		List<Map<String, Object>> list = mapper.getAggList(paramMap);
		for (Map<String, Object> row : list) {
			System.out.println(row);
		}
	}

	// 주문서 출고처리 조회 테스트
	public void testGetReleaseWaitList() {
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("startDate", "2026-06-20");
		paramMap.put("endDate", "2026-06-30");

		List<ReleaseWaitDTO> list = mapper.getReleaseWaitList(paramMap);
		for (ReleaseWaitDTO dto : list) {
			System.out.println(dto);
		}
	}

	// 미출고 수량 조회
	public void testSelectRemainQty() {
		Long orderItemId = 30L;
		Double remainQty = mapper.selectRemainQty(orderItemId);
		System.out.println(orderItemId + "の残りの数は " + remainQty);
	}

	// 주문서품목ID로 주문서ID조회
	public void testSelectOrderIdOfItem() {
		Long orderItemId = 30L;
		Long orderId = mapper.selectOrderIdOfItem(orderItemId);
		System.out.println("orderId : " + orderId);
	}

	// 주문서 헤더 출고 처리
	public void testInsertRelease() {
		OrderReleaseVO vo = new OrderReleaseVO();
		vo.setReleaseDate(LocalDate.now());
		vo.setOrderId(15L);
		vo.setRemarks("출고 처리 테스트");

		mapper.insertRelease(vo);
	}

	// 주문서 품목 출고 처리
	public void insertReleaseItem() {
		Long releaseId = 1L;
		Long orderItemId = 30L;
		Double releasedQty = 5D;
		mapper.insertReleaseItem(releaseId, orderItemId, releasedQty);
	}

	// 출고처리 완료된 목록 조회
	public void testGetReleaseDoneList() {
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("releaseStartDate", "2026-10-01");
		paramMap.put("releaseEndDate", "2026-10-31");

		List<ReleaseDoneDTO> list = mapper.getReleaseDoneList(paramMap);
		for (ReleaseDoneDTO dto : list) {
			System.out.println(dto);
		}

	}

	// 출고된 수량 조회
	public void testCountReleaseByOrder() {
		Long orderId = 15L;
		int result = mapper.countReleaseByOrder(orderId);
		System.out.println(result);
	}

	// 미판매 현황(라인별) 테스트
	public void testGetUnsoldLineList() {
		// 1. 검색 파라미터 맵 생성
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("endDate", "2030-06-30");// 기준일자(종료)
		// paramMap.put("dueStartDate", "2026-11-01");
		// paramMap.put("dueEndDate", "2026-12-31");
		/* paramMap.put("itemPk", 1); */
		// paramMap.put("warehousePk", 1);
		// paramMap.put("businessPartnerId", 1);
		// paramMap.put("orderRemarks", "서비스");
		// paramMap.put("itemRemarks", "");
		// paramMap.put("currencyType", "내자");
		// paramMap.put("spec", "A");
		// paramMap.put("unsoldQtyFrom", "50");
		// paramMap.put("unsoldQtyTo", "100");
		// paramMap.put("qtyFrom", "50");
		// paramMap.put("qtyTo","100");

		// 2. 미판매 현황(라인별) 테스트
		List<UnsoldDTO> list = mapper.getUnsoldLineList(paramMap);
		for (UnsoldDTO dto : list) {
			System.out.println(dto);
		}
	}

	// 미판매 현황(품목별) 테스트
	public void testGetUnsoldItemList() {
		// 1. 검색 파라미터 맵 생성
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("endDate", "2030-06-30");// 기준일자(종료)
		// paramMap.put("dueStartDate", "2026-11-01");
		// paramMap.put("dueEndDate", "2026-12-31");
		/* paramMap.put("itemPk", 1); */
		// paramMap.put("warehousePk", 1);
		// paramMap.put("businessPartnerId", 1);
		// paramMap.put("orderRemarks", "서비스");
		// paramMap.put("itemRemarks", "");
		// paramMap.put("currencyType", "내자");
		// paramMap.put("spec", "A");
		// paramMap.put("unsoldQtyFrom", "50");
		// paramMap.put("unsoldQtyTo", "100");
		// paramMap.put("qtyFrom", "50");
		// paramMap.put("qtyTo","100");

		// 2. 미판매 현황(품목별) 테스트
		List<UnsoldDTO> list = mapper.getUnsoldItemList(paramMap);
		for (UnsoldDTO dto : list) {
			System.out.println(dto);
		}
	}

	// 주문서 조회 테스트
	public void testGet() {
		Long orderId = 82L;
		OrderVO order = mapper.get(orderId);
		System.out.println(order);
	}

	// 주문서 수정 테스트
	public void testUpdate() {

		// 1. 주문서 생성 및 값 세팅
		OrderVO order = new OrderVO();
		order.setOrderId(82L);
		order.setOrderDate(LocalDate.of(2010, 10, 5));
		order.setDueDate(LocalDate.of(2026, 11, 5));
		order.setBusinessPartnerId(1L);
		order.setManagerId(1L);
		order.setTransactionType("N");
		order.setCurrencyId(1L);
		order.setProgressStatus("CONFIRMED");
		order.setRemarks("테스트수정수정");
		order.setWarehouseId(1L);

		// 2. 주문서 수정 테스트
		mapper.update(order);
		log.info("update");
	}

	// 주문서 삭제 테스트
	public void testDelete() {

		// 1. 주문서 ID 생성
		Long orderId = 82L;

		// 2. 주문서 삭제 테스트
		mapper.delete(orderId);
		log.info("delete");
	}

	/*
	 * public void testCountSaleLinkByOrder() { Long orderId = 30L; int result =
	 * mapper.countSaleLinkByOrder(orderId); System.out.println(result); }
	 */

	// 진행상태 변경
	public void testUpdateProgressStatus() {
		mapper.updateProgressStatus(50L, "UNCONFIRMED");
	}

	// 주문서 이력 쓰기
	public void testWriteHistory() {
		OrderVO order = mapper.get(67L);
		VoucherHistoryVO vo = new VoucherHistoryVO();
		vo.setDocumentType("SALES_ORDER");
		vo.setDocumentId(order.getOrderId());
		vo.setActionType("UPDATE");
		vo.setBeforeStatus(order.getProgressStatus());
		vo.setWorkerId(order.getManagerId());
		mapper.writeHistory(vo);
	}

	// 주문서 이력 조회
	@Test
	public void testGetHistoryList() {
		List<OrderHistoryDTO> list = mapper.getHistoryList();
		for (OrderHistoryDTO dto : list) {
			System.out.println(dto);
		}
	}

}
