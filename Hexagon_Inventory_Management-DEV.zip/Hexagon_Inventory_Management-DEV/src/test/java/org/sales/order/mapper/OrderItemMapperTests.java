package org.sales.order.mapper;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.sales.order.domain.OrderItemVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j

/*
 * 주문서 품목 CRUD 테스트 클래스
 */
public class OrderItemMapperTests {

	@Setter(onMethod_ = @Autowired)
	private OrderItemMapper mapper;

	// 주문서 품목 입력 테스트
	public void testInsert() {
		// 1. 주문서 품목 생성 및 값 세팅
		OrderItemVO orderItem = new OrderItemVO();
		orderItem.setItemId(1L);// 품목코드
		orderItem.setOrderId(1L);// 주문서ID
		orderItem.setSpecSnap("테스트 규격");// 규격
		orderItem.setItemNameSnap("테스트 아이템");// 품목명
		orderItem.setQuantity(3L);// 수량
		orderItem.setUnitPrice(5000L);// 단가
		orderItem.setSupplyAmount(15000L);// 공급가액
		orderItem.setVatAmount(1500L);// 부가세
		orderItem.setRemarks("주문 품목 입력 테스트");// 비고

		// 2. 주문서 품목 입력 테스트
		mapper.insert(orderItem);
		log.info("inesert....");
	}
	
	//주문서 품목 조회 테스트
	@Test
	public void testSelectByOrderId() {
		Long orderId = 30L;
		List<OrderItemVO> list = mapper.selectByOrderId(orderId);
		for(OrderItemVO vo : list) {
			System.out.println(vo);
		}
	}

	// 주문서 품목 수정 테스트
	public void testUpdate() {
		
		// 주문서 품목 생성 및 값 세팅
		OrderItemVO orderItem = new OrderItemVO();
		orderItem.setOrderItemId(110L);//주문서 품목 ID
		orderItem.setItemId(1L);//품목코드
		orderItem.setSpecSnap("테스트 규격 수정");//규격
		orderItem.setItemNameSnap("테스트 아이템 수정");//품목명
		orderItem.setQuantity(3L);//수량
		orderItem.setUnitPrice(5001L);//단가
		orderItem.setSupplyAmount(15001L);//공급가액
		orderItem.setVatAmount(1501L);//부가세
		orderItem.setRemarks("주문 품목 수정 테스트");//비고
		orderItem.setOrderId(55L);//주문서ID
		
		//주문서 품목 수정 테스트
		mapper.update(orderItem);
		log.info("update....");
	}

	public void testDelete() {
		Long orderItemId = 106L;
		Long orderId = 52L;
		mapper.delete(orderItemId, orderId);
		log.info("delete....");
	}

}
