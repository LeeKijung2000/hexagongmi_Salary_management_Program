package org.zerock.service;

import static org.junit.Assert.*;

import java.lang.reflect.Proxy;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.zerock.domain.Criteria;
import org.zerock.domain.ItemBulkChangeVO;
import org.zerock.domain.ItemVO;
import org.zerock.mapper.ItemMapper;

/**
 * 한국어: 품목 서비스의 CRUD, 창고·단가 동기화, 바코드 및 일괄변경 기능을 검증합니다.
 * 日本語: 商品サービスのCRUD、倉庫・単価同期、バーコード、一括変更機能を検証します。
 */
public class ItemServiceImplTest {

    private ItemMapper mapper;
    private ItemServiceImpl service;
    private ItemVO stored;
    private int deleteWarehouseCount;
    private int deletePriceCount;
    private int insertWarehouseCount;
    private int updateBarcodeCount;
    private int priceUpsertCount;
    private int updateCount;
    private int deleteCount;
    private BigDecimal capturedDecimalValue;
    private List<Long> linkedWarehouses = Collections.singletonList(3001L);

    @Before
    public void setUp() {
        mapper = (ItemMapper) Proxy.newProxyInstance(
                ItemMapper.class.getClassLoader(),
                new Class<?>[] { ItemMapper.class },
                (proxy, method, args) -> invokeMapper(method.getName(), args));
        service = new ItemServiceImpl(mapper);
    }

    private Object invokeMapper(String name, Object[] args) {
        if ("insertSelectKey".equals(name)) { stored = (ItemVO) args[0]; stored.setItemPk(4001L); return null; }
        if ("read".equals(name)) return stored;
        if ("getWarehousePks".equals(name)) return linkedWarehouses;
        if ("deleteItemWarehouses".equals(name)) { deleteWarehouseCount++; return 1; }
        if ("deleteItemPrices".equals(name)) { deletePriceCount++; return 1; }
        if ("insertItemWarehouse".equals(name)) { insertWarehouseCount++; return 1; }
        if ("upsertItemPrice".equals(name)) { priceUpsertCount++; return 1; }
        if ("updateBarcode".equals(name)) { updateBarcodeCount++; return 1; }
        if ("update".equals(name)) { updateCount++; return 1; }
        if ("delete".equals(name)) { deleteCount++; return 1; }
        if ("countByCode".equals(name) || "countByBarcode".equals(name)) return 0;
        if ("getListWithPaging".equals(name)) return stored == null ? Collections.emptyList() : Collections.singletonList(stored);
        if ("getTotalCount".equals(name)) return stored == null ? 0 : 1;
        if ("bulkModify".equals(name)) {
            ItemBulkChangeVO change = (ItemBulkChangeVO) args[1];
            capturedDecimalValue = change.getDecimalValue();
            return ((List<?>) args[0]).size();
        }
        if ("bulkAssignItemHierGroup".equals(name)) return ((List<?>) args[0]).size();
        if ("getBarcodeItems".equals(name)) return stored == null ? Collections.emptyList() : Collections.singletonList(stored);
        if ("getGroup1List".equals(name) || "getGroup2List".equals(name) || "getGroup3List".equals(name)
                || "getItemHierGroupList".equals(name) || "getHierarchyMembers".equals(name)
                || "getProdProcessList".equals(name) || "getQualityInspTypeList".equals(name)
                || "getWarehouseList".equals(name)) return Collections.emptyList();
        return null;
    }

    private ItemVO newItem() {
        return ItemVO.builder()
                .itemCode("IT-JP-01")
                .itemName("北海道たまねぎ")
                .itemDiv(0)
                .unit("袋")
                .qty(new BigDecimal("120"))
                .warehousePks(Collections.singletonList(3001L))
                .purchasePrice(new BigDecimal("800"))
                .salesPrice(new BigDecimal("1200"))
                .outsourcingPrice(new BigDecimal("1000"))
                .build();
    }

    @Test
    public void register_savesWarehousePricesAndGeneratesBarcode() {
        ItemVO item = newItem();
        service.register(item);

        assertEquals(Long.valueOf(4001L), item.getItemPk());
        assertEquals("998877664001", item.getBarcode());
        assertEquals(1, deleteWarehouseCount);
        assertEquals(1, insertWarehouseCount);
        assertEquals(3, priceUpsertCount);
        assertEquals(1, updateBarcodeCount);
    }

    @Test
    public void get_loadsWarehouseRelations() {
        stored = newItem();
        stored.setItemPk(4001L);

        ItemVO result = service.get(4001L);

        assertNotNull(result);
        assertEquals(Collections.singletonList(3001L), result.getWarehousePks());
    }

    @Test
    public void modify_updatesItemAndSynchronizesRelations() {
        ItemVO item = newItem();
        item.setItemPk(4001L);

        assertTrue(service.modify(item));
        assertEquals(1, updateCount);
        assertEquals(1, deleteWarehouseCount);
        assertEquals(1, insertWarehouseCount);
        assertEquals(3, priceUpsertCount);
    }

    @Test
    public void remove_deletesChildRelationsBeforeItem() {
        assertTrue(service.remove(4001L));
        assertEquals(1, deletePriceCount);
        assertEquals(1, deleteWarehouseCount);
        assertEquals(1, deleteCount);
    }

    @Test
    public void bulkModify_rejectsEmptySelection() {
        try {
            service.bulkModify(Collections.emptyList(), new ItemBulkChangeVO());
            fail("예외가 발생해야 합니다.");
        } catch (IllegalArgumentException expected) {
            assertEquals("변경할 품목을 선택해주세요.", expected.getMessage());
        }
    }

    @Test
    public void bulkModify_convertsDecimalInputAndDelegates() {
        ItemBulkChangeVO change = new ItemBulkChangeVO();
        change.setField("salesPrice");
        change.setTextValue("1200.50");

        int count = service.bulkModify(Arrays.asList(4001L), change);

        assertEquals(1, count);
        assertEquals(new BigDecimal("1200.50"), capturedDecimalValue);
    }

    @Test
    public void duplicateCodeAndBarcode_areFalseWhenMapperReturnsZero() {
        assertFalse(service.isDuplicateCode("IT-JP-01", null));
        assertFalse(service.isDuplicateBarcode("4988000000012", null));
    }

    @Test
    public void listAndTotal_delegateToMapper() {
        ItemVO item = newItem();
        service.register(item);
        Criteria criteria = new Criteria(1, 20);

        assertEquals(1, service.getList(criteria).size());
        assertEquals(1, service.getTotal(criteria));
    }
}
