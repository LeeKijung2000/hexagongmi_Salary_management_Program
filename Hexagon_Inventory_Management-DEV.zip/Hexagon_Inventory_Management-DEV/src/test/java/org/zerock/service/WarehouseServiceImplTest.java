package org.zerock.service;

import static org.junit.Assert.*;

import java.lang.reflect.Proxy;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.zerock.domain.Criteria;
import org.zerock.domain.WarehouseVO;
import org.zerock.mapper.WarehouseMapper;

/**
 * 한국어: 창고 서비스의 등록·조회·수정·삭제와 참조정보 처리를 검증합니다.
 * 日本語: 倉庫サービスの登録・取得・更新・削除と参照情報処理を検証します。
 */
public class WarehouseServiceImplTest {

    private WarehouseMapper mapper;
    private WarehouseServiceImpl service;
    private WarehouseVO stored;
    private int updateCount;
    private int deleteCount;
    private int inventoryCount;
    private int processLookupCount;
    private int partnerLookupCount;

    @Before
    public void setUp() {
        mapper = (WarehouseMapper) Proxy.newProxyInstance(
                WarehouseMapper.class.getClassLoader(),
                new Class<?>[] { WarehouseMapper.class },
                (proxy, method, args) -> invokeMapper(method.getName(), args));
        service = new WarehouseServiceImpl(mapper);
    }

    private Object invokeMapper(String name, Object[] args) {
        if ("findProdProcessIdByName".equals(name)) return ++processLookupCount == 1 ? null : 5001L;
        if ("findOutsourcePartnerIdByName".equals(name)) return ++partnerLookupCount == 1 ? null : 2001L;
        if ("insertProdProcessByName".equals(name) || "insertOutsourcePartnerByName".equals(name)) return 1;
        if ("insertSelectKey".equals(name)) { stored = (WarehouseVO) args[0]; stored.setWarehousePk(3001L); return null; }
        if ("read".equals(name)) return stored;
        if ("update".equals(name)) { updateCount++; return 1; }
        if ("countInventoryItems".equals(name)) return inventoryCount;
        if ("delete".equals(name)) { deleteCount++; return 1; }
        if ("toggleUse".equals(name)) return 1;
        if ("getListWithPaging".equals(name)) return stored == null ? Collections.emptyList() : Collections.singletonList(stored);
        if ("getTotalCount".equals(name)) return stored == null ? 0 : 1;
        if ("bulkAssignHierarchyGroup".equals(name)) return ((List<?>) args[0]).size();
        if (name.startsWith("get") && List.class.isAssignableFrom(methodReturn(name))) return Collections.emptyList();
        return defaultValue(methodReturn(name));
    }

    private Class<?> methodReturn(String methodName) {
        for (java.lang.reflect.Method m : WarehouseMapper.class.getMethods()) {
            if (m.getName().equals(methodName)) return m.getReturnType();
        }
        return Object.class;
    }

    private Object defaultValue(Class<?> type) {
        if (type == int.class) return 0;
        if (type == long.class) return 0L;
        if (type == boolean.class) return false;
        return null;
    }

    @Test
    public void register_resolvesReferenceNamesBeforeInsert() {
        WarehouseVO warehouse = WarehouseVO.builder()
                .warehouseCode("WH-JP-01")
                .warehouseName("大阪物流倉庫")
                .warehouseDiv(0)
                .prodProcessName("原料受入")
                .outsourcingPartnerName("山田食品株式会社")
                .build();

        service.register(warehouse);

        assertEquals(Long.valueOf(5001L), warehouse.getProdProcessPk());
        assertEquals(Long.valueOf(2001L), warehouse.getOutsourcePartnerId());
        assertEquals(Long.valueOf(3001L), warehouse.getWarehousePk());
    }

    @Test
    public void modify_updatesWarehouse() {
        WarehouseVO warehouse = WarehouseVO.builder()
                .warehousePk(3001L).warehouseCode("WH-JP-01").warehouseName("大阪物流倉庫").warehouseDiv(0)
                .useYn("Y").build();

        assertTrue(service.modify(warehouse));
        assertEquals(1, updateCount);
    }

    @Test
    public void toggleUse_rejectsInvalidFlag() {
        try {
            service.toggleUse(3001L, "X");
            fail("예외가 발생해야 합니다.");
        } catch (IllegalArgumentException expected) {
            assertEquals("사용구분 값이 올바르지 않습니다.", expected.getMessage());
        }
    }

    @Test
    public void bulkHierarchyGroup_requiresValidGroup() {
        try {
            service.bulkAssignHierarchyGroup(Collections.singletonList(3001L), null);
            fail("예외가 발생해야 합니다.");
        } catch (IllegalArgumentException expected) {
            assertEquals("적용할 창고계층그룹을 선택해주세요.", expected.getMessage());
        }
    }

    @Test
    public void remove_returnsTrueWhenMapperDeletesOneRow() {
        assertTrue(service.remove(3001L));
        assertEquals(1, deleteCount);
    }

    @Test
    public void remove_rejectsWarehouseThatContainsItems() {
        inventoryCount = 2;
        try {
            service.remove(3001L);
            fail("품목이 들어있는 창고는 삭제되면 안 됩니다.");
        } catch (IllegalArgumentException expected) {
            assertEquals("창고에 등록된 품목이 있어 삭제할 수 없습니다. 품목을 먼저 다른 창고로 이동하거나 삭제해주세요.", expected.getMessage());
        }
        assertEquals(0, deleteCount);
    }

    @Test
    public void listAndTotal_delegateToMapper() {
        WarehouseVO warehouse = WarehouseVO.builder().warehouseCode("WH-JP-01").warehouseName("大阪物流倉庫").warehouseDiv(0).build();
        service.register(warehouse);
        Criteria criteria = new Criteria(1, 20);

        assertEquals(1, service.getList(criteria).size());
        assertEquals(1, service.getTotal(criteria));
    }
}
