package org.zerock.service;

import static org.junit.Assert.*;

import java.lang.reflect.Proxy;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.zerock.domain.BusinessPartnerVO;
import org.zerock.domain.Criteria;
import org.zerock.mapper.BusinessPartnerMapper;

/**
 * 한국어: 거래처 서비스의 핵심 CRUD와 검증 로직을 DB 없이 확인하는 단위 테스트입니다.
 * 日本語: 取引先サービスの主要CRUDと検証ロジックをDBなしで確認する単体テストです。
 */
public class BusinessPartnerServiceImplTest {

    private BusinessPartnerMapper mapper;
    private BusinessPartnerServiceImpl service;
    private BusinessPartnerVO stored;
    private int insertCount;
    private int updateCount;
    private int deleteCount;

    @Before
    public void setUp() {
        mapper = (BusinessPartnerMapper) Proxy.newProxyInstance(
                BusinessPartnerMapper.class.getClassLoader(),
                new Class<?>[] { BusinessPartnerMapper.class },
                (proxy, method, args) -> invokeMapper(method.getName(), args));
        service = new BusinessPartnerServiceImpl(mapper);
    }

    private Object invokeMapper(String name, Object[] args) {
        if ("countByCode".equals(name)) return 0;
        if ("insertSelectKey".equals(name)) {
            stored = (BusinessPartnerVO) args[0];
            stored.setBusinessPartnerId(1001L);
            insertCount++;
            return null;
        }
        if ("read".equals(name)) return stored;
        if ("update".equals(name)) { updateCount++; return 1; }
        if ("delete".equals(name)) { deleteCount++; return 1; }
        if ("getListWithPaging".equals(name)) return stored == null ? Collections.emptyList() : Arrays.asList(stored);
        if ("getTotalCount".equals(name)) return stored == null ? 0 : 1;
        if ("getHierarchyMembers".equals(name)) return Collections.<Map<String, Object>>emptyList();
        if ("bulkAssignHierarchyGroup".equals(name)) return ((List<?>) args[0]).size();
        if ("getGroup1List".equals(name) || "getGroup2List".equals(name)
                || "getSalesPriceGroupList".equals(name) || "getPurchasePriceGroupList".equals(name)
                || "getCurrencyList".equals(name) || "getManagerList".equals(name)) return null;
        return null;
    }

    private Object defaultValue(Class<?> ignored, Class<?> type) {
        if (type == int.class) return 0;
        if (type == long.class) return 0L;
        if (type == boolean.class) return false;
        if (type == void.class) return null;
        if (List.class.isAssignableFrom(type)) return Collections.emptyList();
        return null;
    }

    private BusinessPartnerVO newPartner() {
        return BusinessPartnerVO.builder()
                .businessPartnerCode("  JP-001  ")
                .businessPartnerName("  山田食品株式会社  ")
                .email("sales@example.jp")
                .creditPeriod(30)
                .build();
    }

    @Test
    public void register_assignsId_normalizesAndAppliesDefaults() {
        BusinessPartnerVO partner = newPartner();

        service.register(partner);

        assertEquals(Long.valueOf(1001L), partner.getBusinessPartnerId());
        assertEquals("JP-001", partner.getBusinessPartnerCode());
        assertEquals("山田食品株式会社", partner.getBusinessPartnerName());
        assertEquals("KRW", partner.getCurrencyCode());
        assertEquals("Y", partner.getShipmentTargetYn());
        assertEquals(1, insertCount);
    }

    @Test
    public void modify_updatesExistingPartner() {
        BusinessPartnerVO partner = newPartner();
        partner.setBusinessPartnerId(1001L);
        partner.setBusinessPartnerCode("JP-001");

        boolean result = service.modify(partner);

        assertTrue(result);
        assertEquals(1, updateCount);
    }

    @Test
    public void duplicateCode_isFalseWhenMapperReturnsZero() {
        assertFalse(service.isDuplicateCode(" JP-001 ", null));
    }

    @Test
    public void remove_rejectsMissingId() {
        try {
            service.remove(null);
            fail("예외가 발생해야 합니다.");
        } catch (IllegalArgumentException expected) {
            assertEquals("삭제할 거래처가 없습니다.", expected.getMessage());
        }
    }

    @Test
    public void listAndTotal_delegateToMapper() {
        BusinessPartnerVO partner = newPartner();
        service.register(partner);
        Criteria criteria = new Criteria(1, 20);

        assertEquals(1, service.getList(criteria).size());
        assertEquals(1, service.getTotal(criteria));
    }

    @Test
    public void bulkHierarchyGroup_requiresSelectedPartners() {
        try {
            service.bulkAssignHierarchyGroup(Collections.emptyList(), 10L);
            fail("예외가 발생해야 합니다.");
        } catch (IllegalArgumentException expected) {
            assertEquals("계층그룹을 적용할 거래처를 선택해주세요.", expected.getMessage());
        }
    }
}
